# -*- coding: utf-8 -*-
import dbg
import app
import net

import ui
import localeInfo

import sys

if app.ENABLE_LEAGUEOFLEGENDS_BONUS:
	import background
	import chat

class RestartDialog(ui.ScriptWindow):
	def __init__(self):
		ui.ScriptWindow.__init__(self)

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	if app.ENABLE_LEAGUEOFLEGENDS_BONUS:
		def __IsLeagueOfMaps(self):
			mapDict = ("summonersrift",)
			if background.GetCurrentMapName() in mapDict:
				return False
			return True

	def LoadDialog(self):
		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "uiscript/restartdialog.py")
		except Exception as msg:
			(type, msg, tb)=sys.exc_info()
			dbg.TraceError("RestartDialog.LoadDialog - %s:%s" % (type, msg))
			app.Abort()
			return 0

		try:
			self.restartHereButton=self.GetChild("restart_here_button")
			self.restartTownButton=self.GetChild("restart_town_button")
		except:
			(type, msg, tb)=sys.exc_info()
			dbg.TraceError("RestartDialog.LoadDialog - %s:%s" % (type, msg))
			app.Abort()
			return 0

		self.restartHereButton.SetEvent(ui.__mem_func__(self.RestartHere))
		self.restartTownButton.SetEvent(ui.__mem_func__(self.RestartTown))

		return 1

	def Destroy(self):
		self.restartHereButton=0
		self.restartTownButton=0
		self.ClearDictionary()
		if app.ENABLE_LEAGUEOFLEGENDS_BONUS:
			self.otoddikRefineZaman = 40
			self.otoddikRefineZaman = float(app.GetTime())

	def OpenDialog(self):
		if app.ENABLE_LEAGUEOFLEGENDS_BONUS:
			self.otoddikRefineZaman = 40
			self.otoddikRefineZaman = float(app.GetTime())
		self.Show()

	def Close(self):
		self.Hide()
		return True

	def RestartHere(self):
		if app.ENABLE_LEAGUEOFLEGENDS_BONUS:
			if not self.__IsLeagueOfMaps():
				if app.GetTime() < self.otoddikRefineZaman + 40:
					chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.WAIT_PVPMAP + str(int(app.GetTime()) - int(self.otoddikRefineZaman)) + localeInfo.WAIT_PVPMAPP)
				else:
					net.SendChatPacket("/veeehgan_twra")
			else:
				net.SendChatPacket("/veeehgan_twra")

	def RestartTown(self):
		if app.ENABLE_LEAGUEOFLEGENDS_BONUS:
			if not self.__IsLeagueOfMaps():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeInfo.KLEIDOMENO_CHA)
			else:
				net.SendChatPacket("/veeehgan_poli")

	def OnPressExitKey(self):
		return True

	def OnPressEscapeKey(self):
		return True

