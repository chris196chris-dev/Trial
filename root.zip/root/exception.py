# -*- coding: utf-8 -*-
import app
import dbg
import sys


def Abort(msg="Abort"):
    """Compatibility shim for legacy Metin2 scripts expecting exception.Abort."""
    try:
        import system
        return system.ShowException(msg)
    except Exception:
        exc_type, exc_value, _ = sys.exc_info()
        dbg.TraceError("%s - %s:%s" % (msg, getattr(exc_type, '__name__', 'Exception'), exc_value))
        app.Abort()
        return 0


def GetExceptionString(msg="Run"):
    try:
        import system
        return system.GetExceptionString(msg)
    except Exception:
        exc_type, exc_value, _ = sys.exc_info()
        return "%s - %s:%s" % (msg, getattr(exc_type, '__name__', 'Exception'), exc_value)
