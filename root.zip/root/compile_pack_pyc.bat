@echo off
setlocal
cd /d "%~dp0"
py -3.14 compile_pack_pyc.py
if errorlevel 1 (
  echo Python 3.14 compile failed or not installed, trying Python 3.12...
  py -3.12 compile_pack_pyc.py
)
pause
