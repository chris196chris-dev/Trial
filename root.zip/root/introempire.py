# -*- coding: utf-8 -*-
import ui, net, app, dbg
import localeinfo


EMPIRE_DESC_KEYS = {
	1 : (
		"EMPIRE_SHINSOO_DESC_1",
		"EMPIRE_SHINSOO_DESC_2",
		"EMPIRE_SHINSOO_DESC_3",
		"EMPIRE_SHINSOO_DESC_4",
		"EMPIRE_SHINSOO_DESC_5",
	),
	2 : (
		"EMPIRE_CHUNJO_DESC_1",
		"EMPIRE_CHUNJO_DESC_2",
		"EMPIRE_CHUNJO_DESC_3",
		"EMPIRE_CHUNJO_DESC_4",
		"EMPIRE_CHUNJO_DESC_5",
	),
	3 : (
		"EMPIRE_JINNO_DESC_1",
		"EMPIRE_JINNO_DESC_2",
		"EMPIRE_JINNO_DESC_3",
		"EMPIRE_JINNO_DESC_4",
		"EMPIRE_JINNO_DESC_5",
	),
}


class SelectEmpireWindow(ui.ScriptWindow):

	def __init__(self, stream = None):
		ui.ScriptWindow.__init__(self)
		self.stream = stream
		self.id = 1
		self.__LoadScript("sistimata/code/ui_jack_kingdom.py")
		self.ChangeEmpire("init")
				
	def __del__(self):
		ui.ScriptWindow.__del__(self)
		
	def Open(self):
		self.Show()
		app.ShowCursor()
		
	def Close(self):
		self.Hide()
		app.HideCursor()
		self.exitButton = None

	def __LoadScript(self, fileName):
		try:
			pyLoader = ui.PythonScriptLoader()
			pyLoader.LoadScriptFile(self, fileName)
		except:
			import exception
			exception.Abort("poccix_kingdom.py ## __LoadScript.LoadScriptFile")
		try:
			GetObject=self.GetChild
			self.exitButton = GetObject("exit_button")
			self.kingdom = {
				1 : self.GetChild("kingdom_01"),
				2 : self.GetChild("kingdom_02"),
				3 : self.GetChild("kingdom_03"),
			}
			self.btn_select = {
				0 : self.GetChild("btn_select_01"),
				1 : self.GetChild("btn_select_02"),
				2 : self.GetChild("btn_select_03"),
			}
			self.texts = {
				1 : {
					0 : self.GetChild("text_kingdom_01_01"),
					1 : self.GetChild("text_kingdom_01_02"),
					2 : self.GetChild("text_kingdom_01_03"),
					3 : self.GetChild("text_kingdom_01_04"),
					4 : self.GetChild("text_kingdom_01_05"),
				},
				2 : {
					0 : self.GetChild("text_kingdom_02_01"),
					1 : self.GetChild("text_kingdom_02_02"),
					2 : self.GetChild("text_kingdom_02_03"),
					3 : self.GetChild("text_kingdom_02_04"),
					4 : self.GetChild("text_kingdom_02_05"),
				},
				3 : {
					0 : self.GetChild("text_kingdom_03_01"),
					1 : self.GetChild("text_kingdom_03_02"),
					2 : self.GetChild("text_kingdom_03_03"),
					3 : self.GetChild("text_kingdom_03_04"),
					4 : self.GetChild("text_kingdom_03_05"),
				},
			}
		except:
			import exception
			exception.Abort("poccix_kingdom.py ## __LoadScript.GetChild")
		try:
			for selid in range(len(self.btn_select)):
				self.btn_select[selid].SetEvent(ui.__mem_func__(self.SelectEmpire), selid+1)
		except:
			import exception
			exception.Abort("poccix_kingdom.py ## __LoadScript.SetEvent")

		self.exitButton.SetEvent(ui.__mem_func__(self.CloseBtn))

	def ChangeEmpire(self, count):
		if count == "init":
			pass
		
		for empire, lines in self.texts.items():
			descKeys = EMPIRE_DESC_KEYS.get(empire, ())
			for i, textLine in lines.items():
				if i < len(descKeys):
					textLine.SetText(localeinfo.Get(descKeys[i]))

	def SelectEmpire(self, selid):
		self.id = selid
		net.SendSelectEmpirePacket(selid)
		self.stream.SetSelectCharacterPhase()
		
	def CloseBtn(self):
		self.stream.SetLoginPhase()
			
	def EmptyFunc(self):
		pass
	
	def OnPressExitKey(self):
		self.CloseBtn()

	def OnKeyDown(self, key):
		if key == app.DIK_ESC:
			self.stream.SetLoginPhase()

class ReselectEmpireWindow(SelectEmpireWindow):
	def SelectEmpire(self, selid):
		net.SendSelectEmpirePacket(selid)
		self.stream.SetCreateCharacterPhase()

	def CloseBtn(self):
		self.stream.SetLoginPhase()
