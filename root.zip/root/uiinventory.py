# -*- coding: utf-8 -*-
import ui
import player
import mouseModule
import net
import app
import snd
import item
import player
import chat
import grp
import uiScriptLocale
import uiRefine
import uiAttachMetin
import uiPickMoney
import uiCommon
import uiPrivateShopBuilder
import localeinfo
import constInfo
import ime
import wndMgr
if app.ENABLE_SYSTEM_METINSTONE:
	import event
	import uiToolTip

if app.ENABLE_ACCE_SYSTEM:
	import acce

ITEM_FLAG_APPLICABLE = 1 << 14

class SafeBoxInventoryWindow(ui.ScriptWindow):
	def __init__(self, wndInventory):
		import exception
		if not app.ENABLE_NEW_EQUIPMENT_SYSTEM:
			exception.Abort("What do you do?")
			return
		if not wndInventory:
			exception.Abort("wndInventory parameter must be set to InventoryWindow")
			return
		ui.ScriptWindow.__init__(self)
		self.isLoaded = 0
		self.wndInventory = wndInventory
		#MULTI_LANGUAGE
		self.titleName = None
		#MULTI_LANGUAGE
		self.__LoadWindow()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def Destroy(self):
		self.wndInventory = None

	def Show(self, openSafeBoxSlot = False):
		self.__LoadWindow()
		ui.ScriptWindow.Show(self)

		if openSafeBoxSlot:
			self.OpenSafeBox()
		else:
			self.CloseSafeBox()

		#MULTI_LANGUAGE
		#MULTI_LANGUAGE

	def Close(self):
		self.Hide()

	def OpenSafeBox(self):
		return

	def CloseSafeBox(self):
		return

	def GetBasePositionSafeBox(self):
		return 576, 346

	def AdjustPositionAndSizeSafeBox(self):
		bx, by = self.GetBasePositionSafeBox()
		self.SetPosition(bx, by)
		self.SetSize(self.ORIGINAL_WIDTH, self.GetHeight())

	def __LoadWindow(self):
		# GODMOVE_V10_INVENTORY_EQUIP_GUARD
		wndEquip = None
		if self.isLoaded == 1:
			return

		self.isLoaded = 1

		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "UIScript/SafeBoxInventoryWindow.py")
		except:
			import exception
			exception.Abort("SafeBoxWindow.LoadWindow.LoadObject")

		try:
			self.ORIGINAL_WIDTH = self.GetWidth()
			self.GetChild("TitleBar").SetCloseEvent(ui.__mem_func__(self.Close))
			#MULTI_LANGUAGE
			self.titleName = self.GetChild("TitleName")
			#MULTI_LANGUAGE
#################################################################################
			self.OpenSafeBox = self.GetChild2("SafeboxOpen")
			self.OpenItemShop = self.GetChild2("ItemShopOpen")
#################################################################################

		except:
			import exception
			exception.Abort("SafeBoxWindow.LoadWindow.BindObject")

#################################################################################
		if self.OpenSafeBox:
			self.OpenSafeBox.SetEvent(ui.__mem_func__(self._normal_mall))

		if self.OpenItemShop:
			self.OpenItemShop.SetEvent(ui.__mem_func__(self.OpenIs))
#################################################################################

#################################################################################
	def _normal_mall(self):
		activare_apothikarios_itemshop = constInfo.APOTHIKARIOS_QUESTINDEX
		event.QuestButtonClick(activare_apothikarios_itemshop)
		self.CloseSafeBox()
		self.wndInventory.CloseFixSafeBox()

	def OpenIs(self):
		activare_apothikarios = constInfo.APOTHIKARIOS_ITEMSHOP_QUESTINDEX
		event.QuestButtonClick(activare_apothikarios)
		self.CloseSafeBox()
		self.wndInventory.CloseFixSafeBox()
#################################################################################

class BeltInventoryWindow(ui.ScriptWindow):

	def __init__(self, wndInventory):
		import exception
		
		if not app.ENABLE_NEW_EQUIPMENT_SYSTEM:			
			exception.Abort("What do you do?")
			return

		if not wndInventory:
			exception.Abort("wndInventory parameter must be set to InventoryWindow")
			return						
			 	 
		ui.ScriptWindow.__init__(self)

		self.isLoaded = 0
		self.wndInventory = wndInventory
		self.wndBeltInventorySlot = None
		#MULTI_LANGUAGE
		self.titleName = None
		#MULTI_LANGUAGE

		self.__LoadWindow()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def Destroy(self):
		self.wndInventory = None

	def Show(self, openBeltSlot = False):
		self.__LoadWindow()
		self.RefreshSlot()

		ui.ScriptWindow.Show(self)

		if openBeltSlot:
			self.OpenInventory()
		else:
			self.CloseInventory()

		#MULTI_LANGUAGE
		#MULTI_LANGUAGE

	def Close(self):
		self.Hide()

	def OpenInventory(self):
		return

	def CloseInventory(self):
		return

	def GetBasePosition(self):
		x, y = self.wndInventory.GetGlobalPosition()
		return x - 140, y + 150

	def AdjustPositionAndSize(self):
		bx, by = self.GetBasePosition()
		self.SetPosition(bx, by)
		self.SetSize(self.ORIGINAL_WIDTH, self.GetHeight())

	def __LoadWindow(self):
		if self.isLoaded == 1:
			return

		self.isLoaded = 1

		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "UIScript/BeltInventoryWindow.py")
		except:
			import exception
			exception.Abort("BeltInventoryWindow.LoadWindow.LoadObject")

		try:
			self.ORIGINAL_WIDTH = self.GetWidth()
			wndBeltInventorySlot = self.GetChild("BeltInventorySlot")

			# V24: Some belt uiscripts use board_with_titlebar and do not expose
			# a direct child named TitleBar/TitleName. Missing title controls must
			# not abort enter-game loading.
			titleBar = self.GetChild2("TitleBar")
			if titleBar:
				titleBar.SetCloseEvent(ui.__mem_func__(self.Close))
			#MULTI_LANGUAGE
			self.titleName = self.GetChild2("TitleName")
			#MULTI_LANGUAGE

			for i in range(item.BELT_INVENTORY_SLOT_COUNT):
				slotNumber = item.BELT_INVENTORY_SLOT_START + i
				wndBeltInventorySlot.SetCoverButton(slotNumber,	"d:/ymir work/ui/game/quest/slot_button_01.sub",\
												"d:/ymir work/ui/game/quest/slot_button_01.sub",\
												"d:/ymir work/ui/game/quest/slot_button_01.sub",\
												"d:/ymir work/ui/game/belt_inventory/slot_disabled.tga", False, False)

		except:
			import exception
			exception.Abort("BeltInventoryWindow.LoadWindow.BindObject")

		wndBeltInventorySlot.SetOverInItemEvent(ui.__mem_func__(self.wndInventory.OverInItem))
		wndBeltInventorySlot.SetOverOutItemEvent(ui.__mem_func__(self.wndInventory.OverOutItem))
		wndBeltInventorySlot.SetUnselectItemSlotEvent(ui.__mem_func__(self.wndInventory.UseItemSlot))
		wndBeltInventorySlot.SetUseSlotEvent(ui.__mem_func__(self.wndInventory.UseItemSlot))						
		wndBeltInventorySlot.SetSelectEmptySlotEvent(ui.__mem_func__(self.wndInventory.SelectEmptySlot))
		wndBeltInventorySlot.SetSelectItemSlotEvent(ui.__mem_func__(self.wndInventory.SelectItemSlot))

		self.wndBeltInventorySlot = wndBeltInventorySlot

	def RefreshSlot(self):
		getItemVNum=player.GetItemIndex
		
		for i in range(item.BELT_INVENTORY_SLOT_COUNT):
			slotNumber = item.BELT_INVENTORY_SLOT_START + i
			self.wndBeltInventorySlot.SetItemSlot(slotNumber, getItemVNum(slotNumber), player.GetItemCount(slotNumber))
			self.wndBeltInventorySlot.SetAlwaysRenderCoverButton(slotNumber, True)
			
			avail = "0"
			
			if player.IsAvailableBeltInventoryCell(slotNumber):
				self.wndBeltInventorySlot.EnableCoverButton(slotNumber)				
			else:
				self.wndBeltInventorySlot.DisableCoverButton(slotNumber)				

		self.wndBeltInventorySlot.RefreshSlot()

class InventoryWindow(ui.ScriptWindow):

	if app.ENABLE_COSTUME_TABLEBONUS:
		USE_TYPE_TUPLE = ("USE_CLEAN_SOCKET", "USE_CHANGE_ATTRIBUTE", "USE_ADD_ATTRIBUTE", "USE_ADD_ATTRIBUTE2", "USE_ADD_ACCESSORY_SOCKET", "USE_PUT_INTO_ACCESSORY_SOCKET", "USE_PUT_INTO_BELT_SOCKET", "USE_PUT_INTO_RING_SOCKET", "USE_SET_ATT_COSTUME", "NEWSES_CCHANGE_ATTRIBUTE")

	if app.ENABLE_SYSTEM_METINSTONE:
		wndStoneDetach = None

	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.questionDialog = None
		self.tooltipItem = None
		self.sellingSlotNumber = -1
		self.isLoaded = 0
		self.isOpenedBeltWindowWhenClosingInventory = 0
		self.isOpenedSafeBoxWindowWhenClosingInventory = 0

		self.inventoryPageIndex = 0

		if app.ENABLE_ACCE_SYSTEM:
			self.wndAcceCombine = None
			self.wndAcceAbsorption = None

		if app.ENABLE_HIDE_COSTUME_SYSTEM:
			self.visibleButtonList = []

		self.__LoadWindow()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def Show(self):
		self.__LoadWindow()
		ui.ScriptWindow.Show(self)

		if self.isOpenedBeltWindowWhenClosingInventory and self.wndBelt:
			self.wndBelt.Show()

		if self.isOpenedSafeBoxWindowWhenClosingInventory and self.wndSafebox:
			self.wndSafebox.Show()

		#MULTI_LANGUAGE
		#MULTI_LANGUAGE

	def BindInterfaceClass(self, interface):
		self.interface = interface

	def __LoadWindow(self):
		if self.isLoaded == 1:
			return

		self.isLoaded = 1

		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "UIScript/InventoryWindow.py")
		except:
			import exception
			exception.Abort("InventoryWindow.LoadWindow.LoadObject")

		try:
			wndItem = self.GetChild("ItemSlot")
			wndEquip = self.GetChild2("EquipmentSlot")
			self.wndMoney = self.GetChild("Money")
			self.titlesbarss = self.GetChild2("TitleBarss")
			if app.FIX_BUFF_TROLL:
				self.buffdfixxed = self.GetChild2("FixBuffShamy")
			if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
				self.pincoding = self.GetChild2("PinCooding")
			if app.ENABLE_SYSTEM_METINSTONE:
				self.bonuspge = self.GetChild2("BonusPage")
				self.antiexp = self.GetChild2("AantiExp")
				self.Apotthiki = self.GetChild2("Apothiki")
				self.Sswitchbot = self.GetChild2("Switchbots")

			self.DSSButton = self.GetChild2("DSSButton")
			self.BeltButtons = self.GetChild2("BeltButtonssd")
			if app.ENABLE_HIDE_COSTUME_SYSTEM:
				btn = self.GetChild2("BodyToolTipButton")
				if btn:
					self.visibleButtonList.append(btn)
				btn = self.GetChild2("HairToolTipButton")
				if btn:
					self.visibleButtonList.append(btn)
				btn = self.GetChild2("AcceToolTipButton")
				if btn:
					self.visibleButtonList.append(btn)
				btn = self.GetChild2("WeaponToolTipButton")
				if btn:
					self.visibleButtonList.append(btn)

			self.inventoryTab = []
			self.inventoryTab.append(self.GetChild("Inventory_Tab_01"))
			self.inventoryTab.append(self.GetChild("Inventory_Tab_02"))
			self.inventoryTab.append(self.GetChild("Inventory_Tab_03"))
			self.inventoryTab.append(self.GetChild("Inventory_Tab_04"))

			self.equipmentTab = []
			tab = self.GetChild2("Equipment_Tab_01")
			if tab:
				self.equipmentTab.append(tab)
			tab = self.GetChild2("Equipment_Tab_02")
			if tab:
				self.equipmentTab.append(tab)

			if app.BL_ENABLE_PICKUP_ITEM_EFFECT:
				self.listHighlightedSlot = []

			self.wndBelt = None
			self.wndSafebox = None
			
			if app.ENABLE_NEW_EQUIPMENT_SYSTEM:
				self.wndBelt = BeltInventoryWindow(self)
				self.wndSafebox = SafeBoxInventoryWindow(self)
			
		except:
			import exception
			exception.Abort("InventoryWindow.LoadWindow.BindObject")

		wndItem.SetSelectEmptySlotEvent(ui.__mem_func__(self.SelectEmptySlot))
		wndItem.SetSelectItemSlotEvent(ui.__mem_func__(self.SelectItemSlot))
		wndItem.SetUnselectItemSlotEvent(ui.__mem_func__(self.UseItemSlot))
		wndItem.SetUseSlotEvent(ui.__mem_func__(self.UseItemSlot))
		wndItem.SetOverInItemEvent(ui.__mem_func__(self.OverInItem))
		wndItem.SetOverOutItemEvent(ui.__mem_func__(self.OverOutItem))

		if wndEquip:
			wndEquip.SetSelectEmptySlotEvent(ui.__mem_func__(self.SelectEmptySlot))
			wndEquip.SetSelectItemSlotEvent(ui.__mem_func__(self.SelectItemSlot))
			wndEquip.SetUnselectItemSlotEvent(ui.__mem_func__(self.UseItemSlot))
			wndEquip.SetUseSlotEvent(ui.__mem_func__(self.UseItemSlot))
			wndEquip.SetOverInItemEvent(ui.__mem_func__(self.OverInItem))
			wndEquip.SetOverOutItemEvent(ui.__mem_func__(self.OverOutItem))

		dlgPickMoney = uiPickMoney.PickMoneyDialog()
		dlgPickMoney.LoadDialog()
		dlgPickMoney.Hide()

		self.refineDialog = uiRefine.RefineDialog()
		self.refineDialog.Hide()
		self.attachMetinDialog = uiAttachMetin.AttachMetinDialog()
		self.attachMetinDialog.Hide()

		self.inventoryTab[0].SetEvent(lambda arg=0: self.SetInventoryPage(arg))
		self.inventoryTab[1].SetEvent(lambda arg=1: self.SetInventoryPage(arg))
		self.inventoryTab[2].SetEvent(lambda arg=2: self.SetInventoryPage(arg))
		self.inventoryTab[3].SetEvent(lambda arg=3: self.SetInventoryPage(arg))
		self.inventoryTab[0].Down()

		if len(self.equipmentTab) >= 2:
			self.equipmentTab[0].SetEvent(lambda arg=0: self.SetEquipmentPage(arg))
			self.equipmentTab[1].SetEvent(lambda arg=1: self.SetEquipmentPage(arg))
			self.equipmentTab[0].Down()
			self.equipmentTab[0].Hide()
			self.equipmentTab[1].Hide()

		self.wndItem = wndItem
		self.wndEquip = wndEquip
		self.dlgPickMoney = dlgPickMoney

		if self.DSSButton:
			self.DSSButton.SetEvent(ui.__mem_func__(self.ClickDSSButton)) 

		if app.FIX_BUFF_TROLL:
			if (self.buffdfixxed):
				self.buffdfixxed.SetEvent(ui.__mem_func__(self.ToggleFixBuffDialog))

		if (self.BeltButtons):
			self.BeltButtons.SetEvent(ui.__mem_func__(self.ClickBeltButton))

		if (self.titlesbarss):
			self.titlesbarss.SetEvent(ui.__mem_func__(self.Close))

		if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
			if (self.pincoding):
				self.pincoding.SetEvent(ui.__mem_func__(self.TogglePinCoodings))

		if app.ENABLE_SYSTEM_METINSTONE:
			if (self.bonuspge):
				self.bonuspge.SetEvent(ui.__mem_func__(self.__system_bonuspage))
			if (self.antiexp):
				self.antiexp.SetEvent(ui.__mem_func__(self.__system_antiexp))
			if (self.Apotthiki):
				self.Apotthiki.SetEvent(ui.__mem_func__(self.__apothikarios_fixes))
			if (self.Sswitchbot):
				self.Sswitchbot.SetEvent(ui.__mem_func__(self.__switchbot_fixes))

		if app.ENABLE_ACCE_SYSTEM:
			self.listAttachedAcces = []

		self.wndBelt = None
		self.wndSafebox = None
		self.SetInventoryPage(0)
		if self.wndEquip and len(self.equipmentTab) >= 2:
			self.SetEquipmentPage(0)
		self.RefreshItemSlot()
		self.RefreshStatus()

	def Destroy(self):
		self.ClearDictionary()

		self.dlgPickMoney.Destroy()
		self.dlgPickMoney = 0

		self.refineDialog.Destroy()
		self.refineDialog = 0

		self.attachMetinDialog.Destroy()
		self.attachMetinDialog = 0

		self.tooltipItem = None
		self.wndItem = 0
		self.wndEquip = 0
		self.dlgPickMoney = 0
		self.wndMoney = 0
		self.questionDialog = None
		self.DSSButton = None
		self.wndDragonSoulRefine = None
		self.interface = None

		if app.ENABLE_SYSTEM_METINSTONE:
			if self.wndStoneDetach:
				self.wndStoneDetach.Destroy()
				self.wndStoneDetach = None
		if self.wndBelt:
			self.wndBelt.Destroy()
			self.wndBelt = None

		if self.wndSafebox:
			self.wndSafebox.Destroy()
			self.wndSafebox = None

		if app.ENABLE_ACCE_SYSTEM:
			self.wndAcceCombine = None
			self.wndAcceAbsorption = None

		self.inventoryTab = []
		self.equipmentTab = []

	def Close(self):
		if None != self.tooltipItem:
			self.tooltipItem.HideToolTip()

		if self.wndBelt:
			self.wndBelt.Close()

		if self.wndSafebox:
			self.wndSafebox.Close()

		self.OnCloseQuestionDialog()
		if self.dlgPickMoney:
			self.dlgPickMoney.Close()
		wndMgr.Hide(self.hWnd)
		self.Hide()

	def SetInventoryPage(self, page):
		self.inventoryTab[self.inventoryPageIndex].SetUp()
		self.inventoryPageIndex = page
		self.inventoryTab[self.inventoryPageIndex].Down()
		self.RefreshBagSlotWindow()

	def SetEquipmentPage(self, page):
		if not self.wndEquip or len(self.equipmentTab) < 2:
			self.equipmentPageIndex = page
			return
		self.equipmentPageIndex = page
		self.equipmentTab[1-page].SetUp()
		self.RefreshEquipSlotWindow()

	if app.FIX_BUFF_TROLL:
		def ToggleFixBuffDialog(self):
			activare_disablebuffer = constInfo.DISABLE_BUFFERSSS
			event.QuestButtonClick(activare_disablebuffer)

	if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
		def TogglePinCoodings(self):
			activare_unblockerrr = constInfo.UNBLOCK_PLAYER
			event.QuestButtonClick(activare_unblockerrr)

	def ClickDSSButton(self):
		print("click_dss_button")
		self.interface.ToggleDragonSoulWindow()

	def ClickBeltButton(self):
		print("Click belt Button")
		if self.wndBelt:
			if self.wndBelt.IsShow(): 
				self.wndBelt.Hide()
			else:
				self.wndBelt.Show()
				self.wndBelt.AdjustPositionAndSize()
		else:
			self.wndBelt = BeltInventoryWindow(self)
			self.wndBelt.Show()
			self.wndBelt.AdjustPositionAndSize()

	def CloseFixBelt(self):
		print("Click belt Button")
		if self.wndBelt:
			self.wndBelt.Hide()

	def OnPickItem(self, count):
		itemSlotIndex = self.dlgPickMoney.itemGlobalSlotIndex
		selectedItemVNum = player.GetItemIndex(itemSlotIndex)
		mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_INVENTORY, itemSlotIndex, selectedItemVNum, count)

	def __InventoryLocalSlotPosToGlobalSlotPos(self, local):
		if player.IsEquipmentSlot(local) or player.IsCostumeSlot(local) or (app.ENABLE_NEW_EQUIPMENT_SYSTEM and player.IsBeltInventorySlot(local)):
			return local

		return self.inventoryPageIndex*player.INVENTORY_PAGE_SIZE + local

	def RefreshBagSlotWindow(self):
		getItemVNum=player.GetItemIndex
		getItemCount=player.GetItemCount
		setItemVNum=self.wndItem.SetItemSlot
		
		for i in range(player.INVENTORY_PAGE_SIZE):
			slotNumber = self.__InventoryLocalSlotPosToGlobalSlotPos(i)
			
			itemCount = getItemCount(slotNumber)
			
			if 0 == itemCount:
				self.wndItem.ClearSlot(i)
				continue
			elif 1 == itemCount:
				itemCount = 0
				
			itemVnum = getItemVNum(slotNumber)
			setItemVNum(i, itemVnum, itemCount)
			
			if constInfo.IS_AUTO_POTION(itemVnum):
				metinSocket = [player.GetItemMetinSocket(slotNumber, j) for j in range(player.METIN_SOCKET_MAX_NUM)]

				isActivated = 0 != metinSocket[0]
				
				if isActivated:
					self.wndItem.ActivateSlot(i)
					potionType = 0
					if app.BL_ENABLE_PICKUP_ITEM_EFFECT:
						if constInfo.IS_AUTO_POTION_HP(itemVnum):
							self.wndItem.SetSlotDiffuseColor(i, wndMgr.COLOR_TYPE_RED)
						elif constInfo.IS_AUTO_POTION_SP(itemVnum):
							self.wndItem.SetSlotDiffuseColor(i, wndMgr.COLOR_TYPE_SKY)
						else:
							self.wndItem.SetSlotDiffuseColor(i, wndMgr.COLOR_TYPE_WHITE)
					else:
						if constInfo.IS_AUTO_POTION_HP(itemVnum):
							potionType = player.AUTO_POTION_TYPE_HP
						elif constInfo.IS_AUTO_POTION_SP(itemVnum):
							potionType = player.AUTO_POTION_TYPE_SP

					usedAmount = int(metinSocket[1])
					totalAmount = int(metinSocket[2])
					player.SetAutoPotionInfo(potionType, isActivated, (totalAmount - usedAmount), totalAmount, self.__InventoryLocalSlotPosToGlobalSlotPos(i))
					
				else:
					self.wndItem.DeactivateSlot(i)

			if app.ENABLE_ACCE_SYSTEM:
				slotNumberChecked = 0
				if not constInfo.IS_AUTO_POTION(itemVnum):
					self.wndItem.DeactivateSlot(i)

				for j in range(acce.WINDOW_MAX_MATERIALS):
					(isHere, iCell) = acce.GetAttachedItem(j)
					if isHere:
						if iCell == slotNumber:
							self.wndItem.ActivateSlot(i, (36.00 / 255.0), (222.00 / 255.0), (3.00 / 255.0), 1.0)
							if not slotNumber in self.listAttachedAcces:
								self.listAttachedAcces.append(slotNumber)

							slotNumberChecked = 1
					else:
						if slotNumber in self.listAttachedAcces and not slotNumberChecked:
							self.wndItem.DeactivateSlot(i)
							self.listAttachedAcces.remove(slotNumber)

		if app.BL_ENABLE_PICKUP_ITEM_EFFECT:
			self.__HighlightSlot_Refresh()

		self.wndItem.RefreshSlot()

		if self.wndBelt:
			self.wndBelt.RefreshSlot()

	def SetItemSlotVnum(self, slotNumber):
		if not self.wndEquip:
			return
		getItemVNum=player.GetItemIndex
		getItemCount=player.GetItemCount
		setItemVNum=self.wndEquip.SetItemSlot
		itemCount = getItemCount(slotNumber)
		if itemCount <= 1:
			itemCount = 0
		setItemVNum(slotNumber, getItemVNum(slotNumber), itemCount)
		return

	def RefreshEquipSlotWindow(self):
		if not self.wndEquip:
			return
		SetItemSlotVnum = self.SetItemSlotVnum
		for i in range(player.EQUIPMENT_PAGE_COUNT):
			SetItemSlotVnum(player.EQUIPMENT_SLOT_START + i)

		if app.ENABLE_NEW_EQUIPMENT_SYSTEM:
			for i in range(player.NEW_EQUIPMENT_SLOT_COUNT):
				SetItemSlotVnum(player.NEW_EQUIPMENT_SLOT_START + i)

		if app.ENABLE_COSTUME_SYSTEM:
			for i in range(player.NEW_COSTUME_SLOT_COUNT):
				SetItemSlotVnum(player.NEW_COSTUME_SLOT_START + i)

		if app.ENABLE_HIDE_COSTUME_SYSTEM:
			body = constInfo.HIDDEN_BODY_COSTUME
			hair = constInfo.HIDDEN_HAIR_COSTUME
			if app.ENABLE_ACCE_SYSTEM:
				acce = constInfo.HIDDEN_ACCE_COSTUME
			if app.ENABLE_WEAPON_COSTUME_SYSTEM:
				weapon = constInfo.HIDDEN_WEAPON_COSTUME

			if body == 1:
				self.visibleButtonList[0].SetToolTipText(localeinfo.Get("SHOW_COSTUME"))
				self.visibleButtonList[0].Down()
			else:
				self.visibleButtonList[0].SetToolTipText(localeinfo.Get("HIDE_COSTUME"))
				self.visibleButtonList[0].SetUp()

			if hair == 1:
				self.visibleButtonList[1].SetToolTipText(localeinfo.Get("SHOW_COSTUME"))
				self.visibleButtonList[1].Down()
			else:
				self.visibleButtonList[1].SetToolTipText(localeinfo.Get("HIDE_COSTUME"))
				self.visibleButtonList[1].SetUp()

			if app.ENABLE_ACCE_SYSTEM:
				if acce == 1:
					self.visibleButtonList[2].SetToolTipText(localeinfo.Get("SHOW_COSTUME"))
					self.visibleButtonList[2].Down()
				else:
					self.visibleButtonList[2].SetToolTipText(localeinfo.Get("HIDE_COSTUME"))
					self.visibleButtonList[2].SetUp()

			if app.ENABLE_WEAPON_COSTUME_SYSTEM:
				if weapon == 1:
					self.visibleButtonList[3].SetToolTipText(localeinfo.Get("SHOW_COSTUME"))
					self.visibleButtonList[3].Down()
				else:
					self.visibleButtonList[3].SetToolTipText(localeinfo.Get("HIDE_COSTUME"))
					self.visibleButtonList[3].SetUp()

		self.wndEquip.RefreshSlot()

	def RefreshItemSlot(self):
		self.RefreshBagSlotWindow()
		self.RefreshEquipSlotWindow()
		if app.ENABLE_HIDE_COSTUME_SYSTEM and len(self.visibleButtonList) >= 2:
			self.visibleButtonList[0].SetToggleUpEvent(ui.__mem_func__(self.VisibleCostume), 1, 0)
			self.visibleButtonList[1].SetToggleUpEvent(ui.__mem_func__(self.VisibleCostume), 2, 0)
			if app.ENABLE_ACCE_SYSTEM and len(self.visibleButtonList) >= 3:
				self.visibleButtonList[2].SetToggleUpEvent(ui.__mem_func__(self.VisibleCostume), 3, 0)
			if app.ENABLE_WEAPON_COSTUME_SYSTEM and len(self.visibleButtonList) >= 4:
				self.visibleButtonList[3].SetToggleUpEvent(ui.__mem_func__(self.VisibleCostume), 4, 0)

			self.visibleButtonList[0].SetToggleDownEvent(ui.__mem_func__(self.VisibleCostume), 1, 1)
			self.visibleButtonList[1].SetToggleDownEvent(ui.__mem_func__(self.VisibleCostume), 2, 1)
			if app.ENABLE_ACCE_SYSTEM and len(self.visibleButtonList) >= 3:
				self.visibleButtonList[2].SetToggleDownEvent(ui.__mem_func__(self.VisibleCostume), 3, 1)
			if app.ENABLE_WEAPON_COSTUME_SYSTEM and len(self.visibleButtonList) >= 4:
				self.visibleButtonList[3].SetToggleDownEvent(ui.__mem_func__(self.VisibleCostume), 4, 1)

	if app.ENABLE_HIDE_COSTUME_SYSTEM:
		def VisibleCostume(self, part, hidden):
			net.SendChatPacket("/hide_costume %d %d" % (part, hidden))

	def RefreshStatus(self):
		money = player.GetElk()
		self.wndMoney.SetText(localeinfo.NumberToMoneyString(money))

	def SetItemToolTip(self, tooltipItem):
		self.tooltipItem = tooltipItem

	def SellItem(self):
		net.SendShopSellPacketNew(self.sellingSlotNumber, self.questionDialog.count)
		snd.PlaySound("sound/ui/money.wav")
		self.OnCloseQuestionDialog()

	def OnDetachMetinFromItem(self):
		if None == self.questionDialog:
			return
			
		self.__SendUseItemToItemPacket(self.questionDialog.sourcePos, self.questionDialog.targetPos)
		self.OnCloseQuestionDialog()

	def OnCloseQuestionDialog(self):
		if not self.questionDialog:
			return

		self.questionDialog.Close()
		self.questionDialog = None

	def SelectEmptySlot(self, selectedSlotPos):
		if constInfo.GET_ITEM_QUESTION_DIALOG_STATUS() == 1:
			return

		selectedSlotPos = self.__InventoryLocalSlotPosToGlobalSlotPos(selectedSlotPos)

		if mouseModule.mouseController.isAttached():

			attachedSlotType = mouseModule.mouseController.GetAttachedType()
			attachedSlotPos = mouseModule.mouseController.GetAttachedSlotNumber()
			attachedItemCount = mouseModule.mouseController.GetAttachedItemCount()
			attachedItemIndex = mouseModule.mouseController.GetAttachedItemIndex()

			if player.SLOT_TYPE_INVENTORY == attachedSlotType:
				attachedInvenType = player.SlotTypeToInvenType(attachedSlotType)
				if player.IsDSEquipmentSlot(attachedInvenType, attachedSlotPos):
					mouseModule.mouseController.DeattachObject()
					return

				itemCount = player.GetItemCount(attachedSlotPos)
				attachedCount = mouseModule.mouseController.GetAttachedItemCount()
				self.__SendMoveItemPacket(attachedSlotPos, selectedSlotPos, attachedCount)

				if item.IsRefineScroll(attachedItemIndex):
					self.wndItem.SetUseMode(False)

			elif app.ENABLE_SWITCHBOT and player.SLOT_TYPE_SWITCHBOT == attachedSlotType:
				attachedCount = mouseModule.mouseController.GetAttachedItemCount()
				net.SendItemMovePacket(player.SWITCHBOT, attachedSlotPos, player.INVENTORY, selectedSlotPos, attachedCount)

			elif player.SLOT_TYPE_PRIVATE_SHOP == attachedSlotType:
				mouseModule.mouseController.RunCallBack("INVENTORY")

			elif player.SLOT_TYPE_SHOP == attachedSlotType:
				net.SendShopBuyPacket(attachedSlotPos)

			elif player.SLOT_TYPE_SAFEBOX == attachedSlotType:

				if player.ITEM_MONEY == attachedItemIndex:
					net.SendSafeboxWithdrawMoneyPacket(mouseModule.mouseController.GetAttachedItemCount())
					snd.PlaySound("sound/ui/money.wav")

				else:
					net.SendSafeboxCheckoutPacket(attachedSlotPos, selectedSlotPos)

			elif player.SLOT_TYPE_MALL == attachedSlotType:
				net.SendMallCheckoutPacket(attachedSlotPos, selectedSlotPos)

			mouseModule.mouseController.DeattachObject()

	def SelectItemSlot(self, itemSlotIndex):
		if constInfo.GET_ITEM_QUESTION_DIALOG_STATUS() == 1:
			return

		itemSlotIndex = self.__InventoryLocalSlotPosToGlobalSlotPos(itemSlotIndex)

		if mouseModule.mouseController.isAttached():
			attachedSlotType = mouseModule.mouseController.GetAttachedType()
			attachedSlotPos = mouseModule.mouseController.GetAttachedSlotNumber()
			attachedItemVID = mouseModule.mouseController.GetAttachedItemIndex()

			if player.SLOT_TYPE_INVENTORY == attachedSlotType:
				attachedInvenType = player.SlotTypeToInvenType(attachedSlotType)
				if player.IsDSEquipmentSlot(attachedInvenType, attachedSlotPos):
					mouseModule.mouseController.DeattachObject()
					return
				self.__DropSrcItemToDestItemInInventory(attachedItemVID, attachedSlotPos, itemSlotIndex)

			mouseModule.mouseController.DeattachObject()

		else:

			curCursorNum = app.GetCursor()
			if app.SELL == curCursorNum:
				self.__SellItem(itemSlotIndex)
				
			elif app.BUY == curCursorNum:
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("SHOP_BUY_INFO"))

			elif app.IsPressed(app.DIK_LALT):
				link = player.GetItemLink(itemSlotIndex)
				ime.PasteString(link)

			elif app.IsPressed(app.DIK_LSHIFT):
				itemCount = player.GetItemCount(itemSlotIndex)
				
				if itemCount > 1:
					self.dlgPickMoney.SetTitleName(localeinfo.Get("PICK_ITEM_TITLE"))
					self.dlgPickMoney.SetAcceptEvent(ui.__mem_func__(self.OnPickItem))
					self.dlgPickMoney.Open(itemCount)
					self.dlgPickMoney.itemGlobalSlotIndex = itemSlotIndex

			elif app.IsPressed(app.DIK_LCONTROL):
				itemIndex = player.GetItemIndex(itemSlotIndex)

				if True == item.CanAddToQuickSlotItem(itemIndex):
					player.RequestAddToEmptyLocalQuickSlot(player.SLOT_TYPE_INVENTORY, itemSlotIndex)
				else:
					chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("QUICKSLOT_REGISTER_DISABLE_ITEM"))

			else:
				selectedItemVNum = player.GetItemIndex(itemSlotIndex)
				itemCount = player.GetItemCount(itemSlotIndex)
				mouseModule.mouseController.AttachObject(self, player.SLOT_TYPE_INVENTORY, itemSlotIndex, selectedItemVNum, itemCount)
				
				if self.__IsUsableItemToItem(selectedItemVNum, itemSlotIndex):				
					self.wndItem.SetUseMode(True)
				else:					
					self.wndItem.SetUseMode(False)

				snd.PlaySound("sound/ui/pick.wav")

	def __DropSrcItemToDestItemInInventory(self, srcItemVID, srcItemSlotPos, dstItemSlotPos):
		if srcItemSlotPos == dstItemSlotPos:
			return

		if item.IsRefineScroll(srcItemVID):
			self.RefineItem(srcItemSlotPos, dstItemSlotPos)
			self.wndItem.SetUseMode(False)

		##if app.ENABLE_SYSTEM_METINSTONE:
		##elif item.IsMetin(srcItemVID):
		##	self.AttachMetinToItem(srcItemSlotPos, dstItemSlotPos)
		elif item.IsMetin(srcItemVID) and not item.IsMetin(player.GetItemIndex(dstItemSlotPos)):
			self.AttachMetinToItem(srcItemSlotPos, dstItemSlotPos)

		elif item.IsDetachScroll(srcItemVID):
			self.DetachMetinFromItem(srcItemSlotPos, dstItemSlotPos)

		elif item.IsKey(srcItemVID):
			self.__SendUseItemToItemPacket(srcItemSlotPos, dstItemSlotPos)			

		elif (player.GetItemFlags(srcItemSlotPos) & ITEM_FLAG_APPLICABLE) == ITEM_FLAG_APPLICABLE:
			self.__SendUseItemToItemPacket(srcItemSlotPos, dstItemSlotPos)

		elif item.GetUseType(srcItemVID) in self.USE_TYPE_TUPLE:
			self.__SendUseItemToItemPacket(srcItemSlotPos, dstItemSlotPos)

		else:
			if player.IsEquipmentSlot(dstItemSlotPos) or player.IsCostumeSlot(dstItemSlotPos):
				if item.IsEquipmentVID(srcItemVID):
					self.__UseItem(srcItemSlotPos)
			else:
				self.__SendMoveItemPacket(srcItemSlotPos, dstItemSlotPos, 0)

	def __SellItem(self, itemSlotPos):
		if player.IsCostumeSlot(itemSlotPos):
			return;
		if not player.IsEquipmentSlot(itemSlotPos):
			self.sellingSlotNumber = itemSlotPos
			itemIndex = player.GetItemIndex(itemSlotPos)
			itemCount = player.GetItemCount(itemSlotPos)

			item.SelectItem(itemIndex)
			if item.IsAntiFlag(item.ANTIFLAG_SELL):
				popup = uiCommon.PopupDialog()
				popup.SetText(localeinfo.Get("SHOP_CANNOT_SELL_ITEM"))
				popup.SetAcceptEvent(self.__OnClosePopupDialog)
				popup.Open()
				self.popup = popup
				return
			itemPrice = item.GetISellItemPrice()

			if item.Is1GoldItem():
				itemPrice = itemCount / itemPrice / 5
			else:
				itemPrice = itemPrice * itemCount / 5

			item.GetItemName(itemIndex)
			itemName = item.GetItemName()

			self.questionDialog = uiCommon.QuestionDialog()
			self.questionDialog.SetText(localeinfo.DO_YOU_SELL_ITEM(itemName, itemCount, itemPrice))
			self.questionDialog.SetAcceptEvent(ui.__mem_func__(self.SellItem))
			self.questionDialog.SetCancelEvent(ui.__mem_func__(self.OnCloseQuestionDialog))
			self.questionDialog.Open()
			self.questionDialog.count = itemCount

	def __OnClosePopupDialog(self):
		self.pop = None

	def RefineItem(self, scrollSlotPos, targetSlotPos):

		scrollIndex = player.GetItemIndex(scrollSlotPos)
		targetIndex = player.GetItemIndex(targetSlotPos)

		if player.REFINE_OK != player.CanRefine(scrollIndex, targetSlotPos):
			return

		self.__SendUseItemToItemPacket(scrollSlotPos, targetSlotPos)
		return

		result = player.CanRefine(scrollIndex, targetSlotPos)

		if player.REFINE_ALREADY_MAX_SOCKET_COUNT == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("REFINE_FAILURE_NO_MORE_SOCKET"))

		elif player.REFINE_NEED_MORE_GOOD_SCROLL == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("REFINE_FAILURE_NEED_BETTER_SCROLL"))

		elif player.REFINE_CANT_MAKE_SOCKET_ITEM == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("REFINE_FAILURE_SOCKET_DISABLE_ITEM"))

		elif player.REFINE_NOT_NEXT_GRADE_ITEM == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("REFINE_FAILURE_UPGRADE_DISABLE_ITEM"))

		elif player.REFINE_CANT_REFINE_METIN_TO_EQUIPMENT == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("REFINE_FAILURE_EQUIP_ITEM"))

		if player.REFINE_OK != result:
			return

		self.refineDialog.Open(scrollSlotPos, targetSlotPos)

	def DetachMetinFromItem(self, scrollSlotPos, targetSlotPos):
		scrollIndex = player.GetItemIndex(scrollSlotPos)
		targetIndex = player.GetItemIndex(targetSlotPos)

		if not player.CanDetach(scrollIndex, targetSlotPos):
			if app.ENABLE_ACCE_COSTUME_SYSTEM:
				item.SelectItem(scrollIndex)
				if item.GetValue(0) == acce.CLEAN_ATTR_VALUE0:
					chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("ACCE_FAILURE_CLEAN"))
				else:
					chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("REFINE_FAILURE_METIN_INSEPARABLE_ITEM"))
			else:
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("REFINE_FAILURE_METIN_INSEPARABLE_ITEM"))
			return

		self.questionDialog = uiCommon.QuestionDialog()
		self.questionDialog.SetText(localeinfo.Get("REFINE_DO_YOU_SEPARATE_METIN"))
		if app.ENABLE_ACCE_COSTUME_SYSTEM:
			item.SelectItem(targetIndex)
			if item.GetItemType() == item.ITEM_TYPE_COSTUME and item.GetItemSubType() == item.COSTUME_TYPE_ACCE:
				item.SelectItem(scrollIndex)
				if item.GetValue(0) == acce.CLEAN_ATTR_VALUE0:
					self.questionDialog.SetText(localeinfo.Get("ACCE_DO_YOU_CLEAN"))

		if app.ENABLE_SYSTEM_METINSTONE:
			self.OpenNewStoneDetachWindow(scrollSlotPos, targetSlotPos)
			return

		self.questionDialog.SetAcceptEvent(ui.__mem_func__(self.OnDetachMetinFromItem))
		self.questionDialog.SetCancelEvent(ui.__mem_func__(self.OnCloseQuestionDialog))
		self.questionDialog.Open()
		self.questionDialog.sourcePos = scrollSlotPos
		self.questionDialog.targetPos = targetSlotPos

	def AttachMetinToItem(self, metinSlotPos, targetSlotPos):
		metinIndex = player.GetItemIndex(metinSlotPos)
		targetIndex = player.GetItemIndex(targetSlotPos)

		item.SelectItem(metinIndex)
		itemName = item.GetItemName()

		result = player.CanAttachMetin(metinIndex, targetSlotPos)

		if player.ATTACH_METIN_NOT_MATCHABLE_ITEM == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.REFINE_FAILURE_CAN_NOT_ATTACH(itemName))

		if player.ATTACH_METIN_NO_MATCHABLE_SOCKET == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.REFINE_FAILURE_NO_SOCKET(itemName))

		elif player.ATTACH_METIN_NOT_EXIST_GOLD_SOCKET == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.REFINE_FAILURE_NO_GOLD_SOCKET(itemName))

		elif player.ATTACH_METIN_CANT_ATTACH_TO_EQUIPMENT == result:
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("REFINE_FAILURE_EQUIP_ITEM"))

		if player.ATTACH_METIN_OK != result:
			return

		self.attachMetinDialog.Open(metinSlotPos, targetSlotPos)

		
	def OverOutItem(self):
		self.wndItem.SetUsableItem(False)
		if None != self.tooltipItem:
			self.tooltipItem.HideToolTip()

	def OverInItem(self, overSlotPos):
		overSlotPos = self.__InventoryLocalSlotPosToGlobalSlotPos(overSlotPos)
		self.wndItem.SetUsableItem(False)

		if mouseModule.mouseController.isAttached():
			attachedItemType = mouseModule.mouseController.GetAttachedType()
			if player.SLOT_TYPE_INVENTORY == attachedItemType:

				attachedSlotPos = mouseModule.mouseController.GetAttachedSlotNumber()
				attachedItemVNum = mouseModule.mouseController.GetAttachedItemIndex()
				if attachedItemVNum==player.ITEM_MONEY:
					pass
				elif self.__CanUseSrcItemToDstItem(attachedItemVNum, attachedSlotPos, overSlotPos):
					self.wndItem.SetUsableItem(True)
					self.ShowToolTip(overSlotPos)
					return

		if app.BL_ENABLE_PICKUP_ITEM_EFFECT:
			self.DelHighlightSlot(overSlotPos)

		self.ShowToolTip(overSlotPos)

	def __IsUsableItemToItem(self, srcItemVNum, srcSlotPos):
		if item.IsRefineScroll(srcItemVNum):
			return True
		elif item.IsMetin(srcItemVNum):
			return True
		elif item.IsDetachScroll(srcItemVNum):
			return True
		elif item.IsKey(srcItemVNum):
			return True
		elif (player.GetItemFlags(srcSlotPos) & ITEM_FLAG_APPLICABLE) == ITEM_FLAG_APPLICABLE:
			return True
		else:
			if item.GetUseType(srcItemVNum) in self.USE_TYPE_TUPLE:
				return True
			
		return False

	def __CanUseSrcItemToDstItem(self, srcItemVNum, srcSlotPos, dstSlotPos):
		if srcSlotPos == dstSlotPos:
			return False

		if item.IsRefineScroll(srcItemVNum):
			if player.REFINE_OK == player.CanRefine(srcItemVNum, dstSlotPos):
				return True

		##if app.ENABLE_SYSTEM_METINSTONE:
		##elif item.IsMetin(srcItemVNum):
		##	if player.ATTACH_METIN_OK == player.CanAttachMetin(srcItemVNum, dstSlotPos):
		##		return True
		elif item.IsMetin(srcItemVNum):
			if player.ATTACH_METIN_OK == player.CanAttachMetin(srcItemVNum, dstSlotPos) or (item.IsMetin(player.GetItemIndex(dstSlotPos)) and player.GetItemIndex(dstSlotPos) == srcItemVNum):
				return True

		elif item.IsDetachScroll(srcItemVNum):
			if player.DETACH_METIN_OK == player.CanDetach(srcItemVNum, dstSlotPos):
				return True
		elif item.IsKey(srcItemVNum):
			if player.CanUnlock(srcItemVNum, dstSlotPos):
				return True

		elif (player.GetItemFlags(srcSlotPos) & ITEM_FLAG_APPLICABLE) == ITEM_FLAG_APPLICABLE:
			return True

		else:
			useType=item.GetUseType(srcItemVNum)

			if "USE_CLEAN_SOCKET" == useType:
				if self.__CanCleanBrokenMetinStone(dstSlotPos):
					return True
			elif "USE_CHANGE_ATTRIBUTE" == useType:
				if self.__CanChangeItemAttrList(dstSlotPos):
					return True
			elif "USE_ADD_ATTRIBUTE" == useType:
				if self.__CanAddItemAttr(dstSlotPos):
					return True
			elif "USE_ADD_ATTRIBUTE2" == useType:
				if self.__CanAddItemAttr(dstSlotPos):
					return True
			##EINAI TO USE_SET_ATT_COSTUME kai NEWSES_CCHANGE_ATTRIBUTE if app.ENABLE_COSTUME_TABLEBONUS:
			elif "USE_SET_ATT_COSTUME" == useType:
				if self.__CanSetItemAttr(dstSlotPos):
					return True
			elif "NEWSES_CCHANGE_ATTRIBUTE" == useType:
				if self.__CanSetItemAttr(dstSlotPos):
					return True
			##ENDD
			elif "USE_ADD_ACCESSORY_SOCKET" == useType:
				if self.__CanAddAccessorySocket(dstSlotPos):
					return True
			elif "USE_PUT_INTO_ACCESSORY_SOCKET" == useType:								
				if self.__CanPutAccessorySocket(dstSlotPos, srcItemVNum):
					return True;
			elif "USE_PUT_INTO_BELT_SOCKET" == useType:								
				dstItemVNum = player.GetItemIndex(dstSlotPos)
				print("USE_PUT_INTO_BELT_SOCKET", srcItemVNum, dstItemVNum)

				item.SelectItem(dstItemVNum)
				if item.ITEM_TYPE_BELT == item.GetItemType():
					return True

		return False

	def __CanCleanBrokenMetinStone(self, dstSlotPos):
		dstItemVNum = player.GetItemIndex(dstSlotPos)
		if dstItemVNum == 0:
			return False

		item.SelectItem(dstItemVNum)
		
		if item.ITEM_TYPE_WEAPON != item.GetItemType():
			return False

		for i in range(player.METIN_SOCKET_MAX_NUM):
			if player.GetItemMetinSocket(dstSlotPos, i) == constInfo.ERROR_METIN_STONE:
				return True

		return False

	def __CanChangeItemAttrList(self, dstSlotPos):
		dstItemVNum = player.GetItemIndex(dstSlotPos)
		if dstItemVNum == 0:
			return False

		item.SelectItem(dstItemVNum)
		
		if not item.GetItemType() in (item.ITEM_TYPE_WEAPON, item.ITEM_TYPE_ARMOR):	 
			return False

		for i in range(player.METIN_SOCKET_MAX_NUM):
			if player.GetItemAttribute(dstSlotPos, i)[0] != 0:
				return True

		return False

	def __CanPutAccessorySocket(self, dstSlotPos, mtrlVnum):
		dstItemVNum = player.GetItemIndex(dstSlotPos)
		if dstItemVNum == 0:
			return False

		item.SelectItem(dstItemVNum)

		if item.GetItemType() != item.ITEM_TYPE_ARMOR:
			return False

		if not item.GetItemSubType() in (item.ARMOR_WRIST, item.ARMOR_NECK, item.ARMOR_EAR):
			return False

		curCount = player.GetItemMetinSocket(dstSlotPos, 0)
		maxCount = player.GetItemMetinSocket(dstSlotPos, 1)

		if mtrlVnum != constInfo.GET_ACCESSORY_MATERIAL_VNUM(dstItemVNum, item.GetItemSubType()):
			return False
		
		if curCount>=maxCount:
			return False

		return True

	def __CanAddAccessorySocket(self, dstSlotPos):
		dstItemVNum = player.GetItemIndex(dstSlotPos)
		if dstItemVNum == 0:
			return False

		item.SelectItem(dstItemVNum)

		if item.GetItemType() != item.ITEM_TYPE_ARMOR:
			return False

		if not item.GetItemSubType() in (item.ARMOR_WRIST, item.ARMOR_NECK, item.ARMOR_EAR):
			return False

		curCount = player.GetItemMetinSocket(dstSlotPos, 0)
		maxCount = player.GetItemMetinSocket(dstSlotPos, 1)
		
		ACCESSORY_SOCKET_MAX_SIZE = 3
		if maxCount >= ACCESSORY_SOCKET_MAX_SIZE:
			return False

		return True

	def __CanAddItemAttr(self, dstSlotPos):
		dstItemVNum = player.GetItemIndex(dstSlotPos)
		if dstItemVNum == 0:
			return False

		item.SelectItem(dstItemVNum)
		
		if not item.GetItemType() in (item.ITEM_TYPE_WEAPON, item.ITEM_TYPE_ARMOR):	 
			return False
			
		attrCount = 0
		for i in range(player.METIN_SOCKET_MAX_NUM):
			if player.GetItemAttribute(dstSlotPos, i)[0] != 0:
				attrCount += 1

		if attrCount<4:
			return True
								
		return False

	if app.ENABLE_COSTUME_TABLEBONUS:
		def __CanSetItemAttr(self, dstSlotPos):
			dstItemVNum = player.GetItemIndex(dstSlotPos)
			if dstItemVNum == 0:
				return False
			item.SelectItem(dstItemVNum)
			attrCount = 0
			for i in range(player.METIN_SOCKET_MAX_NUM):
				if player.GetItemAttribute(dstSlotPos, i) != 0:
					attrCount += 1
			if attrCount<7:
				return True
			return False

	def ShowToolTip(self, slotIndex):
		if None != self.tooltipItem:
			self.tooltipItem.SetInventoryItem(slotIndex)

	def OnTop(self):
		if None != self.tooltipItem:
			self.tooltipItem.SetTop()

	def OnPressEscapeKey(self):
		self.Close()
		return True

	def UseItemSlot(self, slotIndex):
		curCursorNum = app.GetCursor()
		if app.SELL == curCursorNum:
			return
		if constInfo.GET_ITEM_QUESTION_DIALOG_STATUS():
			return

		slotIndex = self.__InventoryLocalSlotPosToGlobalSlotPos(slotIndex)

		if app.ENABLE_DRAGON_SOUL_SYSTEM:
			if self.wndDragonSoulRefine.IsShow():
				self.wndDragonSoulRefine.AutoSetItem((player.INVENTORY, slotIndex), 1)
				return
		if app.ENABLE_ACCE_SYSTEM:
			if self.isShowAcceWindow():
				acce.Add(player.INVENTORY, slotIndex, 255)
				return

		self.__UseItem(slotIndex)
		mouseModule.mouseController.DeattachObject()
		self.OverOutItem()

	def __UseItem(self, slotIndex):
		ItemVNum = player.GetItemIndex(slotIndex)
		item.SelectItem(ItemVNum)
		if item.IsFlag(item.ITEM_FLAG_CONFIRM_WHEN_USE):
			self.questionDialog = uiCommon.QuestionDialog()
			self.questionDialog.SetText(localeinfo.Get("INVENTORY_REALLY_USE_ITEM"))
			self.questionDialog.SetAcceptEvent(ui.__mem_func__(self.__UseItemQuestionDialog_OnAccept))
			self.questionDialog.SetCancelEvent(ui.__mem_func__(self.__UseItemQuestionDialog_OnCancel))
			self.questionDialog.Open()
			self.questionDialog.slotIndex = slotIndex

		else:
			self.__SendUseItemPacket(slotIndex)

	def __UseItemQuestionDialog_OnCancel(self):
		self.OnCloseQuestionDialog()

	def __UseItemQuestionDialog_OnAccept(self):
		self.__SendUseItemPacket(self.questionDialog.slotIndex)
		self.OnCloseQuestionDialog()

	def __SendUseItemToItemPacket(self, srcSlotPos, dstSlotPos):
		if uiPrivateShopBuilder.IsBuildingPrivateShop():
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("USE_ITEM_FAILURE_PRIVATE_SHOP"))
			return

		net.SendItemUseToItemPacket(srcSlotPos, dstSlotPos)

	def __SendUseItemPacket(self, slotPos):
		if uiPrivateShopBuilder.IsBuildingPrivateShop():
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("USE_ITEM_FAILURE_PRIVATE_SHOP"))
			return

		net.SendItemUsePacket(slotPos)
	
	def __SendMoveItemPacket(self, srcSlotPos, dstSlotPos, srcItemCount):
		if uiPrivateShopBuilder.IsBuildingPrivateShop():
			chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("MOVE_ITEM_FAILURE_PRIVATE_SHOP"))
			return

		net.SendItemMovePacket(srcSlotPos, dstSlotPos, srcItemCount)
	
	def SetDragonSoulRefineWindow(self, wndDragonSoulRefine):
		if app.ENABLE_DRAGON_SOUL_SYSTEM:
			self.wndDragonSoulRefine = wndDragonSoulRefine

	def OnMoveWindow(self, x, y):	
		if self.wndBelt:
			self.wndBelt.AdjustPositionAndSize()
		if self.wndSafebox:
			self.wndSafebox.AdjustPositionAndSizeSafeBox()

	if app.BL_ENABLE_PICKUP_ITEM_EFFECT:
		def ActivateSlot(self, slotindex, type):
			if type == wndMgr.HILIGHTSLOT_MAX:
				return
					
		def DeactivateSlot(self, slotindex, type):
			if type == wndMgr.HILIGHTSLOT_MAX:
				return

		def __HighlightSlot_Refresh(self):
			for i in range(self.wndItem.GetSlotCount()):
				slotNumber = self.__InventoryLocalSlotPosToGlobalSlotPos(i)
				if slotNumber in self.listHighlightedSlot:
					self.wndItem.DeactivateSlot(i)
					self.wndItem.ActivateSlot(i)
					self.wndItem.SetSlotDiffuseColor(i, wndMgr.COLOR_TYPE_WHITE)

		def __HighlightSlot_Clear(self):
			for i in range(self.wndItem.GetSlotCount()):
				slotNumber = self.__InventoryLocalSlotPosToGlobalSlotPos(i)
				if slotNumber in self.listHighlightedSlot:
					self.wndItem.DeactivateSlot(i)
					self.listHighlightedSlot.remove(slotNumber)
		
		def HighlightSlot(self, slot):
			if slot > player.INVENTORY_PAGE_SIZE * player.INVENTORY_PAGE_COUNT:
				return
			
			if not slot in self.listHighlightedSlot:
				self.listHighlightedSlot.append(slot)

		def DelHighlightSlot(self, inventorylocalslot):
			slotNumber = self.__InventoryLocalSlotPosToGlobalSlotPos(inventorylocalslot)
			if slotNumber in self.listHighlightedSlot:
				if inventorylocalslot >= player.INVENTORY_PAGE_SIZE:
					self.wndItem.DeactivateSlot(slotNumber - (self.inventoryPageIndex * player.INVENTORY_PAGE_SIZE) )
				else:
					self.wndItem.DeactivateSlot(inventorylocalslot)

				self.listHighlightedSlot.remove(slotNumber)

	if app.ENABLE_ACCE_SYSTEM:
		def SetAcceWindow(self, wndAcceCombine, wndAcceAbsorption):
			self.wndAcceCombine = wndAcceCombine
			self.wndAcceAbsorption = wndAcceAbsorption

		def isShowAcceWindow(self):
			if self.wndAcceCombine:
				if self.wndAcceCombine.IsShow():
					return 1

			if self.wndAcceAbsorption:
				if self.wndAcceAbsorption.IsShow():
					return 1

			return 0

	if app.ENABLE_SYSTEM_METINSTONE:
		def OpenNewStoneDetachWindow(self, scrollSlotPos, targetSlotPos):
			if item.ITEM_TYPE_COSTUME == item.GetItemType():
				chat.AppendChat(chat.CHAT_TYPE_INFO, localeinfo.Get("NOT_COSTUME_EXTRACTLITA"))
				return
			import uistonedetach
			if not self.wndStoneDetach:
				self.wndStoneDetach = uistonedetach.StoneDetachWindow()
			self.wndStoneDetach.Open(scrollSlotPos, targetSlotPos)

		def __system_bonuspage(self):
			if self.interface:
				self.interface.ToggleBonusWindowPage()

		def __system_antiexp(self):
			activare_antiexpirian = constInfo.ANTIEXP_QUESTINDEX
			event.QuestButtonClick(activare_antiexpirian)

		def __apothikarios_fixes(self):
			print("Click SafeBox Button")
			if self.wndSafebox:
				if self.wndSafebox.IsShow(): 
					self.wndSafebox.Hide()
				else:
					self.wndSafebox.Show()
					self.wndSafebox.AdjustPositionAndSizeSafeBox()
			else:
				self.wndSafebox = SafeBoxInventoryWindow(self)
				self.wndSafebox.Show()
				self.wndSafebox.AdjustPositionAndSizeSafeBox()

		def CloseFixSafeBox(self):
			print("Click SafeBox Button")
			if self.wndSafebox:
				self.wndSafebox.Hide()

		def __switchbot_fixes(self):
			self.interface.ToggleSwitchbotWindow()

