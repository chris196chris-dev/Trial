# -*- coding: utf-8 -*-
import grp
import app
import wndMgr
import snd
import net
import systemSetting
import localeinfo
import chr
import ui
import uiScriptLocale
import musicInfo
import playerSettingModule
import uiCommon
import constInfo

ENABLE_ENGNUM_DELETE_CODE = True

class SelectCharacterWindow(ui.Window):

	SLOT_COUNT = 4

	#MULTI_LANGUAGE - Dynamic lookup for empire names
	EMPIRE_NAME_KEYS = {
		net.EMPIRE_A : "EMPIRE_A",
		net.EMPIRE_B : "EMPIRE_B",
		net.EMPIRE_C : "EMPIRE_C",
	}

	def GetEmpireName(self, empireId):
		if empireId in self.EMPIRE_NAME_KEYS:
			return localeinfo.Get(self.EMPIRE_NAME_KEYS[empireId])
		return ""
	#MULTI_LANGUAGE
	
	class CharacterRenderer(ui.Window):
		def OnRender(self):
			grp.ClearDepthBuffer()

			grp.SetGameRenderState()
			grp.PushState()
			grp.SetOmniLight()

			screenWidth = wndMgr.GetScreenWidth()
			screenHeight = wndMgr.GetScreenHeight()
			newScreenWidth = float(screenWidth+30)
			newScreenHeight = float(screenHeight+30)
			
			grp.SetViewport(270.0/screenWidth, 0.0, newScreenWidth/screenWidth, newScreenHeight/screenHeight)

			if app.DIRECTX9:
				app.SetCenterPosition(0.0, 0.0, 0.0)
			else:
				app.SetCenterPosition(155.0, -5.0, -5.0)
			app.SetCamera(1700.0, 15.0, 180.0, 90.0)
			grp.SetPerspective(11.0, newScreenWidth/newScreenHeight, 1000.0, 3000.0)

			(x, y) = app.GetCursorPosition()
			grp.SetCursorPosition(x, y)

			chr.Deform()
			chr.Render()

			grp.RestoreViewport()
			grp.PopState()
			grp.SetInterfaceRenderState()

	def __init__(self, stream):
		ui.Window.__init__(self)
		net.SetPhaseWindow(net.PHASE_WINDOW_SELECT, self)

		self.stream=stream
		self.slot = self.stream.GetCharacterSlot()

		self.openLoadingFlag = False
		self.startIndex = -1

		self.dlgBoard = 0
		self.changeNameFlag = False
		self.nameInputBoard = None
		self.sendedChangeNamePacket = False

		self.startIndex = -1
		self.isLoad = 0
		
		self.curGauge = [0.0, 0.0, 0.0, 0.0]
		self.destGauge = [0.0, 0.0, 0.0, 0.0]

	def __del__(self):
		ui.Window.__del__(self)
		net.SetPhaseWindow(net.PHASE_WINDOW_SELECT, 0)

	def Open(self):
		if not self.__LoadBoardDialog("sistimata/code/selectcharacterwindow.py"):
			import dbg
			dbg.TraceError("SelectCharacterWindow.Open - __LoadScript Error")
			return

		if not self.__LoadQuestionDialog("uiscript/questiondialog.py"):
			return

		playerSettingModule.LoadGameData("INIT")

		self.btnStart.Enable()
		self.btnDelete.Enable()
		self.btnCreated.Enable()

		self.dlgBoard.Show()
		self.SetWindowName("SelectCharacterWindow")
		self.Show()

		if self.slot>=0:
			self.SelectSlot(self.slot)

		if musicInfo.selectMusic != "":
			snd.SetMusicVolume(systemSetting.GetMusicVolume())
			snd.FadeInMusic("miles/BGM/"+musicInfo.selectMusic)

		app.SetCenterPosition(0.0, 0.0, 0.0)
		app.SetCamera(1550.0, 15.0, 180.0, 95.0)

		self.isLoad=1
		self.Refresh()

		if self.stream.isAutoSelect:
			chrSlot=self.stream.GetCharacterSlot()
			self.SelectSlot(chrSlot)
			self.StartGame()

		self.selected = 0

		app.ShowCursor()

	def Close(self):
		if musicInfo.selectMusic != "":
			snd.FadeOutMusic("miles/BGM/"+musicInfo.selectMusic)

		self.stream.popupWindow.Close()

		if self.dlgBoard:
			self.dlgBoard.ClearDictionary()

		self.empireName = None
		self.flagDict = {}
		self.dlgBoard = None
		self.btnStart = None
		self.btnDelete = None
		self.btnCreated = None
		self.backGround = None

		self.dlgQuestion.ClearDictionary()
		self.dlgQuestion = None
		self.dlgQuestionText = None
		self.dlgQuestionAcceptButton = None
		self.dlgQuestionCancelButton = None
		self.privateInputBoard = None
		self.nameInputBoard = None

		chr.DeleteInstance(0)
		chr.DeleteInstance(1)
		chr.DeleteInstance(2)
		chr.DeleteInstance(3)

		self.Hide()
		self.KillFocus()

		app.HideCursor()

	def Refresh(self):
		if not self.isLoad:
			return
			
		races = ['warrior', 'assassin', 'sura', 'shaman']
		sex = ['woman', 'man']

		# SLOT4
		indexArray = (3, 2, 1, 0)
		for index in indexArray:
			id=net.GetAccountCharacterSlotDataInteger(index, net.ACCOUNT_CHARACTER_SLOT_ID)
			race=net.GetAccountCharacterSlotDataInteger(index, net.ACCOUNT_CHARACTER_SLOT_RACE)
			form=net.GetAccountCharacterSlotDataInteger(index, net.ACCOUNT_CHARACTER_SLOT_FORM)
			name=net.GetAccountCharacterSlotDataString(index, net.ACCOUNT_CHARACTER_SLOT_NAME)
			hair=net.GetAccountCharacterSlotDataInteger(index, net.ACCOUNT_CHARACTER_SLOT_HAIR)
			if app.ENABLE_ACCE_SYSTEM:
				acce = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_ACCE)

			if id:
				if app.ENABLE_ACCE_SYSTEM:
					self.MakeCharacter(index, id, name, race, form, hair, acce)
				else:
					self.MakeCharacter(index, id, name, race, form, hair)
				self.char[index].SetUpVisual("sistimata/images/select/%s_%s_0.tga" % (sex[chr.RaceToSex(race)], races[chr.RaceToJob(race)]))
				self.char[index].SetOverVisual("sistimata/images/select/%s_%s_1.tga" % (sex[chr.RaceToSex(race)], races[chr.RaceToJob(race)]))
				self.char[index].SetDownVisual("sistimata/images/select/%s_%s_2.tga" % (sex[chr.RaceToSex(race)], races[chr.RaceToJob(race)]))
				self.SelectSlot(index)
			else:
				self.char[index].SetUpVisual("sistimata/images/select/select/empty_0.tga")
				self.char[index].SetOverVisual("sistimata/images/select/select/empty_1.tga")
				self.char[index].SetDownVisual("sistimata/images/select/select/empty_2.tga")

		self.SelectSlot(self.slot)

	def GetCharacterSlotID(self, slotIndex):
		return net.GetAccountCharacterSlotDataInteger(slotIndex, net.ACCOUNT_CHARACTER_SLOT_ID)

	def __LoadQuestionDialog(self, fileName):
		self.dlgQuestion = ui.ScriptWindow()

		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self.dlgQuestion, fileName)
		except:
			import exception
			exception.Abort("SelectCharacterWindow.LoadQuestionDialog.LoadScript")

		try:
			GetObject=self.dlgQuestion.GetChild
			self.dlgQuestionText=GetObject("message")
			self.dlgQuestionAcceptButton=GetObject("accept")
			self.dlgQuestionCancelButton=GetObject("cancel")
		except:
			import exception
			exception.Abort("SelectCharacterWindow.LoadQuestionDialog.BindObject")

		self.dlgQuestionText.SetText(localeinfo.Get("SELECT_DO_YOU_DELETE_REALLY"))
		self.dlgQuestionAcceptButton.SetEvent(ui.__mem_func__(self.RequestDeleteCharacter))
		self.dlgQuestionCancelButton.SetEvent(ui.__mem_func__(self.dlgQuestion.Hide))
		return 1

	def __LoadBoardDialog(self, fileName):
		self.dlgBoard = ui.ScriptWindow()

		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self.dlgBoard, fileName)
		except:
			import exception
			exception.Abort("SelectCharacterWindow.LoadBoardDialog.LoadScript")

		try:
			GetObject=self.dlgBoard.GetChild

			self.btnStart = GetObject("start_button")
			self.btnDelete = GetObject("delete_button")
			self.btnCreated = GetObject("created_button")
			
			self.name = GetObject("name_value")
			self.empire = GetObject("empire_value")
			self.level = GetObject("level_value")
			self.playtime = GetObject("playtime_value")
			self.guild = GetObject("guild_value")
			
			self.char = []
			self.char.append(GetObject("char1"))
			self.char.append(GetObject("char2"))
			self.char.append(GetObject("char3"))
			self.char.append(GetObject("char4"))
			
			self.GaugeList = []
			self.GaugeList.append(GetObject("gauge_hth"))
			self.GaugeList.append(GetObject("gauge_int"))
			self.GaugeList.append(GetObject("gauge_str"))
			self.GaugeList.append(GetObject("gauge_dex"))
			
			self.CharacterHTH	= GetObject("character_hth_value")
			self.CharacterINT	= GetObject("character_int_value")
			self.CharacterSTR	= GetObject("character_str_value")
			self.CharacterDEX	= GetObject("character_dex_value")

			self.backGround = GetObject("background")

		except:
			import exception
			exception.Abort("SelectCharacterWindow.LoadBoardDialog.BindObject")

		self.btnStart.SetEvent(ui.__mem_func__(self.StartGame))
		self.btnDelete.SetEvent(ui.__mem_func__(self.InputPrivateCode))
		self.btnCreated.SetEvent(ui.__mem_func__(self.CreateCharacter))
		
		self.char[0].SetEvent(ui.__mem_func__(self.SelectSlot), 0)
		self.char[1].SetEvent(ui.__mem_func__(self.SelectSlot), 1)
		self.char[2].SetEvent(ui.__mem_func__(self.SelectSlot), 2)
		self.char[3].SetEvent(ui.__mem_func__(self.SelectSlot), 3)
		
		self.chrRenderer = self.CharacterRenderer()
		self.chrRenderer.SetParent(self.backGround)
		self.chrRenderer.Show()
		
		return 1

	def SameLoginDisconnect(self):
		self.stream.popupWindow.Close()
		self.stream.popupWindow.Open(localeinfo.Get("LOGIN_FAILURE_SAMELOGIN"), self.ExitSelect, localeinfo.Get("UI_OK"))

	if app.ENABLE_ACCE_SYSTEM:
		def MakeCharacter(self, index, id, name, race, form, hair, acce =0):
			if 0 == id:
				return
			chr.CreateInstance(index)
			chr.SelectInstance(index)
			chr.SetVirtualID(index)
			chr.SetNameString(name)
			chr.SetRace(race)
			chr.SetArmor(form)
			chr.SetHair(hair)
			chr.SetAcce(acce)
			chr.Refresh()
			chr.SetMotionMode(chr.MOTION_MODE_GENERAL)
			chr.SetLoopMotion(chr.MOTION_INTRO_WAIT)
			chr.SetRotation(0.0)
	else:
		def MakeCharacter(self, index, id, name, race, form, hair):
			if 0 == id:
				return
			chr.CreateInstance(index)
			chr.SelectInstance(index)
			chr.SetVirtualID(index)
			chr.SetNameString(name)
			chr.SetRace(race)
			chr.SetArmor(form)
			chr.SetHair(hair)
			chr.Refresh()
			chr.SetMotionMode(chr.MOTION_MODE_GENERAL)
			chr.SetLoopMotion(chr.MOTION_INTRO_WAIT)
			chr.SetRotation(0.0)

	def StartGame(self):
		if self.sendedChangeNamePacket:
			return
		if self.changeNameFlag:
			self.OpenChangeNameDialog()
			return
		if -1 != self.startIndex:
			return
		if musicInfo.selectMusic != "":
			snd.FadeLimitOutMusic("miles/BGM/"+musicInfo.selectMusic, systemSetting.GetMusicVolume()*0.05)
		self.btnStart.SetUp()
		self.btnStart.Disable()
		self.btnDelete.SetUp()
		self.btnDelete.Disable()
		self.btnCreated.SetUp()
		self.btnCreated.Disable()
		self.dlgQuestion.Hide()
		self.stream.SetCharacterSlot(self.slot)
		self.selected = 1
		self.startIndex = self.slot
		id = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_ID)
		if 0 == id:
			self.CreateCharacter()
		for i in range(self.SLOT_COUNT):
			if False == chr.HasInstance(i):
				continue
			chr.SelectInstance(i)
			if i == self.slot:
				self.slot=self.slot
				continue

	def OpenChangeNameDialog(self):
		import uiCommon
		nameInputBoard = uiCommon.InputDialogWithDescription()
		nameInputBoard.SetTitle(localeinfo.Get("SELECT_CHANGE_NAME_TITLE"))
		nameInputBoard.SetAcceptEvent(ui.__mem_func__(self.AcceptInputName))
		nameInputBoard.SetCancelEvent(ui.__mem_func__(self.CancelInputName))
		nameInputBoard.SetMaxLength(chr.PLAYER_NAME_MAX_LEN)
		nameInputBoard.SetBoardWidth(200)
		nameInputBoard.SetDescription(localeinfo.Get("SELECT_INPUT_CHANGING_NAME"))
		nameInputBoard.Open()
		nameInputBoard.slot = self.slot
		self.nameInputBoard = nameInputBoard

	def OnChangeName(self, id, name):
		self.SelectSlot(id)
		self.sendedChangeNamePacket = False
		self.PopupMessage(localeinfo.Get("SELECT_CHANGED_NAME"))

	def AcceptInputName(self):
		changeName = self.nameInputBoard.GetText()
		if not changeName:
			return

		self.sendedChangeNamePacket = True
		net.SendChangeNamePacket(self.nameInputBoard.slot, changeName)
		return self.CancelInputName()

	def CancelInputName(self):
		self.nameInputBoard.Close()
		self.nameInputBoard = None
		return True

	def OnCreateFailure(self, type):
		self.sendedChangeNamePacket = False
		if 0 == type:
			self.PopupMessage(localeinfo.Get("SELECT_CHANGE_FAILURE_STRANGE_NAME"))
		elif 1 == type:
			self.PopupMessage(localeinfo.Get("SELECT_CHANGE_FAILURE_ALREADY_EXIST_NAME"))
		elif 100 == type:
			self.PopupMessage(localeinfo.Get("SELECT_CHANGE_FAILURE_STRANGE_INDEX"))

	def CreateCharacter(self):
		id = self.GetCharacterSlotID(self.slot)
		if 0==id:
			self.stream.SetCharacterSlot(self.slot)
			self.stream.SetCreateCharacterPhase()

	def __AreAllSlotEmpty(self):
		for iSlot in range(self.SLOT_COUNT):
			if 0!=net.GetAccountCharacterSlotDataInteger(iSlot, net.ACCOUNT_CHARACTER_SLOT_ID):
				return 0
		return 1

	def PopupDeleteQuestion(self):
		id = self.GetCharacterSlotID(self.slot)
		if 0 == id:
			return

		self.dlgQuestion.Show()
		self.dlgQuestion.SetTop()

	def RequestDeleteCharacter(self):
		self.dlgQuestion.Hide()

		id = self.GetCharacterSlotID(self.slot)
		if 0 == id:
			self.PopupMessage(localeinfo.Get("SELECT_EMPTY_SLOT"))
			return

		net.SendDestroyCharacterPacket(self.slot, "1234567")
		self.PopupMessage(localeinfo.Get("SELECT_DELEING"))

	def InputPrivateCode(self):

		import uiCommon
		privateInputBoard = uiCommon.InputDialogWithDescription()
		privateInputBoard.SetTitle(localeinfo.Get("INPUT_PRIVATE_CODE_DIALOG_TITLE"))
		privateInputBoard.SetAcceptEvent(ui.__mem_func__(self.AcceptInputPrivateCode))
		privateInputBoard.SetCancelEvent(ui.__mem_func__(self.CancelInputPrivateCode))

		if ENABLE_ENGNUM_DELETE_CODE:
			pass
		else:
			privateInputBoard.SetNumberMode()

		privateInputBoard.SetSecretMode()
		privateInputBoard.SetMaxLength(7)

		privateInputBoard.SetBoardWidth(250)
		privateInputBoard.SetDescription(localeinfo.Get("INPUT_PRIVATE_CODE_DIALOG_DESCRIPTION"))
		privateInputBoard.Open()
		self.privateInputBoard = privateInputBoard

	def AcceptInputPrivateCode(self):
		privateCode = self.privateInputBoard.GetText()
		if not privateCode:
			return

		id = self.GetCharacterSlotID(self.slot)
		if 0 == id:
			self.PopupMessage(localeinfo.Get("SELECT_EMPTY_SLOT"))
			return

		net.SendDestroyCharacterPacket(self.slot, privateCode)
		self.PopupMessage(localeinfo.Get("SELECT_DELEING"))

		self.CancelInputPrivateCode()
		return True

	def CancelInputPrivateCode(self):
		self.privateInputBoard = None
		return True

	def OnDeleteSuccess(self, slot):
		self.PopupMessage(localeinfo.Get("SELECT_DELETED"))
		self.DeleteCharacter(slot)

	def OnDeleteFailure(self):
		self.PopupMessage(localeinfo.Get("SELECT_CAN_NOT_DELETE"))

	def DeleteCharacter(self, index):
		chr.DeleteInstance(index)
		self.SelectSlot(self.slot)
		self.Refresh()

	def ExitSelect(self):
		self.Hide()
		self.dlgQuestion.Hide()
		self.stream.SetLoginPhase()

	def GetSlotIndex(self):
		return self.slot

	def DecreaseSlotIndex(self):
		if self.selected == 0:
			slotIndex = (self.GetSlotIndex() - 1 + self.SLOT_COUNT) % self.SLOT_COUNT
			self.SelectSlot(slotIndex)

	def IncreaseSlotIndex(self):
		if self.selected == 0:
			slotIndex = (self.GetSlotIndex() + 1) % self.SLOT_COUNT
			self.SelectSlot(slotIndex)

	def SelectSlot(self, index):

		if index < 0:
			return
		if index >= self.SLOT_COUNT:
			return

		self.slot = index
		
		for button in self.char:
			button.SetUp()

		self.char[index].Down()
		
		self.destGauge = [0.0, 0.0, 0.0, 0.0]
		
		for i in range(self.SLOT_COUNT):
			chr.DeleteInstance(i)

		chr.SelectInstance(self.slot)
		id = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_ID)
		if 0 != id:

			self.btnStart.Show()
			self.btnDelete.Show()
			self.btnCreated.Hide()

			level = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_LEVEL)
			race = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_RACE)
			name = net.GetAccountCharacterSlotDataString(self.slot, net.ACCOUNT_CHARACTER_SLOT_NAME)
			hair = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_HAIR)
			form = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_FORM)
			if app.ENABLE_ACCE_SYSTEM:
				acce = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_ACCE)
			self.changeNameFlag = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_CHANGE_NAME_FLAG)

			if app.ENABLE_ACCE_SYSTEM:
				self.MakeCharacter(self.slot, id, name, race, form, hair, acce)
			else:
				self.MakeCharacter(self.slot, id, name, race, form, hair)
			self.name.SetText(name)
			self.level.SetText(str(level))
			if net.GetAccountCharacterSlotDataString(self.slot, net.ACCOUNT_CHARACTER_SLOT_GUILD_NAME):
				self.guild.SetText(str(net.GetAccountCharacterSlotDataString(self.slot, net.ACCOUNT_CHARACTER_SLOT_GUILD_NAME)))
			else:
				self.guild.SetText("-")
			self.playtime.SetText(str(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_PLAYTIME)))
			self.empire.SetText(self.GetEmpireName(net.GetEmpireID()))
			
			self.CharacterHTH.SetText(str(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_HTH)))
			self.CharacterINT.SetText(str(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_INT)))
			self.CharacterSTR.SetText(str(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_STR)))
			self.CharacterDEX.SetText(str(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_DEX)))

			statesSummary = float(95)
			if statesSummary > 0.0:
				self.destGauge =	[
										float(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_HTH)) / statesSummary,
										float(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_INT)) / statesSummary,
										float(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_STR)) / statesSummary,
										float(net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_DEX)) / statesSummary
									]

		else:
			self.name.SetText("")
			self.level.SetText("")
			self.empire.SetText("")
			self.playtime.SetText("")
			self.guild.SetText("")
			self.CharacterHTH.SetText("0")
			self.CharacterINT.SetText("0")
			self.CharacterSTR.SetText("0")
			self.CharacterDEX.SetText("0")
			self.btnDelete.Hide()
			self.btnCreated.Show()
			self.btnStart.Hide()

	def OnKeyDown(self, key):
		if key == app.DIK_ESC:
			self.stream.SetLoginPhase()
		if 28 == key:
			id = net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_ID)
			if 0 == id:
				self.CreateCharacter()
			else:
				self.StartGame()

	def OnUpdate(self):
		chr.Update()
		for i in range(4):
			self.curGauge[i] += (self.destGauge[i] - self.curGauge[i]) / 10.0
			if abs(self.curGauge[i] - self.destGauge[i]) < 0.005:
				self.curGauge[i] = self.destGauge[i]
			self.GaugeList[i].SetPercentage(self.curGauge[i], 1.0)
		for i in range(self.SLOT_COUNT):
			if False == chr.HasInstance(i):
				continue
			chr.SelectInstance(i)
		if -1 != self.startIndex:
			if False == self.openLoadingFlag:
				chrSlot=self.stream.GetCharacterSlot()
				net.DirectEnter(chrSlot)
				self.openLoadingFlag = True
				playTime=net.GetAccountCharacterSlotDataInteger(self.slot, net.ACCOUNT_CHARACTER_SLOT_PLAYTIME)
				import chat
				chat.Clear()

	def EmptyFunc(self):
		pass

	def PopupMessage(self, msg, func=0):
		if not func:
			func=self.EmptyFunc

		self.stream.popupWindow.Close()
		self.stream.popupWindow.Open(msg, func, localeinfo.Get("UI_OK"))

	def OnPressExitKey(self):
		self.ExitSelect()
		return True

