FINAL ROOT V2 - PY314/X64

Base: previous merged root that fixed sidebar/quest buttons and black buildings.

Extra fixes in V2:
1) npclist.txt restored from the old Python 2.7 working root.
   The current roots were missing the alias rows with vnum 0, e.g.
   pony_normal -> pony, horse_normal -> horse, dog_god_0 -> dog_god,
   boar_0 -> boar, lion_0 -> lion, white pets/mount variants, etc.
   Without those aliases, the client tries to load wrong model folders and NPCs/mounts/pets/3D objects can appear invisible.

2) uiswitchbot.py fixed for Python 3.14.
   The bonus selector called ItemToolTip.AFFECT_DICT, but this root uses
   ItemToolTip.ITEM_AFFECT_LOCALE_KEYS + localeinfo.GetFormatted().
   On Python 3 this can raise AttributeError, so clicking bonus rows opens no list.
   Also added fallback max values when the switchbot table packet is empty.

Before testing:
- Delete all __pycache__, .pyc, .pyo from the client/root.
- Pack this root cleanly.
- Full client restart.
