﻿# -*- coding: utf-8 -*-
import dbg
import ui
import snd
import systemSetting
import net
import chat
import app
import localeinfo
import constInfo
import chrmgr
import player
import musicInfo
import uiSelectMusic
import background
import uiCommon

blockMode = 0
class OptionDialog(ui.ScriptWindow):

	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.__Initialize()
		self.__Load()

	def __del__(self):
		ui.ScriptWindow.__del__(self)
		print(" -------------------------------------- DELETE SYSTEM OPTION DIALOG")

	def __Initialize(self):
		self.tilingMode = 0
		self.titleBar = 0
		self.changeMusicButton = 0
		self.selectMusicFile = 0
		self.ctrlMusicVolume = 0
		self.ctrlSoundVolume = 0
		self.musicListDlg = 0
		self.tilingApplyButton = 0
		self.cameraModeButtonList = []
		self.fogModeButtonList = []
		self.tilingModeButtonList = []
		self.ctrlShadowQuality = 0
		if app.__BL_FOG_FIX__:
			self.fogButtonList	= []
		if app.STONE_SCALE_SYSTEM:
			self.ctrlStoneScale = 0
		if app.ENABLE_FOV_OPTION:
			self.ctrlFoveScale = 0
			self.fovValueText = 0
			self.fovResetButton = 0
		## MULTI_LANGUAGE
		## This will hold the dropdown menu for language selection
		self.languageComboBox = None
		## List of all available languages: (code, display_name)
		## These match the languages in your server's locale_json.cpp
		self.languageList = [
			("en", "English"),
			("de", "Deutsch"),
			("es", "Espanol"),
			("fr", "Francais"),
			("it", "Italiano"),
			("pt", "Portugues"),
			("gr", "Greek"),
			("tr", "Turkce"),
			("hu", "Magyar"),
			("pl", "Polski"),
			("ro", "Romana"),
			("cz", "Cestina"),
		]
		self.pendingLangCode = None
		self.pendingLangName = None
		self.languageConfirmDialog = None
		## END MULTI_LANGUAGE
		
	def Destroy(self):
		self.ClearDictionary()
		self.__Initialize()
		print(" -------------------------------------- DESTROY SYSTEM OPTION DIALOG")

	def __Load_LoadScript(self, fileName):
		try:
			pyScriptLoader = ui.PythonScriptLoader()
			pyScriptLoader.LoadScriptFile(self, fileName)
		except:
			import exception
			exception.Abort("System.OptionDialog.__Load_LoadScript")

	def __Load_BindObject(self):
		try:
			GetObject = self.GetChild
			self.titleBar = GetObject("titlebar")
			self.selectMusicFile = GetObject("bgm_file")
			self.changeMusicButton = GetObject("bgm_button")
			self.ctrlMusicVolume = GetObject("music_volume_controller")
			self.ctrlSoundVolume = GetObject("sound_volume_controller")			
			self.cameraModeButtonList.append(GetObject("camera_short"))
			self.cameraModeButtonList.append(GetObject("camera_long"))
			if app.__BL_FOG_FIX__:
				self.fogButtonList.append(GetObject("fog_off"))
				self.fogButtonList.append(GetObject("fog_on"))
			else:
				self.fogModeButtonList.append(GetObject("fog_level0"))
				self.fogModeButtonList.append(GetObject("fog_level1"))
				self.fogModeButtonList.append(GetObject("fog_level2"))
			if app.STONE_SCALE_SYSTEM:
				self.ctrlStoneScale = GetObject("stone_scale_controller")
			if app.ENABLE_FOV_OPTION:
				self.ctrlFoveScale = GetObject("fove_scale_controller")
				self.fovValueText = GetObject("fov_value_text")
				self.fovResetButton = GetObject("fov_reset_button")
			self.tilingModeButtonList.append(GetObject("tiling_cpu"))
			self.tilingModeButtonList.append(GetObject("tiling_gpu"))
			self.tilingApplyButton=GetObject("tiling_apply")
		except:
			import exception
			exception.Abort("OptionDialog.__Load_BindObject")

	def __Load(self):
		self.__Load_LoadScript("uiscript/systemoptiondialog.py")
		self.__Load_BindObject()

		self.SetCenterPosition()
		
		self.titleBar.SetCloseEvent(ui.__mem_func__(self.Close))

		self.ctrlMusicVolume.SetSliderPos(float(systemSetting.GetMusicVolume()))
		self.ctrlMusicVolume.SetEvent(ui.__mem_func__(self.OnChangeMusicVolume))

		self.ctrlSoundVolume.SetSliderPos(float(systemSetting.GetSoundVolume()) / 5.0)
		self.ctrlSoundVolume.SetEvent(ui.__mem_func__(self.OnChangeSoundVolume))
		self.changeMusicButton.SAFE_SetEvent(self.__OnClickChangeMusicButton)

		self.cameraModeButtonList[0].SAFE_SetEvent(self.__OnClickCameraModeShortButton)
		self.cameraModeButtonList[1].SAFE_SetEvent(self.__OnClickCameraModeLongButton)

		if app.__BL_FOG_FIX__:
			self.fogButtonList[0].SAFE_SetEvent(self.__OnClickFogModeOffButton)
			self.fogButtonList[1].SAFE_SetEvent(self.__OnClickFogModeOnButton)
		else:
			self.fogModeButtonList[0].SAFE_SetEvent(self.__OnClickFogModeLevel0Button)
			self.fogModeButtonList[1].SAFE_SetEvent(self.__OnClickFogModeLevel1Button)
			self.fogModeButtonList[2].SAFE_SetEvent(self.__OnClickFogModeLevel2Button)

		if app.STONE_SCALE_SYSTEM:
			self.ctrlStoneScale.SetSliderPos(float(systemSetting.GetStoneScale()))
			self.ctrlStoneScale.SetEvent(ui.__mem_func__(self.OnChangeStoneScale))

		if app.ENABLE_FOV_OPTION:
			self.ctrlFoveScale.SetSliderPos(float(systemSetting.GetFOV()) / float(app.MAX_CAMERA_PERSPECTIVE))
			self.ctrlFoveScale.SetEvent(ui.__mem_func__(self.__OnChangeFOV))
			if self.fovValueText:
				self.fovValueText.SetText(str(int(systemSetting.GetFOV()))+ chr(176))
			if self.fovResetButton:
				self.fovResetButton.SetEvent(ui.__mem_func__(self.__OnClickFOVResetButton))

		self.tilingModeButtonList[0].SAFE_SetEvent(self.__OnClickTilingModeCPUButton)
		self.tilingModeButtonList[1].SAFE_SetEvent(self.__OnClickTilingModeGPUButton)

		self.tilingApplyButton.SAFE_SetEvent(self.__OnClickTilingApplyButton)

		## MULTI_LANGUAGE
		## Create the language dropdown (ComboBox) programmatically
		## We create it in code because ComboBox needs special setup
		self.languageComboBox = ui.ComboBox()
		self.languageComboBox.SetParent(self.GetChild("board"))  ## Attach to the board
		self.languageComboBox.SetPosition(90, 263)               ## Position next to the label
		self.languageComboBox.SetSize(150, 15)                   ## Width=150, Height=15
		self.languageComboBox.SetEvent(self.__OnSelectLanguage)  ## Called when user selects

		## Add all languages to the dropdown
		## index = position in list (0, 1, 2...)
		## langCode = "en", "de", etc.
		## langName = "English", "Deutsch", etc.
		for index, (langCode, langName) in enumerate(self.languageList):
			self.languageComboBox.InsertItem(index, langName)

		## Load saved language from config open(me.a)
		savedLang = systemSetting.GetLanguage()
		selectedIndex = 0
		for index, (langCode, langName) in enumerate(self.languageList):
			if langCode == savedLang:
				selectedIndex = index
				break
		self.languageComboBox.SetCurrentItem(self.languageList[selectedIndex][1])
		self.languageComboBox.Show()
		## END MULTI_LANGUAGE

		self.__SetCurTilingMode()

		self.__ClickRadioButton(self.fogModeButtonList, constInfo.GET_FOG_LEVEL_INDEX())
		self.__ClickRadioButton(self.cameraModeButtonList, constInfo.GET_CAMERA_MAX_DISTANCE_INDEX())

		if app.__BL_FOG_FIX__:
			self.__ClickRadioButton(self.fogButtonList, background.GetFogMode())

		if musicInfo.fieldMusic==musicInfo.METIN2THEMA:
			self.selectMusicFile.SetText(uiSelectMusic.DEFAULT_THEMA)
		else:
			self.selectMusicFile.SetText(musicInfo.fieldMusic[:25])

	def __OnClickTilingModeCPUButton(self):
		#MULTI_LANGUAGE
		self.__NotifyChatLine(localeinfo.Get("SYSTEM_OPTION_CPU_TILING_1"))
		self.__NotifyChatLine(localeinfo.Get("SYSTEM_OPTION_CPU_TILING_2"))
		self.__NotifyChatLine(localeinfo.Get("SYSTEM_OPTION_CPU_TILING_3"))
		#MULTI_LANGUAGE
		self.__SetTilingMode(0)

	def __OnClickTilingModeGPUButton(self):
		#MULTI_LANGUAGE
		self.__NotifyChatLine(localeinfo.Get("SYSTEM_OPTION_GPU_TILING_1"))
		self.__NotifyChatLine(localeinfo.Get("SYSTEM_OPTION_GPU_TILING_2"))
		self.__NotifyChatLine(localeinfo.Get("SYSTEM_OPTION_GPU_TILING_3"))
		#MULTI_LANGUAGE
		self.__SetTilingMode(1)

	def __OnClickTilingApplyButton(self):
		#MULTI_LANGUAGE
		self.__NotifyChatLine(localeinfo.Get("SYSTEM_OPTION_TILING_EXIT"))
		#MULTI_LANGUAGE
		if 0==self.tilingMode:
			background.EnableSoftwareTiling(1)
		else:
			background.EnableSoftwareTiling(0)

		net.ExitGame()

	def __OnClickChangeMusicButton(self):
		if not self.musicListDlg:
			
			self.musicListDlg=uiSelectMusic.FileListDialog()
			self.musicListDlg.SAFE_SetSelectEvent(self.__OnChangeMusic)

		self.musicListDlg.Open()

		
	def __ClickRadioButton(self, buttonList, buttonIndex):
		try:
			selButton=buttonList[buttonIndex]
		except IndexError:
			return

		for eachButton in buttonList:
			eachButton.SetUp()

		selButton.Down()


	def __SetTilingMode(self, index):
		self.__ClickRadioButton(self.tilingModeButtonList, index)
		self.tilingMode=index

	def __SetCameraMode(self, index):
		constInfo.SET_CAMERA_MAX_DISTANCE_INDEX(index)
		self.__ClickRadioButton(self.cameraModeButtonList, index)

	def __SetFogLevel(self, index):
		constInfo.SET_FOG_LEVEL_INDEX(index)
		self.__ClickRadioButton(self.fogModeButtonList, index)

	def __OnClickCameraModeShortButton(self):
		self.__SetCameraMode(0)

	def __OnClickCameraModeLongButton(self):
		self.__SetCameraMode(1)

	def __OnClickFogModeLevel0Button(self):
		self.__SetFogLevel(0)

	def __OnClickFogModeLevel1Button(self):
		self.__SetFogLevel(1)

	def __OnClickFogModeLevel2Button(self):
		self.__SetFogLevel(2)

	if app.__BL_FOG_FIX__:
		def __OnClickFogModeOnButton(self):
			background.SetFogMode(True)
			self.__ClickRadioButton(self.fogButtonList, 1)
		def __OnClickFogModeOffButton(self):
			background.SetFogMode(False)
			self.__ClickRadioButton(self.fogButtonList, 0)

	if app.STONE_SCALE_SYSTEM:
		def OnChangeStoneScale(self):
			pos = self.ctrlStoneScale.GetSliderPos()
			systemSetting.SetStoneScale(pos)

	if app.ENABLE_FOV_OPTION:
		def __OnChangeFOV(self):
			pos = self.ctrlFoveScale.GetSliderPos()
			systemSetting.SetFOV(pos * float(app.MAX_CAMERA_PERSPECTIVE))
			if self.fovValueText:
				self.fovValueText.SetText(str(int(systemSetting.GetFOV()))+ chr(176))

		def __OnClickFOVResetButton(self):
			self.ctrlFoveScale.SetSliderPos(float(app.DEFAULT_CAMERA_PERSPECTIVE) / float(app.MAX_CAMERA_PERSPECTIVE))
			systemSetting.SetFOV(float(app.DEFAULT_CAMERA_PERSPECTIVE))
			if self.fovValueText:
				self.fovValueText.SetText(str(int(systemSetting.GetFOV()))+ chr(176))

	def __OnChangeMusic(self, fileName):
		self.selectMusicFile.SetText(fileName[:25])

		if musicInfo.fieldMusic != "":
			snd.FadeOutMusic("miles/BGM/"+ musicInfo.fieldMusic)

		if fileName==uiSelectMusic.DEFAULT_THEMA:
			musicInfo.fieldMusic=musicInfo.METIN2THEMA
		else:
			musicInfo.fieldMusic=fileName

		musicInfo.SaveLastPlayFieldMusic()
		
		if musicInfo.fieldMusic != "":
			snd.FadeInMusic("miles/BGM/" + musicInfo.fieldMusic)

	def OnChangeMusicVolume(self):
		pos = self.ctrlMusicVolume.GetSliderPos()
		snd.SetMusicVolume(pos * net.GetFieldMusicVolume())
		systemSetting.SetMusicVolume(pos)

	def OnChangeSoundVolume(self):
		pos = self.ctrlSoundVolume.GetSliderPos()
		snd.SetSoundVolumef(pos)
		systemSetting.SetSoundVolumef(pos)

	def OnChangeShadowQuality(self):
		pos = self.ctrlShadowQuality.GetSliderPos()
		systemSetting.SetShadowLevel(int(pos / 0.2))

	def OnCloseInputDialog(self):
		self.inputDialog.Close()
		self.inputDialog = None
		return True

	def OnCloseQuestionDialog(self):
		self.questionDialog.Close()
		self.questionDialog = None
		return True

	def OnPressEscapeKey(self):
		self.Close()
		return True
	
	def Show(self):
		ui.ScriptWindow.Show(self)

	def Close(self):
		try:
			if self.languageComboBox:
				self.languageComboBox.CloseListBox()
		except:
			pass
		if self.languageConfirmDialog:
			self.languageConfirmDialog.Close()
			self.languageConfirmDialog = None
		self.__SetCurTilingMode()
		self.Hide()

	def __SetCurTilingMode(self):
		if background.IsSoftwareTiling():
			self.__SetTilingMode(0)
		else:
			self.__SetTilingMode(1)	

	def __NotifyChatLine(self, text):
		chat.AppendChat(chat.CHAT_TYPE_INFO, text)

	## MULTI_LANGUAGE
	def __OnSelectLanguage(self, index):
		## Get the language code and name from our list
		langCode, langName = self.languageList[index]

		## Check if language is actually changing
		currentLang = systemSetting.GetLanguage()
		if langCode == currentLang:
			return

		## Store pending language for confirmation
		self.pendingLangCode = langCode
		self.pendingLangName = langName

		## Show confirmation dialog - player will be teleported
		## Keep the ComboBox/list from staying in TOP_MOST and stealing the Yes/No click.
		try:
			self.languageComboBox.CloseListBox()
		except:
			pass

		if self.languageConfirmDialog:
			self.languageConfirmDialog.Close()
			self.languageConfirmDialog = None

		self.languageConfirmDialog = uiCommon.QuestionDialog()
		self.languageConfirmDialog.SetText(localeinfo.Get("LANGUAGE_CHANGE_CONFIRM"))
		self.languageConfirmDialog.SAFE_SetAcceptEvent(ui.__mem_func__(self.__OnConfirmLanguageChange))
		self.languageConfirmDialog.SAFE_SetCancelEvent(ui.__mem_func__(self.__OnCancelLanguageChange))
		self.languageConfirmDialog.Open()
		try:
			self.languageConfirmDialog.SetTop()
		except:
			pass

	def __OnConfirmLanguageChange(self):
		if self.languageConfirmDialog:
			self.languageConfirmDialog.Close()
			self.languageConfirmDialog = None

		if not self.pendingLangCode:
			return

		langCode = self.pendingLangCode
		langName = self.pendingLangName

		## Update the dropdown to show the selected language
		self.languageComboBox.SetCurrentItem(langName)

		## Save to config open(me.a) for persistence
		systemSetting.SetLanguage(langCode)
		systemSetting.SaveConfig()

		## Close options window
		self.Close()

		## Teleport to refresh locale (language already saved to config)
		net.SendChatPacket("/refresh_locale")

		## Clear pending
		self.pendingLangCode = None
		self.pendingLangName = None

	def __OnCancelLanguageChange(self):
		if self.languageConfirmDialog:
			self.languageConfirmDialog.Close()
			self.languageConfirmDialog = None

		## Restore dropdown to current language
		currentLang = systemSetting.GetLanguage()
		for index, (langCode, langName) in enumerate(self.languageList):
			if langCode == currentLang:
				self.languageComboBox.SetCurrentItem(langName)
				break

		## Clear pending
		self.pendingLangCode = None
		self.pendingLangName = None
	## MULTI_LANGUAGE


