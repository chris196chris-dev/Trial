# -*- coding: utf-8 -*-
import app
import net
import ui
import os
import snd
import wndMgr
import systemSetting
import localeinfo
import constInfo
import ime
import uiScriptLocale
import serverInfo
from _weakref import proxy

import winreg as _winreg

REG_PATH = r"SOFTWARE\Nirvana Project"


def set_reg(name, value):
	try:
		_winreg.CreateKey(_winreg.HKEY_CURRENT_USER, REG_PATH)
		registry_key = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, REG_PATH, 0, _winreg.KEY_WRITE)
		_winreg.SetValueEx(registry_key, name, 0, _winreg.REG_SZ, value)
		_winreg.CloseKey(registry_key)
		return True
	except OSError:
		return False


def get_reg(name):
	try:
		registry_key = _winreg.OpenKey(_winreg.HKEY_CURRENT_USER, REG_PATH, 0, _winreg.KEY_READ)
		value, regtype = _winreg.QueryValueEx(registry_key, name)
		_winreg.CloseKey(registry_key)
		return str(value)
	except OSError:
		return None


class LoginWindow(ui.ScriptWindow):
	def __init__(self, stream):
		ui.ScriptWindow.__init__(self)

		net.SetPhaseWindow(net.PHASE_WINDOW_LOGIN, self)
		net.SetAccountConnectorHandler(self)

		self.stream = stream

	def __del__(self):
		ui.ScriptWindow.__del__(self)

		net.ClearPhaseWindow(net.PHASE_WINDOW_LOGIN, self)
		net.SetAccountConnectorHandler(0)

	def Open(self):
		# MULTI_LANGUAGE - Dynamic lookup for login failure messages
		self.loginFailureMsgKeys = {
			"ALREADY": "LOGIN_FAILURE_ALREAY",
			"NOID": "LOGIN_FAILURE_NOT_EXIST_ID",
			"WRONGPWD": "LOGIN_FAILURE_WRONG_PASSWORD",
			"FULL": "LOGIN_FAILURE_TOO_MANY_USER",
			"SHUTDOWN": "LOGIN_FAILURE_SHUTDOWN",
			"REPAIR": "LOGIN_FAILURE_REPAIR_ID",
			"BLOCK": "LOGIN_FAILURE_BLOCK_ID",
			"BESAMEKEY": "LOGIN_FAILURE_BE_SAME_KEY",
			"NOTAVAIL": "LOGIN_FAILURE_NOT_AVAIL",
			"NOBILL": "LOGIN_FAILURE_NOBILL",
			"BLKLOGIN": "LOGIN_FAILURE_BLOCK_LOGIN",
			"WEBBLK": "LOGIN_FAILURE_WEB_BLOCK",
			"NOCLIENT": "LOGIN_FAILURE_WRONG_PASSWORD",
			"QUIIT": "LOGIN_FAILURI_SPAMME_FIX",
		}

		self.loginFailureFuncDict = {
			"QUIT": app.Exit,
			"QUIIT": app.Exit,
		}
		# MULTI_LANGUAGE

		self.SetSize(wndMgr.GetScreenWidth(), wndMgr.GetScreenHeight())
		self.SetWindowName("LoginWindow")

		self.__LoadScript("sistimata/code/loginwindow.py")

		self.CheckAccount()

		ime.AddExceptKey(91)
		ime.AddExceptKey(93)
		self.SetChannel(0)

		self.Show()
		app.ShowCursor()

	def Close(self):
		if self.stream.popupWindow:
			self.stream.popupWindow.Close()

		self.Hide()
		app.HideCursor()
		ime.ClearExceptKey()

	def OnConnectFailure(self):
		snd.PlaySound("sound/ui/loginfail.wav")
		self.PopupNotifyMessage(localeinfo.Get("LOGIN_CONNECT_FAILURE"), self.EmptyFunc)

	def OnHandShake(self):
		snd.PlaySound("sound/ui/loginok.wav")
		self.PopupDisplayMessage(localeinfo.Get("LOGIN_CONNECT_SUCCESS"))
		constInfo.ACCOUNT_NAME = str(self.idEditLine.GetText())

	def OnLoginStart(self):
		self.PopupDisplayMessage(localeinfo.Get("LOGIN_PROCESSING"))

	def OnLoginFailure(self, error):
		# MULTI_LANGUAGE - Dynamic lookup
		if error in self.loginFailureMsgKeys:
			loginFailureMsg = localeinfo.Get(self.loginFailureMsgKeys[error])
		else:
			loginFailureMsg = localeinfo.Get("LOGIN_FAILURE_UNKNOWN") + error
		# MULTI_LANGUAGE

		loginFailureFunc = self.loginFailureFuncDict.get(error, self.EmptyFunc)

		self.PopupNotifyMessage(loginFailureMsg, loginFailureFunc)

		snd.PlaySound("sound/ui/loginfail.wav")

	def __LoadScript(self, fileName):
		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, fileName)
		except:
			import exception
			exception.Abort("LoginWindow.__LoadScript.LoadObject")

		try:
			self.idEditLine = self.GetChild("id")
			self.pwdEditLine = self.GetChild("pwd")
			if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
				self.pinEditLine = self.GetChild("pin")
			self.loginButton = self.GetChild("login_button")
			self.exitButton = self.GetChild("exit_button")

			self.channelButton = {
				0: self.GetChild("ch1"),
				1: self.GetChild("ch2"),
				2: self.GetChild("ch3"),
				3: self.GetChild("ch4"),
			}

			self.accountData = {
				0: [[self.GetChild("delete_button_0"), self.GetChild("save_button_0"), self.GetChild("load_button_0")], self.GetChild("account_0_text")],
				1: [[self.GetChild("delete_button_1"), self.GetChild("save_button_1"), self.GetChild("load_button_1")], self.GetChild("account_1_text")],
				2: [[self.GetChild("delete_button_2"), self.GetChild("save_button_2"), self.GetChild("load_button_2")], self.GetChild("account_2_text")],
				3: [[self.GetChild("delete_button_3"), self.GetChild("save_button_3"), self.GetChild("load_button_3")], self.GetChild("account_3_text")],
			}

		except:
			import exception
			exception.Abort("LoginWindow.__LoadScript.BindObject")

		for (key, item) in self.accountData.items():
			if isinstance(item[0], list):
				item[0][0].SetEvent(ui.__mem_func__(self.DeleteAccount), key)
				item[0][1].SetEvent(ui.__mem_func__(self.SaveAccount), key)
				item[0][2].SetEvent(ui.__mem_func__(self.LoadAccount), key)

		for (channelID, channelButtons) in self.channelButton.items():
			channelButtons.SetEvent(ui.__mem_func__(self.SetChannel), channelID)

		self.loginButton.SetEvent(ui.__mem_func__(self.__OnClickLoginButton))
		self.exitButton.SetEvent(ui.__mem_func__(self.OnPressExitKey))

		self.idEditLine.SetReturnEvent(ui.__mem_func__(self.pwdEditLine.SetFocus))
		self.idEditLine.SetTabEvent(ui.__mem_func__(self.pwdEditLine.SetFocus))

		self.pwdEditLine.SetReturnEvent(ui.__mem_func__(self.__OnClickLoginButton))
		if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
			self.pwdEditLine.SetTabEvent(ui.__mem_func__(self.pinEditLine.SetFocus))
		else:
			self.pwdEditLine.SetTabEvent(ui.__mem_func__(self.idEditLine.SetFocus))

		if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
			self.pinEditLine.SetReturnEvent(ui.__mem_func__(self.__OnClickLoginButton))
			self.pinEditLine.SetTabEvent(ui.__mem_func__(self.idEditLine.SetFocus))

	def CheckAccount(self):
		for i in range(4):
			if get_reg("id_%d" % i):
				self.accountData[i][1].SetText(str(get_reg("id_%d" % i)))
				self.accountData[i][0][1].Hide()
				self.accountData[i][0][0].Show()
			else:
				self.accountData[i][1].SetText(uiScriptLocale.LOGIN_ACCOUNT_EMPTY)
				self.accountData[i][0][1].Show()
				self.accountData[i][0][0].Hide()

	def DeleteAccount(self, key):
		if get_reg("id_%d" % key):
			set_reg("id_%d" % key, "")
			set_reg("pwd_%d" % key, "")
			if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
				set_reg("pin_%d" % key, "")
			self.PopupNotifyMessage(uiScriptLocale.LOGIN_ACCOUNT_DELETE)
		else:
			self.PopupNotifyMessage(uiScriptLocale.LOGIN_ACCOUNT_D_S)

		self.CheckAccount()

	def LoadAccount(self, key):
		if get_reg("id_%d" % key):
			self.idEditLine.SetText(str(get_reg("id_%d" % key)))
			self.pwdEditLine.SetText(str(get_reg("pwd_%d" % key)))
			self.pwdEditLine.SetFocus()
			if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
				self.pinEditLine.SetText(str(get_reg("pin_%d" % key)))
				self.pinEditLine.SetFocus()
		else:
			self.PopupNotifyMessage(uiScriptLocale.LOGIN_ACCOUNT_N_S)

	def SaveAccount(self, key):
		if get_reg("id_%d" % key):
			self.PopupNotifyMessage(uiScriptLocale.LOGIN_ACCOUNT_N_S_D)
			return

		if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
			if self.idEditLine.GetText() == "" or self.pwdEditLine.GetText() == "" or self.pinEditLine.GetText() == "":
				self.PopupNotifyMessage(uiScriptLocale.LOGIN_ACCOUNT_SAVE)
				return
		else:
			if self.idEditLine.GetText() == "" or self.pwdEditLine.GetText() == "":
				self.PopupNotifyMessage(uiScriptLocale.LOGIN_ACCOUNT_SAVE)
				return

		set_reg("id_%d" % key, self.idEditLine.GetText())
		set_reg("pwd_%d" % key, self.pwdEditLine.GetText())
		if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
			set_reg("pin_%d" % key, self.pinEditLine.GetText())
		self.PopupNotifyMessage(uiScriptLocale.LOGIN_ACCOUNT_SAVED)
		self.CheckAccount()

	def SetChannel(self, ch):
		for key, button in self.channelButton.items():
			button.SetUp()

		self.channelButton[ch].Down()

		self.stream.SetConnectInfo(serverInfo.SERVER_IP, self.ChannelPort(ch, 0), serverInfo.SERVER_IP, self.ChannelPort("LOGIN"))
		net.SetMarkServer(serverInfo.SERVER_IP, self.ChannelPort("LOGO"))
		app.SetGuildMarkPath("10.tga")
		app.SetGuildSymbolPath("10")
		net.SetServerInfo(self.ChannelPort(ch, 2))
		constInfo.CURRENT_CHANNEL = ch

	def ChannelPort(self, ch, value=0):
		channel = {
			0: serverInfo.CH1_PORT,
			1: serverInfo.CH2_PORT,
			2: serverInfo.CH3_PORT,
			3: serverInfo.CH4_PORT,
		}

		if ch == "LOGIN":
			return serverInfo.PORT_AUTH
		elif ch == "LOGO":
			return channel[0]
		elif value == 2:
			return serverInfo.NUME_SERVER + ", " + localeinfo.Get("CHANNEL_NAME") + " %s" % (ch + 1)
		else:
			return channel[ch]

	if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
		def Connect(self, id, pwd, pin):
			self.stream.popupWindow.Close()
			self.stream.popupWindow.Open(localeinfo.Get("LOGIN_CONNETING"), self.EmptyFunc, localeinfo.Get("UI_CANCEL"))
			self.stream.SetLoginInfo(id, pwd, pin)
			self.stream.Connect()
	else:
		def Connect(self, id, pwd):
			self.stream.popupWindow.Close()
			self.stream.popupWindow.Open(localeinfo.Get("LOGIN_CONNETING"), self.EmptyFunc, localeinfo.Get("UI_CANCEL"))
			self.stream.SetLoginInfo(id, pwd)
			self.stream.Connect()

	def PopupDisplayMessage(self, msg):
		self.stream.popupWindow.Close()
		self.stream.popupWindow.Open(msg)

	def PopupNotifyMessage(self, msg, func=0):
		if not func:
			func = self.EmptyFunc

		self.stream.popupWindow.Close()
		self.stream.popupWindow.Open(msg, func, localeinfo.Get("UI_OK"))

	def OnPressExitKey(self):
		if self.stream.popupWindow:
			self.stream.popupWindow.Close()
		self.stream.SetPhaseWindow(0)
		return True

	def EmptyFunc(self):
		pass

	if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
		def __OnClickLoginButton(self):
			id = self.idEditLine.GetText()
			pwd = self.pwdEditLine.GetText()
			pin = self.pinEditLine.GetText()
			if len(id) == 0:
				self.PopupNotifyMessage(localeinfo.Get("LOGIN_INPUT_ID"), self.EmptyFunc)
				return
			if len(pwd) == 0 or len(pin) == 0:
				self.PopupNotifyMessage(localeinfo.Get("LOGIN_INPUT_PASSWORD"), self.EmptyFunc)
				return
			self.Connect(id, pwd, pin)
	else:
		def __OnClickLoginButton(self):
			id = self.idEditLine.GetText()
			pwd = self.pwdEditLine.GetText()
			if len(id) == 0:
				self.PopupNotifyMessage(localeinfo.Get("LOGIN_INPUT_ID"), self.EmptyFunc)
				return
			if len(pwd) == 0:
				self.PopupNotifyMessage(localeinfo.Get("LOGIN_INPUT_PASSWORD"), self.EmptyFunc)
				return
			self.Connect(id, pwd)
