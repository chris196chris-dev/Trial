# -*- coding: utf-8 -*-
import uiScriptLocale

window = {
	"name" : "SafeBoxInventoryWindow",

	"x" : SCREEN_WIDTH - 365 - 425,
	"y" : SCREEN_HEIGHT - 37 - 320,

	"style" : ("movable", "float",),

	"width" : 210,
	"height" : 80,

	"children" :
	(
		{
			"name" : "board",
			"type" : "board",
			"style" : ("attach",),
			"x" : 0,
			"y" : 0,
			"width" : 210,
			"height" : 80,
			"children" :
			(
				## Title
				{
					"name" : "TitleBar",
					"type" : "titlebar",
					"style" : ("attach",),

					"x" : 6,
					"y" : 6,

					"width" : 200,
					"color" : "yellow",

					"children" :
					(
						{ "name":"TitleName", "type":"text", "x":100, "y":3, "text":uiScriptLocale.SAFE_TITLE, "text_horizontal_align":"center" },
					),
				},

				{
					"name" : "SafeboxOpen",
					"type" : "button",
					"x" : 15,
					"y" : 37,
					"default_image" : "sistimata/safebox/is_01.tga",
					"over_image" : "sistimata/safebox/is_02.tga",
					"down_image" : "sistimata/safebox/is_03.tga",
				},

				{
					"name" : "ItemShopOpen",
					"type" : "button",
					"x" : 110,
					"y" : 37,
					"default_image" : "sistimata/safebox/safebox_1.tga",
					"over_image" : "sistimata/safebox/safebox_2.tga",
					"down_image" : "sistimata/safebox/safebox_3.tga",
				},

			),
		},
	),
}
