# -*- coding: utf-8 -*-
import uiScriptLocale
import item

BOARD_WIDTH = 180
BOARD_HEIGHT = 290
COSTUME_BUTTON_TEXT = uiScriptLocale.COSTUME_TITLE
MALL_BUTTON_TEXT = uiScriptLocale.MALL_TITLE
PREMIUM_SHOP_BUTTON_TEXT = uiScriptLocale.PREMIUM_PRIVATE_SHOP

window = {
	"name" : "EquipmentDialog",
	"style" : ("movable", "float",),

	"x" : SCREEN_WIDTH - BOARD_WIDTH - 40,
	"y" : 97,

	"width" : BOARD_WIDTH,
	"height" : BOARD_HEIGHT,

	"children" :
	(
		{
			"name" : "board",
			"type" : "board_with_titlebar",

			"x" : 0,
			"y" : 0,

			"width" : BOARD_WIDTH,
			"height" : BOARD_HEIGHT,

			"title" : uiScriptLocale.EQUIPMENT_TITLE,

			"children" :
			(
				{
					"name" : "base_tab",
					"type" : "image",
					"x" : 12,
					"y" : 33,
					"image" : "d:/ymir work/ui/equipment_bg_without_ring_tab00.tga",
				},
				{
					"name" : "equipment_window",
					"type" : "window",
					"x" : 0,
					"y" : 56,
					"width" : BOARD_WIDTH,
					"height" : BOARD_HEIGHT - 56,

					"children" :
					(
						{
							"name" : "EquipmentBaseImage",
							"type" : "image",
							"style" : ("attach",),
							"x" : 0,
							"y" : 0,
							"horizontal_align" : "center",
							"image" : "d:/ymir work/ui/equipment_bg_without_ring.tga",

							"children" :
							(
								{
									"name" : "EquipmentSlot",
									"type" : "slot",
									"x" : 3,
									"y" : 3,
									"width" : 150,
									"height" : 140,

									"slot" :
									(
										{"index":item.EQUIPMENT_BODY,    "x":39,  "y":37,  "width":32, "height":64},
										{"index":item.EQUIPMENT_HEAD,    "x":39,  "y":2,   "width":32, "height":32},
										{"index":item.EQUIPMENT_SHOES,   "x":4,   "y":99,  "width":32, "height":32},
										{"index":item.EQUIPMENT_WRIST,   "x":75,  "y":67,  "width":32, "height":32},
										{"index":item.EQUIPMENT_WEAPON,  "x":3,   "y":3,   "width":32, "height":96},
										{"index":item.EQUIPMENT_NECK,    "x":114, "y":67,  "width":32, "height":32},
										{"index":item.EQUIPMENT_EAR,     "x":114, "y":35,  "width":32, "height":32},
										{"index":item.EQUIPMENT_ARROW,   "x":114, "y":2,   "width":32, "height":32},
										{"index":item.EQUIPMENT_SHIELD,  "x":75,  "y":35,  "width":32, "height":32},
										{"index":item.EQUIPMENT_BELT,    "x":39,  "y":99,  "width":32, "height":32},
									),
								},
								{
									"name" : "UniqueSlot",
									"type" : "slot",
									"x" : 3,
									"y" : 140,
									"width" : 150,
									"height" : 36,

									"slot" :
									(
										{"index":item.EQUIPMENT_UNIQUE1, "x":2,  "y":7, "width":32, "height":32},
										{"index":item.EQUIPMENT_UNIQUE2, "x":39, "y":7, "width":32, "height":32},
										{"index":item.EQUIPMENT_RING1,   "x":76, "y":7, "width":32, "height":32},
										{"index":item.EQUIPMENT_RING2,   "x":113,"y":7, "width":32, "height":32},
									),
								},
								{
									"name" : "Equipment_Tab_01",
									"type" : "radio_button",
									"x" : 86,
									"y" : 161,
									"default_image" : "d:/ymir work/ui/game/windows/tab_button_small_01.sub",
									"over_image" : "d:/ymir work/ui/game/windows/tab_button_small_02.sub",
									"down_image" : "d:/ymir work/ui/game/windows/tab_button_small_03.sub",
									"children" :
									(
										{"name" : "Equipment_Tab_01_Print", "type" : "text", "x" : 0, "y" : 0, "all_align" : "center", "text" : "I"},
									),
								},
								{
									"name" : "Equipment_Tab_02",
									"type" : "radio_button",
									"x" : 118,
									"y" : 161,
									"default_image" : "d:/ymir work/ui/game/windows/tab_button_small_01.sub",
									"over_image" : "d:/ymir work/ui/game/windows/tab_button_small_02.sub",
									"down_image" : "d:/ymir work/ui/game/windows/tab_button_small_03.sub",
									"children" :
									(
										{"name" : "Equipment_Tab_02_Print", "type" : "text", "x" : 0, "y" : 0, "all_align" : "center", "text" : "II"},
									),
								},
							),
						},
						{
							"name" : "DSSButton",
							"type" : "button",
							"x" : 18,
							"y" : 186,
							"tooltip_text" : uiScriptLocale.TASKBAR_DRAGON_SOUL,
							"default_image" : "d:/ymir work/ui/dragonsoul/DragonSoul_Button_01.tga",
							"over_image" : "d:/ymir work/ui/dragonsoul/DragonSoul_Button_02.tga",
							"down_image" : "d:/ymir work/ui/dragonsoul/DragonSoul_Button_03.tga",
						},
						{
							"name" : "MallButton",
							"type" : "button",
							"x" : 53,
							"y" : 186,
							"tooltip_text" : MALL_BUTTON_TEXT,
							"default_image" : "d:/ymir work/ui/game/taskbar/mall_button_01.tga",
							"over_image" : "d:/ymir work/ui/game/taskbar/mall_button_02.tga",
							"down_image" : "d:/ymir work/ui/game/taskbar/mall_button_03.tga",
						},
						{
							"name" : "premium_private_shop_button",
							"type" : "button",
							"x" : 91,
							"y" : 186,
							"width" : 32,
							"height" : 32,
							"tooltip_text" : PREMIUM_SHOP_BUTTON_TEXT,
							"default_image" : "icon/item/private_button_01.tga",
							"over_image" : "icon/item/private_button_02.tga",
							"down_image" : "icon/item/private_button_03.tga",
						},
						{
							"name" : "CostumeButton",
							"type" : "button",
							"x" : 132,
							"y" : 186,
							"tooltip_text" : COSTUME_BUTTON_TEXT,
							"default_image" : "d:/ymir work/ui/game/taskbar/costume_button_01.tga",
							"over_image" : "d:/ymir work/ui/game/taskbar/costume_button_02.tga",
							"down_image" : "d:/ymir work/ui/game/taskbar/costume_button_03.tga",
						},
					),
				},
			),
		},
	),
}
