# -*- coding: utf-8 -*-
#if app.AFFECT_SYSTEM:
import uiScriptLocale

ROOT_PATH = "d:/ymir work/ui/affect_gui/"
BUTTON_PATH = "d:/ymir work/ui/affect_system/"

def create_button(name, x, y, image):
	return {
		"name": name,
		"type": "button",
		"x": x,
		"y": y,
		"horizontal_align": "center",
		"default_image": BUTTON_PATH + image,
		"over_image": BUTTON_PATH + image,
		"down_image": BUTTON_PATH + image
	}

window = {
	"name": "Affect_Panel",
	"x": 0,
	"y": 15,
	"style": ("movable", "float"),
	"width": 880,
	"height": 352,
	"children": (
		{
			"name": "board",
			"type": "board",
			"style": ("attach", "ignore_size"),
			"x": 0,
			"y": 0,
			"horizontal_align": "center",
			"vertical_align": "center",
			"width": 880,
			"height": 352,
			"children": (
				# Title Bar
				{
					"name": "TitleBar",
					"type": "titlebar",
					"style": ("attach",),
					"x": 6,
					"y": 6,
					"width": 865,
					"color": "yellow",
					"children": (
						{
							"name": "TitleName",
							"type": "text",
							"x": 0,
							"y": 3,
							"horizontal_align": "center",
							"text": "Welcome in menu [League of Legends]",
							"text_horizontal_align": "center",
						},
					),
				},

				{
					"name": "Character_Info_Bar",
					"type": "image",
					"x": 0,
					"y": 35,
					"horizontal_align": "center",
					"image": ROOT_PATH + "public_affect.tga",
				},
				{
					"name": "Character_Info",
					"type": "text",
					"x": -30,
					"y": 37,
					"horizontal_align": "center",
					"text": "[FREE] EFFECT",
				},

				{"name": "Character_Info_Bar", "type": "image", "x": 0, "y": 160, "horizontal_align": "center", "image": ROOT_PATH+"public_affect.tga"},
				{"name": "Character_Info", "type": "text", "x": -40, "y": 162, "horizontal_align": "center", "text": "[PREMIUM] EFFECT"},

				create_button("Desert1", 30, 85, "yellow_box.png"),
				create_button("Desert2", 50, 85, "orange_box.png"),
				create_button("Desert3", 70, 85, "white_box.png"),
				create_button("Desert4", 90, 85, "orange_box.png"),
				create_button("Desert5", -90, 110, "pink_box.png"),
				create_button("Desert6", -70, 110, "purple_box.png"),
				create_button("Desert7", -50, 110, "green_box.png"),
				create_button("Desert8", -30, 110, "turquoise_box.png"),
				create_button("Desert9", -10, 110, "red_box.png"),



				create_button("Tornado1", 10, 210, "tornado_yellow.png"),
				create_button("Tornado2", 30, 210, "tornado_blue.png"),
				create_button("Tornado3", 50, 210, "tornado_red.png"),
				create_button("Tornado4", 70, 210, "tornado_green.png"),
				create_button("Electric1", -90, 185, "red_electric.png"),
				create_button("Electric2", -70, 185, "yellow_electric.png"),
				create_button("Electric3", -50, 185, "green_electric.png"),
				create_button("Electric4", -30, 185, "blue_electric.png"),
				create_button("Electric5", -10, 185, "pink_electric.png"),
			),
		},
	),
}
