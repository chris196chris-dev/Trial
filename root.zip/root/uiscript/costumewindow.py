# -*- coding: utf-8 -*-
import uiScriptLocale
import item
import app

BOARD_WIDTH = 140
BOARD_HEIGHT = 227
COSTUME_WINDOW_TEXT = getattr(uiScriptLocale, "COSTUME_WINDOW_TITLE", getattr(uiScriptLocale, "COSTUME_TITLE", "Costume"))
COSTUME_BG_IMAGE = uiScriptLocale.LOCALE_UISCRIPT_PATH + "costume/new_costume_bg.jpg"

if app.ENABLE_HIDE_COSTUME_SYSTEM:
	HIDE_COSTUME_BUTTONS = (
		{
			"name" : "BodyToolTipButton",
			"type" : "toggle_button",
			"x" : 96,
			"y" : 45,
			"default_image" : "d:/ymir work/ui/game/costume/eye_normal_01.tga",
			"over_image" : "d:/ymir work/ui/game/costume/eye_normal_02.tga",
			"down_image" : "d:/ymir work/ui/game/costume/eye_closed_01.tga",
		},
		{
			"name" : "AcceToolTipButton",
			"type" : "toggle_button",
			"x" : 102,
			"y" : 126,
			"default_image" : "d:/ymir work/ui/game/costume/eye_normal_01.tga",
			"over_image" : "d:/ymir work/ui/game/costume/eye_normal_02.tga",
			"down_image" : "d:/ymir work/ui/game/costume/eye_closed_01.tga",
		},
		{
			"name" : "WeaponToolTipButton",
			"type" : "toggle_button",
			"x" : 46,
			"y" : 13,
			"default_image" : "d:/ymir work/ui/game/costume/eye_normal_01.tga",
			"over_image" : "d:/ymir work/ui/game/costume/eye_normal_02.tga",
			"down_image" : "d:/ymir work/ui/game/costume/eye_closed_01.tga",
		},
	)
else:
	HIDE_COSTUME_BUTTONS = ()

window = {
	"name" : "CostumeWindow",
	"style" : ("movable", "float",),

	"x" : SCREEN_WIDTH - BOARD_WIDTH - 200 - 184,
	"y" : SCREEN_HEIGHT - 37 - 375,

	"width" : BOARD_WIDTH,
	"height" : BOARD_HEIGHT,

	"children" :
	(
		{
			"name" : "Board",
			"type" : "board_with_titlebar",

			"x" : 0,
			"y" : 0,

			"width" : BOARD_WIDTH,
			"height" : BOARD_HEIGHT,

			"title" : COSTUME_WINDOW_TEXT,

			"children" :
			(
				{
					"name" : "Costume_Base",
					"type" : "image",

					"x" : 13,
					"y" : 38,
					"image" : COSTUME_BG_IMAGE,

					"children" :
					(
						{
							"name" : "CostumeSlot",
							"type" : "slot",

							"x" : 3,
							"y" : 3,

							"width" : 127,
							"height" : 192,

							"slot" :
							(
								{"index":item.COSTUME_SLOT_BODY,   "x":62, "y":45, "width":32, "height":64},
								{"index":item.COSTUME_SLOT_HAIR,   "x":62, "y":9,  "width":32, "height":32},
								{"index":item.COSTUME_SLOT_ACCE,   "x":68, "y":126,"width":32, "height":32},
								{"index":item.COSTUME_SLOT_WEAPON, "x":13, "y":13, "width":32, "height":96},
							),
						},
						## Hide/Show costume buttons
						## Body, sash(acce), weapon only.
					) + HIDE_COSTUME_BUTTONS,
				},
			),
		},
	),
}
