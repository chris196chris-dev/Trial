# -*- coding: utf-8 -*-
import uiScriptLocale
import item
import app

ENABLE_BELT_INVENTORY_RENEWAL = getattr(app, "ENABLE_BELT_INVENTORY_RENEWAL", False)

if ENABLE_BELT_INVENTORY_RENEWAL:
	BOARD_WIDTH = 212
	BOARD_HEIGHT = 239
	INVENTORY_WIDTH = 176
else:
	BOARD_WIDTH = 148
	BOARD_HEIGHT = 139

LAYER_WIDTH = BOARD_WIDTH + 14
LAYER_HEIGHT = BOARD_HEIGHT + 38

window = {
	"name" : "BeltInventoryWindow",
		"x" : SCREEN_WIDTH - INVENTORY_WIDTH - BOARD_WIDTH if ENABLE_BELT_INVENTORY_RENEWAL else SCREEN_WIDTH - 176 - 148,
		"y" : SCREEN_HEIGHT - 37 - 565 + 209 + 32,
		"style" : ("float",),
		"width" : LAYER_WIDTH,
		"height" : LAYER_HEIGHT,
	"children" :
	(
		{
			"name" : "ExpandBtn",
			"type" : "button",
			"x" : 2,
			"y" : 15,
			"default_image" : "d:/ymir work/ui/game/belt_inventory/btn_expand_normal.tga",
			"over_image" : "d:/ymir work/ui/game/belt_inventory/btn_expand_over.tga",
			"down_image" : "d:/ymir work/ui/game/belt_inventory/btn_expand_down.tga",
			"disable_image" : "d:/ymir work/ui/game/belt_inventory/btn_expand_disabled.tga",
		},
		{
				"name" : "BeltInventoryLayer",
				"type" : "board_with_titlebar",
				"x" : 2,
				"y" : 0,
				"width" : LAYER_WIDTH,
				"height" : LAYER_HEIGHT,
			"title" : uiScriptLocale.BELT_WINDOW_TITLE,
			"children" :
			(
				{
					"name" : "beltbackimage",
					"type" : "image",
					"x" : 10,
					"y" : 30,
					"width" : BOARD_WIDTH,
					"height" : BOARD_HEIGHT,
					"image" : "d:/ymir work/ui/game/belt_inventory/bg.tga",
					"children" :
					(
						{
							"name" : "BeltInventorySlot",
							"type" : "grid_table",
							"x" : 9,
							"y" : 5,
							"start_index" : item.BELT_INVENTORY_SLOT_START,
							"x_count" : item.BELT_INVENTORY_SLOT_WIDTH if ENABLE_BELT_INVENTORY_RENEWAL else 4,
							"y_count" : item.BELT_INVENTORY_SLOT_HEIGHT if ENABLE_BELT_INVENTORY_RENEWAL else 4,
							"x_step" : 32,
							"y_step" : 32,
							"image" : "d:/ymir work/ui/public/Slot_Base.sub",
						},
					),
				},
			),
		},
	),
}
