# -*- coding: utf-8 -*-
# v32 restored from working Python 2.7 pack and kept as Python 3.14-compatible UI dict.
import uiScriptLocale
import item

EQUIPMENT_START_INDEX = 240

window = {
	"name" : "InventoryWindow",
	"x" : SCREEN_WIDTH - 470,
	"y" : SCREEN_HEIGHT - 37 - 500,
	"style" : ("movable", "float",),
	"width" : 335,
	"height" : 470,
	"children" :
	(
		{
			"name" : "board",
			"type" : "board",
			"style" : ("attach",),
			"x" : 5,
			"y" : 0,
			"width" : 325,
			"height" : 453,
			"children" :
			(
				{
					"name" : "Equipment_Base",
					"type" : "image",
					"style" : ("attach",),
					"x" : -58,
					"y" : -98,
					"image" : "sistimata/new_inventory/inventar.tga",
					"children" :
					(
						{
							"name" : "EquipmentSlot",
							"type" : "slot",
							"x" : 63,
							"y" : 128,
							"width" : 400,
							"height" : 300,
							"slot" :
							(
								{"index":item.EQUIPMENT_BODY, "x":39, "y":37, "width":32, "height":64},
								{"index":item.EQUIPMENT_HEAD, "x":39, "y":2, "width":32, "height":32},
								{"index":item.EQUIPMENT_SHOES, "x":39, "y":145, "width":32, "height":32},
								{"index":item.EQUIPMENT_WRIST, "x":75, "y":67, "width":32, "height":32},
								{"index":item.EQUIPMENT_WEAPON, "x":3, "y":3, "width":32, "height":96},
								{"index":item.EQUIPMENT_NECK, "x":114, "y":67, "width":32, "height":32},
								{"index":item.EQUIPMENT_EAR, "x":114, "y":35, "width":32, "height":32},
								{"index":item.EQUIPMENT_ARROW, "x":93, "y":2, "width":32, "height":32},
								{"index":item.EQUIPMENT_SHIELD, "x":75, "y":35, "width":32, "height":32},
								{"index":item.EQUIPMENT_UNIQUE1, "x":2, "y":105, "width":32, "height":32},
								{"index":item.EQUIPMENT_UNIQUE2, "x":75, "y":105, "width":32, "height":32},
								## costumes ring etc
								{"index":item.COSTUME_SLOT_BODY, "x":225, "y":42, "width":32, "height":64},
								{"index":item.COSTUME_SLOT_HAIR, "x":226, "y":7, "width":32, "height":32},
								{"index":item.COSTUME_SLOT_ACCE, "x":203, "y":152, "width":32, "height":32},
								{"index":item.COSTUME_SLOT_WEAPON, "x":177, "y":10, "width":32, "height":96},
								{"index":item.EQUIPMENT_BELT, "x":203, "y":118, "width":32, "height":32},
								{"index":item.EQUIPMENT_RING1, "x":169, "y":118, "width":32, "height":32},
								{"index":item.EQUIPMENT_RING2, "x":236, "y":118, "width":32, "height":32},
								##endif
							),
						},
						##if TITLE BAR:
						{
							"name" : "TitleBarss",
							"type" : "button",
							"x" : 363,
							"y" : 94,
							"tooltip_text" : uiScriptLocale.CLOSE,
							"default_image" : "sistimata/new_inventory/minimize_1.tga",
							"over_image" : "sistimata/new_inventory/minimize_2.tga",
							"down_image" : "sistimata/new_inventory/minimize_3.tga",
						},
						##endif
						##if app.FIX_BUFF_TROLL:
						{
							"name" : "FixBuffShamy",
							"type" : "button",
							"x" : 342,
							"y" : 33 + 138,
							"default_image" : "sistimata/buff_shamy_disable/block_shamy_01.tga",
							"over_image" : "sistimata/buff_shamy_disable/block_shamy_02.tga",
							"down_image" : "sistimata/buff_shamy_disable/block_shamy_03.tga",
						},
						##endif
						##if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
						{
							"name" : "PinCooding",
							"type" : "button",
							"x" : 340,
							"y" : 33 + 100,
							"default_image" : "sistimata/lock_inventory/lock_inventory_button_01.tga",
							"over_image" : "sistimata/lock_inventory/lock_inventory_button_02.tga",
							"down_image" : "sistimata/lock_inventory/lock_inventory_button_03.tga",
						},
						##endif
						##if app.ENABLE_SYSTEM_METINSTONE:
						{
							"name" : "BonusPage",
							"type" : "button",
							"x" : 342,
							"y" : 33 + 170,
							"default_image" : "sistimata/bonuspages/bonuspbutton01.tga",
							"over_image" : "sistimata/bonuspages/bonuspbutton02.tga",
							"down_image" : "sistimata/bonuspages/bonuspbutton03.tga",
						},
						{
							"name" : "AantiExp",
							"type" : "button",
							"x" : 342,
							"y" : 33 + 203,
							"default_image" : "sistimata/anti_exp/anti_exp_01.tga",
							"over_image" : "sistimata/anti_exp/anti_exp_02.tga",
							"down_image" : "sistimata/anti_exp/anti_exp_03.tga",
						},
						{
							"name" : "Switchbots",
							"type" : "button",
							"x" : 342,
							"y" : 33 + 240,
							"default_image" : "sistimata/switchbots/switchbots_01.tga",
							"over_image" : "sistimata/switchbots/switchbots_02.tga",
							"down_image" : "sistimata/switchbots/switchbots_03.tga",
						},
						{
							"name" : "Apothiki",
							"type" : "button",
							"x" : 145,
							"y" : 33 + 245,
							"default_image" : "sistimata/apothiki_and_is/apothiki_and_is01.tga",
							"over_image" : "sistimata/apothiki_and_is/apothiki_and_is02.tga",
							"down_image" : "sistimata/apothiki_and_is/apothiki_and_is03.tga",
						},
						##endif
						{
							"name" : "DSSButton",
							"type" : "button",
							"x" : 180,
							"y" : 33 + 245,
							"default_image" : "sistimata/dragon_souls/soul_inventory_button_01.tga",
							"over_image" : "sistimata/dragon_souls/soul_inventory_button_02.tga",
							"down_image" : "sistimata/dragon_souls/soul_inventory_button_03.tga",
						},
						{
							"name" : "BeltButtonssd",
							"type" : "button",
							"x" : 180,
							"y" : 33 + 210,
							"default_image" : "sistimata/belt_inventory/belt_inventory_button_01.tga",
							"over_image" : "sistimata/belt_inventory/belt_inventory_button_02.tga",
							"down_image" : "sistimata/belt_inventory/belt_inventory_button_03.tga",
						},
						{
							"name" : "BodyToolTipButton",
							"type" : "toggle_button",
							"x" : 66 + 222,
							"y" : 170,
							"tooltip_text" : uiScriptLocale.HIDE_COSTUME,
							"default_image" : "sistimata/hide_etc/visible_mark_01.tga",
							"over_image" : "sistimata/hide_etc/visible_mark_02.tga",
							"down_image" : "sistimata/hide_etc/visible_mark_03.tga",
						},
						{
							"name" : "HairToolTipButton",
							"type" : "toggle_button",
							"x" : 66 + 222,
							"y" : 135,
							"tooltip_text" : uiScriptLocale.HIDE_COSTUME,
							"default_image" : "sistimata/hide_etc/visible_middle_01.tga",
							"over_image" : "sistimata/hide_etc/visible_middle_02.tga",
							"down_image" : "sistimata/hide_etc/visible_middle_03.tga",
						},
						{
							"name" : "AcceToolTipButton",
							"type" : "toggle_button",
							"x" : 62 + 204,
							"y" : 280,
							"tooltip_text" : uiScriptLocale.HIDE_COSTUME,
							"default_image" : "sistimata/hide_etc/visible_middle_01.tga",
							"over_image" : "sistimata/hide_etc/visible_middle_02.tga",
							"down_image" : "sistimata/hide_etc/visible_middle_03.tga",
						},
						{
							"name" : "WeaponToolTipButton",
							"type" : "toggle_button",
							"x" : 62 + 178,
							"y" : 138,
							"tooltip_text" : uiScriptLocale.HIDE_COSTUME,
							"default_image" : "sistimata/hide_etc/visible_mark_01.tga",
							"over_image" : "sistimata/hide_etc/visible_mark_02.tga",
							"down_image" : "sistimata/hide_etc/visible_mark_03.tga",
						},
						##endif
						{
							"name" : "Equipment_Tab_01",
							"type" : "radio_button",
							"x" : 240,
							"y" : 161,
							"default_image" : "d:/ymir work/ui/game/windows/tab_button_small_01.sub",
							"over_image" : "d:/ymir work/ui/game/windows/tab_button_small_02.sub",
							"down_image" : "d:/ymir work/ui/game/windows/tab_button_small_03.sub",
							"children" :
							(
								{
									"name" : "Equipment_Tab_01_Print",
									"type" : "text",
									"x" : 0,
									"y" : -200,
									"all_align" : "center",
									"text" : "I",
								},
							),
						},
						{
							"name" : "Equipment_Tab_02",
							"type" : "radio_button",
							"x" : 86 + 32,
							"y" : 261,
							"default_image" : "d:/ymir work/ui/game/windows/tab_button_small_01.sub",
							"over_image" : "d:/ymir work/ui/game/windows/tab_button_small_02.sub",
							"down_image" : "d:/ymir work/ui/game/windows/tab_button_small_03.sub",
							"children" :
							(
								{
									"name" : "Equipment_Tab_02_Print",
									"type" : "text",
									"x" : 0,
									"y" : -200,
									"all_align" : "center",
									"text" : "II",
								},
							),
						},
					),
				},
				{
					"name" : "Inventory_Tab_01",
					"type" : "radio_button",
					"x" : 14,
					"y" : 33 + 191,
					"default_image" : "sistimata/new_inventory/inventory_coldt_01.tga",
					"over_image" : "sistimata/new_inventory/inventory_1.tga",
					"down_image" : "sistimata/new_inventory/3.tga",
					"children" :
					(
						{
							"name" : "Inventory_Tab_01_Print",
							"type" : "text",
							"x" : 0,
							"y" : 0,
							"all_align" : "center",
							"text" : "",
						},
					),
				},
				{
					"name" : "Inventory_Tab_02",
					"type" : "radio_button",
					"x" : 94,
					"y" : 33 + 191,
					"default_image" : "sistimata/new_inventory/inventory_coldt_02.tga",
					"over_image" : "sistimata/new_inventory/inventory_2.tga",
					"down_image" : "sistimata/new_inventory/3.tga",
					"children" :
					(
						{
							"name" : "Inventory_Tab_02_Print",
							"type" : "text",
							"x" : 0,
							"y" : 0,
							"all_align" : "center",
							"text" : "",
						},
					),
				},
				{
					"name" : "Inventory_Tab_03",
					"type" : "radio_button",
					"x" : 174,
					"y" : 33 + 191,
					"default_image" : "sistimata/new_inventory/inventory_coldt_03.tga",
					"over_image" : "sistimata/new_inventory/inventory_3.tga",
					"down_image" : "sistimata/new_inventory/3.tga",
					"children" :
					(
						{
							"name" : "Inventory_Tab_03_Print",
							"type" : "text",
							"x" : 0,
							"y" : 0,
							"all_align" : "center",
							"text" : "",
						},
					),
				},
				{
					"name" : "Inventory_Tab_04",
					"type" : "radio_button",
					"x" : 254,
					"y" : 33 + 191,
					"default_image" : "sistimata/new_inventory/inventory_coldt_04.tga",
					"over_image" : "sistimata/new_inventory/inventory_4.tga",
					"down_image" : "sistimata/new_inventory/3.tga",
					"children" :
					(
						{
							"name" : "Inventory_Tab_04_Print",
							"type" : "text",
							"x" : 0,
							"y" : 0,
							"all_align" : "center",
							"text" : "",
						},
					),
				},
				{
					"name" : "ItemSlot",
					"type" : "grid_table",
					"x" : 5,
					"y" : 255,
					"start_index" : 0,
					"x_count" : 10,
					"y_count" : 6,
					"x_step" : 32,
					"y_step" : 32,
					"image" : "d:/ymir work/ui/public/Slot_Base.sub",
				},
				{
					"name":"Money_Slot",
					"type":"button",
					"x":147,
					"y":1,
					"horizontal_align":"left",
					"vertical_align":"bottom",
					"default_image" : "sistimata/new_inventory/yang.tga",
					"over_image" : "sistimata/new_inventory/yang.tga",
					"down_image" : "sistimata/new_inventory/yang.tga",
					"children" :
					(
						{
							"name" : "Money",
							"type" : "text",
							"x" : 20,
							"y" : 0,
							"horizontal_align" : "right",
							"text_horizontal_align" : "right",
							"text" : "123456789",
						},
					),
				},
			),
		},
	),
}

