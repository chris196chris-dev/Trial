# -*- coding: utf-8 -*-
import app
import constInfo

#MULTI_LANGUAGE - JSON-based locale strings
def Get(key):
	"""V38_SAFE_LOCALE_GET: Get localized string by key from JSON, never None."""
	try:
		value = app.GetLocaleString(key)
	except Exception:
		value = None
	if value is None or value == "":
		return str(key)
	return value

def GetFormatted(key, *args):
	"""V38_SAFE_LOCALE_GET: Get formatted string safely."""
	text = Get(key)
	try:
		if args and app.IsFormatString(key):
			return text % args
	except Exception:
		pass
	return text

def ReloadStrings():
	"""Hot reload all locale strings."""
	# Reload C++ side strings (JSON-based)
	try:
		app.ReloadLocaleStrings()
	except:
		pass
#MULTI_LANGUAGE

MAP_TRENT02 = "MAP_TRENT02"
MAP_WL = "MAP_WL"
MAP_NUSLUCK = "MAP_NUSLUCK"
MAP_TREE2 = "MAP_TREE2"

BLEND_POTION_NO_TIME = "BLEND_POTION_NO_TIME"
BLEND_POTION_NO_INFO = "BLEND_POTION_NO_INFO"

APP_TITLE = "Nirvana Project"

GUILD_HEADQUARTER = "Main Building"
GUILD_FACILITY = "Facility"
GUILD_OBJECT = "Object"
GUILD_MEMBER_COUNT_INFINITY = "INFINITY"

LOGIN_FAILURE_BLOCK_LOGIN = "BLOCK_LOGIN"
CHANNEL_NOTIFY_FULL = "CHANNEL_NOTIFY_FULL"

GUILD_BUILDING_LIST_TXT = app.GetLocalePath() + "/guildbuildinglist.txt"

GUILD_MARK_MIN_LEVEL = "3"
GUILD_MARK_NOT_ENOUGH_LEVEL = "Guild mark not enough level."

ERROR_MARK_UPLOAD_NEED_RECONNECT = "UploadMark: Reconnect to game"
ERROR_MARK_CHECK_NEED_RECONNECT = "CheckMark: Reconnect to game"

VIRTUAL_KEY_ALPHABET_LOWERS  = r"[1234567890]/qwertyuiop\=asdfghjkl;`'zxcvbnm.,"
VIRTUAL_KEY_ALPHABET_UPPERS  = r'{1234567890}?QWERTYUIOP|+ASDFGHJKL:~"ZXCVBNM!='
VIRTUAL_KEY_SYMBOLS    = '!@#$%^&*()_+|{}:"!=?~'
VIRTUAL_KEY_NUMBERS    = r"1234567890-=\[];',./`"

def LoadLocaleData():
	app.LoadLocaleData(app.GetLocalePath())

def mapping(**kwargs):
	return kwargs

def SNA(text):	
	def f(x):
		return text
	return f

def SA(text):
	def f(x):
		return text % x
	return f

#MULTI_LANGUAGE - Static paths (not translatable)
all = ["locale","error"]
FN_GM_MARK = "%s/effect/gm.mse" % app.GetLocalePath()
#MULTI_LANGUAGE

def CutMoneyString(sourceText, startIndex, endIndex, insertingText, backText):

	sourceLength = len(sourceText)

	if sourceLength < startIndex:
		return backText

	text = sourceText[max(0, sourceLength-endIndex):sourceLength-startIndex]

	if not text:
		return backText

	if int(text) <= 0:
		return backText

	text = str(int(text))

	if backText:
		backText = " " + backText

	return text + insertingText + backText

#MULTI_LANGUAGE - Dynamic time functions
def SecondToDHM(time):
	if time < 60:
		return "0" + Get("MINUTE")

	second = int(time % 60)
	minute = int((time / 60) % 60)
	hour = int((time / 60) / 60) % 24
	day = int(int((time / 60) / 60) / 24)

	text = ""

	if day > 0:
		text += str(day) + Get("DAY")
		text += " "

	if hour > 0:
		text += str(hour) + Get("HOUR")
		text += " "

	if minute > 0:
		text += str(minute) + Get("MINUTE")

	return text

def SecondToHM(time):

	if time < 60:
		return "0" + Get("MINUTE")

	second = int(time % 60)
	minute = int((time / 60) % 60)
	hour = int((time / 60) / 60)

	text = ""

	if hour > 0:
		text += str(hour) + Get("HOUR")
		if hour > 0:
			text += " "

	if minute > 0:
		text += str(minute) + Get("MINUTE")

	return text
#MULTI_LANGUAGE

#MULTI_LANGUAGE - Dynamic lookup structures
# Key mappings - store JSON keys, not values
_TITLE_NAME_KEYS = ("PVP_LEVEL0", "PVP_LEVEL1", "PVP_LEVEL2", "PVP_LEVEL3", "PVP_LEVEL4", "PVP_LEVEL5", "PVP_LEVEL6", "PVP_LEVEL7", "PVP_LEVEL8")
_MODE_NAME_KEYS = ("PVP_OPTION_NORMAL", "PVP_OPTION_REVENGE", "PVP_OPTION_KILL", "PVP_OPTION_PROTECT")

def GetTitleName(index):
	"""Get PVP title name by index (0-8)."""
	if 0 <= index < len(_TITLE_NAME_KEYS):
		return Get(_TITLE_NAME_KEYS[index])
	return ""

def GetModeName(index):
	"""Get PVP mode name by index (0-3)."""
	if 0 <= index < len(_MODE_NAME_KEYS):
		return Get(_MODE_NAME_KEYS[index])
	return ""

def GetAlignmentTitleName(alignment):
	if alignment >= 12000:
		return GetTitleName(0)
	elif alignment >= 8000:
		return GetTitleName(1)
	elif alignment >= 4000:
		return GetTitleName(2)
	elif alignment >= 1000:
		return GetTitleName(3)
	elif alignment >= 0:
		return GetTitleName(4)
	elif alignment > -4000:
		return GetTitleName(5)
	elif alignment > -8000:
		return GetTitleName(6)
	elif alignment > -12000:
		return GetTitleName(7)
	return GetTitleName(8)

# PVP Mode messages
_PVPMODE_MESSAGE_KEYS = {
	0: "PVP_MODE_NORMAL",
	1: "PVP_MODE_REVENGE",
	2: "PVP_MODE_KILL",
	3: "PVP_MODE_PROTECT",
	4: "PVP_MODE_GUILD",
}

def GetPvpModeMessage(mode):
	key = _PVPMODE_MESSAGE_KEYS.get(mode)
	return Get(key) if key else ""

# Error mapping for system init errors
_ERROR_KEYS = {
	"CREATE_WINDOW": "GAME_INIT_ERROR_MAIN_WINDOW",
	"CREATE_CURSOR": "GAME_INIT_ERROR_CURSOR",
	"CREATE_NETWORK": "GAME_INIT_ERROR_NETWORK",
	"CREATE_ITEM_PROTO": "GAME_INIT_ERROR_ITEM_PROTO",
	"CREATE_MOB_PROTO": "GAME_INIT_ERROR_MOB_PROTO",
	"CREATE_NO_DIRECTX": "GAME_INIT_ERROR_DIRECTX",
	"CREATE_DEVICE": "GAME_INIT_ERROR_GRAPHICS_NOT_EXIST",
	"CREATE_NO_APPROPRIATE_DEVICE": "GAME_INIT_ERROR_GRAPHICS_BAD_PERFORMANCE",
	"CREATE_FORMAT": "GAME_INIT_ERROR_GRAPHICS_NOT_SUPPORT_32BIT",
	"NO_ERROR": "",
}

def GetError(errorType):
	key = _ERROR_KEYS.get(errorType, "")
	return Get(key) if key else ""

# Guild war description lists
_GUILDWAR_NORMAL_KEYS = ["GUILD_WAR_USE_NORMAL_MAP", "GUILD_WAR_LIMIT_30MIN", "GUILD_WAR_WIN_CHECK_SCORE"]
_GUILDWAR_WARP_KEYS = ["GUILD_WAR_USE_BATTLE_MAP", "GUILD_WAR_WIN_WIPE_OUT_GUILD", "GUILD_WAR_REWARD_POTION"]
_GUILDWAR_CTF_KEYS = ["GUILD_WAR_USE_BATTLE_MAP", "GUILD_WAR_WIN_TAKE_AWAY_FLAG1", "GUILD_WAR_WIN_TAKE_AWAY_FLAG2", "GUILD_WAR_REWARD_POTION"]

def GetGuildwarNormalDescList():
	return [Get(key) for key in _GUILDWAR_NORMAL_KEYS]

def GetGuildwarWarpDescList():
	return [Get(key) for key in _GUILDWAR_WARP_KEYS]

def GetGuildwarCtfDescList():
	return [Get(key) for key in _GUILDWAR_CTF_KEYS]

# Minimap zone names
_MINIMAP_ZONE_KEYS = {
	"metin2_map_a1": "MAP_A1",
	"metin2_map_a3": "MAP_A3",
	"metin2_map_b1": "MAP_B1",
	"metin2_map_b3": "MAP_B3",
	"metin2_map_c1": "MAP_C1",
	"metin2_map_c3": "MAP_C3",
	"metin2_map_ascaria": "MAP_DW",
	"metin2_map_diavoliki": "MAP_DQ",
	"metin2_map_epicmap": "EPICS_MAPS",
}

def GetMinimapZoneName(mapName):
	key = _MINIMAP_ZONE_KEYS.get(mapName)
	return Get(key) if key else ""

# Job info titles
_JOBINFO_KEYS = [
	["JOB_WARRIOR0", "JOB_WARRIOR1", "JOB_WARRIOR2"],
	["JOB_ASSASSIN0", "JOB_ASSASSIN1", "JOB_ASSASSIN2"],
	["JOB_SURA0", "JOB_SURA1", "JOB_SURA2"],
	["JOB_SHAMAN0", "JOB_SHAMAN1", "JOB_SHAMAN2"],
]

def GetJobTitle(jobIndex, subIndex):
	if 0 <= jobIndex < len(_JOBINFO_KEYS) and 0 <= subIndex < len(_JOBINFO_KEYS[jobIndex]):
		return Get(_JOBINFO_KEYS[jobIndex][subIndex])
	return ""

# Whisper errors - note these use SA format (%s)
_WHISPER_ERROR_KEYS = {
	1: "CANNOT_WHISPER_NOT_LOGON",
	2: "CANNOT_WHISPER_DEST_REFUSE",
	3: "CANNOT_WHISPER_SELF_REFUSE",
}

def GetWhisperError(mode, name=""):
	key = _WHISPER_ERROR_KEYS.get(mode)
	if key:
		text = Get(key)
		if "%s" in text and name:
			return text % name
		return text
	return ""

def HasWhisperError(mode):
	return mode in _WHISPER_ERROR_KEYS

# Notify messages
_NOTIFY_MESSAGE_KEYS = {
	"CANNOT_EQUIP_SHOP": "CANNOT_EQUIP_IN_SHOP",
	"CANNOT_EQUIP_EXCHANGE": "CANNOT_EQUIP_IN_EXCHANGE",
}

def GetNotifyMessage(msgType):
	key = _NOTIFY_MESSAGE_KEYS.get(msgType)
	return Get(key) if key else ""

def HasNotifyMessage(msgType):
	return msgType in _NOTIFY_MESSAGE_KEYS

# Attack error messages
_ATTACK_ERROR_KEYS = {
	"IN_SAFE": "CANNOT_ATTACK_SELF_IN_SAFE",
	"DEST_IN_SAFE": "CANNOT_ATTACK_DEST_IN_SAFE",
}

def GetAttackError(errorType):
	key = _ATTACK_ERROR_KEYS.get(errorType)
	return Get(key) if key else ""

# Shot error messages
_SHOT_ERROR_KEYS = {
	"EMPTY_ARROW": "CANNOT_SHOOT_EMPTY_ARROW",
	"IN_SAFE": "CANNOT_SHOOT_SELF_IN_SAFE",
	"DEST_IN_SAFE": "CANNOT_SHOOT_DEST_IN_SAFE",
}

def GetShotError(errorType, fallback=""):
	key = _SHOT_ERROR_KEYS.get(errorType)
	if key:
		return Get(key)
	return fallback

# Skill error messages (tail)
_SKILL_ERROR_TAIL_KEYS = {
	"IN_SAFE": "CANNOT_SKILL_SELF_IN_SAFE",
	"NEED_TARGET": "CANNOT_SKILL_NEED_TARGET",
	"NEED_EMPTY_BOTTLE": "CANNOT_SKILL_NEED_EMPTY_BOTTLE",
	"NEED_POISON_BOTTLE": "CANNOT_SKILL_NEED_POISON_BOTTLE",
	"REMOVE_FISHING_ROD": "CANNOT_SKILL_REMOVE_FISHING_ROD",
	"NOT_YET_LEARN": "CANNOT_SKILL_NOT_YET_LEARN",
	"NOT_MATCHABLE_WEAPON": "CANNOT_SKILL_NOT_MATCHABLE_WEAPON",
	"WAIT_COOLTIME": "CANNOT_SKILL_WAIT_COOLTIME",
	"NOT_ENOUGH_HP": "CANNOT_SKILL_NOT_ENOUGH_HP",
	"NOT_ENOUGH_SP": "CANNOT_SKILL_NOT_ENOUGH_SP",
	"CANNOT_USE_SELF": "CANNOT_SKILL_USE_SELF",
	"ONLY_FOR_ALLIANCE": "CANNOT_SKILL_ONLY_FOR_ALLIANCE",
	"CANNOT_ATTACK_ENEMY_IN_SAFE_AREA": "CANNOT_SKILL_DEST_IN_SAFE",
	"CANNOT_APPROACH": "CANNOT_SKILL_APPROACH",
	"CANNOT_ATTACK": "CANNOT_SKILL_ATTACK",
	"ONLY_FOR_CORPSE": "CANNOT_SKILL_ONLY_FOR_CORPSE",
	"EQUIP_FISHING_ROD": "CANNOT_SKILL_EQUIP_FISHING_ROD",
	"NOT_HORSE_SKILL": "CANNOT_SKILL_NOT_HORSE_SKILL",
	"HAVE_TO_RIDE": "CANNOT_SKILL_HAVE_TO_RIDE",
}

def GetSkillErrorTail(errorType):
	key = _SKILL_ERROR_TAIL_KEYS.get(errorType)
	return Get(key) if key else ""

def HasSkillErrorTail(errorType):
	return errorType in _SKILL_ERROR_TAIL_KEYS

# Skill error messages (chat)
_SKILL_ERROR_CHAT_KEYS = {
	"NEED_EMPTY_BOTTLE": "SKILL_NEED_EMPTY_BOTTLE",
	"NEED_POISON_BOTTLE": "SKILL_NEED_POISON_BOTTLE",
	"ONLY_FOR_GUILD_WAR": "SKILL_ONLY_FOR_GUILD_WAR",
}

def GetSkillErrorChat(errorType):
	key = _SKILL_ERROR_CHAT_KEYS.get(errorType)
	return Get(key) if key else ""

def HasSkillErrorChat(errorType):
	return errorType in _SKILL_ERROR_CHAT_KEYS

# Horse level list
if app.HORSE_MAX_LEVEL_60:
	_LEVEL_KEYS = ["", "HORSE_LEVEL1", "HORSE_LEVEL2", "HORSE_LEVEL3", "HORSE_LEVEL4", "HORSE_LEVEL5", "HORSE_LEVEL6"]
else:
	_LEVEL_KEYS = ["", "HORSE_LEVEL1", "HORSE_LEVEL2", "HORSE_LEVEL3"]

def GetHorseLevel(index):
	if 0 <= index < len(_LEVEL_KEYS):
		key = _LEVEL_KEYS[index]
		return Get(key) if key else ""
	return ""

# Horse health list
_HEALTH_KEYS = ["HORSE_HEALTH0", "HORSE_HEALTH1", "HORSE_HEALTH2", "HORSE_HEALTH3"]

def GetHorseHealth(index):
	if 0 <= index < len(_HEALTH_KEYS):
		return Get(_HEALTH_KEYS[index])
	return ""

# Shop error messages
_SHOP_ERROR_KEYS = {
	"NOT_ENOUGH_MONEY": "SHOP_NOT_ENOUGH_MONEY",
	"SOLDOUT": "SHOP_SOLDOUT",
	"INVENTORY_FULL": "SHOP_INVENTORY_FULL",
	"INVALID_POS": "SHOP_INVALID_POS",
	"NOT_ENOUGH_MONEY_EX": "SHOP_NOT_ENOUGH_MONEY_EX",
}

def GetShopError(errorType):
	key = _SHOP_ERROR_KEYS.get(errorType)
	return Get(key) if key else ""

# Stat minus descriptions
_STAT_MINUS_KEYS = {
	"HTH-": "STAT_MINUS_CON",
	"INT-": "STAT_MINUS_INT",
	"STR-": "STAT_MINUS_STR",
	"DEX-": "STAT_MINUS_DEX",
}

def GetStatMinusDescription(statType):
	key = _STAT_MINUS_KEYS.get(statType)
	return Get(key) if key else ""

# Legacy compatibility - these return dynamic values now
def _get_title_name_list():
	return tuple(Get(key) for key in _TITLE_NAME_KEYS)

def _get_mode_name_list():
	return tuple(Get(key) for key in _MODE_NAME_KEYS)
#MULTI_LANGUAGE

def GetLetterImageName():
	return "season1/icon/scroll_close.tga"
def GetLetterOpenImageName():
	return "season1/icon/scroll_open.tga"
def GetLetterCloseImageName():
	return "season1/icon/scroll_close.tga"

#MULTI_LANGUAGE - Dynamic item/shop functions
def DO_YOU_SELL_ITEM(sellItemName, sellItemCount, sellItemPrice):
	if sellItemCount > 1:
		return Get("DO_YOU_SELL_ITEM2") % (sellItemName, sellItemCount, NumberToMoneyString(sellItemPrice))
	else:
		return Get("DO_YOU_SELL_ITEM1") % (sellItemName, NumberToMoneyString(sellItemPrice))

def DO_YOU_BUY_ITEM(buyItemName, buyItemCount, buyItemPrice):
	if buyItemCount > 1:
		return Get("DO_YOU_BUY_ITEM2") % (buyItemName, buyItemCount, buyItemPrice)
	else:
		return Get("DO_YOU_BUY_ITEM1") % (buyItemName, buyItemPrice)

def REFINE_FAILURE_CAN_NOT_ATTACH(attachedItemName):
	return Get("REFINE_FAILURE_CAN_NOT_ATTACH0") % (attachedItemName)

def REFINE_FAILURE_NO_SOCKET(attachedItemName):
	return Get("REFINE_FAILURE_NO_SOCKET0") % (attachedItemName)

def REFINE_FAILURE_NO_GOLD_SOCKET(attachedItemName):
	return Get("REFINE_FAILURE_NO_GOLD_SOCKET0") % (attachedItemName)

def HOW_MANY_ITEM_DO_YOU_DROP(dropItemName, dropItemCount):
	if dropItemCount > 1:
		return Get("HOW_MANY_ITEM_DO_YOU_DROP2") % (dropItemName, dropItemCount)
	else:
		return Get("HOW_MANY_ITEM_DO_YOU_DROP1") % (dropItemName)

def FISHING_NOTIFY(isFish, fishName):
	if isFish:
		return Get("FISHING_NOTIFY1") % (fishName)
	else:
		return Get("FISHING_NOTIFY2") % (fishName)

def FISHING_SUCCESS(isFish, fishName):
	if isFish:
		return Get("FISHING_SUCCESS1") % (fishName)
	else:
		return Get("FISHING_SUCCESS2") % (fishName)

def NumberToMoneyString(n):
	unit = Get("MONETARY_UNIT0")
	if n <= 0:
		return "0 %s" % (unit)
	return "%s %s" % ('.'.join([i-3<0 and str(n)[:i] or str(n)[i-3:i] for i in range(len(str(n))%3, len(str(n))+1, 3) if i]), unit)

# Tooltip time charger functions
def TOOLTIP_TIME_CHARGER_PER(value):
	return Get("TOOLTIP_TIME_CHARGER_PER") % (value)

def TOOLTIP_TIME_CHARGER_FIX(value):
	return Get("TOOLTIP_TIME_CHARGER_FIX") % (value)

# Dragon Soul strength function
def DRAGON_SOUL_STRENGTH(refine):
	return Get("DRAGON_SOUL_STRENGTH") % (refine + 1)

# Option PVP mode function
def OPTION_PVPMODE_PROTECT(level):
	return Get("OPTION_PVPMODE_PROTECT") % (level)
#MULTI_LANGUAGE

# GODMOVE_V10_LOCALE_FALLBACKS: prevents crash when one translated locale misses modern UI keys.
try:
	INVENTORY_TITLE
except NameError:
	INVENTORY_TITLE = "Inventory"
try:
	INVENTORY_PAGE_BUTTON_TOOLTIP_1
except NameError:
	INVENTORY_PAGE_BUTTON_TOOLTIP_1 = "Inventory page 1"
try:
	INVENTORY_PAGE_BUTTON_TOOLTIP_2
except NameError:
	INVENTORY_PAGE_BUTTON_TOOLTIP_2 = "Inventory page 2"
try:
	INVENTORY_PAGE_BUTTON_TOOLTIP_3
except NameError:
	INVENTORY_PAGE_BUTTON_TOOLTIP_3 = "Inventory page 3"
try:
	INVENTORY_PAGE_BUTTON_TOOLTIP_4
except NameError:
	INVENTORY_PAGE_BUTTON_TOOLTIP_4 = "Inventory page 4"
