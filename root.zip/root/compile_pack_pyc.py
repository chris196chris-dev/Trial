#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Compile Metin2 pack .py files to side-by-side .pyc files.

Run this with the SAME Python version your client embeds.
Examples:
  py -3.12 compile_pack_pyc.py
  py -3.14 compile_pack_pyc.py

It compiles .py files in root/, root/uiscript/, locale/, and all subfolders.
Side-by-side .pyc is used intentionally because many old clients load file.pyc
directly instead of __pycache__/file.cpython-XY.pyc.
"""
from __future__ import annotations

import py_compile
from pathlib import Path
import sys
import traceback

BASE = Path(__file__).resolve().parent
SEARCH_DIRS = [
    BASE,
    BASE / "uiscript",
    BASE.parent / "locale",
]

def compile_one(path: Path) -> bool:
    cfile = path.with_suffix(".pyc")
    try:
        py_compile.compile(str(path), cfile=str(cfile), doraise=True, optimize=0)
        print(f"OK  {path.relative_to(BASE.parent)} -> {cfile.relative_to(BASE.parent)}")
        return True
    except Exception:
        print(f"ERR {path}")
        traceback.print_exc()
        return False

def main() -> int:
    files = []
    seen = set()
    for folder in SEARCH_DIRS:
        if not folder.exists():
            continue
        for path in folder.rglob("*.py"):
            if path.name == Path(__file__).name:
                continue
            key = path.resolve()
            if key not in seen:
                seen.add(key)
                files.append(path)

    ok = 0
    fail = 0
    for path in sorted(files):
        if compile_one(path):
            ok += 1
        else:
            fail += 1

    print(f"\nPython: {sys.version}")
    print(f"Compiled: {ok}, failed: {fail}")
    return 0 if fail == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())
