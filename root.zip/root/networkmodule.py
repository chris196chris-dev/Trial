# -*- coding: utf-8 -*-
import app
import chr
import dbg
import net
import snd

import chrmgr
import background
import player
import playerSettingModule

import ui
import uiPhaseCurtain
import localeinfo
import constInfo

# MULTI_LANGUAGE - Fast path: reload UI strings only when language changed
def ReloadLocaleIfChanged():
	try:
		import systemSetting
		langCode = systemSetting.GetLanguage()
		if langCode != constInfo.ACTIVE_LANGUAGE:
			app.ReloadLocaleLoginStrings()
			import uiScriptLocale
			uiScriptLocale.ReloadLocaleFile()
			constInfo.ACTIVE_LANGUAGE = langCode
			return True
	except:
		pass
	return False

# MULTI_LANGUAGE - Heavy path: reload item/mob/skill locale data only when needed
def ReloadLocaleNamesIfNeeded():
	try:
		import systemSetting
		langCode = systemSetting.GetLanguage()
		if langCode != constInfo.ACTIVE_LOCALE_NAMES_LANGUAGE:
			app.ReloadLocaleNames(langCode)
			import uiScriptLocale
			uiScriptLocale.ReloadLocaleFile()
			constInfo.ACTIVE_LOCALE_NAMES_LANGUAGE = langCode
			constInfo.ACTIVE_LANGUAGE = langCode
			return True
	except:
		pass
	return False

class PopupDialog(ui.ScriptWindow):

	def __init__(self):
		print("NEW POPUP DIALOG ----------------------------------------------------------------------------")
		ui.ScriptWindow.__init__(self)
		self.CloseEvent = 0

	def __del__(self):
		print("---------------------------------------------------------------------------- DELETE POPUP DIALOG ")
		ui.ScriptWindow.__del__(self)

	def LoadDialog(self):
		PythonScriptLoader = ui.PythonScriptLoader()
		PythonScriptLoader.LoadScriptFile(self, "UIScript/PopupDialog.py")

	def Open(self, Message, event = 0, ButtonName = None):
		#MULTI_LANGUAGE - Dynamic lookup for default button name
		if ButtonName is None:
			ButtonName = localeinfo.Get("UI_CANCEL")
		#MULTI_LANGUAGE

		if True == self.IsShow():
			self.Close()

		self.Lock()
		self.SetTop()
		self.CloseEvent = event

		AcceptButton = self.GetChild("accept")
		AcceptButton.SetText(ButtonName)
		AcceptButton.SetEvent(ui.__mem_func__(self.Close))

		self.GetChild("message").SetText(Message)
		self.Show()

	def Close(self):

		if False == self.IsShow():
			self.CloseEvent = 0
			return

		self.Unlock()
		self.Hide()

		if 0 != self.CloseEvent:
			self.CloseEvent()
			self.CloseEvent = 0

	def Destroy(self):
		self.Close()
		self.ClearDictionary()

	def OnPressEscapeKey(self):
		self.Close()
		return True

	def OnIMEReturn(self):
		self.Close()
		return True

class MainStream(object):

	def __init__(self):
		print("NEWMAIN STREAM ----------------------------------------------------------------------------")
		net.SetHandler(self)
		net.SetTCPRecvBufferSize(128*1024)
		net.SetTCPSendBufferSize(4096)

		self.id=""
		self.pwd=""
		if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
			self.pin=""
		self.addr=""
		self.port=0
		self.account_addr=0
		self.account_port=0
		self.slot=0
		self.isAutoSelect=0
		self.isAutoLogin=0

		self.curtain = 0
		self.curPhaseWindow = 0
		self.newPhaseWindow = 0

	def __del__(self):
		print("---------------------------------------------------------------------------- DELETE MAIN STREAM ")

	def Destroy(self):
		if self.curPhaseWindow:
			self.curPhaseWindow.Close()
			self.curPhaseWindow = 0

		if self.newPhaseWindow:
			self.newPhaseWindow.Close()
			self.newPhaseWindow = 0

		self.popupWindow.Destroy()
		self.popupWindow = 0

		self.curtain = 0

	def Create(self):
		self.CreatePopupDialog()

		self.curtain = uiPhaseCurtain.PhaseCurtain()

	def SetPhaseWindow(self, newPhaseWindow):
		if self.newPhaseWindow:
			self.__ChangePhaseWindow()

		self.newPhaseWindow=newPhaseWindow
		if self.curPhaseWindow:
			self.curtain.FadeOut(self.__ChangePhaseWindow)
		else:
			self.__ChangePhaseWindow()

	def __ChangePhaseWindow(self):
		oldPhaseWindow=self.curPhaseWindow
		newPhaseWindow=self.newPhaseWindow
		self.curPhaseWindow=0
		self.newPhaseWindow=0

		if oldPhaseWindow:
			oldPhaseWindow.Close()

		if newPhaseWindow:
			newPhaseWindow.Open()

		self.curPhaseWindow=newPhaseWindow
		
		if self.curPhaseWindow:
			self.curtain.FadeIn()
		else:
			app.Exit()

	def CreatePopupDialog(self):
		self.popupWindow = PopupDialog()
		self.popupWindow.LoadDialog()
		self.popupWindow.SetCenterPosition()
		self.popupWindow.Hide()

	def SetLoginPhase(self):
		net.Disconnect()

		# Always load login-only locale strings before opening login UI.
		# This avoids missing keys when returning from in-game language changes.
		try:
			import systemSetting
			langCode = systemSetting.GetLanguage()
			app.ReloadLocaleLoginStrings()
			import uiScriptLocale
			uiScriptLocale.ReloadLocaleFile()
			constInfo.ACTIVE_LANGUAGE = langCode
		except:
			ReloadLocaleIfChanged()

		import introLogin
		self.SetPhaseWindow(introLogin.LoginWindow(self))

	def SetSelectEmpirePhase(self):
		try:
			import introEmpire	
			self.SetPhaseWindow(introEmpire.SelectEmpireWindow(self))
		except:
			import exception
			exception.Abort("networkModule.SetSelectEmpirePhase")


	def SetReselectEmpirePhase(self):
		try:
			import introEmpire
			self.SetPhaseWindow(introEmpire.ReselectEmpireWindow(self))
		except:
			import exception
			exception.Abort("networkModule.SetReselectEmpirePhase")

	def SetSelectCharacterPhase(self):
		try:
			ReloadLocaleIfChanged()

			localeinfo.LoadLocaleData()
			import uiScriptLocale
			uiScriptLocale.ReloadLocaleFile()

			import systemSetting
			langCode = systemSetting.GetLanguage()
			constInfo.ACTIVE_LOCALE_NAMES_LANGUAGE = langCode
			constInfo.ACTIVE_LANGUAGE = langCode

			import introSelect
			self.popupWindow.Close()
			self.SetPhaseWindow(introSelect.SelectCharacterWindow(self))
		except:
			import exception
			exception.Abort("networkModule.SetSelectCharacterPhase")

	def SetCreateCharacterPhase(self):
		try:
			import introCreate
			self.SetPhaseWindow(introCreate.CreateCharacterWindow(self))
		except:
			import exception
			exception.Abort("networkModule.SetCreateCharacterPhase")

	def SetLoadingPhase(self):
		try:
			import introLoading
			self.SetPhaseWindow(introLoading.LoadingWindow(self))
		except:
			import exception
			exception.Abort("networkModule.SetLoadingPhase")

	def SetGamePhase(self):
		try:
			ReloadLocaleIfChanged()
			ReloadLocaleNamesIfNeeded()

			import game
			self.popupWindow.Close()
			self.SetPhaseWindow(game.GameWindow(self))
		except:
			raise

	def Connect(self):		
		import constInfo
		if constInfo.KEEP_ACCOUNT_CONNETION_ENABLE:
			net.ConnectToAccountServer(self.addr, self.port, self.account_addr, self.account_port)
		else:
			net.ConnectTCP(self.addr, self.port)

	def SetConnectInfo(self, addr, port, account_addr=0, account_port=0):
		self.addr = addr
		self.port = port
		self.account_addr = account_addr
		self.account_port = account_port

	def GetConnectAddr(self):
		return self.addr

	if app.ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN:
		def SetLoginInfo(self, id, pwd, pin):
			self.id = id
			self.pwd = pwd
			self.pin = pin
			net.SetLoginInfo(id, pwd, pin)
	else:
		def SetLoginInfo(self, id, pwd):
			self.id = id
			self.pwd = pwd
			net.SetLoginInfo(id, pwd)

	def SetCharacterSlot(self, slot):
		self.slot=slot

	def GetCharacterSlot(self):
		return self.slot

