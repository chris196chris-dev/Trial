# -*- coding: utf-8 -*-
import sys
import __main__
import app
import dbg
import marshal
import pack
import builtins
import importlib
import types

sys.path = []
sys.path.append("lib")

class TraceFile:
	def write(self, msg):
		dbg.Trace(msg)
		
	def flush(self):
		pass

class TraceErrorFile:
	def write(self, msg):
		dbg.TraceError(msg)
		dbg.RegisterExceptionString(msg)
		
	def flush(self):
		pass

class LogBoxFile:
	def __init__(self):
		self.stderrSave = sys.stderr
		self.msg = ""

	def __del__(self):
		self.restore()

	def restore(self):
		sys.stderr = self.stderrSave

	def write(self, msg):
		self.msg = self.msg + msg

	def show(self):
		dbg.TraceError(self.msg)
		dbg.LogBox(self.msg, "Error")

sys.stdout = TraceFile()
sys.stderr = TraceErrorFile()

class LocaleInfoWrapper(object):
	def __init__(self, wrapped):
		self.wrapped = wrapped
	def __getattr__(self, name):
		try:
			return getattr(self.wrapped, name)
		except AttributeError:
			dbg.TraceError("Locale attribute not found: {}".format(name))
			return name

class pack_file_iterator(object):
	def __init__(self, packfile):
		self.pack_file = packfile

	def __iter__(self):
		# Python 3 requires iterator objects to return themselves from __iter__.
		return self

	def __next__(self):
		tmp = self.pack_file.readline()
		if tmp:
			return tmp
		raise StopIteration

	# Keep Python 2 style alias harmless for compatibility with old scripts.
	next = __next__

_chr = chr

builtins.NEW_PACK_FILE = True
if NEW_PACK_FILE:
	builtins.old_len = len

_TEXT_DECODE_ENCODINGS = ("utf-8-sig", "utf-8", "cp1253", "cp1252", "latin1")

def _decode_pack_text(data):
	if isinstance(data, str):
		return data.replace("\r\n", "\n")
	for enc in _TEXT_DECODE_ENCODINGS:
		try:
			return data.decode(enc).replace("\r\n", "\n")
		except Exception:
			pass
	return data.decode("latin1", "ignore").replace("\r\n", "\n")

class pack_file(object):
	def __init__(self, filename, mode='rb'):
		assert mode in ('r', 'rb')
		if not pack.Exist(filename):
			raise IOError('No file or directory')

		self.data = pack.Get(filename)
		if NEW_PACK_FILE and not self.data:
			with open(filename, 'rb') as tmp:
				self.data = tmp.read() or b''

		if mode == 'r':
			self.data = _decode_pack_text(self.data)

		self.mode = mode
		self.closed = False
		self.tell_size = 0

	def __enter__(self):
		return self

	def __exit__(self, exc_type, exc_value, traceback):
		self.close()

	def __iter__(self):
		return pack_file_iterator(self)

	def read(self, length=0):
		if not self.data:
			return ''
		if length:
			tmp = self.data[:length]
			if NEW_PACK_FILE:
				self.tell_size += len(tmp)
			self.data = self.data[length:]
			return tmp
		else:
			tmp = self.data
			if NEW_PACK_FILE:
				self.tell_size += len(tmp)
			self.data = ''
			return tmp

	def readline(self):
		newline_index = self.data.find('\\n') + 1
		return self.read(newline_index)

	def readlines(self):
		# Avoid relying on iterator protocol here; this is used by npclist.txt loading.
		if not self.data:
			return []
		data = self.data
		if NEW_PACK_FILE:
			self.tell_size += len(data)
		self.data = '' if isinstance(data, str) else b''
		if isinstance(data, str):
			return data.splitlines(True)
		return data.splitlines(True)

	if NEW_PACK_FILE:
		def tell(self):
			return self.tell_size

		def close(self):
			self.closed = True
			self.data = ''

		def flush(self):
			pass

		def seek(self, offset, whence=0):
			pass

old_open = open
def open(filename, mode='rb'):
	if pack.Exist(filename) and mode in ('r', 'rb'):
		return pack_file(filename, mode)
	else:
		return old_open(filename, mode)

builtins.open = open
builtins.old_open = old_open
builtins.new_open = open
builtins.pack_open = open
builtins.pack_exist = pack.Exist

_ModuleType = type(sys)

old_import = __import__

def _process_result(code, fqname):
	is_module = isinstance(code, types.ModuleType)

	if is_module:
		module = code
	else:
		module = types.ModuleType(fqname)

	sys.modules[fqname] = module

	if not is_module:
		exec(code, module.__dict__)

	module = sys.modules[fqname]
	module.__name__ = fqname
	return module

module_do = lambda x: None

def __hybrid_import(name, globals=None, locals=None, fromlist=None, level=0):
	filename = name + '.py'

	if pack.Exist(filename):
		if name in sys.modules:
			dbg.Tracen('importing from sys.modules %s' % name)
			return sys.modules[name]

		dbg.Tracen('importing from pack %s' % name)

		newmodule = _process_result(compile(pack_file(filename, 'r').read(), filename, 'exec'), name)

		module_do(newmodule)
		if name.lower() in ("localeinfo", "uiscriptlocale"):
			newmodule = LocaleInfoWrapper(newmodule)
			sys.modules[name] = newmodule
		return newmodule
	else:
		dbg.Tracen('importing from lib %s' % name)
		return old_import(name, globals, locals, fromlist, level)

def splitext(p):
	root, ext = '', ''
	for c in p:
		if c in ['/']:
			root, ext = root + ext + c, ''
		elif c == '.':
			if ext:
				root, ext = root + ext, c
			else:
				ext = c
		elif ext:
			ext = ext + c
		else:
			root = root + c
	return root, ext

def __IsCompiledFile__(sFileName):
	sBase, sExt = splitext(sFileName)
	sExt = sExt.lower()
	return sExt in [".pyc", ".pyo"]

def __LoadTextFile__(sFileName):
	sText = open(sFileName, 'r').read()
	return compile(sText, sFileName, "exec")

def __LoadCompiledFile__(sFileName):
	with open(sFileName, 'rb') as kFile:
		if kFile.read(4) != importlib.util.MAGIC_NUMBER:
			raise ValueError("Bad magic number")
		# Python 3.7+ (including 3.14) uses a 4-word .pyc header as per PEP 552.
		# The legacy loader only skipped one extra word, which corrupts marshal.loads()
		# on modern interpreters.
		kFile.seek(0)
		kData = kFile.read()
		if len(kData) < 16:
			raise EOFError("marshal data too short")
		return marshal.loads(kData[16:])

def execfile(fileName, dict):
	if __IsCompiledFile__(fileName):
		code = __LoadCompiledFile__(fileName)
	else:
		code = __LoadTextFile__(fileName)
	exec(code, dict)

builtins.__import__ = __hybrid_import

builtins.execfile = execfile

# Python 2 compatibility aliases for legacy client scripts
builtins.range = range
builtins.str = str
builtins.int = int
builtins.str = str
builtins.TRUE = True
builtins.FALSE = False
def apply(func, args=(), kwargs=None):
	if kwargs is None:
		kwargs = {}
	return func(*args, **kwargs)
builtins.apply = apply

# Legacy "exception" module compatibility used across many client scripts.
# Some old code does `import exception; exception.Abort(...)`. Provide a minimal
# shim centrally so individual script files do not all need patching.
if "exception" not in sys.modules:
	exception_module = types.ModuleType("exception")
	def _exception_abort(excTitle="Abort"):
		ShowException(excTitle)
	def _exception_show(excTitle="ShowException"):
		ShowException(excTitle)
	exception_module.Abort = _exception_abort
	exception_module.ShowException = _exception_show
	sys.modules["exception"] = exception_module
def StringColorToInt(colorstring):
	import grp
	colorstring = colorstring.strip()
	if len(colorstring) != 10:
		raise ValueError("input #%s is not in #0xAARRGGBB format" % colorstring)
	a, r, g, b = colorstring[2:4], colorstring[4:6], colorstring[6:8],colorstring[8:10]
	a = int(a, 16)
	r = int(r, 16)
	g = int(g, 16)
	b = int(b, 16)
	return grp.GenerateColor(float(r) / 255.0, float(g) / 255.0, float(b) / 255.0, float(a) / 255.0)
builtins.CTOA = StringColorToInt
def GetExceptionString(excTitle):
	(excType, excMsg, excTraceBack) = sys.exc_info()
	excText = "\\n"

	import traceback
	traceLineList = traceback.extract_tb(excTraceBack)

	for traceLine in traceLineList:
		if traceLine[3]:
			excText += "%s(line:%d) %s - %s\\n" % (traceLine[0], traceLine[1], traceLine[2], traceLine[3])
		else:
			excText += "%s(line:%d) %s\\n" % (traceLine[0], traceLine[1], traceLine[2])

	excText += "\\n%s - %s:%s\\n" % (excTitle, excType.__name__, excMsg)
	return excText

def ShowException(excTitle):
	excText = GetExceptionString(excTitle)
	dbg.TraceError(excText)
	app.Abort()
	return 0

def RunMainScript(name):
	try:
		execfile(name, __main__.__dict__)
	except RuntimeError as msg:
		msg = str(msg)

		import localeInfo
		if localeInfo.error:
			msg = localeInfo.error.get(msg, msg)

		dbg.TraceError(msg)
		dbg.LogBox(msg)
		app.Abort()

	except Exception as e:
		msg = GetExceptionString("Run")
		dbg.TraceError(msg)
		dbg.LogBox(msg)
		app.Abort()
		
RunMainScript("prototype.py")
