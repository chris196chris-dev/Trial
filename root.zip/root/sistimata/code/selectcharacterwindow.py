import uiScriptLocale
import app
window = {
	"name" : "SelectCharacterWindow",
	"x" : 0,
	"y" : 0,
	"width" : SCREEN_WIDTH,
	"height" : SCREEN_HEIGHT,
	"children" :
	(
		{
			"name" : "background",
			"type" : "expanded_image",
			"x" : 0,
			"y" : 0,
			"x_scale" : float(SCREEN_WIDTH) / 1280.0,
			"y_scale" : float(SCREEN_HEIGHT) / 720.0,
			"image" : "sistimata/images/select/background.tga",
			
			"children" : 
			(
				{
					"name" : "character_board",
					"type" : "image",
					"vertical_align" : "center",
					"horizontal_align" : "left",
					"x" : 30,
					"y" : -35,
					"image" : "sistimata/images/select/select/board.tga",
					"children" :
					(
						{
							"name" : "name",
							"type" : "slotbar",
							"x" : 210,
							"y" : 76,
							"width" : 118,
							"height" : 21,
							"children" :
							(
								{
									"name" : "name_value",
									"type" : "text",
									"x" : 0,
									"y" : -1,
									"text" : "",
									"all_align" : "true",
								},
							),
						},
						{
							"name" : "empire",
							"type" : "slotbar",
							"x" : 210,
							"y" : 106,
							"width" : 118,
							"height" : 21,
							"children" :
							(
								{
									"name" : "empire_value",
									"type" : "text",
									"x" : 0,
									"y" : -1,
									"text" : "",
									"all_align" : "true",
								},
							),
						},
						{
							"name" : "level",
							"type" : "slotbar",
							"x" : 210,
							"y" : 136,
							"width" : 118,
							"height" : 21,
							"children" :
							(
								{
									"name" : "level_value",
									"type" : "text",
									"x" : 0,
									"y" : -1,
									"text" : "",
									"all_align" : "true",
								},
							),
						},
						{
							"name" : "playtime",
							"type" : "slotbar",
							"x" : 210,
							"y" : 166,
							"width" : 118,
							"height" : 21,
							"children" :
							(
								{
									"name" : "playtime_value",
									"type" : "text",
									"x" : 0,
									"y" : -1,
									"text" : "",
									"all_align" : "true",
								},
							),
						},
						{
							"name" : "guild",
							"type" : "slotbar",
							"x" : 210,
							"y" : 196,
							"width" : 118,
							"height" : 21,
							"children" :
							(
								{
									"name" : "guild_value",
									"type" : "text",
									"x" : 0,
									"y" : -1,
									"text" : "",
									"all_align" : "true",
								},
							),
						},
						{
							"name" : "character_hth",
							"type" : "text",
							"x" : 355,
							"y" : 95,
							"text" : uiScriptLocale.SELECT_HP,
							"children" :
							(
								{
									"name" : "gauge_hth",
									"type" : "gauge",
									"x" : 30,
									"y" : 4,
									"width" : 100,
									"color" : "red",
								},
								{
									"name" : "character_hth_slot",
									"type" : "image",
									"x" : 134,
									"y" : -2,
									"image" : "d:/ymir work/ui/public/Parameter_Slot_00.sub",
									"children" : 
									(
										{
											"name" : "character_hth_value",
											"type" : "text",
											"x" : 0,
											"y" : -2,
											"all_align" : "true",
										},
									),
								},
							),
						},
						{
							"name" : "character_int",
							"type" : "text",
							"x" : 355,
							"y" : 125,
							"text" : uiScriptLocale.SELECT_SP,
							"children" :
							(
								{
									"name" : "gauge_int",
									"type" : "gauge",
									"x" : 30,
									"y" : 4,
									"width" : 100,
									"color" : "pink",
								},
								{
									"name" : "character_int_slot",
									"type" : "image",
									"x" : 134,
									"y" : -2,
									"image" : "d:/ymir work/ui/public/Parameter_Slot_00.sub",
									"children" : 
									(
										{
											"name" : "character_int_value",
											"type" : "text",
											"x" : 0,
											"y" : -2,
											"all_align" : "true",
										},
									),
								},
							),
						},
						{
							"name" : "character_str",
							"type" : "text",
							"x" : 355,
							"y" : 155,
							"text" : uiScriptLocale.SELECT_ATT_GRADE,
							"children" :
							(
								{
									"name" : "gauge_str",
									"type" : "gauge",
									"x" : 30,
									"y" : 4,
									"width" : 100,
									"color" : "purple",
								},
								{
									"name" : "character_str_slot",
									"type" : "image",
									"x" : 134,
									"y" : -2,
									"image" : "d:/ymir work/ui/public/Parameter_Slot_00.sub",
									"children" : 
									(
										{
											"name" : "character_str_value",
											"type" : "text",
											"x" : 0,
											"y" : -2,
											"all_align" : "true",
										},
									),
								},
							),
						},
						{
							"name" : "character_dex",
							"type" : "text",
							"x" : 355,
							"y" : 185,
							"text" : uiScriptLocale.SELECT_DEX_GRADE,
							"children" :
							(
								{
									"name" : "gauge_dex",
									"type" : "gauge",
									"x" : 30,
									"y" : 4,
									"width" : 100,
									"color" : "blue",
								},
								{
									"name" : "character_dex_slot",
									"type" : "image",
									"x" : 134,
									"y" : -2,
									"image" : "d:/ymir work/ui/public/Parameter_Slot_00.sub",
									"children" :
									(
										{
											"name" : "character_dex_value",
											"type" : "text",
											"x" : 0,
											"y" : -2,
											"all_align" : "true",
										},
									),
								},
							),
						},
						{
							"name" : "start_button",
							"type" : "button",
							"x" : -15,
							"y" : 135,
							"vertical_align" : "center",
							"horizontal_align" : "center",
							"default_image" : "sistimata/images/select/select/enter_0.tga",
							"over_image" : "sistimata/images/select/select/enter_1.tga",
							"down_image" : "sistimata/images/select/select/enter_2.tga",
						},
						{
							"name" : "delete_button",
							"type" : "button",
							"x" : 110,
							"y" : 50,
							"vertical_align" : "bottom",
							"horizontal_align" : "center",
							"default_image" : "sistimata/images/select/select/delete_0.tga",
							"over_image" : "sistimata/images/select/select/delete_1.tga",
							"down_image" : "sistimata/images/select/select/delete_2.tga",
						},
						{
							"name" : "created_button",
							"type" : "button",
							"x" : 1,
							"y" : 1,
							"width" : 118,
							"height" : 21,
							"default_image" : "sistimata/images/select/select/board_0.tga",
							"over_image" : "sistimata/images/select/select/board_1.tga",
							"down_image" : "sistimata/images/select/select/board_2.tga",
						},
					),
				},
				{
					"name" : "char1",
					"type" : "radio_button",
					"vertical_align" : "center",
					"horizontal_align" : "left",
					"x" : 50,
					"y" : -235,
					"default_image" : "sistimata/images/select/select/empty_0.tga",
					"over_image" : "sistimata/images/select/select/empty_1.tga",
					"down_image" : "sistimata/images/select/select/empty_2.tga",
				},
				{
					"name" : "char2",
					"type" : "radio_button",
					"vertical_align" : "center",
					"horizontal_align" : "left",
					"x" : 200,
					"y" : -235,
					"default_image" : "sistimata/images/select/select/empty_0.tga",
					"over_image" : "sistimata/images/select/select/empty_1.tga",
					"down_image" : "sistimata/images/select/select/empty_2.tga",
				},
				{
					"name" : "char3",
					"type" : "radio_button",
					"vertical_align" : "center",
					"horizontal_align" : "left",
					"x" : 350,
					"y" : -235,
					"default_image" : "sistimata/images/select/select/empty_0.tga",
					"over_image" : "sistimata/images/select/select/empty_1.tga",
					"down_image" : "sistimata/images/select/select/empty_2.tga",
				},
				{
					"name" : "char4",
					"type" : "radio_button",
					"vertical_align" : "center",
					"horizontal_align" : "left",
					"x" : 500,
					"y" : -235,
					"default_image" : "sistimata/images/select/select/empty_0.tga",
					"over_image" : "sistimata/images/select/select/empty_1.tga",
					"down_image" : "sistimata/images/select/select/empty_2.tga",
				},
				{
					"name" : "footer",
					"type" : "image",
					"x" : 495,
					"y" : 60,
					"horizontal_align" : "right",
					"vertical_align" : "bottom",
					"image" : "sistimata/images/select/select/footer.tga",
				},
			),
		},
	),
}
