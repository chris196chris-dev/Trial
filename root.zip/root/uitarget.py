# -*- coding: utf-8 -*-
import app
import ui
import player
import net
import wndMgr
import messenger
import guild
import chr
import nonplayer
import localeinfo
import constInfo

class TargetBoard(ui.ThinBoard):
	#MULTI_LANGUAGE - Use constant keys instead of localized strings
	BUTTON_WHISPER = "WHISPER"
	BUTTON_EXCHANGE = "EXCHANGE"
	BUTTON_FIGHT = "FIGHT"
	BUTTON_ACCEPT_FIGHT = "ACCEPT_FIGHT"
	BUTTON_AVENGE = "AVENGE"
	BUTTON_FRIEND = "FRIEND"
	BUTTON_INVITE_PARTY = "INVITE_PARTY"
	BUTTON_LEAVE_PARTY = "LEAVE_PARTY"
	BUTTON_EXCLUDE = "EXCLUDE"
	BUTTON_BLOCK = "BLOCK"
	BUTTON_INVITE_GUILD = "INVITE_GUILD"
	BUTTON_DISMOUNT = "DISMOUNT"
	BUTTON_EXIT_OBSERVER = "EXIT_OBSERVER"
	BUTTON_VIEW_EQUIPMENT = "VIEW_EQUIPMENT"
	BUTTON_REQUEST_ENTER_PARTY = "REQUEST_ENTER_PARTY"
	BUTTON_BUILDING_DESTROY = "BUILDING_DESTROY"
	BUTTON_EMOTION_ALLOW = "EMOTION_ALLOW"
	BUTTON_VOTE_BLOCK_CHAT = "VOTE_BLOCK_CHAT"

	BUTTON_KEY_LIST = (
		BUTTON_WHISPER,
		BUTTON_EXCHANGE,
		BUTTON_FIGHT,
		BUTTON_ACCEPT_FIGHT,
		BUTTON_AVENGE,
		BUTTON_FRIEND,
		BUTTON_INVITE_PARTY,
		BUTTON_LEAVE_PARTY,
		BUTTON_EXCLUDE,
		BUTTON_BLOCK,
		BUTTON_INVITE_GUILD,
		BUTTON_DISMOUNT,
		BUTTON_EXIT_OBSERVER,
		BUTTON_VIEW_EQUIPMENT,
		BUTTON_REQUEST_ENTER_PARTY,
		BUTTON_BUILDING_DESTROY,
		BUTTON_EMOTION_ALLOW,
		BUTTON_VOTE_BLOCK_CHAT,
	)

	# Map constant keys to locale keys for getting button text
	BUTTON_LOCALE_MAP = {
		BUTTON_WHISPER: "TARGET_BUTTON_WHISPER",
		BUTTON_EXCHANGE: "TARGET_BUTTON_EXCHANGE",
		BUTTON_FIGHT: "TARGET_BUTTON_FIGHT",
		BUTTON_ACCEPT_FIGHT: "TARGET_BUTTON_ACCEPT_FIGHT",
		BUTTON_AVENGE: "TARGET_BUTTON_AVENGE",
		BUTTON_FRIEND: "TARGET_BUTTON_FRIEND",
		BUTTON_INVITE_PARTY: "TARGET_BUTTON_INVITE_PARTY",
		BUTTON_LEAVE_PARTY: "TARGET_BUTTON_LEAVE_PARTY",
		BUTTON_EXCLUDE: "TARGET_BUTTON_EXCLUDE",
		BUTTON_BLOCK: "TARGET_BUTTON_BLOCK",
		BUTTON_INVITE_GUILD: "TARGET_BUTTON_INVITE_GUILD",
		BUTTON_DISMOUNT: "TARGET_BUTTON_DISMOUNT",
		BUTTON_EXIT_OBSERVER: "TARGET_BUTTON_EXIT_OBSERVER",
		BUTTON_VIEW_EQUIPMENT: "TARGET_BUTTON_VIEW_EQUIPMENT",
		BUTTON_REQUEST_ENTER_PARTY: "TARGET_BUTTON_REQUEST_ENTER_PARTY",
		BUTTON_BUILDING_DESTROY: "TARGET_BUTTON_BUILDING_DESTROY",
		BUTTON_EMOTION_ALLOW: "TARGET_BUTTON_EMOTION_ALLOW",
		BUTTON_VOTE_BLOCK_CHAT: "VOTE_BLOCK_CHAT",
	}

	#MULTI_LANGUAGE - Use locale keys instead of cached translations
	GRADE_LOCALE_KEYS = {
		nonplayer.PAWN : "TARGET_LEVEL_PAWN",
		nonplayer.S_PAWN : "TARGET_LEVEL_S_PAWN",
		nonplayer.KNIGHT : "TARGET_LEVEL_KNIGHT",
		nonplayer.S_KNIGHT : "TARGET_LEVEL_S_KNIGHT",
		nonplayer.BOSS : "TARGET_LEVEL_BOSS",
		nonplayer.KING : "TARGET_LEVEL_KING",
	}
	#MULTI_LANGUAGE
	EXCHANGE_LIMIT_RANGE = 3000

	def __init__(self):
		ui.ThinBoard.__init__(self)

		name = ui.TextLine()
		name.SetParent(self)
		name.SetDefaultFontName()
		name.SetOutline()
		name.Show()

		hpGauge = ui.Gauge()
		hpGauge.SetParent(self)
		hpGauge.MakeGauge(130, "red")
		hpGauge.Hide()

		if app.ENABLE_VIEW_TARGET_PLAYER_HP:
			hpDecimal = ui.TextLine()
			hpDecimal.SetParent(hpGauge)
			hpDecimal.SetDefaultFontName()
			hpDecimal.SetPosition(5, 5)
			hpDecimal.SetOutline()
			hpDecimal.Hide()

		closeButton = ui.Button()
		closeButton.SetParent(self)
		closeButton.SetUpVisual("d:/ymir work/ui/public/close_button_01.sub")
		closeButton.SetOverVisual("d:/ymir work/ui/public/close_button_02.sub")
		closeButton.SetDownVisual("d:/ymir work/ui/public/close_button_03.sub")
		closeButton.SetPosition(30, 13)

		hpGauge.SetPosition(175, 17)
		hpGauge.SetWindowHorizontalAlignRight()
		closeButton.SetWindowHorizontalAlignRight()

		closeButton.SetEvent(ui.__mem_func__(self.OnPressedCloseButton))
		closeButton.Show()

		self.buttonDict = {}
		self.showingButtonList = []

		#MULTI_LANGUAGE - Use constant keys for buttons
		for buttonKey in self.BUTTON_KEY_LIST:
			button = ui.Button()
			button.SetParent(self)
			button.SetUpVisual("d:/ymir work/ui/public/small_thin_button_01.sub")
			button.SetOverVisual("d:/ymir work/ui/public/small_thin_button_02.sub")
			button.SetDownVisual("d:/ymir work/ui/public/small_thin_button_03.sub")

			button.SetWindowHorizontalAlignCenter()
			# Get localized text for button
			localeKey = self.BUTTON_LOCALE_MAP.get(buttonKey, buttonKey)
			button.SetText(localeinfo.Get(localeKey))
			button.Hide()
			self.buttonDict[buttonKey] = button
			self.showingButtonList.append(button)

		# Set button events using constant keys
		self.buttonDict[self.BUTTON_WHISPER].SetEvent(ui.__mem_func__(self.OnWhisper))
		self.buttonDict[self.BUTTON_EXCHANGE].SetEvent(ui.__mem_func__(self.OnExchange))
		self.buttonDict[self.BUTTON_FIGHT].SetEvent(ui.__mem_func__(self.OnPVP))
		self.buttonDict[self.BUTTON_ACCEPT_FIGHT].SetEvent(ui.__mem_func__(self.OnPVP))
		self.buttonDict[self.BUTTON_AVENGE].SetEvent(ui.__mem_func__(self.OnPVP))
		self.buttonDict[self.BUTTON_FRIEND].SetEvent(ui.__mem_func__(self.OnAppendToMessenger))
		self.buttonDict[self.BUTTON_INVITE_PARTY].SetEvent(ui.__mem_func__(self.OnPartyInvite))
		self.buttonDict[self.BUTTON_LEAVE_PARTY].SetEvent(ui.__mem_func__(self.OnPartyExit))
		self.buttonDict[self.BUTTON_EXCLUDE].SetEvent(ui.__mem_func__(self.OnPartyRemove))

		if app.ENABLE_PLAYER_BLOCK_SYSTEM:
			self.buttonDict[self.BUTTON_BLOCK].SAFE_SetEvent(self.__OnPlayerBlock)
		self.buttonDict[self.BUTTON_INVITE_GUILD].SAFE_SetEvent(self.__OnGuildAddMember)
		self.buttonDict[self.BUTTON_DISMOUNT].SAFE_SetEvent(self.__OnDismount)
		self.buttonDict[self.BUTTON_EXIT_OBSERVER].SAFE_SetEvent(self.__OnExitObserver)
		self.buttonDict[self.BUTTON_VIEW_EQUIPMENT].SAFE_SetEvent(self.__OnViewEquipment)
		self.buttonDict[self.BUTTON_REQUEST_ENTER_PARTY].SAFE_SetEvent(self.__OnRequestParty)
		self.buttonDict[self.BUTTON_BUILDING_DESTROY].SAFE_SetEvent(self.__OnDestroyBuilding)
		self.buttonDict[self.BUTTON_EMOTION_ALLOW].SAFE_SetEvent(self.__OnEmotionAllow)

		self.buttonDict[self.BUTTON_VOTE_BLOCK_CHAT].SetEvent(ui.__mem_func__(self.__OnVoteBlockChat))

		self.name = name
		self.hpGauge = hpGauge
		if app.ENABLE_VIEW_TARGET_PLAYER_HP:
			self.hpDecimal = hpDecimal
		self.closeButton = closeButton
		self.nameString = 0
		self.nameLength = 0
		self.vid = 0
		self.eventWhisper = None
		self.isShowButton = False

		self.__Initialize()
		self.ResetTargetBoard()

	def __del__(self):
		ui.ThinBoard.__del__(self)

		print("===================================================== DESTROYED TARGET BOARD")

	def __Initialize(self):
		self.nameString = ""
		self.nameLength = 0
		self.vid = 0
		self.isShowButton = False

	def Destroy(self):
		self.eventWhisper = None
		self.closeButton = None
		self.showingButtonList = None
		self.buttonDict = None
		self.name = None
		self.hpGauge = None
		if app.ENABLE_VIEW_TARGET_PLAYER_HP:
			self.hpDecimal = None
		self.__Initialize()

	def OnPressedCloseButton(self):
		player.ClearTarget()
		self.Close()

	def Close(self):
		self.__Initialize()
		self.Hide()

	def Open(self, vid, name):
		if vid:
			if not constInfo.GET_VIEW_OTHER_EMPIRE_PLAYER_TARGET_BOARD():
				if not player.IsSameEmpire(vid):
					self.Hide()
					return

			if vid != self.GetTargetVID():
				self.ResetTargetBoard()
				self.SetTargetVID(vid)
				self.SetTargetName(name)

			if player.IsMainCharacterIndex(vid):
				self.__ShowMainCharacterMenu()		
			elif chr.INSTANCE_TYPE_BUILDING == chr.GetInstanceType(self.vid):
				self.Hide()
			else:
				self.RefreshButton()
				self.Show()
		else:
			self.HideAllButton()
			self.__ShowButton(self.BUTTON_WHISPER)
			self.__ShowButton("VOTE_BLOCK_CHAT")
			self.__ArrangeButtonPosition()
			self.SetTargetName(name)
			self.Show()
			
	def Refresh(self):
		if self.IsShow():
			if self.IsShowButton():			
				self.RefreshButton()		

	def RefreshByVID(self, vid):
		if vid == self.GetTargetVID():			
			self.Refresh()
			
	def RefreshByName(self, name):
		if name == self.GetTargetName():
			self.Refresh()

	def __ShowMainCharacterMenu(self):
		canShow=0

		self.HideAllButton()

		if player.IsMountingHorse():
			self.__ShowButton(self.BUTTON_DISMOUNT)
			canShow=1

		if player.IsObserverMode():
			self.__ShowButton(self.BUTTON_EXIT_OBSERVER)
			canShow=1

		if canShow:
			self.__ArrangeButtonPosition()
			self.Show()
		else:
			self.Hide()
			
	def __ShowNameOnlyMenu(self):
		self.HideAllButton()

	def SetWhisperEvent(self, event):
		self.eventWhisper = event

	def UpdatePosition(self):
		self.SetPosition(int(wndMgr.GetScreenWidth()/2 - self.GetWidth()/2), 10)

	def ResetTargetBoard(self):

		for btn in self.buttonDict.values():
			btn.Hide()

		self.__Initialize()

		self.name.SetPosition(0, 13)
		self.name.SetHorizontalAlignCenter()
		self.name.SetWindowHorizontalAlignCenter()
		self.hpGauge.Hide()
		if app.ENABLE_VIEW_TARGET_PLAYER_HP:
			self.hpDecimal.Hide()
		self.SetSize(250, 40)

	def SetTargetVID(self, vid):
		self.vid = vid

	def SetEnemyVID(self, vid):
		self.SetTargetVID(vid)

		name = chr.GetNameByVID(vid)
		level = nonplayer.GetLevelByVID(vid)
		grade = nonplayer.GetGradeByVID(vid)

		nameFront = ""
		if -1 != level:
			nameFront += "Lv." + str(level) + " "
		#MULTI_LANGUAGE - Fetch fresh translation
		if (grade in self.GRADE_LOCALE_KEYS):
			nameFront += "(" + localeinfo.Get(self.GRADE_LOCALE_KEYS[grade]) + ") "
		#MULTI_LANGUAGE

		self.SetTargetName(nameFront + name)

	def GetTargetVID(self):
		return self.vid

	def GetTargetName(self):
		return self.nameString

	def SetTargetName(self, name):
		self.nameString = name
		self.nameLength = len(name)
		self.name.SetText(name)

	def SetHP(self, hpPercentage):
		if not self.hpGauge.IsShow():

			self.SetSize(200 + 7*self.nameLength, self.GetHeight())
			self.name.SetPosition(23, 13)

			self.name.SetWindowHorizontalAlignLeft()
			self.name.SetHorizontalAlignLeft()
			self.hpGauge.Show()
			self.UpdatePosition()

		self.hpGauge.SetPercentage(hpPercentage, 100)

	if app.ENABLE_VIEW_TARGET_PLAYER_HP:
		def SetHP(self, hpPercentage, iMinHP, iMaxHP):
			if not self.hpGauge.IsShow():
				if app.ENABLE_VIEW_TARGET_PLAYER_HP:
					if self.showingButtonList:
						showingButtonCount = len(self.showingButtonList)
					else:
						showingButtonCount = 0
					
					if showingButtonCount > 0:
						if chr.GetInstanceType(self.vid) == chr.INSTANCE_TYPE_PLAYER:
							self.SetSize(max(150 + 75 * 3, 7 * 75), self.GetHeight())
						else:
							self.SetSize(200 + 7*self.nameLength, self.GetHeight())
					else:
						self.SetSize(200 + 7*self.nameLength, self.GetHeight())
				else:
					self.SetSize(200 + 7*self.nameLength, self.GetHeight())
				
				self.name.SetPosition(23, 13)
				
				self.name.SetWindowHorizontalAlignLeft()
				self.name.SetHorizontalAlignLeft()
				self.hpGauge.Show()
				self.UpdatePosition()
			
			self.hpGauge.SetPercentage(hpPercentage, 100)
			if app.ENABLE_VIEW_TARGET_PLAYER_HP:
				iMinHPText = '.'.join([i - 3 < 0 and str(iMinHP)[:i] or str(iMinHP)[i-3:i] for i in range(len(str(iMinHP)) % 3, len(str(iMinHP))+1, 3) if i])
				iMaxHPText = '.'.join([i - 3 < 0 and str(iMaxHP)[:i] or str(iMaxHP)[i-3:i] for i in range(len(str(iMaxHP)) % 3, len(str(iMaxHP))+1, 3) if i])
				self.hpDecimal.SetText(str(iMinHPText) + "/" + str(iMaxHPText))
				(textWidth, textHeight)=self.hpDecimal.GetTextSize()
				self.hpDecimal.SetPosition(int(130 / 2 - textWidth / 2), -13)
				self.hpDecimal.Show()

	def ShowDefaultButton(self):

		self.isShowButton = True
		self.showingButtonList.append(self.buttonDict[self.BUTTON_WHISPER])
		self.showingButtonList.append(self.buttonDict[self.BUTTON_EXCHANGE])
		self.showingButtonList.append(self.buttonDict[self.BUTTON_FIGHT])
		self.showingButtonList.append(self.buttonDict[self.BUTTON_EMOTION_ALLOW])
		for button in self.showingButtonList:
			button.Show()

	def HideAllButton(self):
		self.isShowButton = False
		for button in self.showingButtonList:
			button.Hide()
		self.showingButtonList = []

	def __ShowButton(self, name):

		if not (name in self.buttonDict):
			return

		self.buttonDict[name].Show()
		self.showingButtonList.append(self.buttonDict[name])

	def __HideButton(self, name):

		if not (name in self.buttonDict):
			return

		button = self.buttonDict[name]
		button.Hide()

		for btnInList in self.showingButtonList:
			if btnInList == button:
				self.showingButtonList.remove(button)
				break

	def OnWhisper(self):
		if None != self.eventWhisper:
			self.eventWhisper(self.nameString)

	def OnExchange(self):
		net.SendExchangeStartPacket(self.vid)

	def OnPVP(self):
		net.SendChatPacket("/pvp %d" % (self.vid))

	def OnAppendToMessenger(self):
		net.SendMessengerAddByVIDPacket(self.vid)

	def OnPartyInvite(self):
		net.SendPartyInvitePacket(self.vid)

	def OnPartyExit(self):
		net.SendPartyExitPacket()

	def OnPartyRemove(self):
		net.SendPartyRemovePacketVID(self.vid)

	def __OnGuildAddMember(self):
		net.SendGuildAddMemberPacket(self.vid)

	def __OnDismount(self):
		net.SendChatPacket("/unmount")

	def __OnExitObserver(self):
		net.SendChatPacket("/observer_exit")

	def __OnViewEquipment(self):
		net.SendChatPacket("/view_equip " + str(self.vid))

	def __OnRequestParty(self):
		net.SendChatPacket("/party_request " + str(self.vid))

	def __OnDestroyBuilding(self):
		net.SendChatPacket("/build d %d" % (self.vid))

	def __OnEmotionAllow(self):
		net.SendChatPacket("/emotion_allow %d" % (self.vid))
		
	def __OnVoteBlockChat(self):
		cmd = "/vote_block_chat %s" % (self.nameString)
		net.SendChatPacket(cmd)

	if app.ENABLE_PLAYER_BLOCK_SYSTEM:
		def __OnPlayerBlock(self):
			net.SendChatPacket("/block_player %s" % (self.nameString))

	def OnPressEscapeKey(self):
		self.OnPressedCloseButton()
		return True

	def IsShowButton(self):
		return self.isShowButton

	def RefreshButton(self):
		self.HideAllButton()
		if chr.INSTANCE_TYPE_BUILDING == chr.GetInstanceType(self.vid):
			return
		
		if player.IsPVPInstance(self.vid) or player.IsObserverMode():
			self.SetSize(200 + 7*self.nameLength, 40)
			self.UpdatePosition()
			return	

		self.ShowDefaultButton()

		if guild.MainPlayerHasAuthority(guild.AUTH_ADD_MEMBER):
			if not guild.IsMemberByName(self.nameString):
				if 0 == chr.GetGuildID(self.vid):
					self.__ShowButton(self.BUTTON_INVITE_GUILD)

		if not messenger.IsFriendByName(self.nameString):
			self.__ShowButton(self.BUTTON_FRIEND)

		if app.ENABLE_PLAYER_BLOCK_SYSTEM:
			if player.IsPlayerBlock(self.vid):
				self.__HideButton(self.BUTTON_BLOCK)
			else:
				self.__ShowButton(self.BUTTON_BLOCK)

		if player.IsPartyMember(self.vid):

			self.__HideButton(self.BUTTON_FIGHT)

			if player.IsPartyLeader(self.vid):
				self.__ShowButton(self.BUTTON_LEAVE_PARTY)
			elif player.IsPartyLeader(player.GetMainCharacterIndex()):
				self.__ShowButton(self.BUTTON_EXCLUDE)

		else:
			if player.IsPartyMember(player.GetMainCharacterIndex()):
				if player.IsPartyLeader(player.GetMainCharacterIndex()):
					self.__ShowButton(self.BUTTON_INVITE_PARTY)
			else:
				if chr.IsPartyMember(self.vid):
					self.__ShowButton(self.BUTTON_REQUEST_ENTER_PARTY)
				else:
					self.__ShowButton(self.BUTTON_INVITE_PARTY)

			if player.IsRevengeInstance(self.vid):
				self.__HideButton(self.BUTTON_FIGHT)
				self.__ShowButton(self.BUTTON_AVENGE)
			elif player.IsChallengeInstance(self.vid):
				self.__HideButton(self.BUTTON_FIGHT)
				self.__ShowButton(self.BUTTON_ACCEPT_FIGHT)
			elif player.IsCantFightInstance(self.vid):
				self.__HideButton(self.BUTTON_FIGHT)

			if not player.IsSameEmpire(self.vid):
				self.__HideButton(self.BUTTON_INVITE_PARTY)
				self.__HideButton(self.BUTTON_FRIEND)
				self.__HideButton(self.BUTTON_FIGHT)

		distance = player.GetCharacterDistance(self.vid)
		if distance > self.EXCHANGE_LIMIT_RANGE:
			self.__HideButton(self.BUTTON_EXCHANGE)
			self.__ArrangeButtonPosition()

		self.__ArrangeButtonPosition()

	def __ArrangeButtonPosition(self):
		showingButtonCount = len(self.showingButtonList)

		pos = -(showingButtonCount / 2) * 68
		if 0 == showingButtonCount % 2:
			pos += 34

		for button in self.showingButtonList:
			button.SetPosition(pos, 33)
			pos += 68

		if app.ENABLE_VIEW_TARGET_PLAYER_HP:
			if showingButtonCount <= 2:
				self.SetSize(max(150 + 125, showingButtonCount * 75), 65)
			else:
				self.SetSize(max(150, showingButtonCount * 75), 65)
		else:
			self.SetSize(max(150, showingButtonCount * 75), 65)

		self.UpdatePosition()

	def OnUpdate(self):
		if self.isShowButton:

			exchangeButton = self.buttonDict[self.BUTTON_EXCHANGE]
			distance = player.GetCharacterDistance(self.vid)

			if distance < 0:
				return

			if exchangeButton.IsShow():
				if distance > self.EXCHANGE_LIMIT_RANGE:
					self.RefreshButton()

			else:
				if distance < self.EXCHANGE_LIMIT_RANGE:
					self.RefreshButton()
