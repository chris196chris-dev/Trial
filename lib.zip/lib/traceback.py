# Minimal traceback module for embedded clients that don't ship _tokenize.
# Purpose: avoid importing codeop/tokenize just to print exceptions.

import sys


def _safe_str(obj):
    try:
        return str(obj)
    except Exception:
        try:
            return repr(obj)
        except Exception:
            return '<unprintable exception>'


def _iter_tb(tb):
    while tb is not None:
        yield tb
        tb = tb.tb_next


def extract_tb(tb, limit=None):
    out = []
    count = 0
    for cur in _iter_tb(tb):
        if limit is not None and count >= limit:
            break
        frame = cur.tb_frame
        code = getattr(frame, 'f_code', None)
        filename = getattr(code, 'co_filename', '<unknown>') if code else '<unknown>'
        name = getattr(code, 'co_name', '<module>') if code else '<module>'
        lineno = getattr(cur, 'tb_lineno', 0)
        out.append((filename, lineno, name, None))
        count += 1
    return out


def format_list(extracted_list):
    lines = []
    for filename, lineno, name, line in extracted_list:
        lines.append('  File "%s", line %s, in %s\n' % (filename, lineno, name))
        if line:
            try:
                lines.append('    %s\n' % line.strip())
            except Exception:
                pass
    return lines


def format_tb(tb, limit=None):
    return format_list(extract_tb(tb, limit))


def print_tb(tb, limit=None, file=None):
    if file is None:
        file = sys.stderr
    for line in format_tb(tb, limit):
        try:
            file.write(line)
        except Exception:
            pass


def format_exception_only(exc_type, exc_value):
    name = getattr(exc_type, '__name__', _safe_str(exc_type))
    if exc_value is None:
        return [name + '\n']
    return ['%s: %s\n' % (name, _safe_str(exc_value))]


def format_exception(exc_type, exc_value, exc_tb, limit=None, chain=True):
    lines = ['Traceback (most recent call last):\n']
    lines.extend(format_tb(exc_tb, limit))
    lines.extend(format_exception_only(exc_type, exc_value))
    return lines


def print_exception(exc_type, exc_value, exc_tb, limit=None, file=None, chain=True):
    if file is None:
        file = sys.stderr
    for line in format_exception(exc_type, exc_value, exc_tb, limit, chain):
        try:
            file.write(line)
        except Exception:
            pass


def format_exc(limit=None, chain=True):
    exc_type, exc_value, exc_tb = sys.exc_info()
    if exc_type is None:
        return ''
    return ''.join(format_exception(exc_type, exc_value, exc_tb, limit, chain))


def print_exc(limit=None, file=None, chain=True):
    exc_type, exc_value, exc_tb = sys.exc_info()
    if exc_type is None:
        return
    print_exception(exc_type, exc_value, exc_tb, limit, file, chain)


def walk_tb(tb):
    while tb is not None:
        yield tb.tb_frame, tb.tb_lineno
        tb = tb.tb_next
