"""Patched linecache for embedded Metin2 client.

This version avoids importing tokenize/_tokenize just to read source lines
for tracebacks. The standard Python 3.13+/3.14 linecache module calls
``tokenize.open()``, which imports the C extension ``_tokenize``. Some
embedded clients do not ship that extension, causing secondary errors like:
    No module named '_tokenize'

This patch falls back to plain text loading with UTF-8 first and latin-1 as a
last resort so the real traceback can be printed.
"""

__all__ = ["getline", "clearcache", "checkcache", "lazycache"]

cache = {}
_interactive_cache = {}


def clearcache():
    cache.clear()


def getline(filename, lineno, module_globals=None):
    lines = getlines(filename, module_globals)
    if 1 <= lineno <= len(lines):
        return lines[lineno - 1]
    return ''


def getlines(filename, module_globals=None):
    if filename in cache:
        entry = cache[filename]
        if len(entry) != 1:
            return cache[filename][2]
    try:
        return updatecache(filename, module_globals)
    except MemoryError:
        clearcache()
        return []


def _getline_from_code(filename, lineno):
    lines = _getlines_from_code(filename)
    if 1 <= lineno <= len(lines):
        return lines[lineno - 1]
    return ''


def _make_key(code):
    return (code.co_filename, code.co_qualname, code.co_firstlineno)


def _getlines_from_code(code):
    code_id = _make_key(code)
    if code_id in _interactive_cache:
        entry = _interactive_cache[code_id]
        if len(entry) != 1:
            return _interactive_cache[code_id][2]
    return []


def checkcache(filename=None):
    if filename is None:
        filenames = cache.copy().keys()
    else:
        filenames = [filename]

    for filename in filenames:
        try:
            entry = cache[filename]
        except KeyError:
            continue

        if len(entry) == 1:
            continue
        size, mtime, lines, fullname = entry
        if mtime is None:
            continue
        try:
            import os
            stat = os.stat(fullname)
        except (OSError, ValueError):
            cache.pop(filename, None)
            continue
        if size != stat.st_size or mtime != stat.st_mtime:
            cache.pop(filename, None)


def _safe_read_lines(fullname):
    # Avoid tokenize.open() so embedded runtimes without _tokenize still work.
    # Source files in Metin2 clients are usually plain ASCII/UTF-8.
    for encoding in ('utf-8', 'utf-8-sig', 'cp1252', 'latin-1'):
        try:
            with open(fullname, 'r', encoding=encoding, errors='strict') as fp:
                return fp.readlines()
        except (OSError, UnicodeDecodeError):
            pass
    try:
        with open(fullname, 'r', encoding='utf-8', errors='replace') as fp:
            return fp.readlines()
    except OSError:
        return []


def updatecache(filename, module_globals=None):
    try:
        import os
        import sys
    except ImportError:
        return []

    if filename in cache:
        if len(cache[filename]) != 1:
            cache.pop(filename, None)
    if not filename or (filename.startswith('<') and filename.endswith('>')):
        return []

    fullname = filename
    try:
        stat = os.stat(fullname)
    except OSError:
        basename = filename

        if lazycache(filename, module_globals):
            try:
                data = cache[filename][0]()
            except (ImportError, OSError):
                pass
            else:
                if data is None:
                    return []
                cache[filename] = (
                    len(data),
                    None,
                    [line + '\n' for line in data.splitlines()],
                    fullname,
                )
                return cache[filename][2]

        if os.path.isabs(filename):
            return []

        for dirname in sys.path:
            try:
                fullname = os.path.join(dirname, basename)
            except (TypeError, AttributeError):
                continue
            try:
                stat = os.stat(fullname)
                break
            except (OSError, ValueError):
                pass
        else:
            return []
    except ValueError:
        return []

    lines = _safe_read_lines(fullname)
    if not lines:
        return []
    if not lines[-1].endswith('\n'):
        lines[-1] += '\n'
    size, mtime = stat.st_size, stat.st_mtime
    cache[filename] = size, mtime, lines, fullname
    return lines


def lazycache(filename, module_globals):
    if filename in cache:
        if len(cache[filename]) == 1:
            return True
        else:
            return False
    if not filename or (filename.startswith('<') and filename.endswith('>')):
        return False
    if module_globals and '__loader__' in module_globals and '__name__' in module_globals:
        name = module_globals['__name__']
        loader = module_globals['__loader__']
        get_source = getattr(loader, 'get_source', None)
        if name and get_source:
            cache[filename] = (lambda name=name, get_source=get_source: get_source(name),)
            return True
    return False


def _register_code(code, string, name):
    entry = (len(string), None, [line + '\n' for line in string.splitlines()], name)
    _interactive_cache[_make_key(code)] = entry


def _clear_code_cache():
    _interactive_cache.clear()
