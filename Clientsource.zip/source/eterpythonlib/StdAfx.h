#pragma once

#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <AttackDefines.h>
#include "../eterlib/StdAfx.h"
#include "../scriptlib/StdAfx.h"

#include "PythonGraphic.h"
#include "PythonWindowManager.h"

PyMODINIT_FUNC PyInit_grp(void);
PyMODINIT_FUNC PyInit_grpImage(void);
PyMODINIT_FUNC PyInit_grpText(void);
PyMODINIT_FUNC PyInit_grpThing(void);
void initscriptWindow();
PyMODINIT_FUNC PyInit_wndMgr(void);

