#include "stdafx.h"
namespace { char dummy; };
#include "MssStub.inl"
