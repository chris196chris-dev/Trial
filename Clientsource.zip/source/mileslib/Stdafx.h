#ifndef __INC_MILESLIB_STDAFX_H__
#define __INC_MILESLIB_STDAFX_H__
#pragma once

#include <windows.h>

#pragma warning(disable:4786)
#pragma warning(disable:4100)

#pragma warning(disable:4201)
#include <milesound/mss.h>
#pragma warning(default:4201)

#include "../eterbase/CRC32.h"
#include "../eterbase/Utils.h"
#include "../eterbase/Debug.h"

#include <AttackDefines.h>

#endif

