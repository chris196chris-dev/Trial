#pragma once

#include <milesound/mss.h>

static char g_mss_last_error[] = "Miles stub active (audio disabled)";

extern "C" int __cdecl MSS_auto_cleanup(void) { return 0; }

#define MSS_STUB_VOID(name, args) \
    static void AILCALL stub_##name args {} \
    extern "C" void* __imp_##name = (void*)&stub_##name;

#define MSS_STUB_RET(ret, name, args, value) \
    static ret AILCALL stub_##name args { return value; } \
    extern "C" void* __imp_##name = (void*)&stub_##name;

MSS_STUB_VOID(AIL_startup, (void))
MSS_STUB_VOID(AIL_shutdown, (void))
MSS_STUB_RET(char FAR*, AIL_set_redist_directory, (char const FAR* dir), (char FAR*)nullptr)
MSS_STUB_RET(char FAR*, AIL_last_error, (void), g_mss_last_error)
MSS_STUB_RET(S32, AIL_WAV_info, (void const FAR* data, AILSOUNDINFO FAR* info), 0)
MSS_STUB_RET(S32, AIL_decompress_ADPCM, (AILSOUNDINFO const FAR * info, void FAR* FAR* outdata, U32 FAR* outsize), 0)
MSS_STUB_RET(S32, AIL_decompress_ASI, (void const FAR* indata, U32 insize, char const FAR* filename_ext, void FAR* FAR* wav, U32 FAR* wavsize, AILLENGTHYCB callback), 0)
MSS_STUB_RET(S32, AIL_file_type, (void const FAR* data, U32 size), 0)
MSS_STUB_RET(void FAR*, AIL_file_read, (char const FAR* filename, void FAR* dest), (void FAR*)nullptr)
MSS_STUB_VOID(AIL_set_file_callbacks, (AIL_file_open_callback opencb, AIL_file_close_callback closecb, AIL_file_seek_callback seekcb, AIL_file_read_callback readcb))
MSS_STUB_VOID(AIL_mem_free_lock, (void FAR *ptr))

MSS_STUB_RET(HDIGDRIVER, AIL_open_digital_driver, (U32 frequency, S32 bits, S32 channel, U32 flags), (HDIGDRIVER)nullptr)
MSS_STUB_VOID(AIL_close_digital_driver, (HDIGDRIVER dig))
MSS_STUB_RET(HSAMPLE, AIL_allocate_sample_handle, (HDIGDRIVER dig), (HSAMPLE)nullptr)
MSS_STUB_VOID(AIL_release_sample_handle, (HSAMPLE S))
MSS_STUB_VOID(AIL_init_sample, (HSAMPLE S))
MSS_STUB_RET(S32, AIL_set_sample_file, (HSAMPLE S, void const FAR *file_image, S32 block), 0)
MSS_STUB_VOID(AIL_start_sample, (HSAMPLE S))
MSS_STUB_VOID(AIL_stop_sample, (HSAMPLE S))
MSS_STUB_VOID(AIL_resume_sample, (HSAMPLE S))
MSS_STUB_VOID(AIL_end_sample, (HSAMPLE S))
MSS_STUB_VOID(AIL_set_sample_volume_pan, (HSAMPLE S, F32 volume, F32 pan))
MSS_STUB_VOID(AIL_set_sample_loop_count, (HSAMPLE S, S32 loop_count))
MSS_STUB_RET(U32, AIL_sample_status, (HSAMPLE S), 0)
MSS_STUB_VOID(AIL_sample_volume_pan, (HSAMPLE S, F32 FAR* volume, F32 FAR* pan))

MSS_STUB_RET(S32, AIL_enumerate_3D_providers, (HPROENUM FAR *next, HPROVIDER FAR *dest, C8 FAR * FAR *name), 0)
MSS_STUB_RET(M3DRESULT, AIL_open_3D_provider, (HPROVIDER lib), 0)
MSS_STUB_VOID(AIL_close_3D_provider, (HPROVIDER lib))
MSS_STUB_RET(H3DPOBJECT, AIL_open_3D_listener, (HPROVIDER lib), (H3DPOBJECT)nullptr)
MSS_STUB_VOID(AIL_close_3D_listener, (H3DPOBJECT listener))
MSS_STUB_RET(H3DSAMPLE, AIL_allocate_3D_sample_handle, (HPROVIDER lib), (H3DSAMPLE)nullptr)
MSS_STUB_VOID(AIL_release_3D_sample_handle, (H3DSAMPLE S))
MSS_STUB_VOID(AIL_start_3D_sample, (H3DSAMPLE S))
MSS_STUB_VOID(AIL_stop_3D_sample, (H3DSAMPLE S))
MSS_STUB_VOID(AIL_resume_3D_sample, (H3DSAMPLE S))
MSS_STUB_VOID(AIL_end_3D_sample, (H3DSAMPLE S))
MSS_STUB_RET(S32, AIL_set_3D_sample_file, (H3DSAMPLE S, void const FAR* file_image), 0)
MSS_STUB_VOID(AIL_set_3D_sample_volume, (H3DSAMPLE S, F32 volume))
MSS_STUB_VOID(AIL_set_3D_sample_loop_count, (H3DSAMPLE S, U32 loops))
MSS_STUB_RET(U32, AIL_3D_sample_status, (H3DSAMPLE S), 0)
MSS_STUB_RET(F32, AIL_3D_sample_volume, (H3DSAMPLE S), 0.0f)
MSS_STUB_VOID(AIL_set_3D_position, (H3DPOBJECT obj, F32 X, F32 Y, F32 Z))
MSS_STUB_VOID(AIL_set_3D_velocity, (H3DPOBJECT obj, F32 dX_per_ms, F32 dY_per_ms, F32 dZ_per_ms, F32 magnitude))
MSS_STUB_VOID(AIL_set_3D_orientation, (H3DPOBJECT obj, F32 X_face, F32 Y_face, F32 Z_face, F32 X_up, F32 Y_up, F32 Z_up))
MSS_STUB_VOID(AIL_update_3D_position, (H3DPOBJECT obj, F32 dt_milliseconds))
MSS_STUB_VOID(AIL_auto_update_3D_position, (H3DPOBJECT obj, S32 enable))

MSS_STUB_RET(HSTREAM, AIL_open_stream, (HDIGDRIVER dig, char const FAR * filename, S32 stream_mem), (HSTREAM)nullptr)
MSS_STUB_VOID(AIL_close_stream, (HSTREAM stream))
MSS_STUB_VOID(AIL_start_stream, (HSTREAM stream))
MSS_STUB_VOID(AIL_pause_stream, (HSTREAM stream, S32 onoff))
MSS_STUB_VOID(AIL_set_stream_volume_levels, (HSTREAM S, F32 left_level, F32 right_level))
MSS_STUB_VOID(AIL_stream_volume_levels, (HSTREAM S, F32 FAR * left_level, F32 FAR * right_level))
MSS_STUB_VOID(AIL_set_stream_loop_count, (HSTREAM stream, S32 count))
MSS_STUB_RET(S32, AIL_stream_status, (HSTREAM stream), 0)

#undef MSS_STUB_VOID
#undef MSS_STUB_RET
