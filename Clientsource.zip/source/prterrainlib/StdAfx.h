#if !defined(AFX_STDAFX_H__EECC0C4D_07A5_4D9E_B40F_767A80FD6DE6__INCLUDED_)
#define AFX_STDAFX_H__EECC0C4D_07A5_4D9E_B40F_767A80FD6DE6__INCLUDED_
#pragma once

#define WIN32_LEAN_AND_MEAN

#pragma warning(disable:4702)

#include "../eterlib/StdAfx.h"
#include "../etergrnlib/StdAfx.h"
#include "../scriptlib/StdAfx.h"

#include <AttackDefines.h>

extern float		PR_FCNV;
extern long			PR_ICNV;

#endif

