#pragma once

#include <cstddef>

// Helper to validate that a pointer from a mapped file lies inside the mapped region
static inline bool IsPointerInRange(const void* base, size_t baseSize, const void* ptr)
{
    if (!base || baseSize == 0 || !ptr)
        return false;

    const uintptr_t b = reinterpret_cast<uintptr_t>(base);
    const uintptr_t e = b + baseSize;
    const uintptr_t p = reinterpret_cast<uintptr_t>(ptr);

    return (p >= b && p < e);
}
