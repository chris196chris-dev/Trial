#pragma once

#pragma warning(disable:4786)
#ifndef BUILDING_GRANNY_STATIC
#define BUILDING_GRANNY_STATIC 1
#endif
#include <granny/granny.h>
#include <AttackDefines.h>
#include "../eterbase/Utils.h"
#include "../eterbase/Debug.h"
#include "../eterbase/Stl.h"
#include "Util.h"

