#pragma once
#define WIN32_LEAN_AND_MEAN

#include <AttackDefines.h>
#ifdef DIRECTX9
#include <directx/d3d9/d3d9.h>
#include <directx/d3d9/d3dx9.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <math.h>

#include "../eterbase/StdAfx.h"

