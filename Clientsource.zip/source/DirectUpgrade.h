#define DIRECTX_ON

//ENABLE DIRECT9 #ifndef
//ENABLE DIRECT8 #ifdef
#ifndef DIRECT_UPDATE_NOW
	#define DIRECTX9
#endif
