#include "StdAfx.h"
#include "FileDir.h"
#include <string>

CDir::CDir()
{
	Initialize();
}

CDir::~CDir()
{
	Destroy();
}

void CDir::Destroy()
{
	if (m_hFind)
	{
		FindClose (m_hFind);
	}

	Initialize();
}

bool CDir::Create (const char* c_szFilter, const char* c_szPath, BOOL bCheckedExtension)
{
	Destroy();

	auto stPath = std::string(c_szPath); //fix12

	if (stPath.length())
	{
		char end = stPath[stPath.length() - 1];

		if (end != '\\')
		{
			stPath += '\\';
		}
	}

	std::string stQuery;
	auto fix13 = std::string(stQuery); //fix13
	fix13 += stPath;
	fix13 += "*.*";

	m_wfd.dwFileAttributes |= FILE_ATTRIBUTE_DIRECTORY;
	m_hFind = FindFirstFile (fix13.c_str(), &m_wfd);

	if (m_hFind == INVALID_HANDLE_VALUE)
	{
		return true;
	}

	do
	{
		if (*m_wfd.cFileName == '.')
		{
			continue;
		}

		if (IsFolder())
		{
			if (!OnFolder (c_szFilter, stPath.c_str(), m_wfd.cFileName))
			{
				return false;
			}
		}
		else
		{
			const char* c_szExtension = strchr (m_wfd.cFileName, '.');
			if (!c_szExtension)
			{
				continue;
			}

			if (bCheckedExtension)
			{
				auto strFilter = std::string(c_szFilter); //fix14

				int iPos = strFilter.find_first_of (';', 0);
				if (iPos > 0)
				{
					std::string strFirstFilter = std::string (c_szFilter).substr (0, iPos);
					std::string strSecondFilter = std::string (c_szFilter).substr (iPos + 1, strlen (c_szFilter));
					if (0 != strFirstFilter.compare (c_szExtension + 1) && 0 != strSecondFilter.compare (c_szExtension + 1))
					{
						continue;
					}
				}
				else
				{
					if (0 != stricmp (c_szExtension + 1, c_szFilter))
					{
						continue;
					}
				}
			}

			if (!OnFile (stPath.c_str(), m_wfd.cFileName))
			{
				return false;
			}
		}
	}
	while (FindNextFile (m_hFind, &m_wfd));

	return true;
}

bool CDir::IsFolder()
{
	if (m_wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)
	{
		return true;
	}

	return false;
}

void CDir::Initialize()
{
	memset (&m_wfd, 0, sizeof (m_wfd));
	m_hFind = NULL;
}

