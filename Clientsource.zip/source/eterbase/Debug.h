#ifndef __INC_ETERLIB_DEBUG_H__
#define __INC_ETERLIB_DEBUG_H__

#include <windows.h>

#ifdef _DEBUG
extern void SetLogLevel (unsigned int uLevel);
#endif
extern void Logn (unsigned int uLevel, const char* c_szMsg);
extern void Lognf (unsigned int uLevel, const char* c_szFormat, ...);

extern void Trace (const char* c_szMsg);
extern void Tracen (const char* c_szMsg);
extern void Tracenf (const char* c_szFormat, ...);
extern void Tracef (const char* c_szFormat, ...);
extern void TraceError (const char* c_szFormat, ...);

extern void LogBox (const char* c_szMsg, const char* c_szCaption = NULL, HWND hWnd = NULL);
extern void LogBoxf (const char* c_szMsg, ...);

extern void LogFile (const char* c_szMsg);
extern void OpenConsoleWindow();

extern void OpenLogFile (bool bUseLogFile = true);
extern void CloseLogFile();

extern HWND g_PopupHwnd;
#endif

