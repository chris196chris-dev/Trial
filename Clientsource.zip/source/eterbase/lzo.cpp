#include "StdAfx.h"
#include <stdlib.h>
#include "lzo.h"
#include "tea.h"
#include "debug.h"

#define dbg_printf

static class LZOFreeMemoryMgr
{
	public:
		enum
		{
			REUSING_CAPACITY = 64 * 1024,
		};
	public:
		~LZOFreeMemoryMgr()
		{
			for (auto i = m_freeVector.begin(); i != m_freeVector.end(); ++i)
			{
				delete[] *i;
			}
			m_freeVector.clear();
		}
		BYTE* Alloc (unsigned capacity)
		{
			assert (capacity > 0);
			if (capacity < REUSING_CAPACITY)
			{
				if (!m_freeVector.empty())
				{
					BYTE* freeMem = m_freeVector.back();
					m_freeVector.pop_back();
					return freeMem;
				}
				return new BYTE[REUSING_CAPACITY];
			}
			return new BYTE[capacity];
		}
		void Free (BYTE* ptr, unsigned capacity)
		{
			assert (ptr != NULL);
			assert (capacity > 0);
			if (capacity < REUSING_CAPACITY)
			{
				m_freeVector.push_back (ptr);
				return;
			}
			delete[] ptr;
		}
	private:
		std::vector<BYTE*> m_freeVector;
} gs_freeMemMgr;

DWORD CLZObject::ms_dwFourCC = MAKEFOURCC ('M', 'C', 'O', 'Z');

CLZObject::CLZObject()
{
	Initialize();
}

void CLZObject::Initialize()
{
	m_bInBuffer = false;
	m_pbBuffer = NULL;
	m_dwBufferSize = 0;
	m_pHeader = NULL;
	m_pbIn = NULL;
	m_bCompressed = false;
}

void CLZObject::Clear()
{
	if (m_pbBuffer && !m_bInBuffer)
	{
		gs_freeMemMgr.Free (m_pbBuffer, m_dwBufferSize);
	}
	Initialize();
}

CLZObject::~CLZObject()
{
	Clear();
}

DWORD CLZObject::GetSize()
{
	assert (m_pHeader);
	if (m_bCompressed)
	{
		if (m_pHeader->dwEncryptSize)
			return sizeof (THeader) + sizeof (DWORD) + m_pHeader->dwEncryptSize;
		return sizeof (THeader) + sizeof (DWORD) + m_pHeader->dwCompressedSize;
	}
	return m_pHeader->dwRealSize;
}

void CLZObject::BeginCompress (const void* pvIn, unsigned int uiInLen)
{
	m_pbIn = (const BYTE*)pvIn;
	m_dwBufferSize = sizeof (THeader) + sizeof (DWORD) + (uiInLen + uiInLen / 64 + 16 + 3) + 8;
	m_pbBuffer = gs_freeMemMgr.Alloc (m_dwBufferSize);
	memset (m_pbBuffer, 0, m_dwBufferSize);
	m_pHeader = (THeader*)m_pbBuffer;
	m_pHeader->dwFourCC = ms_dwFourCC;
	m_pHeader->dwEncryptSize = m_pHeader->dwCompressedSize = m_pHeader->dwRealSize = 0;
	m_pHeader->dwRealSize = uiInLen;
}

bool CLZObject::Compress()
{
	lzo_uint outLen = 0;
	BYTE* pbBuffer = m_pbBuffer + sizeof (THeader);
	*(DWORD*)pbBuffer = ms_dwFourCC;
	pbBuffer += sizeof (DWORD);

	int r = lzo1x_1_compress ((BYTE*)m_pbIn, (lzo_uint)m_pHeader->dwRealSize, pbBuffer, &outLen, CLZO::Instance().GetWorkMemory());
	if (LZO_E_OK != r)
	{
		TraceError ("LZO: lzo1x_1_compress failed (%d)", r);
		return false;
	}

	m_pHeader->dwCompressedSize = (DWORD)outLen;
	m_bCompressed = true;
	return true;
}

bool CLZObject::BeginDecompress (const void* pvIn)
{
	THeader* pHeader = (THeader*)pvIn;
	if (pHeader->dwFourCC != ms_dwFourCC)
	{
		TraceError ("LZObject: not a valid data");
		return false;
	}
	m_pHeader = pHeader;
	m_pbIn = (const BYTE*)pvIn + (sizeof (THeader) + sizeof (DWORD));
	m_dwBufferSize = pHeader->dwRealSize;
	m_pbBuffer = gs_freeMemMgr.Alloc (m_dwBufferSize);
	memset (m_pbBuffer, 0, pHeader->dwRealSize);
	return true;
}

class DecryptBuffer
{
	public:
		enum { LOCAL_BUF_SIZE = 8 * 1024 };
		DecryptBuffer (unsigned size)
		{
			if (size >= LOCAL_BUF_SIZE)
				m_buf = new char[size];
			else
				m_buf = m_local_buf;
		}
		~DecryptBuffer()
		{
			if (m_local_buf != m_buf)
				delete[] m_buf;
		}
		void* GetBufferPtr() { return m_buf; }
	private:
		char* m_buf;
		char  m_local_buf[LOCAL_BUF_SIZE];
};

bool CLZObject::Decompress (DWORD* pdwKey)
{
	lzo_uint outLen = (lzo_uint)m_pHeader->dwRealSize;
	int r;

	if (m_pHeader->dwEncryptSize)
	{
		DecryptBuffer buf (m_pHeader->dwEncryptSize);
		BYTE* pbDecryptedBuffer = (BYTE*)buf.GetBufferPtr();
		__Decrypt (pdwKey, pbDecryptedBuffer);
		DWORD decryptedMark = *(DWORD*)pbDecryptedBuffer;
		if (decryptedMark != ms_dwFourCC)
		{
			TraceError ("LZObject: TEA decryption failed");
			return false;
		}
		r = lzo1x_decompress_safe (pbDecryptedBuffer + sizeof (DWORD), (lzo_uint)m_pHeader->dwCompressedSize, m_pbBuffer, &outLen, NULL);
	}
	else
	{
		r = lzo1x_decompress_safe (m_pbIn, (lzo_uint)m_pHeader->dwCompressedSize, m_pbBuffer, &outLen, NULL);
	}

	if (LZO_E_OK != r)
	{
		TraceError ("LZO: lzo1x_decompress_safe failed (%d)", r);
		return false;
	}
	if (outLen != m_pHeader->dwRealSize)
	{
		TraceError ("LZO: size mismatch %u != %u", (unsigned)outLen, (unsigned)m_pHeader->dwRealSize);
		return false;
	}
	return true;
}

bool CLZObject::Encrypt (DWORD* pdwKey)
{
	if (!m_bCompressed)
	{
		assert (!"not compressed yet");
		return false;
	}
	BYTE* pbBuffer = m_pbBuffer + sizeof (THeader);
	m_pHeader->dwEncryptSize = tea_encrypt ((DWORD*)pbBuffer, (const DWORD*)pbBuffer, pdwKey, m_pHeader->dwCompressedSize + 19);
	return true;
}

bool CLZObject::__Decrypt (DWORD* key, BYTE* data)
{
	assert (m_pbBuffer);
	tea_decrypt ((DWORD*)data, (const DWORD*)(m_pbIn - sizeof (DWORD)), key, m_pHeader->dwEncryptSize);
	return true;
}

CLZO::CLZO() : m_pWorkMem (NULL)
{
	if (lzo_init() != LZO_E_OK)
	{
		TraceError ("LZO: cannot initialize");
		return;
	}
	m_pWorkMem = (BYTE*)malloc (LZO1X_1_MEM_COMPRESS);
	if (NULL == m_pWorkMem)
	{
		TraceError ("LZO: cannot alloc memory");
		return;
	}
}

CLZO::~CLZO()
{
	if (m_pWorkMem)
	{
		free (m_pWorkMem);
		m_pWorkMem = NULL;
	}
}

bool CLZO::CompressMemory (CLZObject& rObj, const void* pIn, unsigned int uiInLen)
{
	rObj.BeginCompress (pIn, uiInLen);
	return rObj.Compress();
}

bool CLZO::CompressEncryptedMemory (CLZObject& rObj, const void* pIn, unsigned int uiInLen, DWORD* pdwKey)
{
	rObj.BeginCompress (pIn, uiInLen);
	if (rObj.Compress())
		return rObj.Encrypt (pdwKey);
	return false;
}

bool CLZO::Decompress (CLZObject& rObj, const BYTE* pbBuf, DWORD* pdwKey)
{
	if (!rObj.BeginDecompress (pbBuf))
		return false;
	if (!rObj.Decompress (pdwKey))
		return false;
	return true;
}

BYTE* CLZO::GetWorkMemory()
{
	return m_pWorkMem;
}
