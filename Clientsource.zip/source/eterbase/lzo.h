#ifndef __INC_METIN_II_371GNFBQOCJ_LZO_H__
#define __INC_METIN_II_371GNFBQOCJ_LZO_H__

#include <windows.h>
#include "Singleton.h"
#include <lzo/lzo1x.h>

class CLZObject
{
	public:
#pragma pack(4)
		typedef struct SHeader
		{
			DWORD dwFourCC;
			DWORD dwEncryptSize;
			DWORD dwCompressedSize;
			DWORD dwRealSize;
		} THeader;
#pragma pack()

		CLZObject();
		~CLZObject();

		void Clear();

		void BeginCompress (const void* pvIn, unsigned int uiInLen);
		bool Compress();

		bool BeginDecompress (const void* pvIn);
		bool Decompress (DWORD* pdwKey = NULL);

		bool Encrypt (DWORD* pdwKey);
		bool __Decrypt (DWORD* key, BYTE* data);

		BYTE* GetBuffer()
		{
			return m_pbBuffer;
		}

		DWORD GetSize();

	private:
		void Initialize();

		BYTE* m_pbBuffer;
		DWORD m_dwBufferSize;

		THeader* m_pHeader;
		const BYTE* m_pbIn;
		bool m_bCompressed;

		bool m_bInBuffer;

	public:
		static DWORD ms_dwFourCC;
};

class CLZO : public CSingleton<CLZO>
{
	public:
		CLZO();
		virtual~CLZO();

		bool CompressMemory (CLZObject& rObj, const void* pIn, unsigned int uiInLen);
		bool CompressEncryptedMemory (CLZObject& rObj, const void* pIn, unsigned int uiInLen, DWORD* pdwKey);
		bool Decompress (CLZObject& rObj, const BYTE* pbBuf, DWORD* pdwKey = NULL);
		BYTE* GetWorkMemory();

	private:
		BYTE* m_pWorkMem;
};

#endif

