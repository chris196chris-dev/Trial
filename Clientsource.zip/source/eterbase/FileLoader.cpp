#include "StdAfx.h"
#include "FileLoader.h"
#include <assert.h>
bool CMemoryTextFileLoader::SplitLineByTab (DWORD dwLine, CTokenVector* pstTokenVector)
{
	pstTokenVector->reserve (10);
	pstTokenVector->clear();
	const std::string& c_rstLine = GetLineString (dwLine);
	const int c_iLineLength = c_rstLine.length();

	if (0 == c_iLineLength)
	{
		return false;
	}

	int basePos = 0;

	do
	{
		int beginPos = c_rstLine.find_first_of ("\t", basePos);
		pstTokenVector->push_back (c_rstLine.substr (basePos, beginPos - basePos));
		basePos = beginPos + 1;
	}
	while (basePos < c_iLineLength && basePos > 0);

	return true;
}

int CMemoryTextFileLoader::SplitLine2 (DWORD dwLine, CTokenVector* pstTokenVector, const char* c_szDelimeter)
{
	pstTokenVector->reserve (10);
	pstTokenVector->clear();
	std::string stToken;
	const std::string& c_rstLine = GetLineString (dwLine);

	DWORD basePos = 0;

	do
	{
		int beginPos = c_rstLine.find_first_not_of (c_szDelimeter, basePos);
		if (beginPos < 0)
		{
			return -1;
		}

		int endPos;

		if (c_rstLine[beginPos] == '"')
		{
			++beginPos;
			endPos = c_rstLine.find_first_of ("\"", beginPos);
			if (endPos < 0)
			{
				return -2;
			}
			basePos = endPos + 1;
		}
		else
		{
			endPos = c_rstLine.find_first_of (c_szDelimeter, beginPos);
			basePos = endPos;
		}

		pstTokenVector->push_back (c_rstLine.substr (beginPos, endPos - beginPos));

		if (int (c_rstLine.find_first_not_of (c_szDelimeter, basePos)) < 0)
		{
			break;
		}
	}
	while (basePos < c_rstLine.length());

	return 0;
}

bool CMemoryTextFileLoader::SplitLine (DWORD dwLine, CTokenVector* pstTokenVector, const char* c_szDelimeter)
{
	pstTokenVector->reserve (10);
	pstTokenVector->clear();
	std::string stToken;
	const std::string& c_rstLine = GetLineString (dwLine);

	DWORD basePos = 0;

	do
	{
		int beginPos = c_rstLine.find_first_not_of (c_szDelimeter, basePos);
		if (beginPos < 0)
		{
			return false;
		}

		int endPos;

		if (c_rstLine[beginPos] == '"')
		{
			++beginPos;
			endPos = c_rstLine.find_first_of ("\"", beginPos);
			if (endPos < 0)
			{
				return false;
			}
			basePos = endPos + 1;
		}
		else
		{
			endPos = c_rstLine.find_first_of (c_szDelimeter, beginPos);
			basePos = endPos;
		}

		pstTokenVector->push_back (c_rstLine.substr (beginPos, endPos - beginPos));

		if (int (c_rstLine.find_first_not_of (c_szDelimeter, basePos)) < 0)
		{
			break;
		}
	}
	while (basePos < c_rstLine.length());

	return true;
}

DWORD CMemoryTextFileLoader::GetLineCount()
{
	return m_stLineVector.size();
}

bool CMemoryTextFileLoader::CheckLineIndex (DWORD dwLine)
{
	if (dwLine >= m_stLineVector.size())
	{
		return false;
	}

	return true;
}

const std::string& CMemoryTextFileLoader::GetLineString (DWORD dwLine)
{
	assert (CheckLineIndex (dwLine));
	return m_stLineVector[dwLine];
}

void CMemoryTextFileLoader::Bind (int bufSize, const void* c_pvBuf)
{
	m_stLineVector.reserve (128);
	m_stLineVector.clear();

	const char* c_pcBuf = (const char*)c_pvBuf;
	std::string stLine;
	auto fix15 = std::string(stLine); //fix15
	int pos = 0;

	while (pos < bufSize)
	{
		const char c = c_pcBuf[pos++];
		if ('\n' == c || '\r' == c)
		{
			if (pos < bufSize)
			{
				if ('\n' == c_pcBuf[pos] || '\r' == c_pcBuf[pos])
				{
					++pos;
				}
			}
			m_stLineVector.push_back (fix15);
			fix15 = "";
		}
		else if (c < 0)
		{
			fix15.append (c_pcBuf + (pos - 1), 2);
			++pos;
		}
		else
		{
			fix15 += c;
		}
	}

	m_stLineVector.push_back (fix15);
}

