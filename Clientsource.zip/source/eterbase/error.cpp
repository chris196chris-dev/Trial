#include "StdAfx.h"

#include <stdio.h>
#include <time.h>
#include <winsock.h>
#include <imagehlp.h>

FILE* fException;

BOOL CALLBACK EnumerateLoadedModulesProc (PCSTR ModuleName, ULONG ModuleBase, ULONG ModuleSize, PVOID UserContext)
{
	DWORD offset = * ((DWORD*)UserContext);

	if (offset >= ModuleBase && offset <= ModuleBase + ModuleSize)
	{
		fprintf (fException, "%s", ModuleName);
		return FALSE;
	}
	else
	{
		return TRUE;
	}
}

LONG __stdcall EterExceptionFilter (_EXCEPTION_POINTERS* pExceptionInfo)
{
	return EXCEPTION_EXECUTE_HANDLER;
}

void SetEterExceptionHandler()
{
	SetUnhandledExceptionFilter (EterExceptionFilter);
}

