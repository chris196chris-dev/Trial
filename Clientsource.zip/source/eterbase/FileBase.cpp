#include "StdAfx.h"
#include "FileBase.h"
#include "Debug.h"

CFileBase::CFileBase() : m_hFile (NULL), m_dwSize (0)
{
}

CFileBase::~CFileBase()
{
	Destroy();
}

char* CFileBase::GetFileName()
{
	return m_filename;
}

void CFileBase::Destroy()
{
	Close();
	m_dwSize = 0;
}

void CFileBase::Close()
{
	if (m_hFile)
	{
		CloseHandle (m_hFile);
		m_hFile = NULL;
	}
}

BOOL CFileBase::Create (const char* filename, EFileMode mode)
{
	Destroy();
    // store provided name
	strncpy (m_filename, filename, MAX_PATH);
	m_filename[MAX_PATH] = '\0';

	Tracef("CFileBase::Create called for '%s'", filename);

	DWORD dwMode, dwShareMode = FILE_SHARE_READ;

	if (mode == FILEMODE_WRITE)
	{
		dwMode = GENERIC_READ | GENERIC_WRITE;
		dwShareMode = FILE_SHARE_READ | FILE_SHARE_WRITE;
	}
	else
	{
		dwMode = GENERIC_READ;
	}

    // Resolve full path for clearer logging
	char fullPath[MAX_PATH + 1] = {0};
	// request buffer size including terminating null
	if (GetFullPathNameA(filename, MAX_PATH + 1, fullPath, NULL) == 0)
	{
		strncpy(fullPath, filename, MAX_PATH);
	}
	fullPath[MAX_PATH] = '\0';

    // Try wide-char open first (handles Unicode paths reliably on Win32/Win64)
    wchar_t wpath[MAX_PATH + 1] = {0};
	// fullPath is an ANSI string (GetFullPathNameA / CreateFileA fallback uses ANSI). Convert using the ANSI code page.
	int rc = MultiByteToWideChar(CP_ACP, 0, fullPath, -1, wpath, MAX_PATH + 1);
	if (rc > 0)
	{
		HANDLE hw = CreateFileW(wpath, dwMode, dwShareMode, NULL, mode == FILEMODE_READ ? OPEN_EXISTING : OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hw != INVALID_HANDLE_VALUE)
		{
			m_hFile = hw;
			m_dwSize = GetFileSize (m_hFile, NULL);
			m_mode = mode;
			Tracef("CFileBase::Create - CreateFileW succeeded for '%s'", fullPath);
			return true;
		}

		DWORD dwErrW = GetLastError();
		char sysMsgW[512] = {0};
		FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
					   NULL, dwErrW, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), sysMsgW, (DWORD)sizeof(sysMsgW), NULL);

		TraceError("CFileBase::Create - CreateFileW failed for '%s' (mode=%d) GetLastError=%lu - %s", fullPath, mode, dwErrW, sysMsgW);
	}
	else
	{
		TraceError("CFileBase::Create - MultiByteToWideChar conversion failed for '%s'", fullPath);
	}

	// Fallback to ANSI open for paths that are local-encoded (legacy behavior)
	m_hFile = CreateFileA (fullPath, dwMode, dwShareMode, NULL, mode == FILEMODE_READ ? OPEN_EXISTING : OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
	if (m_hFile != INVALID_HANDLE_VALUE)
	{
		m_dwSize = GetFileSize (m_hFile, NULL);
		m_mode = mode;
		Tracef("CFileBase::Create - CreateFileA succeeded for '%s' (fallback)", fullPath);
		return true;
	}

	DWORD dwErr = GetLastError();
	m_hFile = NULL;

	// Format system message for the error code
	char sysMsg[512] = {0};
	FormatMessageA(FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
				   NULL, dwErr, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), sysMsg, (DWORD)sizeof(sysMsg), NULL);

    // Log detailed create failure to help diagnose missing files / path issues
	TraceError("CFileBase::Create - CreateFileA failed for '%s' (mode=%d) GetLastError=%lu - %s", fullPath, mode, dwErr, sysMsg);

	// Additional hint: if path contains drive-root like 'd:/ymir work', show it explicitly to help debug pack remapping
	if (strstr(fullPath, "d:/ymir") || strstr(fullPath, "d:\\ymir"))
	{
		Tracef("CFileBase::Create - NOTE: requested path contains 'ymir' root: %s", fullPath);
	}

	return false;
}

DWORD CFileBase::Size()
{
	return (m_dwSize);
}

void CFileBase::SeekCur (DWORD size)
{
	SetFilePointer (m_hFile, size, NULL, FILE_CURRENT);
}

void CFileBase::Seek (DWORD offset)
{
	if (offset > m_dwSize)
	{
		offset = m_dwSize;
	}

	SetFilePointer (m_hFile, offset, NULL, FILE_BEGIN);
}

DWORD CFileBase::GetPosition()
{
	return SetFilePointer (m_hFile, 0, NULL, FILE_CURRENT);
}

BOOL CFileBase::Write (const void* src, int bytes)
{
	DWORD dwUseless;
	BOOL ret = WriteFile (m_hFile, src, bytes, &dwUseless, NULL);

	if (!ret)
	{
		return false;
	}

	m_dwSize = GetFileSize (m_hFile, NULL);
	return true;
}

BOOL CFileBase::Read (void* dest, int bytes)
{
	DWORD dwUseless;
	return ReadFile (m_hFile, dest, bytes, &dwUseless, NULL);
}

BOOL CFileBase::IsNull()
{
	return !m_hFile ? true : false;
}

