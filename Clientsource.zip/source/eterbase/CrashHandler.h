#pragma once

#include <Windows.h>

void InstallCrashHandler();
void WritePythonErrorLog(const char* info);
void WriteSystemLog(const char* info);
