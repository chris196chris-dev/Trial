#include "CrashHandler.h"
#include <Windows.h>
#include <string>
#include <fstream>
#include <ctime>
#include <sstream>
#include <exception>
#include <cstdio>

typedef BOOL(WINAPI *MiniDumpWriteDump_t)(HANDLE, DWORD, HANDLE, int, PVOID, PVOID, PVOID);

static std::string GetTimestamp()
{
    std::time_t t = std::time(nullptr);
    tm localTm;
    localtime_s(&localTm, &t);
    char buf[64];
    sprintf_s(buf, "%04d%02d%02d_%02d%02d%02d", localTm.tm_year + 1900, localTm.tm_mon + 1, localTm.tm_mday, localTm.tm_hour, localTm.tm_min, localTm.tm_sec);
    return std::string(buf);
}

static std::string GetExeDir()
{
    char path[MAX_PATH];
    GetModuleFileNameA(NULL, path, MAX_PATH);
    std::string s(path);
    size_t pos = s.find_last_of("\\/");
    if (pos != std::string::npos) s = s.substr(0, pos);
    return s;
}

static void EnsureDirectory(const std::string &dir)
{
    // simple create; assumes intermediate directories exist
    CreateDirectoryA(dir.c_str(), NULL);
}

static void WriteTextLog(const std::string &filename, const std::string &contents)
{
    std::ofstream ofs(filename, std::ios::out | std::ios::app);
    if (!ofs.is_open()) return;
    ofs << contents;
    ofs.close();
}

void WriteSystemLog(const char* info)
{
    std::string exeDir = GetExeDir();
    std::string dumpDir = exeDir + "\\logs";
    EnsureDirectory(dumpDir);
    std::string path = dumpDir + "\\sysser.log";
    std::ostringstream ss;
    ss << GetTimestamp() << " - " << info << "\n";
    WriteTextLog(path, ss.str());
}

static void CreateMiniDump(EXCEPTION_POINTERS* pExceptionInfo)
{
    std::string exeDir = GetExeDir();
    std::string dumpDir = exeDir + "\\logs";
    EnsureDirectory(dumpDir);

    std::string ts = GetTimestamp();
    std::string dumpPath = dumpDir + "\\crash_" + ts + ".dmp";

    HMODULE hDbgHelp = LoadLibraryA("Dbghelp.dll");
    if (!hDbgHelp)
    {
        // fallback: write basic text log
        std::ostringstream ss;
        ss << "[Crash] Could not load Dbghelp.dll\n";
        WriteTextLog(dumpDir + "\\sysser.log", ss.str());
        return;
    }

    auto pMiniDumpWriteDump = (MiniDumpWriteDump_t)GetProcAddress(hDbgHelp, "MiniDumpWriteDump");
    if (!pMiniDumpWriteDump)
    {
        std::ostringstream ss;
        ss << "[Crash] MiniDumpWriteDump not found\n";
        WriteTextLog(dumpDir + "\\sysser.log", ss.str());
        FreeLibrary(hDbgHelp);
        return;
    }

    HANDLE hFile = CreateFileA(dumpPath.c_str(), GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (hFile != INVALID_HANDLE_VALUE)
    {
        HANDLE hProcess = GetCurrentProcess();
        DWORD dwPid = GetCurrentProcessId();

        // Use MINIDUMP_TYPE as an integer to avoid linking to dbghelp headers
        const int MiniDumpWithFullMemory = 0x00000002; // minimal: make some useful flags
        pMiniDumpWriteDump(hProcess, dwPid, hFile, MiniDumpWithFullMemory, pExceptionInfo, NULL, NULL);
        CloseHandle(hFile);

        std::ostringstream ss;
        ss << "[Crash] MiniDump written: " << dumpPath << "\n";
        WriteTextLog(dumpDir + "\\sysser.log", ss.str());
    }
    else
    {
        std::ostringstream ss;
        ss << "[Crash] Failed to create dump file: " << dumpPath << "\n";
        WriteTextLog(dumpDir + "\\sysser.log", ss.str());
    }

    FreeLibrary(hDbgHelp);
}

static LONG WINAPI ExceptionFilter(EXCEPTION_POINTERS* pExceptionInfo)
{
    std::string exeDir = GetExeDir();
    std::string dumpDir = exeDir + "\\logs";
    EnsureDirectory(dumpDir);

    std::ostringstream ss;
    ss << "Timestamp: " << GetTimestamp() << "\n";
    ss << "Exception code: 0x" << std::hex << pExceptionInfo->ExceptionRecord->ExceptionCode << "\n";
    ss << "Exception address: 0x" << std::hex << (uintptr_t)pExceptionInfo->ExceptionRecord->ExceptionAddress << "\n";
    ss << "Thread Id: " << std::dec << GetCurrentThreadId() << "\n";

#if defined(_M_X64)
    CONTEXT* c = pExceptionInfo->ContextRecord;
    ss << "RIP=0x" << std::hex << c->Rip << " RSP=0x" << c->Rsp << " RBP=0x" << c->Rbp << "\n";
    ss << "RAX=0x" << c->Rax << " RBX=0x" << c->Rbx << " RCX=0x" << c->Rcx << " RDX=0x" << c->Rdx << "\n";
#else
    CONTEXT* c = pExceptionInfo->ContextRecord;
    ss << "EIP=0x" << std::hex << c->Eip << " ESP=0x" << c->Esp << " EBP=0x" << c->Ebp << "\n";
    ss << "EAX=0x" << c->Eax << " EBX=0x" << c->Ebx << " ECX=0x" << c->Ecx << " EDX=0x" << c->Edx << "\n";
#endif

    WriteTextLog(dumpDir + "\\sysser.log", ss.str());

    // create minidump
    CreateMiniDump(pExceptionInfo);

    return EXCEPTION_EXECUTE_HANDLER;
}

void InstallCrashHandler()
{
    SetUnhandledExceptionFilter(ExceptionFilter);
    // also set terminate handler for C++ exceptions
    std::set_terminate([]()
    {
        std::ostringstream ss;
        ss << "[Terminate] std::terminate called at " << GetTimestamp() << "\n";
        std::string exeDir = GetExeDir();
        std::string dumpDir = exeDir + "\\logs";
        EnsureDirectory(dumpDir);
        WriteTextLog(dumpDir + "\\sysser.log", ss.str());
        abort();
    });
}

void WritePythonErrorLog(const char* info)
{
    std::string exeDir = GetExeDir();
    std::string dumpDir = exeDir + "\\logs";
    EnsureDirectory(dumpDir);
    std::string path = dumpDir + "\\pythonerror.log";
    std::ofstream ofs(path, std::ios::out | std::ios::app);
    if (!ofs.is_open()) return;
    ofs << GetTimestamp() << " - " << info << "\n";
    ofs.close();
}

// ensure installer runs at module startup
struct CrashInstaller
{
    CrashInstaller() { InstallCrashHandler(); }
};

static CrashInstaller s_crashInstaller;
