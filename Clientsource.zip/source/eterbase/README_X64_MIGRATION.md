Steps to migrate the client to x64

1) Create x64 platform
- In Visual Studio: Build -> Configuration Manager -> Active solution platform -> <New...> -> choose "x64" and copy settings from Win32.
- Ensure every project in the solution has Platform = x64 for both Debug and Release.

2) Update project properties (for each project)
- Configuration: Release | x64 (and Debug | x64)
- C/C++ -> General -> Debug Information Format = Program Database (/Zi)
- C/C++ -> Optimization = Maximize Speed (/O2) for Release
- C/C++ -> Preprocessor -> add _WIN64 where necessary
- Linker -> Advanced -> Target Machine = MachineX64 (/MACHINE:X64)
- Linker -> Debugging -> Generate Debug Info = Yes (/DEBUG)

3) Replace 32-bit libs
- Ensure all third-party libraries and import libraries are x64 builds.
- For DirectX: use x64 SDK libs or rely on system DLLs (d3d9/d3dx9 are in system32 for x64 OS).
- For Python: ship matching Python runtime (you uploaded python314.zip). Ensure Python .libs are x64 or use static embedding.
- For any middleware (MILES), get x64 SDKs.

4) Fix pointer-size issues
- Search for places where pointers are cast to 32-bit types (DWORD, int).
  - Replace with uintptr_t or UINT_PTR or size_t or reinterpret_cast<uintptr_t>(ptr).
- Avoid printing pointers with %08x; use "%p" and cast to void* or use PRIuPTR macros.
- Change format specifiers for 64-bit integers where needed.

5) Libraries and runtime files
- Replace any DLLs in the project folder that are 32-bit with x64 versions (e.g. D3DX9_43.dll — in x64 OS the system folder contains x64 versions).
- Python runtime: ensure embedded python is x64.

6) Rebuild and test
- Clean, Rebuild the whole solution for x64 Release and Debug.
- Test startup, login, rendering; check logs\ for crash dumps.

Notes
- I can scan for risky pointer casts and automatically replace simple cases. Complex cases need manual review.
- If you want I can try to update project files, but I need the .sln and .vcxproj files present in the repo/workspace.

