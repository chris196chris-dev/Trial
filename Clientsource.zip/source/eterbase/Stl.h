#ifndef __INC_ETERBASE_STL_H__
#define __INC_ETERBASE_STL_H__

#pragma warning(disable:4786)
#pragma warning(disable:4018)
#pragma warning(disable:4503)
#pragma warning(disable:4018)

#include <assert.h>

#pragma warning ( push, 3 )

#include <algorithm>
#include <string>
#include <vector>
#include <stack>
#include <deque>
#include <list>
#include <set>
#include <map>
#include <queue>
#include <functional>
#include <SSTREAM>

#pragma warning ( pop )
#include <AttackDefines.h> // __FIX_BUFFER_CLIENT__

extern char korean_tolower (const char c);
extern std::string& stl_static_string (const char* c_sz);
extern void stl_lowers (std::string& rstRet);
extern int split_string (const std::string& input, const std::string& delimiter, std::vector<std::string>& results, bool includeEmpties);

#ifdef __FIX_BUFFER_CLIENT__
namespace utils
{
	template <typename T> struct IsContiguous {
		static bool constexpr value = false;
	};

	template <typename... Args>
	struct IsContiguous<std::vector<Args...>> {
		static bool constexpr value = true;
	};

	template <>
	struct IsContiguous<std::string> {
		static bool constexpr value = true;
	};

	template <typename... Args>
	struct IsContiguous<std::array<Args...>> {
		static bool constexpr value = true;
	};

	template<typename T>
	constexpr bool IsContiguousV = IsContiguous<T>::value;

	template<typename T>
	constexpr bool IsRawV = !std::is_pointer_v<T> && std::is_trivially_copyable_v<T> && !IsContiguousV<T>;
};
#endif

struct stl_sz_less
{
	bool operator() (char* const& left, char* const& right) const
	{
		return (strcmp (left, right) < 0);
	}
};

template<typename TContainer>
inline void stl_wipe (TContainer& container)
{
	for (auto i = container.begin(); i != container.end(); ++i)
	{
		delete* i;
		#ifdef FIX_BLACK_SCREEN
		*i = nullptr;
		#else
		*i = NULL;
		#endif
	}

	container.clear();
}
template<typename TContainer>
inline void stl_wipe_second (TContainer& container)
{
	for (auto i = container.begin(); i != container.end(); ++i)
	{
		delete i->second;
		#ifdef FIX_BLACK_SCREEN
		i->second = nullptr;
		#else
		i->second = NULL;
		#endif
	}

	container.clear();
}

template<typename T>
inline void safe_release (T& rpObject)
{
	if (!rpObject)
	{
		return;
	}

	rpObject->Release();
	rpObject = NULL;
}

template<typename TData>
class stl_stack_pool
{
	public:
		stl_stack_pool()
		{
			m_pos = 0;
		}

		stl_stack_pool (int capacity)
		{
			m_pos = 0;
			initialize (capacity);
		}

		virtual ~stl_stack_pool()
		{
		}

		void initialize (int capacity)
		{
			m_dataVector.clear();
			m_dataVector.resize (capacity);
		}

		void clear()
		{
			m_pos = 0;
		}

		TData* alloc()
		{
			assert (!m_dataVector.empty() && "stl_stack_pool::alloc you MUST run stl_stack_pool::initialize");

			int max = m_dataVector.size();

			if (m_pos >= max)
			{
				assert (!"stl_stack_pool::alloc OUT of memory");
				m_pos = 0;
			}

			return &m_dataVector[m_pos++];
		}

		TData* base()
		{
			return &m_dataVector[0];
		}

		int size()
		{
			return m_pos;
		}

	private:
		int m_pos;

		std::vector<TData>	m_dataVector;
};
typedef std::vector<std::string> CTokenVector;
typedef std::map<std::string, CTokenVector> CTokenVectorMap;
#endif

