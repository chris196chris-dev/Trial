#pragma once
#pragma warning(disable:4786)

#include <windows.h>
#include <vector>
#include <map>

#include "Stl.h"

class CMemoryTextFileLoader
{
	public:
		CMemoryTextFileLoader() = default;
		virtual~CMemoryTextFileLoader() = default;
		void				Bind (int bufSize, const void* c_pvBuf);
		DWORD				GetLineCount();
		bool				CheckLineIndex (DWORD dwLine);
		bool				SplitLine (DWORD dwLine, CTokenVector* pstTokenVector, const char* c_szDelimeter = " \t");
		int					SplitLine2 (DWORD dwLine, CTokenVector* pstTokenVector, const char* c_szDelimeter = " \t");
		bool				SplitLineByTab (DWORD dwLine, CTokenVector* pstTokenVector);
		const std::string& GetLineString (DWORD dwLine);

	protected:
		std::vector<std::string> m_stLineVector;
};
typedef std::map<std::string, std::string> TStringMap;

