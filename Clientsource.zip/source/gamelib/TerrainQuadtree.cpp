#include "stdafx.h"
#include "TerrainQuadtree.h"

CTerrainQuadtreeNode::CTerrainQuadtreeNode() : NW_Node (NULL), NE_Node (NULL), SW_Node (NULL), SE_Node (NULL), center (-1.0f, -1.0f, -1.0f)
{
	x0 = y0 = x1 = y1 = 0;
	Size = 0;
	PatchNum = 0;
	radius = 0.0f;
	m_byLODLevel = 0;
}

CTerrainQuadtreeNode::~CTerrainQuadtreeNode()
{
	if (NW_Node)
	{
		delete NW_Node;
		#ifdef FIX_BLACK_SCREEN
		NW_Node = nullptr;
		#else
		NW_Node = NULL;
		#endif
	}
	if (NE_Node)
	{
		delete NE_Node;
		#ifdef FIX_BLACK_SCREEN
		NE_Node = nullptr;
		#else
		NE_Node = NULL;
		#endif
	}
	if (SW_Node)
	{
		delete SW_Node;
		#ifdef FIX_BLACK_SCREEN
		SW_Node = nullptr;
		#else
		SW_Node = NULL;
		#endif
	}
	if (SE_Node)
	{
		delete SE_Node;
		#ifdef FIX_BLACK_SCREEN
		SE_Node = nullptr;
		#else
		SE_Node = NULL;
		#endif
	}
}

