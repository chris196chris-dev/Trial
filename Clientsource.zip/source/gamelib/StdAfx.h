#ifndef __INC_YMIR_gamelib__
#define __INC_YMIR_gamelib__

#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif

#pragma warning(disable:4710)
#pragma warning(disable:4786)
#pragma warning(disable:4244)
#pragma warning(disable:4018)
#pragma warning(disable:4245)
#pragma warning(disable:4512)
#pragma warning(disable:4201)

#pragma warning(disable:4201 4512 4238 4239)

#include <AttackDefines.h>

#include "../eterlib/StdAfx.h"
#include "../mileslib/StdAfx.h"
#include "../effectlib/StdAfx.h"

#include "../eterbase/Utils.h"
#include "../eterbase/CRC32.h"
#include "../eterbase/Random.h"

#include "GameType.h"
#include "GameUtil.h"
#include "MapType.h"
#include "MapUtil.h"
#include "Interface.h"
#endif

