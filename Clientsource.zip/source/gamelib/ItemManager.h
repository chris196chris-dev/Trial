#pragma once

#include "ItemData.h"
//MULTI_LANGUAGE
#include "../userinterface/LocaleJson.h"
//MULTI_LANGUAGE
#ifdef ENABLE_SKILL_COOLTIME_UPDATE
	#include "PhysicsObject.h"
#endif

class CItemManager : public CSingleton<CItemManager>
{
	public:
#ifdef ENABLE_ACCE_SYSTEM
		enum EItemScaleColumn
		{
			ITEMSCALE_VNUM,
			ITEMSCALE_JOB,
			ITEMSCALE_SEX,
			ITEMSCALE_SCALE_X,
			ITEMSCALE_SCALE_Y,
			ITEMSCALE_SCALE_Z,
			ITEMSCALE_POSITION_X,
			ITEMSCALE_POSITION_Y,
			ITEMSCALE_POSITION_Z,
			ITEMSCALE_NUM,
			ITEMSCALE_REQ = ITEMSCALE_SCALE_Z + 1,
			ITEMSCALE_AURA_NUM = ITEMSCALE_POSITION_X + 1,
		};
#endif

	public:
		typedef std::map<DWORD, CItemData*> TItemMap;
		typedef std::map<std::string, CItemData*> TItemNameMap;

	public:
		CItemManager();
		virtual ~CItemManager();

		void			Destroy();

		BOOL			SelectItemData (DWORD dwIndex);
		CItemData* GetSelectedItemDataPointer();

		BOOL			GetItemDataPointer (DWORD dwItemID, CItemData** ppItemData);

		bool			LoadItemList (const char* c_szFileName);
		bool			LoadItemTable (const char* c_szFileName);
		CItemData* MakeItemData (DWORD dwIndex);
		//MULTI_LANGUAGE
		bool LoadItemNamesFromJSON(const char* filename);
		bool LoadItemDescFromJSON(const char* filename);
		//MULTI_LANGUAGE

#ifdef ENABLE_ACCE_SYSTEM
		bool			LoadItemScale(const char* c_szFileName);
#endif

	protected:
		TItemMap m_ItemMap;
		std::vector<CItemData*>  m_vec_ItemRange;
		CItemData* m_pSelectedItemData;
};

