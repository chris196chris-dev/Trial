#include "StdAfx.h"
#include "ActorInstance.h"
#include "RaceData.h"

void CActorInstance::__Push (int x, int y)
{
#ifndef ENABLE_SKILL_COOLTIME_UPDATE
	if (IsResistFallen())
	{
		return;
	}
#endif

	const D3DXVECTOR3& c_rv3Src = GetPosition();
	const D3DXVECTOR3 c_v3Dst = D3DXVECTOR3 (x, -y, c_rv3Src.z);
	const D3DXVECTOR3 c_v3Delta = c_v3Dst - c_rv3Src;
#ifdef ENABLE_SKILL_COOLTIME_UPDATE
	const auto LoopValue = 100;
#else
	const int LoopValue = 100;
#endif
	const D3DXVECTOR3 inc = c_v3Delta / LoopValue;

	D3DXVECTOR3 v3Movement (0.0f, 0.0f, 0.0f);

#ifdef ENABLE_SKILL_COOLTIME_UPDATE
	auto pWorld = IPhysicsWorld::GetPhysicsWorld();
#else
	IPhysicsWorld* pWorld = IPhysicsWorld::GetPhysicsWorld();
#endif

	if (!pWorld)
	{
		return;
	}

	for (int i = 0; i < LoopValue; ++i)
	{
		if (pWorld->isPhysicalCollision (c_rv3Src + v3Movement))
		{
			ResetBlendingPosition();
			return;
		}
		v3Movement += inc;
	}

	SetBlendingPosition (c_v3Dst);

#ifdef ENABLE_SKILL_COOLTIME_UPDATE
	if (IsResistFallen() || IsPushing())
	{
		return;
	}
#endif

	if (!IsUsingSkill())
	{
		#ifdef ENABLE_SKILL_COOLTIME_UPDATE
		const int len = sqrt(c_v3Delta.x*c_v3Delta.x+c_v3Delta.y*c_v3Delta.y);
		#else
		int len = sqrt (c_v3Delta.x * c_v3Delta.x + c_v3Delta.y * c_v3Delta.y);
		#endif
		if (len > 150.0f)
		{
			InterceptOnceMotion (CRaceMotionData::NAME_DAMAGE_FLYING);
			PushOnceMotion (CRaceMotionData::NAME_STAND_UP);
		}
	}
}

void CActorInstance::TEMP_Push (int x, int y)
{
	__Push (x, y);
}

bool CActorInstance::__IsSyncing()
{
	if (IsDead())
	{
		return TRUE;
	}

	if (IsStun())
	{
		return TRUE;
	}

	if (IsPushing())
	{
		return TRUE;
	}

	return FALSE;
}

bool CActorInstance::IsPushing()
{
	return m_PhysicsObject.isBlending();
}

