#pragma once

#include "../eterlib/SkyBox.h"
#include "../eterlib/LensFlare.h"
#include "../eterlib/ScreenFilter.h"

#include "../prterrainlib/TerrainType.h"
#include "../prterrainlib/TextureSet.h"

#include "../speedtreelib/SpeedTreeForestDirectX8.h"

#include "MapBase.h"
#include "Area.h"
#include "AreaTerrain.h"

#define LOAD_SIZE_WIDTH				1
#define AROUND_AREA_NUM				1+(LOAD_SIZE_WIDTH*2)*(LOAD_SIZE_WIDTH*2)*2
#define MAX_PREPARE_SIZE			9
#define MAX_MAPSIZE					256

#define TERRAINPATCH_LODMAX		3

typedef struct SOutdoorMapCoordinate
{
	short m_sTerrainCoordX;
	short m_sTerrainCoordY;
} TOutdoorMapCoordinate;

typedef std::map<const std::string, TOutdoorMapCoordinate> TOutdoorMapCoordinateMap;

class CTerrainPatchProxy;
class CTerrainQuadtreeNode;

class CMapOutdoor : public CMapBase
{
	public:
		enum
		{
			VIEW_NONE = 0,
			VIEW_PART,
			VIEW_ALL,
		};

		enum EPart
		{
			PART_TERRAIN,
			PART_OBJECT,
			PART_CLOUD,
			PART_WATER,
			PART_TREE,
			PART_SKY,
			PART_NUM,
		};

		enum ETerrainRenderSort
		{
			DISTANCE_SORT,
			TEXTURE_SORT,
		};

	public:
		CMapOutdoor();
		virtual ~CMapOutdoor();

		virtual void	OnBeginEnvironment();

	protected:
		bool			Initialize();
		void			InitializeFog();

		virtual bool	Destroy();
		virtual void	OnSetEnvironmentDataPtr();
		virtual void	OnResetEnvironmentDataPtr();

		virtual void	OnRender();

		virtual void	OnPreAssignTerrainPtr() {};

	public:
		void			SetInverseViewAndDynamicShaodwMatrices();
		virtual bool	Load (float x, float y, float z);
		virtual float	GetHeight (float x, float y);
		virtual float	GetCacheHeight (float x, float y);

		virtual bool	Update (float fX, float fY, float fZ);
		virtual void	UpdateAroundAmbience (float fX, float fY, float fZ);

	public:
		void			Clear();

		void			SetVisiblePart (int ePart, bool isVisible);
		void			SetSplatLimit (int iSplatNum);
		std::vector<int>& GetRenderedSplatNum (int* piPatch, int* piSplat, float* pfSplatRatio);
		CArea::TCRCWithNumberVector& GetRenderedGraphicThingInstanceNum (DWORD* pdwGraphicThingInstanceNum, DWORD* pdwCRCNum);

		bool			LoadSetting (const char* c_szFileName);

#ifdef DIRECTX9
		void			ApplyLight (std::uintptr_t lightVersion, const D3DLIGHT9& c_rkLight);
#endif
		void			SetEnvironmentScreenFilter();
		void			SetEnvironmentSkyBox();
		void			SetEnvironmentLensFlare();

		void			CreateCharacterShadowTexture();
		void			ReleaseCharacterShadowTexture();
		void			SetShadowTextureSize (WORD size);

		bool			BeginRenderCharacterShadowToTexture();
		void			EndRenderCharacterShadowToTexture();
		void			RenderWater();
		void			RenderMarkedArea();
		void			RecurseRenderAttr (CTerrainQuadtreeNode* Node, bool bCullEnable = TRUE);
		void			DrawPatchAttr (long patchnum);
		void			ClearGuildArea();
		void			RegisterGuildArea (int isx, int isy, int iex, int iey);

		void			VisibleMarkedArea();
		void			DisableMarkedArea();

		void			UpdateSky();
		void			RenderCollision();
		void			RenderSky();
		void			RenderCloud();
		void			RenderBeforeLensFlare();
		void			RenderAfterLensFlare();
		void			RenderScreenFiltering();

		void			SetWireframe (bool bWireFrame);
		bool			IsWireframe();

		bool			GetPickingPointWithRay (const CRay& rRay, D3DXVECTOR3* v3IntersectPt);
		bool			GetPickingPointWithRayOnlyTerrain (const CRay& rRay, D3DXVECTOR3* v3IntersectPt);
		bool			GetPickingPoint (D3DXVECTOR3* v3IntersectPt);
		void			GetTerrainCount (short* psTerrainCountX, short* psTerrainCountY)
		{
			*psTerrainCountX = m_sTerrainCountX;
			*psTerrainCountY = m_sTerrainCountY;
		}

		bool			SetTerrainCount (short sTerrainCountX, short sTerrainCountY);
		void			SetDrawShadow (bool bDrawShadow);
		void			SetDrawCharacterShadow (bool bDrawChrShadow);

		DWORD			GetShadowMapColor (float fx, float fy);

	protected:
		bool			__PickTerrainHeight (float& fPos, const D3DXVECTOR3& v3Start, const D3DXVECTOR3& v3End, float fStep, float fRayRange, float fLimitRange, D3DXVECTOR3* pv3Pick);

#ifdef JTX_ENTIRE_TERRAIN_RENDER
		virtual bool	LoadTerrain(WORD wTerrainCoordX, WORD wTerrainCoordY);
		virtual bool	LoadArea(WORD wAreaCoordX, WORD wAreaCoordY);
#else
		virtual void	__ClearGarvage();
		virtual void	__UpdateGarvage();
		virtual bool	LoadTerrain (WORD wTerrainCoordX, WORD wTerrainCoordY, WORD wCellCoordX, WORD wCellCoordY);
		virtual bool	LoadArea (WORD wAreaCoordX, WORD wAreaCoordY, WORD wCellCoordX, WORD wCellCoordY);
		virtual void	UpdateAreaList (long lCenterX, long lCenterY);
#endif

		bool			isTerrainLoaded (WORD wX, WORD wY);
		bool			isAreaLoaded (WORD wX, WORD wY);

		void			AssignTerrainPtr();

		void			SaveAlphaFogOperation();
		void			RestoreAlphaFogOperation();
		void			GetHeightMap (const BYTE& c_rucTerrainNum, WORD** pwHeightMap);
		void			GetNormalMap (const BYTE& c_rucTerrainNum, char** pucNormalMap);
		void			GetWaterMap (const BYTE& c_rucTerrainNum, BYTE** pucWaterMap);
		void			GetWaterHeight (BYTE byTerrainNum, BYTE byWaterNum, long* plWaterHeight);

	protected:
		CTerrain* m_pTerrain[AROUND_AREA_NUM];
		CTerrainPatchProxy* m_pTerrainPatchProxyList;

		long						m_lViewRadius;
		float						m_fHeightScale;

		short						m_sTerrainCountX, m_sTerrainCountY;

		TOutdoorMapCoordinate		m_CurCoordinate;

		long						m_lCurCoordStartX, m_lCurCoordStartY;
		TOutdoorMapCoordinate		m_PrevCoordinate;
		TOutdoorMapCoordinateMap	m_EntryPointMap;

		WORD						m_wPatchCount;

		WORD* m_pwaIndices[TERRAINPATCH_LODMAX];

		CGraphicIndexBuffer			m_IndexBuffer[TERRAINPATCH_LODMAX];
		WORD						m_wNumIndices[TERRAINPATCH_LODMAX];
		virtual void	DestroyTerrain();

		void			CreateTerrainPatchProxyList();
		void			DestroyTerrainPatchProxyList();

		void			UpdateTerrain (float fX, float fY);

		void			ConvertTerrainToTnL (long lx, long ly);

		void			AssignPatch (long lPatchNum, long lx0, long ly0, long lx1, long ly1);

		void			ADDLvl1TL (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl1T (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl1TR (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl1L (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl1R (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl1BL (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl1B (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl1BR (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl1M (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2TL (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2T (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2TR (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2L (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2R (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2BL (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2B (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2BR (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);
		void			ADDLvl2M (WORD* pIndices, WORD& rwCount, const WORD& c_rwCurCount, const BYTE& c_rucNumLineWarp);

	public:
		BOOL			GetTerrainPointer (BYTE c_ucTerrainNum, CTerrain** ppTerrain);
		float			GetTerrainHeight (float fx, float fy);
		bool			GetWaterHeight (int iX, int iY, long* plWaterHeight);
		bool			GetNormal (int ix, int iy, D3DXVECTOR3* pv3Normal);

		void			RenderTerrain();

		const long		GetViewRadius()
		{
			return m_lViewRadius;
		}
		const float		GetHeightScale()
		{
			return m_fHeightScale;
		}

		const TOutdoorMapCoordinate& GetEntryPoint (const std::string& c_rstrEntryPointName) const;
		void SetEntryPoint (const std::string& c_rstrEntryPointName, const TOutdoorMapCoordinate& c_rOutdoorMapCoordinate);
		const TOutdoorMapCoordinate& GetCurCoordinate()
		{
			return m_CurCoordinate;
		}
		const TOutdoorMapCoordinate& GetPrevCoordinate()
		{
			return m_PrevCoordinate;
		}
	protected:
		CArea* m_pArea[AROUND_AREA_NUM];

		virtual void	DestroyArea();

		void			__UpdateArea (D3DXVECTOR3& v3Player);
		void			__Game_UpdateArea (D3DXVECTOR3& v3Player);

		void			__BuildDynamicSphereInstanceVector();

		void			__CollectShadowReceiver (D3DXVECTOR3& v3Target, D3DXVECTOR3& v3Light);
		void			__CollectCollisionPCBlocker (D3DXVECTOR3& v3Eye, D3DXVECTOR3& v3Target, float fDistance);
		void			__CollectCollisionShadowReceiver (D3DXVECTOR3& v3Target, D3DXVECTOR3& v3Light);
		void			__UpdateAroundAreaList();
		bool			__IsInShadowReceiverList (CGraphicObjectInstance* pkObjInstTest);
		bool			__IsInPCBlockerList (CGraphicObjectInstance* pkObjInstTest);

		void			ConvertToMapCoords (float fx, float fy, int* iCellX, int* iCellY, BYTE* pucSubCellX, BYTE* pucSubCellY, WORD* pwTerrainNumX, WORD* pwTerrainNumY);

	public:
		BOOL			GetAreaPointer (const BYTE c_ucAreaNum, CArea** ppArea);
		void			RenderArea (bool bRenderAmbience = true);
		void			RenderBlendArea();
		void			RenderDungeon();
		void			RenderEffect();
		void			RenderPCBlocker();
		void			RenderTree(unsigned long flags = 0);

	public:
		float		GetHeight (float* pPos);
		bool		GetBrushColor (float fX, float fY, float* pLowColor, float* pHighColor);
		bool		isAttrOn (float fX, float fY, BYTE byAttr);
		bool		GetAttr (float fX, float fY, BYTE* pbyAttr);
		bool		isAttrOn (int iX, int iY, BYTE byAttr);
		bool		GetAttr (int iX, int iY, BYTE* pbyAttr);

		void		SetMaterialDiffuse (float fr, float fg, float fb);
		void		SetMaterialAmbient (float fr, float fg, float fb);
		void		SetTerrainMaterial (const PR_MATERIAL* pMaterial);

		bool		GetTerrainNum (float fx, float fy, BYTE* pbyTerrainNum);
		bool		GetTerrainNumFromCoord (WORD wCoordX, WORD wCoordY, BYTE* pbyTerrainNum);

	protected:
		long					m_lCenterX, m_lCenterY;
		long					m_lOldReadX, m_lOldReadY;
		CTerrainQuadtreeNode* m_pRootNode;

		void					BuildQuadTree();
		CTerrainQuadtreeNode* AllocQuadTreeNode (long x0, long y0, long x1, long y1);
		void					SubDivideNode (CTerrainQuadtreeNode* Node);
		void					UpdateQuadTreeHeights (CTerrainQuadtreeNode* Node);


		void					FreeQuadTree();

		struct TPatchDrawStruct
		{
			float fDistance;
			BYTE byTerrainNum;
			long lPatchNum;
			CTerrainPatchProxy* pTerrainPatchProxy;

			bool operator< (const TPatchDrawStruct& rhs) const
			{
				return fDistance < rhs.fDistance;
			}
		};

	public:
		typedef std::vector<BYTE> TTerrainNumVector;
		struct FSortPatchDrawStructWithTerrainNum
		{
			static TTerrainNumVector m_TerrainNumVector;
			FSortPatchDrawStructWithTerrainNum()
			{
				m_TerrainNumVector.clear();
			}

			bool operator() (const TPatchDrawStruct& lhs, const TPatchDrawStruct& rhs)
			{
				DWORD lhsTerrainNumOrder = 0, rhsTerrainNumOrder = 0;
				bool blhsOrderFound = false;
				bool brhsOrderFound = false;

				TTerrainNumVector::iterator lhsIterator = std::find (m_TerrainNumVector.begin(), m_TerrainNumVector.end(), lhs.byTerrainNum);
				TTerrainNumVector::iterator rhsIterator = std::find (m_TerrainNumVector.begin(), m_TerrainNumVector.end(), rhs.byTerrainNum);

				if (lhsIterator != m_TerrainNumVector.end())
				{
					blhsOrderFound = true;
					lhsTerrainNumOrder = lhsIterator - m_TerrainNumVector.begin();
				}
				if (rhsIterator != m_TerrainNumVector.end())
				{
					brhsOrderFound = true;
					rhsTerrainNumOrder = rhsIterator - m_TerrainNumVector.begin();
				}
				if (!brhsOrderFound)
				{
					m_TerrainNumVector.push_back (rhs.byTerrainNum);
					rhsTerrainNumOrder = m_TerrainNumVector.size() - 1;
				}
				if (!blhsOrderFound)
				{
					lhsIterator = std::find (m_TerrainNumVector.begin(), m_TerrainNumVector.end(), lhs.byTerrainNum);
					if (lhsIterator != m_TerrainNumVector.end())
					{
						blhsOrderFound = true;
						lhsTerrainNumOrder = lhsIterator - m_TerrainNumVector.begin();
					}
					if (!blhsOrderFound)
					{
						m_TerrainNumVector.push_back (lhs.byTerrainNum);
						lhsTerrainNumOrder = m_TerrainNumVector.size() - 1;
					}
				}

				return lhsTerrainNumOrder < rhsTerrainNumOrder;
			}
		};

	protected:

		std::vector<std::pair<float, long>> m_PatchVector;
		std::vector<TPatchDrawStruct> m_PatchDrawStructVector;

		void					SetPatchDrawVector();

		void					NEW_DrawWireFrame (CTerrainPatchProxy* pTerrainPatchProxy, WORD wPrimitiveCount, D3DPRIMITIVETYPE ePrimitiveType);

		void					DrawWireFrame (long patchnum, WORD wPrimitiveCount, D3DPRIMITIVETYPE ePrimitiveType);
		void					DrawWater (long patchnum);

		bool					m_bDrawWireFrame;
		bool					m_bDrawShadow;
		bool					m_bDrawChrShadow;

		D3DXMATRIX				m_matBump;
		void					LoadWaterTexture();
		void					UnloadWaterTexture();

		CGraphicImageInstance	m_AlphaFogImageInstance;
		D3DXMATRIX				m_matAlphaFogTexture;

#ifdef DIRECTX9
		LPDIRECT3DTEXTURE9		m_lpCharacterShadowMapTexture;
		LPDIRECT3DSURFACE9		m_lpCharacterShadowMapRenderTargetSurface;
		LPDIRECT3DSURFACE9		m_lpCharacterShadowMapDepthSurface;
		D3DVIEWPORT9				m_ShadowMapViewport;
		WORD					m_wShadowMapSize;

		LPDIRECT3DSURFACE9		m_lpBackupRenderTargetSurface;
		LPDIRECT3DSURFACE9		m_lpBackupDepthSurface;
		D3DVIEWPORT9				m_BackupViewport;
#endif

		D3DXPLANE					m_plane[6];

		void BuildViewFrustum (D3DXMATRIX& mat);

		CTextureSet					m_TextureSet;

	protected:
		CSkyBox						m_SkyBox;
		CLensFlare					m_LensFlare;
		CScreenFilter				m_ScreenFilter;

	protected:
		void SetIndexBuffer();
		void SelectIndexBuffer (BYTE byLODLevel, WORD* pwPrimitiveCount, D3DPRIMITIVETYPE* pePrimitiveType);

		D3DXMATRIX m_matWorldForCommonUse;
		D3DXMATRIX m_matViewInverse;

		D3DXMATRIX m_matSplatAlpha;
		D3DXMATRIX m_matStaticShadow;
		D3DXMATRIX m_matDynamicShadow;
		D3DXMATRIX m_matDynamicShadowScale;
		D3DXMATRIX m_matLightView;

		float m_fTerrainTexCoordBase;
		float m_fWaterTexCoordBase;

		float m_fXforDistanceCaculation, m_fYforDistanceCaculation;

	protected:
		typedef std::vector<CTerrain*>		TTerrainPtrVector;
		typedef TTerrainPtrVector::iterator TTerrainPtrVectorIterator;
		typedef std::vector<CArea*>		TAreaPtrVector;
		typedef TAreaPtrVector::iterator	TAreaPtrVectorIterator;

		TTerrainPtrVector m_TerrainVector;
		TAreaPtrVector m_AreaVector;

#ifndef JTX_ENTIRE_TERRAIN_RENDER
		TTerrainPtrVector			m_TerrainDeleteVector;
		TTerrainPtrVector			m_TerrainLoadRequestVector;
		TTerrainPtrVector			m_TerrainLoadWaitVector;
		TTerrainPtrVectorIterator	m_TerrainPtrVectorIterator;

		TAreaPtrVector				m_AreaDeleteVector;
		TAreaPtrVectorIterator		m_AreaPtrVectorIterator;
		TAreaPtrVector				m_AreaLoadWaitVector;
		TAreaPtrVector				m_AreaLoadRequestVector;

		struct FPushToDeleteVector
		{
			enum EDeleteDir
			{
				DELETE_LEFT,
				DELETE_RIGHT,
				DELETE_TOP,
				DELETE_BOTTOM,
			};
	
			EDeleteDir m_eLRDeleteDir;
			EDeleteDir m_eTBDeleteDir;
			TOutdoorMapCoordinate m_CurCoordinate;
	
			FPushToDeleteVector(EDeleteDir eLRDeleteDir, EDeleteDir eTBDeleteDir, TOutdoorMapCoordinate CurCoord)
			{
				m_eLRDeleteDir = eLRDeleteDir;
				m_eTBDeleteDir = eTBDeleteDir;
				m_CurCoordinate = CurCoord;
			}
		};
	
		struct FPushTerrainToDeleteVector : public FPushToDeleteVector
		{
			TTerrainPtrVector	m_ReturnTerrainVector;
	
			FPushTerrainToDeleteVector(EDeleteDir eLRDeleteDir, EDeleteDir eTBDeleteDir, TOutdoorMapCoordinate CurCoord)
				: FPushToDeleteVector(eLRDeleteDir, eTBDeleteDir, CurCoord)
			{
				m_ReturnTerrainVector.clear();
			}
	
			void operator() (CTerrain* pTerrain);
		};
	
		struct FPushAreaToDeleteVector : public FPushToDeleteVector
		{
			TAreaPtrVector		m_ReturnAreaVector;
	
			FPushAreaToDeleteVector(EDeleteDir eLRDeleteDir, EDeleteDir eTBDeleteDir, TOutdoorMapCoordinate CurCoord)
				: FPushToDeleteVector(eLRDeleteDir, eTBDeleteDir, CurCoord)
			{
				m_ReturnAreaVector.clear();
			}
	
			void operator() (CArea* pArea);
		};
#endif

	protected:
		void InitializeVisibleParts();
		bool IsVisiblePart (int ePart);

		float __GetNoFogDistance();
		float __GetFogDistance();


	protected:
		DWORD m_dwVisiblePartFlags;

		int m_iRenderedSplatNumSqSum;
		int m_iRenderedSplatNum;
		int m_iRenderedPatchNum;
		std::vector<int> m_RenderedTextureNumVector;
		int m_iSplatLimit;

	protected:
		int m_iPatchTerrainVertexCount;
		int m_iPatchWaterVertexCount;

		int m_iPatchTerrainVertexSize;
		int m_iPatchWaterVertexSize;

		DWORD m_dwRenderedCRCNum;
		DWORD m_dwRenderedGraphicThingInstanceNum;

		std::list<RECT> m_rkList_kGuildArea;

	protected:
		void __RenderTerrain_RecurseRenderQuadTree (CTerrainQuadtreeNode* Node, bool bCullCheckNeed = true);
		int	 __RenderTerrain_RecurseRenderQuadTree_CheckBoundingCircle (const D3DXVECTOR3& c_v3Center, const float& c_fRadius);

		void __RenderTerrain_AppendPatch (const D3DXVECTOR3& c_rv3Center, float fDistance, long lPatchNum);

		void __RenderTerrain_RenderSoftwareTransformPatch();
		void __RenderTerrain_RenderHardwareTransformPatch();

	protected:
		void __HardwareTransformPatch_RenderPatchSplat (long patchnum, WORD wPrimitiveCount, D3DPRIMITIVETYPE ePrimitiveType);
		void __HardwareTransformPatch_RenderPatchNone (long patchnum, WORD wPrimitiveCount, D3DPRIMITIVETYPE ePrimitiveType);


	protected:
		struct SoftwareTransformPatch_SData
		{
			enum
			{
				SPLAT_VB_NUM = 8,
				NONE_VB_NUM = 8,
			};

#ifdef DIRECTX9
			IDirect3DVertexBuffer9* m_pkVBSplat[SPLAT_VB_NUM];
			IDirect3DVertexBuffer9* m_pkVBNone[NONE_VB_NUM];
#endif
			DWORD m_dwSplatPos;
			DWORD m_dwNonePos;
			std::uintptr_t m_lightVersion;
		} m_kSTPD;

		struct SoftwareTransformPatch_SRenderState
		{
			D3DXMATRIX m_m4Proj;
			D3DXMATRIX m_m4Frustum;
			D3DXMATRIX m_m4DynamicShadow;
#ifdef DIRECTX9
			D3DLIGHT9 m_kLight;
			D3DMATERIAL9 m_kMtrl;
#endif
			D3DXVECTOR3 m_v3Player;
			DWORD m_dwFogColor;
			float m_fScreenHalfWidth;
			float m_fScreenHalfHeight;

			float m_fFogNearDistance;
			float m_fFogFarDistance;
			float m_fFogNearTransZ;
			float m_fFogFarTransZ;
			float m_fFogLenInv;
		};

		struct SoftwareTransformPatch_STVertex
		{
			D3DXVECTOR4 kPosition;
		};

		struct SoftwareTransformPatch_STLVertex
		{
			D3DXVECTOR4 kPosition;
			DWORD dwDiffuse;
			DWORD dwFog;
			D3DXVECTOR2 kTexTile;
			D3DXVECTOR2 kTexAlpha;
			D3DXVECTOR2 kTexStaticShadow;
			D3DXVECTOR2 kTexDynamicShadow;
		};


		void __SoftwareTransformPatch_ApplyRenderState();
		void __SoftwareTransformPatch_RestoreRenderState (DWORD dwFogEnable);

		void __SoftwareTransformPatch_Initialize();
		bool __SoftwareTransformPatch_Create();
		void __SoftwareTransformPatch_Destroy();
		void __SoftwareTransformPatch_BuildPipeline (SoftwareTransformPatch_SRenderState& rkTPRS);
		void __SoftwareTransformPatch_BuildPipeline_BuildFogFuncTable (SoftwareTransformPatch_SRenderState& rkTPRS);
		bool __SoftwareTransformPatch_SetTransform (SoftwareTransformPatch_SRenderState& rkTPRS, SoftwareTransformPatch_STLVertex* akTransVertex, CTerrainPatchProxy& rkTerrainPatchProxy, unsigned int uTerrainX, unsigned int uTerrainY, bool isFogEnable, bool isDynamicShadow);

		bool __SoftwareTransformPatch_SetSplatStream (SoftwareTransformPatch_STLVertex* akTransVertex);
		bool __SoftwareTransformPatch_SetShadowStream (SoftwareTransformPatch_STLVertex* akTransVertex);

		void __SoftwareTransformPatch_ApplyStaticShadowRenderState();
		void __SoftwareTransformPatch_RestoreStaticShadowRenderState();

		void __SoftwareTransformPatch_ApplyFogShadowRenderState();
		void __SoftwareTransformPatch_RestoreFogShadowRenderState();
		void __SoftwareTransformPatch_ApplyDynamicShadowRenderState();
		void __SoftwareTransformPatch_RestoreDynamicShadowRenderState();
		void __SoftwareTransformPatch_RenderPatchSplat (SoftwareTransformPatch_SRenderState& rkTPRS, long patchnum, WORD wPrimitiveCount, D3DPRIMITIVETYPE ePrimitiveType, bool isFogEnable);
		void __SoftwareTransformPatch_RenderPatchNone (SoftwareTransformPatch_SRenderState& rkTPRS, long patchnum, WORD wPrimitiveCount, D3DPRIMITIVETYPE ePrimitiveType);


	protected:
		std::vector<CGraphicObjectInstance*> m_ShadowReceiverVector;
		std::vector<CGraphicObjectInstance*> m_PCBlockerVector;

	protected:
		float	m_fOpaqueWaterDepth;
		CGraphicImageInstance m_WaterInstances[30];

	public:
		float	GetOpaqueWaterDepth()
		{
			return m_fOpaqueWaterDepth;
		}
		void	SetOpaqueWaterDepth (float fOpaqueWaterDepth)
		{
			m_fOpaqueWaterDepth = fOpaqueWaterDepth;
		}
		void	SetTerrainRenderSort (ETerrainRenderSort eTerrainRenderSort)
		{
			m_eTerrainRenderSort = eTerrainRenderSort;
		}
		ETerrainRenderSort	GetTerrainRenderSort()
		{
			return m_eTerrainRenderSort;
		}

	protected:
		ETerrainRenderSort m_eTerrainRenderSort;

	protected:
		CGraphicImageInstance	m_attrImageInstance;
		CGraphicImageInstance	m_BuildingTransparentImageInstance;
		D3DXMATRIX				m_matBuildingTransparent;

	public:
		void GetBaseXY (DWORD* pdwBaseX, DWORD* pdwBaseY);
		void SetBaseXY (DWORD dwBaseX, DWORD dwBaseY);

		void SetTransparentTree (bool bTransparentTree)
		{
			m_bTransparentTree = bTransparentTree;
		}
		void EnableTerrainOnlyForHeight (bool bFlag)
		{
			m_bEnableTerrainOnlyForHeight = bFlag;
		}
		void EnablePortal (bool bFlag);
		bool IsEnablePortal()
		{
			return m_bEnablePortal;
		}

	protected:
		DWORD			m_dwBaseX;
		DWORD			m_dwBaseY;

		D3DXVECTOR3		m_v3Player;

		bool			m_bShowEntirePatchTextureCount;
		bool			m_bTransparentTree;
		bool			m_bEnableTerrainOnlyForHeight;
		bool			m_bEnablePortal;

	private:
		struct SXMasTree
		{
			CSpeedTreeWrapper* m_pkTree;
			int m_iEffectID;
		} m_kXMas;

		void __XMasTree_Initialize();
		void __XMasTree_Create (float x, float y, float z, const char* c_szTreeName, const char* c_szEffName);

	public:
		void XMasTree_Destroy();
		void XMasTree_Set (float x, float y, float z, const char* c_szTreeName, const char* c_szEffName);

	private:
		typedef std::map<DWORD, int> TSpecialEffectMap;
		TSpecialEffectMap m_kMap_dwID_iEffectID;

	public:
		void SpecialEffect_Create (DWORD dwID, float x, float y, float z, const char* c_szEffName);
		void SpecialEffect_Delete (DWORD dwID);
		void SpecialEffect_Destroy();

	private:
		struct SHeightCache
		{
			struct SItem
			{
				DWORD	m_dwKey;
				float	m_fHeight;
			};

			enum
			{
				HASH_SIZE = 100,
			};

			std::vector<SItem> m_akVct_kItem[HASH_SIZE];

			bool m_isUpdated;
		} m_kHeightCache;

		void __HeightCache_Init();
		void __HeightCache_Update();

	public:
		void SetEnvironmentDataName (const std::string& strEnvironmentDataName);
		std::string& GetEnvironmentDataName();

	protected:
		std::string		m_settings_envDataName;
		std::string		m_envDataName;

	private:
		bool m_bSettingTerrainVisible;
};

