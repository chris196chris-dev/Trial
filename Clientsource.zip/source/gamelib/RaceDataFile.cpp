#include "StdAfx.h"
#include "../eterlib/ResourceManager.h"

#include "RaceData.h"
#include "RaceMotionData.h"
#define ENABLE_SKIN_EXTENDED
BOOL CRaceData::LoadRaceData (const char* c_szFileName)
{
	CTextFileLoader TextFileLoader;
	if (!TextFileLoader.Load (c_szFileName))
	{
		return FALSE;
	}

	TextFileLoader.SetTop();

	TextFileLoader.GetTokenString ("basemodelfilename", &m_strBaseModelFileName);
	TextFileLoader.GetTokenString ("treefilename", &m_strTreeFileName);
	TextFileLoader.GetTokenString ("attributefilename", &m_strAttributeFileName);
	TextFileLoader.GetTokenString ("smokebonename", &m_strSmokeBoneName);
	TextFileLoader.GetTokenString ("motionlistfilename", &m_strMotionListFileName);

	if (!m_strTreeFileName.empty())
	{
		CFileNameHelper::StringPath (m_strTreeFileName);
	}

	CTokenVector* pSmokeTokenVector;
	if (TextFileLoader.GetTokenVector ("smokefilename", &pSmokeTokenVector))
	{
		if (pSmokeTokenVector->size() % 2 != 0)
		{
			TraceError ("SmokeFileName ArgCount[%d]%2==0", pSmokeTokenVector->size());
			return FALSE;
		}

		unsigned int uLineCount = pSmokeTokenVector->size() / 2;

		for (unsigned int uLine = 0; uLine < uLineCount; ++uLine)
		{
			int eSmoke = atoi (pSmokeTokenVector->at (uLine * 2 + 0).c_str());
			if (eSmoke < 0 || eSmoke >= SMOKE_NUM)
			{
				TraceError ("SmokeFileName SmokeNum[%d] OUT OF RANGE", eSmoke);
				return FALSE;
			}

			const std::string& c_rstrEffectFileName = pSmokeTokenVector->at (uLine * 2 + 1);

			DWORD& rdwCRCEft = m_adwSmokeEffectID[eSmoke];
			if (!CEffectManager::Instance().RegisterEffect2 (c_rstrEffectFileName.c_str(), &rdwCRCEft))
			{
				TraceError ("CRaceData::RegisterEffect2(%s) ERROR", c_rstrEffectFileName.c_str());
				rdwCRCEft = 0;
				return false;
			}
		}
	}

	if (TextFileLoader.SetChildNode ("shapedata"))
	{
		std::string strPathName;
		auto fix1800 = std::string(strPathName); //fix1800
		DWORD dwShapeDataCount = 0;
		if (TextFileLoader.GetTokenString ("pathname", &fix1800) &&
				TextFileLoader.GetTokenDoubleWord ("shapedatacount", &dwShapeDataCount))
		{
			for (DWORD i = 0; i < dwShapeDataCount; ++i)
			{
				if (!TextFileLoader.SetChildNode ("shapedata", i))
				{
					continue;
				}
				TextFileLoader.GetTokenString ("specialpath", &fix1800);
				DWORD dwShapeIndex;
				if (!TextFileLoader.GetTokenDoubleWord ("shapeindex", &dwShapeIndex))
				{
					continue;
				}

				std::string strModel;
				if (TextFileLoader.GetTokenString ("model", &strModel))
				{
					SetShapeModel (dwShapeIndex, (fix1800 + strModel).c_str());
				}
				else
				{
					if (!TextFileLoader.GetTokenString ("local_model", &strModel))
					{
						continue;
					}

					SetShapeModel (dwShapeIndex, strModel.c_str());
				}

				std::string strSourceSkin;
				std::string strTargetSkin;
				#ifdef ENABLE_SKIN_EXTENDED
				const auto minSkinExtension = 2;
				const auto maxSkinExtension = 9;
				static char __szSourceSkin[10+6+2+1];
				static char __szTargetSkin[10+6+2+1];
				#endif
				if (TextFileLoader.GetTokenString ("local_sourceskin", &strSourceSkin) &&
						TextFileLoader.GetTokenString ("local_targetskin", &strTargetSkin))
				{
					AppendShapeSkin (dwShapeIndex, 0, strSourceSkin.c_str(), strTargetSkin.c_str());
				}
				#ifdef ENABLE_SKIN_EXTENDED
				for (auto j=minSkinExtension; j<=maxSkinExtension; j++)
				{
					_snprintf(__szSourceSkin, sizeof(__szSourceSkin), "local_sourceskin%d", j);
					_snprintf(__szTargetSkin, sizeof(__szTargetSkin), "local_targetskin%d", j);
					if (TextFileLoader.GetTokenString(__szSourceSkin, &strSourceSkin) &&
						TextFileLoader.GetTokenString(__szTargetSkin, &strTargetSkin))
					{
						AppendShapeSkin(dwShapeIndex, 0, __szSourceSkin, __szTargetSkin);
					}
				}
				#endif
				if (TextFileLoader.GetTokenString ("sourceskin", &strSourceSkin) &&
						TextFileLoader.GetTokenString ("targetskin", &strTargetSkin))
				{
					AppendShapeSkin (dwShapeIndex, 0, (fix1800 + strSourceSkin).c_str(), (fix1800 + strTargetSkin).c_str());
				}
				#ifdef ENABLE_SKIN_EXTENDED
				for (auto j=minSkinExtension; j<=maxSkinExtension; j++)
				{
					_snprintf(__szSourceSkin, sizeof(__szSourceSkin), "sourceskin%d", j);
					_snprintf(__szTargetSkin, sizeof(__szTargetSkin), "targetskin%d", j);
					if (TextFileLoader.GetTokenString(__szSourceSkin, &strSourceSkin) &&
						TextFileLoader.GetTokenString(__szTargetSkin, &strTargetSkin))
					{
						AppendShapeSkin(dwShapeIndex, 0, (fix1800 + strSourceSkin).c_str(), (fix1800 + strTargetSkin).c_str());
					}
				}
				#else
				if (TextFileLoader.GetTokenString ("sourceskin2", &strSourceSkin) &&
						TextFileLoader.GetTokenString ("targetskin2", &strTargetSkin))
				{
					AppendShapeSkin (dwShapeIndex, 0, (fix1800 + strSourceSkin).c_str(), (fix1800 + strTargetSkin).c_str());
				}
				#endif
				TextFileLoader.SetParentNode();
			}
		}

		TextFileLoader.SetParentNode();
	}

	if (TextFileLoader.SetChildNode ("hairdata"))
	{
		std::string strPathName;
		auto fix1801 = std::string(strPathName); //fix1801
		DWORD dwHairDataCount = 0;
		if (TextFileLoader.GetTokenString ("pathname", &fix1801) &&
				TextFileLoader.GetTokenDoubleWord ("hairdatacount", &dwHairDataCount))
		{

			for (DWORD i = 0; i < dwHairDataCount; ++i)
			{
				if (!TextFileLoader.SetChildNode ("hairdata", i))
				{
					continue;
				}

				TextFileLoader.GetTokenString ("specialpath", &fix1801);
				DWORD dwShapeIndex;
				if (!TextFileLoader.GetTokenDoubleWord ("hairindex", &dwShapeIndex))
				{
					continue;
				}

				std::string strModel;
				std::string strSourceSkin;
				std::string strTargetSkin;
				if (TextFileLoader.GetTokenString ("model", &strModel) && TextFileLoader.GetTokenString ("sourceskin", &strSourceSkin) && TextFileLoader.GetTokenString ("targetskin", &strTargetSkin))
				{
					SetHairSkin (dwShapeIndex, 0, (fix1801 + strModel).c_str(), (fix1801 + strSourceSkin).c_str(), (fix1801 + strTargetSkin).c_str());
				}
				#ifdef ENABLE_SKIN_EXTENDED
				if (TextFileLoader.GetTokenString("local_model", &strModel) &&
					TextFileLoader.GetTokenString("local_sourceskin", &strSourceSkin) &&
					TextFileLoader.GetTokenString("local_targetskin", &strTargetSkin))
				{
					SetHairSkin(dwShapeIndex, 0, strModel.c_str(), strSourceSkin.c_str(), strTargetSkin.c_str());
				}
				#endif
				TextFileLoader.SetParentNode();
			}
		}

		TextFileLoader.SetParentNode();
	}


	if (TextFileLoader.SetChildNode ("attachingdata"))
	{
		if (!NRaceData::LoadAttachingData (TextFileLoader, &m_AttachingDataVector))
		{
			return FALSE;
		}

		TextFileLoader.SetParentNode();
	}

	return TRUE;
}

