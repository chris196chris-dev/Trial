#include "StdAfx.h"
#include "../eterpack/EterPackManager.h"
#include "../eterlib/ResourceManager.h"

#include "ItemManager.h"

static DWORD s_adwItemProtoKey[4] =
{
	ITEM_PROTO_KEY_1,
	ITEM_PROTO_KEY_2,
	ITEM_PROTO_KEY_3,
	ITEM_PROTO_KEY_4
};

BOOL CItemManager::SelectItemData(DWORD dwIndex)
{
	TItemMap::iterator f = m_ItemMap.find(dwIndex);

	if (m_ItemMap.end() == f)
	{
		int n = m_vec_ItemRange.size();
		for (int i = 0; i < n; i++)
		{
			CItemData* p = m_vec_ItemRange[i];
			const CItemData::TItemTable* pTable = p->GetTable();
			if ((pTable->dwVnum < dwIndex) && dwIndex < (pTable->dwVnum + pTable->dwVnumRange))
			{
				m_pSelectedItemData = p;
				return TRUE;
			}
		}
		Tracef(" CItemManager::SelectItemData - FIND ERROR [%d]\n", dwIndex);
		return FALSE;
	}

	m_pSelectedItemData = f->second;

	return TRUE;
}

CItemData* CItemManager::GetSelectedItemDataPointer()
{
	return m_pSelectedItemData;
}

BOOL CItemManager::GetItemDataPointer(DWORD dwItemID, CItemData** ppItemData)
{
	if (0 == dwItemID)
	{
		return FALSE;
	}

	TItemMap::iterator f = m_ItemMap.find(dwItemID);

	if (m_ItemMap.end() == f)
	{
		int n = m_vec_ItemRange.size();
		for (int i = 0; i < n; i++)
		{
			CItemData* p = m_vec_ItemRange[i];
			const CItemData::TItemTable* pTable = p->GetTable();
			if ((pTable->dwVnum < dwItemID) && dwItemID < (pTable->dwVnum + pTable->dwVnumRange))
			{
				*ppItemData = p;
				return TRUE;
			}
		}
		Tracef(" CItemManager::GetItemDataPointer - FIND ERROR [%d]\n", dwItemID);
		return FALSE;
	}

	*ppItemData = f->second;

	return TRUE;
}

CItemData* CItemManager::MakeItemData(DWORD dwIndex)
{
	TItemMap::iterator f = m_ItemMap.find(dwIndex);

	if (m_ItemMap.end() == f)
	{
		CItemData* pItemData = CItemData::New();

		m_ItemMap.insert(TItemMap::value_type(dwIndex, pItemData));

		return pItemData;
	}

	return f->second;
}

//MULTI_LANGUAGE
bool CItemManager::LoadItemNamesFromJSON(const char* filename)
{
	if (!LocaleJson_LoadItemNames(filename))
	{
		TraceError("CItemManager::LoadItemNamesFromJSON: Failed to load %s", filename);
		return false;
	}

	// Override item names with JSON translations
	for (TItemMap::iterator it = m_ItemMap.begin(); it != m_ItemMap.end(); ++it)
	{
		DWORD dwVnum = it->first;
		CItemData* pItemData = it->second;

		const char* jsonName = LocaleJson_GetItemName(dwVnum);
		if (jsonName)
		{
			pItemData->SetLocaleName(jsonName);
		}
	}

	Tracef("CItemManager: Applied JSON item names\n");
	return true;
}

bool CItemManager::LoadItemDescFromJSON(const char* filename)
{
	if (!LocaleJson_LoadItemDesc(filename))
	{
		TraceError("CItemManager::LoadItemDescFromJSON: Failed to load %s", filename);
		return false;
	}

	// Apply descriptions to item data
	for (TItemMap::iterator it = m_ItemMap.begin(); it != m_ItemMap.end(); ++it)
	{
		DWORD dwVnum = it->first;
		CItemData* pItemData = it->second;

		const char* jsonDesc = LocaleJson_GetItemDesc(dwVnum);
		if (jsonDesc)
		{
			pItemData->SetDescription(jsonDesc);
		}

		const char* jsonSummary = LocaleJson_GetItemSummary(dwVnum);
		if (jsonSummary)
		{
			pItemData->SetSummary(jsonSummary);
		}
	}

	Tracef("CItemManager: Applied JSON item descriptions\n");
	return true;
}
//MULTI_LANGUAGE

bool CItemManager::LoadItemList (const char* c_szFileName)
{
	CMappedFile File;
	LPCVOID pData;

	if (!CEterPackManager::Instance().Get (File, c_szFileName, &pData))
	{
		return false;
	}

	CMemoryTextFileLoader textFileLoader;
	textFileLoader.Bind (File.Size(), pData);

	CTokenVector TokenVector;
	for (DWORD i = 0; i < textFileLoader.GetLineCount(); ++i)
	{
		if (!textFileLoader.SplitLine (i, &TokenVector, "\t"))
		{
			continue;
		}

		if (! (TokenVector.size() == 3 || TokenVector.size() == 4))
		{
			TraceError (" CItemManager::LoadItemList(%s) - StrangeLine in %d\n", c_szFileName, i);
			continue;
		}

		const std::string& c_rstrID = TokenVector[0];
		const std::string& c_rstrIcon = TokenVector[2];

		DWORD dwItemVNum = atoi(c_rstrID.c_str());

		CItemData* pItemData = MakeItemData (dwItemVNum);

		if (4 == TokenVector.size())
		{
			const std::string& c_rstrModelFileName = TokenVector[3];
			pItemData->SetDefaultItemData (c_rstrIcon.c_str(), c_rstrModelFileName.c_str());
		}
		else
		{
			pItemData->SetDefaultItemData (c_rstrIcon.c_str());
		}
	}

	return true;
}

DWORD GetHashCode(const char* pString)
{
	unsigned long result = 5381;
	const unsigned char* p = reinterpret_cast<const unsigned char*>(pString);

	while (*p)
	{
		result = ((result << 5) + result) + *p;
		++p;
	}

	return result;
}

bool CItemManager::LoadItemTable(const char* c_szFileName)
{
	CMappedFile file;
	LPCVOID pvData;

	if (!CEterPackManager::Instance().Get(file, c_szFileName, &pvData))
	{
		return false;
	}

	DWORD dwFourCC, dwElements, dwDataSize;
	DWORD dwVersion = 0;
	DWORD dwStride = 0;

	file.Read(&dwFourCC, sizeof(DWORD));

	if (dwFourCC == MAKEFOURCC('M', 'I', 'P', 'X'))
	{
		file.Read(&dwVersion, sizeof(DWORD));
		file.Read(&dwStride, sizeof(DWORD));

		if (dwVersion != 1)
		{
			TraceError("CPythonItem::LoadItemTable: invalid item_proto[%s] VERSION[%d]", c_szFileName, dwVersion);
			return false;
		}

		if (dwStride != sizeof(CItemData::TItemTable))
		{
			TraceError("CPythonItem::LoadItemTable: invalid item_proto[%s] STRIDE[%d] != sizeof(SItemTable)", c_szFileName, dwStride, sizeof(CItemData::TItemTable));
			return false;
		}
	}
	else if (dwFourCC != MAKEFOURCC('M', 'I', 'P', 'T'))
	{
		TraceError("CPythonItem::LoadItemTable: invalid item proto type %s", c_szFileName);
		return false;
	}

	file.Read(&dwElements, sizeof(DWORD));
	file.Read(&dwDataSize, sizeof(DWORD));

	BYTE* pbData = new BYTE[dwDataSize];
	file.Read(pbData, dwDataSize);

	CLZObject zObj;

	if (!CLZO::Instance().Decompress(zObj, pbData, s_adwItemProtoKey))
	{
		delete[] pbData;
		#ifdef FIX_BLACK_SCREEN
		pbData = nullptr;
		#endif
		return false;
	}

	char szName[64 + 1];
	CItemData::TItemTable * table = (CItemData::TItemTable *) zObj.GetBuffer();
	std::map<DWORD, DWORD> itemNameMap;

	for (DWORD i = 0; i < dwElements; ++i, ++table)
	{
		CItemData* pItemData;
		DWORD dwVnum = table->dwVnum;

		TItemMap::iterator f = m_ItemMap.find(dwVnum);
		if (m_ItemMap.end() == f)
		{
			_snprintf(szName, sizeof(szName), "icon/item/%05d.tga", dwVnum);

			if (CResourceManager::Instance().IsFileExist(szName) == false)
			{
				std::map<DWORD, DWORD>::iterator itVnum = itemNameMap.find(GetHashCode(table->szName));

				if (itVnum != itemNameMap.end())
				{
					_snprintf(szName, sizeof(szName), "icon/item/%05d.tga", itVnum->second);
				}
				else
				{
					_snprintf(szName, sizeof(szName), "icon/item/%05d.tga", dwVnum - dwVnum % 10);
				}

				if (CResourceManager::Instance().IsFileExist(szName) == false)
				{
#ifdef _DEBUG
					TraceError("%16s(#%-5d) cannot find icon file. setting to default.", table->szName, dwVnum);
#endif
					const DWORD EmptyBowl = 27995;
					_snprintf(szName, sizeof(szName), "icon/item/%05d.tga", EmptyBowl);
				}
			}

			pItemData = CItemData::New();

			pItemData->SetDefaultItemData(szName);
			m_ItemMap.insert(TItemMap::value_type(dwVnum, pItemData));
		}
		else
		{
			pItemData = f->second;
		}
		if (itemNameMap.find(GetHashCode(table->szName)) == itemNameMap.end())
		{
			itemNameMap.insert(std::map<DWORD, DWORD>::value_type(GetHashCode(table->szName), table->dwVnum));
		}
		pItemData->SetItemTableData(table);

		//MULTI_LANGUAGE - Ignore proto name, names come from JSON only (show vnum if missing)
		pItemData->SetDefaultLocaleName();
		//MULTI_LANGUAGE

		if (0 != table->dwVnumRange)
		{
			m_vec_ItemRange.push_back(pItemData);
		}
	}

	delete[] pbData;
	#ifdef FIX_BLACK_SCREEN
	pbData = nullptr;
	#endif
	return true;
}

void CItemManager::Destroy()
{
	TItemMap::iterator i;
	for (i = m_ItemMap.begin(); i != m_ItemMap.end(); ++i)
	{
		CItemData::Delete(i->second);
	}

	m_ItemMap.clear();
}

#ifdef ENABLE_ACCE_SYSTEM
bool CItemManager::LoadItemScale(const char* c_szFileName)
{
	const VOID* pvData;
	CMappedFile kFile;
	if (!CEterPackManager::Instance().Get(kFile, c_szFileName, &pvData))
		return false;

	CMemoryTextFileLoader kTextFileLoader;
	kTextFileLoader.Bind(kFile.Size(), pvData);

	CTokenVector kTokenVector;
	for (DWORD i = 0; i < kTextFileLoader.GetLineCount(); ++i)
	{
		if (!kTextFileLoader.SplitLineByTab(i, &kTokenVector))
			continue;

		if (kTokenVector.size() < ITEMSCALE_REQ)
		{
			TraceError("LoadItemScale: invalid line %d (%s).", i, c_szFileName);
			continue;
		}

		static std::map<std::pair<std::string, std::string>, std::string> scaleMap =
		{
			{ std::make_pair("JOB_ASSASSIN", "M"), "0.26" },
			{ std::make_pair("JOB_ASSASSIN", "F"), "0.38" },
			{ std::make_pair("JOB_SHAMAN",   "M"), "0.18" },
			{ std::make_pair("JOB_SHAMAN",   "F"), "0.26" },
			{ std::make_pair("JOB_SURA",     "M"), "0.21" },
			{ std::make_pair("JOB_SURA",     "F"), "0.3"  },
			{ std::make_pair("JOB_WARRIOR",  "M"), "0.15" },
			{ std::make_pair("JOB_WARRIOR",  "F"), "0.26" },
		};

		auto ascii_toupper = [](unsigned char ch) -> char
			{
				if (ch >= 'a' && ch <= 'z')
					return static_cast<char>(ch - 'a' + 'A');

				return static_cast<char>(ch);
			};

		std::string strJob = kTokenVector[ITEMSCALE_JOB];
		std::string strSex = kTokenVector[ITEMSCALE_SEX];

		std::transform(
			strJob.begin(),
			strJob.end(),
			strJob.begin(),
			[&](unsigned char ch) -> char
			{
				return ascii_toupper(ch);
			});

		std::transform(
			strSex.begin(),
			strSex.end(),
			strSex.begin(),
			[&](unsigned char ch) -> char
			{
				return ascii_toupper(ch);
			});

		const std::string& strScaleX = kTokenVector[ITEMSCALE_SCALE_X];
		const std::string& strScaleY = kTokenVector[ITEMSCALE_SCALE_Y];
		const std::string& strScaleZ = kTokenVector[ITEMSCALE_SCALE_Z];

		std::string strPositionX = "0";
		std::string strPositionY = "0";

		std::string strPositionZ = "0";
		std::map<std::pair<std::string, std::string>, std::string>::const_iterator itScale =
			scaleMap.find(std::make_pair(strJob, strSex));
		if (itScale != scaleMap.end())
			strPositionZ = itScale->second;

		if (kTokenVector.size() == ITEMSCALE_NUM)
		{
			strPositionX = kTokenVector[ITEMSCALE_POSITION_X];
			strPositionY = kTokenVector[ITEMSCALE_POSITION_Y];
			strPositionZ = kTokenVector[ITEMSCALE_POSITION_Z];
		}
		else if (kTokenVector.size() == ITEMSCALE_AURA_NUM)
		{
			strPositionZ = kTokenVector[ITEMSCALE_POSITION_X];
		}

		for (int j = 0; j < 5; ++j)
		{
			CItemData* pItemData = MakeItemData(atoi(kTokenVector[ITEMSCALE_VNUM].c_str()) + j);
			pItemData->SetItemScale(strJob, strSex, strScaleX, strScaleY, strScaleZ, strPositionX, strPositionY, strPositionZ);
		}
	}

	return true;
}
#endif

CItemManager::CItemManager() : m_pSelectedItemData(NULL)
{
}
CItemManager::~CItemManager()
{
	Destroy();
}

