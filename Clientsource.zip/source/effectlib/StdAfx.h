#pragma once
#include "../eterbase/StdAfx.h"
#include "../eterbase/Utils.h"
#include "../eterbase/Timer.h"
#include "../eterbase/CRC32.h"
#include "../eterbase/Debug.h"
#include "../eterlib/StdAfx.h"
#include "../eterlib/TextFileLoader.h"
#include "../mileslib/StdAfx.h"
#include <AttackDefines.h>

