#pragma once
#define WIN32_LEAN_AND_MEAN

#include <assert.h>
#include <AttackDefines.h>
#include <stdio.h>
#include <vector>
#include <map>
#include <string>

#ifdef DIRECTX9
#include <directx/d3d9/d3d9.h>
#include <directx/d3d9/d3d9types.h>
#include <directx/d3d9/d3dx9.h>
#endif

