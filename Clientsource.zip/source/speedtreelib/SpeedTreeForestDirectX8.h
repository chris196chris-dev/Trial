#pragma once

#include "stdafx.h"
#include "SpeedTreeForest.h"
#include "SpeedTreeMaterial.h"

class CSpeedTreeForestDirectX8 : public CSpeedTreeForest, public CGraphicBase, public CSingleton<CSpeedTreeForestDirectX8>
{
	public:
		CSpeedTreeForestDirectX8();
		virtual~CSpeedTreeForestDirectX8() = default;

		void UploadWindMatrix (unsigned int uiLocation, const float* pMatrix) const;
		void UpdateCompundMatrix (const D3DXVECTOR3& c_rEyeVec, const D3DXMATRIX& c_rmatView, const D3DXMATRIX& c_rmatProj);

		void Render (unsigned long ulRenderBitVector = Forest_RenderAll);
#ifdef DIRECTX9
		bool SetRenderingDevice (LPDIRECT3DDEVICE9EX pDevice);
#endif

	private:
		bool InitVertexShaders();

	private:
#ifdef DIRECTX9
		LPDIRECT3DDEVICE9EX m_pDx;
#endif
		DWORD m_dwBranchVertexShader;
		DWORD m_dwLeafVertexShader;
};

