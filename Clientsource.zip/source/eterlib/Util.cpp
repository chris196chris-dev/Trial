#include "StdAfx.h"
#include "../eterpack/EterPackManager.h"

#include "TextFileLoader.h"

static std::string gs_fontFace = "";
static DWORD gs_codePage = 0;
void PrintfTabs (FILE* File, int iTabCount, const char* c_szString, ...)
{
	va_list args;
	va_start (args, c_szString);

	static char szBuf[1024];
	_vsnprintf (szBuf, sizeof (szBuf), c_szString, args);
	va_end (args);

	for (int i = 0; i < iTabCount; ++i)
	{
		fprintf (File, "    ");
	}

	fprintf (File, szBuf);
}

bool LoadMultipleTextData (const char* c_szFileName, CTokenVectorMap& rstTokenVectorMap)
{
	LPCVOID pModelData;
	CMappedFile File;

	if (!CEterPackManager::Instance().Get (File, c_szFileName, &pModelData))
	{
		return false;
	}

	DWORD i;

	CMemoryTextFileLoader textFileLoader;
	CTokenVector stTokenVector;

	textFileLoader.Bind (File.Size(), pModelData);

	for (i = 0; i < textFileLoader.GetLineCount(); ++i)
	{
		if (!textFileLoader.SplitLine (i, &stTokenVector))
		{
			continue;
		}

		stl_lowers (stTokenVector[0]);

		if (0 == stTokenVector[0].compare ("start"))
		{
			CTokenVector stSubTokenVector;

			stl_lowers (stTokenVector[1]);
			const auto key = std::string(stTokenVector[1]); //fix29
			stTokenVector.clear();

			for (i = i + 1; i < textFileLoader.GetLineCount(); ++i)
			{
				if (!textFileLoader.SplitLine (i, &stSubTokenVector))
				{
					continue;
				}

				stl_lowers (stSubTokenVector[0]);

				if (0 == stSubTokenVector[0].compare ("end"))
				{
					break;
				}

				for (DWORD j = 0; j < stSubTokenVector.size(); ++j)
				{
					stTokenVector.push_back (stSubTokenVector[j]);
				}
			}

			rstTokenVectorMap.insert (CTokenVectorMap::value_type (key, stTokenVector));
		}
		else
		{
			const auto key = std::string(stTokenVector[0]); //fix30
			stTokenVector.erase (stTokenVector.begin());
			rstTokenVectorMap.insert (CTokenVectorMap::value_type (key, stTokenVector));
		}
	}

	return true;
}

int CALLBACK EnumFontFamExProc(CONST LOGFONTA* plogFont, CONST TEXTMETRICA*, DWORD, LPARAM lParam)
{
	const char* fontFace = reinterpret_cast<const char*>(lParam);

	if (!fontFace || !plogFont)
		return 1;

	return _stricmp(fontFace, plogFont->lfFaceName);
}

DWORD GetDefaultCodePage()
{
	return gs_codePage;
}

const char* GetDefaultFontFace()
{
	return gs_fontFace.c_str();
}

const char* GetFontFaceFromCodePage (WORD codePage)
{
	LOGFONT logFont;

	memset (&logFont, 0, sizeof (logFont));

	logFont.lfCharSet = DEFAULT_CHARSET;

	const char* fontFace = "tahoma";

	HDC hDC = GetDC (NULL);

	if (EnumFontFamiliesExA(hDC, &logFont, (FONTENUMPROCA)EnumFontFamExProc, reinterpret_cast<LPARAM>(fontFace), 0) == 0)
	{
		ReleaseDC(NULL, hDC);
		return fontFace;
	}

	if (EnumFontFamiliesExA(hDC, &logFont, (FONTENUMPROCA)EnumFontFamExProc, reinterpret_cast<LPARAM>(fontFace), 0) == 0)
	{
		ReleaseDC(NULL, hDC);
		return fontFace;
	}

	ReleaseDC (NULL, hDC);

	return GetDefaultFontFace();
}

void SetDefaultFontFace (const char* fontFace)
{
	gs_fontFace = fontFace;
}

bool SetDefaultCodePage (DWORD codePage)
{
	gs_codePage = codePage;
	auto fontFace = std::string(GetFontFaceFromCodePage (codePage)); //fix31
	if (fontFace.empty())
	{
		return false;
	}

	SetDefaultFontFace (fontFace.c_str());

	return true;
}

