#ifndef __INC_ETERLIB_MUTEX_H__
#define __INC_ETERLIB_MUTEX_H__
#include "StdAfx.h"

class Mutex
{
	public:
		Mutex();
		~Mutex();

		void Lock();
		void Unlock();
#ifdef ENABLE_FIX_GAME_CORE_BUG_NEW_SIX
		bool Trylock();
#endif

	private:
		CRITICAL_SECTION lock;
};

#endif

