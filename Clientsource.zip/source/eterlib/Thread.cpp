#include "StdAfx.h"
#include "Thread.h"

int CThread::Create (void* arg)
{
	Arg (arg);
	m_hThread = (HANDLE)_beginthreadex (NULL, 0, EntryPoint, this, 0, &m_uThreadID);

	if (!m_hThread)
	{
		return false;
	}

	SetThreadPriority (m_hThread, THREAD_PRIORITY_NORMAL);
	return true;
}

unsigned int CThread::Run (void* arg)
{
	if (!Setup())
	{
		return 0;
	}

	return (Execute (arg));
}

unsigned int CALLBACK CThread::EntryPoint (void* pThis)
{
	CThread* pThread = (CThread*)pThis;
	return pThread->Run (pThread->Arg());
}

