#ifndef __INC_ETERLIB_THREAD_H__
#define __INC_ETERLIB_THREAD_H__

class CThread
{
	public:
		CThread() : m_pArg (NULL), m_hThread (NULL), m_uThreadID (0) {};
		int Create (void* arg);

	protected:
		static unsigned int CALLBACK	EntryPoint (void* pThis);

		virtual unsigned int			Setup() = 0;
		virtual unsigned int			Execute (void* arg) = 0;

		unsigned int					Run (void* arg);

		void* Arg() const
		{
			return m_pArg;
		}
		void					Arg (void* arg)
		{
			m_pArg = arg;
		}

		HANDLE					m_hThread;

	private:
		void* m_pArg;
		unsigned				m_uThreadID;
};

#endif

