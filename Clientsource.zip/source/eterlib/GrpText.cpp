#include "StdAfx.h"
#include "../eterbase/Utils.h"
#include "GrpText.h"


bool CGraphicText::CreateDeviceObjects()
{
	return m_fontTexture.CreateDeviceObjects();
}

void CGraphicText::DestroyDeviceObjects()
{
	m_fontTexture.DestroyDeviceObjects();
}

CGraphicFontTexture* CGraphicText::GetFontTexturePointer()
{
	return &m_fontTexture;
}

CGraphicText::TType CGraphicText::Type()
{
	static TType s_type = StringToType ("CGraphicText");
	return s_type;
}

bool CGraphicText::OnLoad (int, const void*)
{
	static char strName[32];
	int size;
	bool bItalic = false;
	const char* p = strrchr (GetFileName(), ':');

	if (p)
	{
		strncpy (strName, GetFileName(), MIN (31, p - GetFileName()));
		++p;

		static char num[8];

		int i = 0;
		while (*p && isdigit (*p))
		{
			num[i++] = * (p++);
		}

		num[i] = '\0';
		if (*p == 'i')
		{
			bItalic = true;
		}
		size = atoi (num);
	}
	else
	{
		p = strrchr (GetFileName(), '.');

		if (!p)
		{
			assert (!"CGraphicText::OnLoadFromFile there is no extension (ie: .fnt)");
			strName[0] = '\0';
		}
		else
		{
			strncpy (strName, GetFileName(), MIN (31, p - GetFileName()));
		}

		size = 12;
	}

	if (!m_fontTexture.Create (strName, size, bItalic))
	{
		return false;
	}

	return true;
}

void CGraphicText::OnClear()
{
	m_fontTexture.Destroy();
}

bool CGraphicText::OnIsEmpty() const
{
	return m_fontTexture.IsEmpty();
}

bool CGraphicText::OnIsType (TType type)
{
	if (CGraphicText::Type() == type)
	{
		return true;
	}

	return CResource::OnIsType (type);
}


