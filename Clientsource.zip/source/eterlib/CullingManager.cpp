#include "StdAfx.h"
#include "CullingManager.h"
#include "GrpObjectInstance.h"

void CCullingManager::RayTraceCallback (const Vector3d&, const Vector3d&, float distance, const Vector3d&, SpherePack* sphere)
{
	if (m_RayFarDistance <= 0.0f || m_RayFarDistance >= distance)
	{
		m_list.push_back ((CGraphicObjectInstance*)sphere->GetUserData());
	}
}


void CCullingManager::VisibilityCallback (const Frustum&, SpherePack* sphere, ViewState state)
{
	CGraphicObjectInstance* pInstance = (CGraphicObjectInstance*)sphere->GetUserData();
	if (state == VS_OUTSIDE)
	{
		pInstance->Hide();
	}
	else
	{
		pInstance->Show();
	}
}

void CCullingManager::RangeTestCallback (const Vector3d&, float, SpherePack* sphere, ViewState state)
{
	if (state != VS_OUTSIDE)
	{
		m_list.push_back ((CGraphicObjectInstance*)sphere->GetUserData());
	}
}

void CCullingManager::Reset()
{
	m_Factory->Reset();
}

void CCullingManager::Update()
{
	m_Factory->Process();
}

void CCullingManager::Process()
{
	UpdateViewMatrix();
	UpdateProjMatrix();
	BuildViewFrustum();
	m_Factory->FrustumTest (GetFrustum(), this);
}

CCullingManager::CullingHandle CCullingManager::Register (CGraphicObjectInstance* obj)
{
	assert (obj);
	Vector3d center;
	float radius;
	obj->GetBoundingSphere (center, radius);
	return m_Factory->AddSphere_ (center, radius, obj, false);
}

void CCullingManager::Unregister (CullingHandle h)
{
	m_Factory->Remove (h);
}

CCullingManager::CCullingManager()
{
	m_Factory = new SpherePackFactory (
		10000,
		6400,
		1600,
		400
	);
}

CCullingManager::~CCullingManager()
{
	delete m_Factory;
	#ifdef FIX_BLACK_SCREEN
	m_Factory = nullptr;
	#endif
}

void CCullingManager::FindRange (const Vector3d& p, float radius)
{
	m_list.clear();
	m_Factory->RangeTest (p, radius, this);
}

void CCullingManager::FindRay (const Vector3d& p1, const Vector3d& dir)
{
	m_RayFarDistance = -1;
	m_list.clear();
	m_Factory->RayTrace (p1, dir, this);
}

void CCullingManager::FindRayDistance (const Vector3d& p1, const Vector3d& dir, float distance)
{
	m_RayFarDistance = distance;
	m_list.clear();
	m_Factory->RayTrace (p1, dir, this);
}

