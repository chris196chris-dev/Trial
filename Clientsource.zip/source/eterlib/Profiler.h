#pragma once

// FINALFORM_V8_GODMOVE
// This header is intentionally small. Some VS project files reference
// EterLib/Profiler.h because the m2dev source contains an empty profiler
// shim. Keeping this file present removes a false build break without
// changing runtime behaviour. Add real profiling here later if needed.
