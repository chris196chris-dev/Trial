#include "StdAfx.h"
#include "GrpDevice.h"
#include "../eterbase/Stl.h"
#include "../eterbase/Debug.h"

bool GRAPHICS_CAPS_SOFTWARE_TILING = false;

D3DPRESENT_PARAMETERS g_kD3DPP;

CGraphicDevice::CGraphicDevice()
	: m_uBackBufferCount (0)
{
	__Initialize();
}

CGraphicDevice::~CGraphicDevice()
{
	Destroy();
}

void CGraphicDevice::__Initialize()
{
	ms_iD3DAdapterInfo = D3DADAPTER_DEFAULT;
	ms_iD3DDevInfo = D3DADAPTER_DEFAULT;
	ms_iD3DModeInfo = D3DADAPTER_DEFAULT;

	ms_lpd3d = NULL;
	ms_lpd3dDevice = NULL;
	ms_lpd3dMatStack = NULL;

	ms_dwWavingEndTime = 0;
	ms_dwFlashingEndTime = 0;

	m_pStateManager = NULL;

	__InitializeDefaultIndexBufferList();
	__InitializePDTVertexBufferList();
}

void CGraphicDevice::RegisterWarningString (unsigned int uiMsg, const char* c_szString)
{
	m_kMap_strWarningMessage[uiMsg] = c_szString;
}

bool CGraphicDevice::ResizeBackBuffer (unsigned int uWidth, unsigned int uHeight)
{
	if (!ms_lpd3dDevice)
	{
		return false;
	}

	D3DPRESENT_PARAMETERS& rkD3DPP = ms_d3dPresentParameter;
	if (rkD3DPP.Windowed)
	{
		if (rkD3DPP.BackBufferWidth != uWidth || rkD3DPP.BackBufferHeight != uHeight)
		{
			rkD3DPP.BackBufferWidth = uWidth;
			rkD3DPP.BackBufferHeight = uHeight;
#ifdef DIRECTX9
			IDirect3DDevice9Ex& rkD3DDev = *ms_lpd3dDevice;

			D3DDISPLAYMODEEX displayMode = {};
			displayMode.Size = sizeof(D3DDISPLAYMODEEX);
			displayMode.Width = rkD3DPP.BackBufferWidth;
			displayMode.Height = rkD3DPP.BackBufferHeight;
			displayMode.Format = rkD3DPP.BackBufferFormat;
			displayMode.RefreshRate = rkD3DPP.FullScreen_RefreshRateInHz;
			displayMode.ScanLineOrdering = D3DSCANLINEORDERING_PROGRESSIVE;

			HRESULT hr = rkD3DDev.ResetEx (&rkD3DPP, rkD3DPP.Windowed ? nullptr : &displayMode);
#endif
			if (FAILED (hr))
			{
				return false;
			}

			__DestroyDefaultIndexBufferList();
			__CreateDefaultIndexBufferList();

			STATEMANAGER.SetDefaultState();
		}
	}

	return true;
}

CGraphicDevice::EDeviceState CGraphicDevice::GetDeviceState()
{
	if (!ms_lpd3dDevice)
	{
		return DEVICESTATE_NULL;
	}

	return DEVICESTATE_OK;
}

bool CGraphicDevice::Reset()
{
	HRESULT hr;

	D3DDISPLAYMODEEX displayMode = {};
	displayMode.Size = sizeof(D3DDISPLAYMODEEX);
	displayMode.Width = ms_d3dPresentParameter.BackBufferWidth;
	displayMode.Height = ms_d3dPresentParameter.BackBufferHeight;
	displayMode.Format = ms_d3dPresentParameter.BackBufferFormat;
	displayMode.RefreshRate = ms_d3dPresentParameter.FullScreen_RefreshRateInHz;
	displayMode.ScanLineOrdering = D3DSCANLINEORDERING_PROGRESSIVE;

	hr = ms_lpd3dDevice->ResetEx(&ms_d3dPresentParameter, &displayMode);
	if (SUCCEEDED(hr))
	{
		__DestroyDefaultIndexBufferList();
		__CreateDefaultIndexBufferList();
	}
	return SUCCEEDED(hr);
}

#ifdef DIRECTX9
static LPDIRECT3DSURFACE9 s_lpStencil;
#endif

static DWORD s_MaxTextureWidth, s_MaxTextureHeight;

#ifdef DIRECTX9
BOOL EL3D_ConfirmDevice (D3DCAPS9& rkD3DCaps, unsigned int uBehavior, D3DFORMAT)
#endif
{
	if (uBehavior & D3DCREATE_PUREDEVICE)
	{
		return FALSE;
	}

	if (uBehavior & D3DCREATE_HARDWARE_VERTEXPROCESSING)
	{
		if (! (rkD3DCaps.VertexProcessingCaps & D3DVTXPCAPS_DIRECTIONALLIGHTS))
		{
			return FALSE;
		}

		if (! (rkD3DCaps.VertexProcessingCaps & D3DVTXPCAPS_POSITIONALLIGHTS))
		{
			return FALSE;
		}

		if (GRAPHICS_CAPS_SOFTWARE_TILING)
		{
			if (! (rkD3DCaps.PrimitiveMiscCaps & D3DPMISCCAPS_CLIPTLVERTS))
			{
				return FALSE;
			}
		}
		else
		{
			if (! (rkD3DCaps.VertexProcessingCaps & D3DVTXPCAPS_TEXGEN))
			{
				return FALSE;
			}
		}
	}

	s_MaxTextureWidth = rkD3DCaps.MaxTextureWidth;
	s_MaxTextureHeight = rkD3DCaps.MaxTextureHeight;

	return TRUE;
}

DWORD GetMaxTextureWidth()
{
	return s_MaxTextureWidth;
}

DWORD GetMaxTextureHeight()
{
	return s_MaxTextureHeight;
}

int CGraphicDevice::Create (HWND hWnd, int iHres, int iVres, bool Windowed, int, int iReflashRate)
{
	int iRet = CREATE_OK;

	Destroy();

	ms_iWidth = iHres;
	ms_iHeight = iVres;

	ms_hWnd = hWnd;
	ms_hDC = GetDC (hWnd);

#ifdef DIRECTX9
	ms_lpd3d = nullptr;
	HRESULT hrEx = Direct3DCreate9Ex(D3D_SDK_VERSION, &ms_lpd3d);
#endif

	if (FAILED(hrEx) || !ms_lpd3d)
	{
		return CREATE_NO_DIRECTX;
	}

	if (!ms_kD3DDetector.Build (*ms_lpd3d, EL3D_ConfirmDevice))
	{
		return CREATE_ENUM;
	}

	#ifndef MEMORY_LEAK_FIX
	if (!ms_kD3DDetector.Find (800, 600, 32, true, &ms_iD3DModeInfo, &ms_iD3DDevInfo, &ms_iD3DAdapterInfo))
	{
		return CREATE_DETECT;
	}
	#endif
	std::string stDevList;
	auto fix23 = std::string(stDevList); //fix23
	ms_kD3DDetector.GetString (&fix23);

	D3D_CAdapterInfo* pkD3DAdapterInfo = ms_kD3DDetector.GetD3DAdapterInfop (ms_iD3DAdapterInfo);
	if (!pkD3DAdapterInfo)
	{
		Tracenf ("adapter %d is EMPTY", ms_iD3DAdapterInfo);
		return CREATE_DETECT;
	}
	
	D3D_SModeInfo* pkD3DModeInfo = pkD3DAdapterInfo->GetD3DModeInfop (ms_iD3DDevInfo, ms_iD3DModeInfo);
	if (!pkD3DModeInfo)
	{
		Tracenf ("device %d, mode %d is EMPTY", ms_iD3DDevInfo, ms_iD3DModeInfo);
		return CREATE_DETECT;
	}

#ifdef DIRECTX9
	D3DADAPTER_IDENTIFIER9& rkD3DAdapterId = pkD3DAdapterInfo->GetIdentifier();
#endif
	if (Windowed && strnicmp (rkD3DAdapterId.Driver, "3dfx", 4) == 0 && 22 == pkD3DAdapterInfo->GetDesktopD3DDisplayModer().Format)
	{
		return CREATE_FORMAT;
	}

	if (pkD3DModeInfo->m_dwD3DBehavior == D3DCREATE_SOFTWARE_VERTEXPROCESSING)
	{
		iRet |= CREATE_NO_TNL;
	}

	std::string stModeInfo;
	auto fix24 = std::string(stModeInfo); //fix24
	pkD3DModeInfo->GetString (&fix24);

	int ErrorCorrection = 0;

RETRY:
	ZeroMemory (&ms_d3dPresentParameter, sizeof (ms_d3dPresentParameter));

	ms_d3dPresentParameter.Windowed = Windowed;
	ms_d3dPresentParameter.BackBufferWidth = iHres;
	ms_d3dPresentParameter.BackBufferHeight = iVres;
	ms_d3dPresentParameter.hDeviceWindow = hWnd;
	ms_d3dPresentParameter.BackBufferCount = m_uBackBufferCount;
	ms_d3dPresentParameter.SwapEffect = D3DSWAPEFFECT_DISCARD;

	if (Windowed)
	{
		ms_d3dPresentParameter.BackBufferFormat = pkD3DAdapterInfo->GetDesktopD3DDisplayModer().Format;
	}
	else
	{
		ms_d3dPresentParameter.BackBufferFormat = pkD3DModeInfo->m_eD3DFmtPixel;
		ms_d3dPresentParameter.FullScreen_RefreshRateInHz = iReflashRate;
	}

	ms_d3dPresentParameter.PresentationInterval = D3DPRESENT_INTERVAL_IMMEDIATE;

	ms_d3dPresentParameter.Flags = D3DPRESENTFLAG_LOCKABLE_BACKBUFFER;
	ms_d3dPresentParameter.EnableAutoDepthStencil = TRUE;
	ms_d3dPresentParameter.AutoDepthStencilFormat = pkD3DModeInfo->m_eD3DFmtDepthStencil;

	ms_dwD3DBehavior = pkD3DModeInfo->m_dwD3DBehavior;

	D3DDISPLAYMODEEX fmEx;
	ZeroMemory(&fmEx, sizeof(fmEx));
	if (!Windowed)
	{
		fmEx.Size = sizeof(D3DDISPLAYMODEEX);
		fmEx.Width = iHres;
		fmEx.Height = iVres;
		fmEx.RefreshRate = iReflashRate;
		fmEx.Format = pkD3DModeInfo->m_eD3DFmtPixel;
		fmEx.ScanLineOrdering = D3DSCANLINEORDERING_PROGRESSIVE;
	}

	if (FAILED(ms_hLastResult = ms_lpd3d->CreateDeviceEx(ms_iD3DAdapterInfo, D3DDEVTYPE_HAL, hWnd, pkD3DModeInfo->m_dwD3DBehavior, &ms_d3dPresentParameter, Windowed ? nullptr : &fmEx, &ms_lpd3dDevice)))
	{
		switch (ms_hLastResult)
		{
			case D3DERR_INVALIDCALL:
				Tracen ("IDirect3DDevice.CreateDeviceEx - ERROR D3DERR_INVALIDCALL\nThe method call is invalid. For example, a method's parameter may have an invalid value.");
				break;
			case D3DERR_NOTAVAILABLE:
				Tracen ("IDirect3DDevice.CreateDeviceEx - ERROR D3DERR_NOTAVAILABLE\nThis device does not support the queried technique. ");
				break;
			case D3DERR_OUTOFVIDEOMEMORY:
				Tracen ("IDirect3DDevice.CreateDeviceEx - ERROR D3DERR_OUTOFVIDEOMEMORY\nDirect3D does not have enough display memory to perform the operation");
				break;
			default:
				Tracenf ("IDirect3DDevice.CreateDeviceEx - ERROR %d", ms_hLastResult);
				break;
		}

		if (ErrorCorrection)
		{
			return CREATE_DEVICE;
		}
		iReflashRate = 0;
		++ErrorCorrection;
		iRet = CREATE_REFRESHRATE;
		goto RETRY;
	}

	if (FAILED ((ms_hLastResult = ms_lpd3dDevice->GetDeviceCaps (&ms_d3dCaps))))
	{
		Tracenf ("IDirect3DDevice.GetDeviceCaps - ERROR %d", ms_hLastResult);
		return CREATE_GET_DEVICE_CAPS2;
	}

	if (!Windowed)
	{
		SetWindowPos (hWnd, HWND_TOPMOST, 0, 0, iHres, iVres, SWP_SHOWWINDOW);
	}

	ms_lpd3dDevice->GetViewport (&ms_Viewport);

	m_pStateManager = new CStateManager (ms_lpd3dDevice);

	D3DXCreateMatrixStack (0, &ms_lpd3dMatStack);
	ms_lpd3dMatStack->LoadIdentity();

	D3DXMatrixIdentity (&ms_matIdentity);
	D3DXMatrixIdentity (&ms_matView);
	D3DXMatrixIdentity (&ms_matProj);
	D3DXMatrixIdentity (&ms_matInverseView);
	D3DXMatrixIdentity (&ms_matInverseViewYAxis);
	D3DXMatrixIdentity (&ms_matScreen0);
	D3DXMatrixIdentity (&ms_matScreen1);
	D3DXMatrixIdentity (&ms_matScreen2);

	ms_matScreen0._11 = 1.0f;
	ms_matScreen0._22 = -1.0f;

	ms_matScreen1._41 = 1.0f;
	ms_matScreen1._42 = 1.0f;

	ms_matScreen2._11 = (float) iHres / 2.0f;
	ms_matScreen2._22 = (float) iVres / 2.0f;

	D3DXCreateSphere (ms_lpd3dDevice, 1.0f, 32, 32, &ms_lpSphereMesh, NULL);
	D3DXCreateCylinder (ms_lpd3dDevice, 1.0f, 1.0f, 1.0f, 8, 8, &ms_lpCylinderMesh, NULL);

	ms_lpd3dDevice->Clear (0L, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, 0xff000000, 1.0f, 0);

	if (!__CreateDefaultIndexBufferList())
	{
		return false;
	}

	if (!__CreatePDTVertexBufferList())
	{
		return false;
	}

	return (iRet);
}

void CGraphicDevice::__InitializePDTVertexBufferList()
{
	for (unsigned int i = 0; i < PDT_VERTEXBUFFER_NUM; ++i)
	{
		ms_alpd3dPDTVB[i] = NULL;
	}
}

void CGraphicDevice::__DestroyPDTVertexBufferList()
{
	for (unsigned int i = 0; i < PDT_VERTEXBUFFER_NUM; ++i)
	{
		if (ms_alpd3dPDTVB[i])
		{
			ms_alpd3dPDTVB[i]->Release();
			ms_alpd3dPDTVB[i] = NULL;
		}
	}
}

bool CGraphicDevice::__CreatePDTVertexBufferList()
{
	for (unsigned int i = 0; i < PDT_VERTEXBUFFER_NUM; ++i)
	{
		#ifdef DIRECTX9
		if (FAILED (ms_lpd3dDevice->CreateVertexBuffer (sizeof (TPDTVertex)*PDT_VERTEX_NUM, D3DUSAGE_DYNAMIC | D3DUSAGE_WRITEONLY, D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1, D3DPOOL_SYSTEMMEM, &ms_alpd3dPDTVB[i], NULL)))
		#endif
		{
			return false;
		}
	}
	return true;
}

void CGraphicDevice::__InitializeDefaultIndexBufferList()
{
	for (unsigned int i = 0; i < DEFAULT_IB_NUM; ++i)
	{
		ms_alpd3dDefIB[i] = NULL;
	}
}

void CGraphicDevice::__DestroyDefaultIndexBufferList()
{
	for (unsigned int i = 0; i < DEFAULT_IB_NUM; ++i)
	{
		if (ms_alpd3dDefIB[i])
		{
			ms_alpd3dDefIB[i]->Release();
			ms_alpd3dDefIB[i] = NULL;
		}
	}
}

bool CGraphicDevice::__CreateDefaultIndexBuffer (unsigned int eDefIB, unsigned int uIdxCount, const WORD* c_awIndices)
{
	assert (ms_alpd3dDefIB[eDefIB] == NULL);

	#ifdef DIRECTX9
	if (FAILED (ms_lpd3dDevice->CreateIndexBuffer (sizeof (WORD)*uIdxCount, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &ms_alpd3dDefIB[eDefIB], NULL)))
	#endif
	{
		return false;
	}

	WORD* dstIndices;

#ifdef DIRECTX9
	if (FAILED(
		ms_alpd3dDefIB[eDefIB]->Lock(0, 0, (void**)&dstIndices, 0)
	)) return false;
#endif

	memcpy (dstIndices, c_awIndices, sizeof (WORD) * uIdxCount);

	ms_alpd3dDefIB[eDefIB]->Unlock();

	return true;
}

bool CGraphicDevice::__CreateDefaultIndexBufferList()
{
	static const WORD c_awLineIndices[2] =
	{
		0, 1,
	};
	static const WORD c_awLineTriIndices[6] =
	{
		0, 1, 0, 2, 1, 2,
	};
	static const WORD c_awLineRectIndices[8] =
	{
		0, 1, 0, 2, 1, 3, 2, 3,
	};
	static const WORD c_awLineCubeIndices[24] =
	{
		0, 1, 0, 2, 1, 3, 2, 3,
		0, 4, 1, 5, 2, 6, 3, 7,
		4, 5, 4, 6, 5, 7, 6, 7,
	};
	static const WORD c_awFillTriIndices[3] =
	{
		0, 1, 2,
	};
	static const WORD c_awFillRectIndices[6] =
	{
		0, 2, 1, 2, 3, 1,
	};
	static const WORD c_awFillCubeIndices[36] =
	{
		0, 1, 2, 1, 3, 2,
		2, 0, 6, 0, 4, 6,
		0, 1, 4, 1, 5, 4,
		1, 3, 5, 3, 7, 5,
		3, 2, 7, 2, 6, 7,
		4, 5, 6, 5, 7, 6,
	};

	if (!__CreateDefaultIndexBuffer (DEFAULT_IB_LINE, 2, c_awLineIndices))
	{
		return false;
	}
	if (!__CreateDefaultIndexBuffer (DEFAULT_IB_LINE_TRI, 6, c_awLineTriIndices))
	{
		return false;
	}
	if (!__CreateDefaultIndexBuffer (DEFAULT_IB_LINE_RECT, 8, c_awLineRectIndices))
	{
		return false;
	}
	if (!__CreateDefaultIndexBuffer (DEFAULT_IB_LINE_CUBE, 24, c_awLineCubeIndices))
	{
		return false;
	}
	if (!__CreateDefaultIndexBuffer (DEFAULT_IB_FILL_TRI, 3, c_awFillTriIndices))
	{
		return false;
	}
	if (!__CreateDefaultIndexBuffer (DEFAULT_IB_FILL_RECT, 6, c_awFillRectIndices))
	{
		return false;
	}
	if (!__CreateDefaultIndexBuffer (DEFAULT_IB_FILL_CUBE, 36, c_awFillCubeIndices))
	{
		return false;
	}

	return true;
}

void CGraphicDevice::InitBackBufferCount (unsigned int uBackBufferCount)
{
	m_uBackBufferCount = uBackBufferCount;
}

void CGraphicDevice::Destroy()
{
	__DestroyPDTVertexBufferList();
	__DestroyDefaultIndexBufferList();

	if (ms_hDC)
	{
		ReleaseDC (ms_hWnd, ms_hDC);
		ms_hDC = NULL;
	}

	safe_release (ms_lpSphereMesh);
	safe_release (ms_lpCylinderMesh);

	safe_release (ms_lpd3dMatStack);
	safe_release (ms_lpd3dDevice);
	safe_release (ms_lpd3d);

	if (m_pStateManager)
	{
		delete m_pStateManager;
		#ifdef FIX_BLACK_SCREEN
		m_pStateManager = nullptr;
		#else
		m_pStateManager = NULL;
		#endif
	}

	__Initialize();
}


