#pragma once
#include "../DirectUpgrade.h"
#ifdef DIRECTX9
#include <directx/d3d9/d3d9.h>
#include <directx/d3d9/d3dx9.h>
#endif

#include <vector>

#include "../eterbase/Singleton.h"
#define STATEMANAGER (CStateManager::Instance())

static const DWORD STATEMANAGER_MAX_RENDERSTATES = 256;
static const DWORD STATEMANAGER_MAX_TEXTURESTATES = 128;
static const DWORD STATEMANAGER_MAX_STAGES = 8;
static const DWORD STATEMANAGER_MAX_VCONSTANTS = 96;
static const DWORD STATEMANAGER_MAX_PCONSTANTS = 8;
static const DWORD STATEMANAGER_MAX_TRANSFORMSTATES = 300;
static const DWORD STATEMANAGER_MAX_STREAMS = 16;

class CStreamData
{
	public:
#ifdef DIRECTX9
		CStreamData (LPDIRECT3DVERTEXBUFFER9 pStreamData = NULL, unsigned int Stride = 0): m_lpStreamData (pStreamData), m_Stride (Stride)
		{
		}
#endif

		bool operator == (const CStreamData& rhs) const
		{
			return ((m_lpStreamData == rhs.m_lpStreamData) && (m_Stride == rhs.m_Stride));
		}

#ifdef DIRECTX9
		LPDIRECT3DVERTEXBUFFER9 m_lpStreamData;
#endif
		unsigned int m_Stride;
};

class CIndexData
{
	public:
#ifdef DIRECTX9
		CIndexData (LPDIRECT3DINDEXBUFFER9 pIndexData = NULL, unsigned int BaseVertexIndex = 0): m_lpIndexData (pIndexData), m_BaseVertexIndex (BaseVertexIndex) {};
#endif

		bool operator == (const CIndexData& rhs) const
		{
			return ((m_lpIndexData == rhs.m_lpIndexData) && (m_BaseVertexIndex == rhs.m_BaseVertexIndex));
		}

#ifdef DIRECTX9
		LPDIRECT3DINDEXBUFFER9 m_lpIndexData;
#endif
		unsigned int m_BaseVertexIndex;
};

class CStateManagerState
{
	public:
		CStateManagerState() = default;

		void ResetState()
		{
			DWORD i, y;

			for (i = 0; i < STATEMANAGER_MAX_RENDERSTATES; i++)
			{
				m_RenderStates[i] = 0x7FFFFFFF;
			}

			for (i = 0; i < STATEMANAGER_MAX_STAGES; i++)
			{
				for (y = 0; y < STATEMANAGER_MAX_TEXTURESTATES; y++)
				{
					m_TextureStates[i][y] = 0x7FFFFFFF;
				}
			}

			for (i = 0; i < STATEMANAGER_MAX_STREAMS; i++)
			{
				m_StreamData[i] = CStreamData();
			}

			m_IndexData = CIndexData();

			for (i = 0; i < STATEMANAGER_MAX_STAGES; i++)
			{
				m_Textures[i] = NULL;
			}

			for (i = 0; i < STATEMANAGER_MAX_TRANSFORMSTATES; i++)
			{
				D3DXMatrixIdentity (&m_Matrices[i]);
			}

			for (i = 0; i < STATEMANAGER_MAX_VCONSTANTS; i++)
			{
				m_VertexShaderConstants[i] = D3DXVECTOR4 (0.0f, 0.0f, 0.0f, 0.0f);
			}
#ifdef DIRECTX9
			m_dwVertexShader = 0;
#endif

			ZeroMemory (&m_Matrices, sizeof (D3DXMATRIX) * STATEMANAGER_MAX_TRANSFORMSTATES);
		}

		DWORD					m_RenderStates[STATEMANAGER_MAX_RENDERSTATES];
		DWORD					m_TextureStates[STATEMANAGER_MAX_STAGES][STATEMANAGER_MAX_TEXTURESTATES];
#ifdef DIRECTX9
		DWORD m_SamplerStates[STATEMANAGER_MAX_STAGES][STATEMANAGER_MAX_TEXTURESTATES];
#endif
		D3DXVECTOR4				m_VertexShaderConstants[STATEMANAGER_MAX_VCONSTANTS];
#ifdef DIRECTX9
		LPDIRECT3DBASETEXTURE9 m_Textures[STATEMANAGER_MAX_STAGES];
#endif

		DWORD					m_dwVertexShader;
		D3DXMATRIX				m_Matrices[STATEMANAGER_MAX_TRANSFORMSTATES];
#ifdef DIRECTX9
		D3DMATERIAL9 m_D3DMaterial;
#endif
		CStreamData				m_StreamData[STATEMANAGER_MAX_STREAMS];
		CIndexData				m_IndexData;
};

class CStateManager : public CSingleton<CStateManager>
{
	public:
#ifdef DIRECTX9
		CStateManager (LPDIRECT3DDEVICE9EX lpDevice);
#endif
		virtual ~CStateManager();
		void	SetDefaultState();
		bool	BeginScene();
		void	EndScene();
		void	SaveMaterial();
#ifdef DIRECTX9
		void SaveMaterial (const D3DMATERIAL9* pMaterial);
		void SetMaterial (const D3DMATERIAL9* pMaterial);
		void GetMaterial (D3DMATERIAL9* pMaterial);
#endif

#ifdef DIRECTX9
		void SetLight (DWORD index, CONST D3DLIGHT9* pLight);
		void GetLight (DWORD index, D3DLIGHT9* pLight);
#endif

		void	SaveRenderState (D3DRENDERSTATETYPE Type, DWORD dwValue);
		void	RestoreRenderState (D3DRENDERSTATETYPE Type);
		void	SetRenderState (D3DRENDERSTATETYPE Type, DWORD Value);
		void	GetRenderState (D3DRENDERSTATETYPE Type, DWORD* pdwValue);

#ifdef DIRECTX9
		void SetTexture (DWORD dwStage, LPDIRECT3DBASETEXTURE9 pTexture);
		void GetTexture (DWORD dwStage, LPDIRECT3DBASETEXTURE9* ppTexture);
#endif
		void	SaveTextureStageState (DWORD dwStage, D3DTEXTURESTAGESTATETYPE Type, DWORD dwValue);
		void	RestoreTextureStageState (DWORD dwStage, D3DTEXTURESTAGESTATETYPE Type);
		void	SetTextureStageState (DWORD dwStage, D3DTEXTURESTAGESTATETYPE Type, DWORD dwValue);
		void	GetTextureStageState (DWORD dwStage, D3DTEXTURESTAGESTATETYPE Type, DWORD* pdwValue);
		void	SetBestFiltering (DWORD dwStage);

		#ifdef DIRECTX9
		void SaveSamplerState (DWORD dwStage, D3DSAMPLERSTATETYPE Type, DWORD dwValue);
		void RestoreSamplerState (DWORD dwStage, D3DSAMPLERSTATETYPE Type);
		void SetSamplerState (DWORD dwStage, D3DSAMPLERSTATETYPE Type, DWORD dwValue);
		#endif
		void	RestoreVertexShader();
		void SaveVertexShader (DWORD dwShader);
		void	SetVertexShader (DWORD dwShader);
		void	GetVertexShader (DWORD* pdwShader);
		void SaveTransform (D3DTRANSFORMSTATETYPE Transform, const D3DMATRIX* pMatrix);
		void RestoreTransform (D3DTRANSFORMSTATETYPE Transform);
		void SetTransform (D3DTRANSFORMSTATETYPE Type, const D3DMATRIX* pMatrix);
		void GetTransform (D3DTRANSFORMSTATETYPE Type, D3DMATRIX* pMatrix);

		void SetVertexShaderConstant (DWORD dwRegister, CONST void* pConstantData, DWORD dwConstantCount);

		// diagnostics
		LPDIRECT3DDEVICE9EX GetDevice() { return m_lpD3DDev; }

#ifdef DIRECTX9
		void SetStreamSource (unsigned int StreamNumber, LPDIRECT3DVERTEXBUFFER9 pStreamData, unsigned int Stride);
		void SetIndices (LPDIRECT3DINDEXBUFFER9 pIndexData, unsigned int BaseVertexIndex);
#endif
		HRESULT DrawPrimitive (D3DPRIMITIVETYPE PrimitiveType, unsigned int StartVertex, unsigned int PrimitiveCount);
		HRESULT DrawPrimitiveUP (D3DPRIMITIVETYPE PrimitiveType, unsigned int PrimitiveCount, const void* pVertexStreamZeroData, unsigned int VertexStreamZeroStride);
		#ifdef DIRECTX9
		HRESULT DrawIndexedPrimitive (D3DPRIMITIVETYPE PrimitiveType, int BaseVertexIndex, unsigned int minIndex, unsigned int NumVertices, unsigned int startIndex, unsigned int primCount);
		#endif
		HRESULT DrawIndexedPrimitiveUP (D3DPRIMITIVETYPE PrimitiveType, unsigned int MinVertexIndex, unsigned int NumVertexIndices, unsigned int PrimitiveCount, CONST void* pIndexData, D3DFORMAT IndexDataFormat, CONST void* pVertexStreamZeroData, unsigned int VertexStreamZeroStride);
		DWORD GetRenderState (D3DRENDERSTATETYPE Type);

	private:
#ifdef DIRECTX9
		void SetDevice (LPDIRECT3DDEVICE9EX lpDevice);
#endif

	private:
		CStateManagerState	m_ChipState;
		CStateManagerState	m_CurrentState;
		CStateManagerState	m_CopyState;
		bool				m_bForce;
		bool				m_bScene;
		DWORD				m_dwBestMinFilter;
		DWORD				m_dwBestMagFilter;
#ifdef DIRECTX9
		LPDIRECT3DDEVICE9EX m_lpD3DDev;
#endif

		#ifdef _DEBUG
		BOOL				m_bRenderStateSavingFlag[STATEMANAGER_MAX_RENDERSTATES];
		BOOL				m_bTextureStageStateSavingFlag[STATEMANAGER_MAX_STAGES][STATEMANAGER_MAX_TEXTURESTATES];
		#ifdef DIRECTX9
		BOOL				m_bSamplerStateSavingFlag[STATEMANAGER_MAX_STAGES][STATEMANAGER_MAX_TEXTURESTATES];
		#endif
		BOOL				m_bTransformSavingFlag[STATEMANAGER_MAX_TRANSFORMSTATES];
		#endif
};

