#include "StdAfx.h"
#include "TextBar.h"
#include "../eterlib/Util.h"

void CTextBar::__SetFont (int fontSize, bool isBold)
{
	int iCodePage = GetDefaultCodePage();

	LOGFONT logFont;

	memset (&logFont, 0, sizeof (LOGFONT));

	logFont.lfHeight = fontSize;
	logFont.lfEscapement = 0;
	logFont.lfOrientation = 0;

	if (isBold)
	{
		logFont.lfWeight = FW_BOLD;
	}
	else
	{
		logFont.lfWeight = FW_NORMAL;
	}

	logFont.lfItalic = FALSE;
	logFont.lfUnderline = FALSE;
	logFont.lfStrikeOut = FALSE;
	logFont.lfCharSet = DEFAULT_CHARSET;
	logFont.lfOutPrecision = OUT_DEFAULT_PRECIS;
	logFont.lfClipPrecision = CLIP_DEFAULT_PRECIS;
	logFont.lfQuality = ANTIALIASED_QUALITY;
	logFont.lfPitchAndFamily = DEFAULT_PITCH;
	strcpy (logFont.lfFaceName, GetFontFaceFromCodePage (iCodePage));
	m_hFont = CreateFontIndirect (&logFont);


	HDC hdc = m_dib.GetDCHandle();
	m_hOldFont = (HFONT)SelectObject (hdc, m_hFont);

}

void CTextBar::SetTextColor (int r, int g, int b)
{
	HDC hDC = m_dib.GetDCHandle();
	::SetTextColor (hDC, RGB (r, g, b));
}

void CTextBar::GetTextExtent (const char* c_szText, SIZE* p_size)
{
	HDC hDC = m_dib.GetDCHandle();
	GetTextExtentPoint32 (hDC, c_szText, strlen (c_szText), p_size);
}

void CTextBar::TextOut (int ix, int iy, const char* c_szText)
{
	c_szText = Hyperlink (c_szText);
	m_dib.TextOut (ix, iy, c_szText);
	Invalidate();
}

const char* CTextBar::Hyperlink (const char* c_szText)
{
	std::string str1c = c_szText;
	std::string find_s1c = "|c";
	std::size_t find_z1c = 0;
	std::size_t pos1c = 0;
	for (int i = 0; i < str1c.length(); i++)
	{
		find_z1c = str1c.find (find_s1c, i);
		if (find_z1c != std::string::npos)
		{
			pos1c = find_z1c + find_s1c.length();
			i = find_z1c + find_s1c.length();
			std::string stHyperlink = str1c.substr (pos1c, str1c.length() - pos1c);

			str1c = str1c.replace (str1c.find (stHyperlink), 8, "");
			c_szText = str1c.c_str();
		}
	}

	std::string str2c = c_szText;
	std::string find_s2c = "|c";
	std::size_t find_z2c = 0;
	for (int i = 0; i < str2c.length(); i++)
	{
		find_z2c = str2c.find (find_s2c, i);
		if (find_z2c != std::string::npos)
		{
			str2c = str2c.replace (str2c.find (find_s2c), find_s2c.length(), "");
			c_szText = str2c.c_str();
		}
	}

	std::string str1r = c_szText;
	std::string find_s1r = "|r";
	std::size_t find_z1r = 0;
	for (int i = 0; i < str1r.length(); i++)
	{
		find_z1r = str1r.find (find_s1r, i);
		if (find_z1r != std::string::npos)
		{
			str1r = str1r.replace (str1r.find (find_s1r), find_s1r.length(), "");
			c_szText = str1r.c_str();
		}
	}

	std::string str1h = c_szText;
	std::string find_s1h = "|H";
	std::size_t find_z1h = 0;
	std::size_t pos1h = 0;
	for (int i = 0; i < str1h.length(); i++)
	{
		find_z1h = str1h.find (find_s1h, i);
		if (find_z1h != std::string::npos)
		{
			pos1h = find_z1h + find_s1h.length();
			i = find_z1h + find_s1h.length();
			std::string stHyperlink = str1h.substr (pos1h, str1h.length() - pos1h);

			std::size_t pos_2 = stHyperlink.find ("|h[");
			std::string item_name = stHyperlink.substr (0, pos_2);

			str1h = str1h.replace (str1h.find (item_name), item_name.length(), "");
			c_szText = str1h.c_str();
		}
	}

	std::string str2h = c_szText;
	std::string find_s2h = "|H";
	std::size_t find_z2h = 0;
	for (int i = 0; i < str2h.length(); i++)
	{
		find_z2h = str2h.find (find_s2h, i);
		if (find_z2h != std::string::npos)
		{
			str2h = str2h.replace (str2h.find (find_s2h), find_s2h.length(), "");
			c_szText = str2h.c_str();
		}
	}

	std::string str3h = c_szText;
	std::string find_s3h = "|h";
	std::size_t find_z3h = 0;
	for (int i = 0; i < str3h.length(); i++)
	{
		find_z3h = str3h.find (find_s3h, i);
		if (find_z3h != std::string::npos)
		{
			str3h = str3h.replace (str3h.find (find_s3h), find_s3h.length(), "");
			c_szText = str3h.c_str();
		}
	}

	return c_szText;
}

void CTextBar::OnCreate()
{
	m_dib.SetBkMode (TRANSPARENT);

	__SetFont (m_fontSize, m_isBold);
}

CTextBar::CTextBar (int fontSize, bool isBold)
{
	m_hOldFont = NULL;
	m_fontSize = fontSize;
	m_isBold = isBold;
}

CTextBar::~CTextBar()
{
	HDC hdc = m_dib.GetDCHandle();
	SelectObject (hdc, m_hOldFont);
}

