#include "StdAfx.h"
#include "StateManager.h"
#include "../eterbase/CrashHandler.h"
#include <windows.h>
#include <sstream>
#define StateManager_Assert(a) assert(a)

struct SLightData
{
	enum ELightNum
	{
		LIGHT_NUM = 8,
	};
#ifdef DIRECTX9
	D3DLIGHT9 m_akD3DLight[LIGHT_NUM];
#endif
} m_kLightData;

#ifdef DIRECTX9
void CStateManager::SetLight (DWORD index, CONST D3DLIGHT9* pLight)
#endif
{
	assert (index < SLightData::LIGHT_NUM);
	m_kLightData.m_akD3DLight[index] = *pLight;
	if (m_lpD3DDev)
	{
		m_lpD3DDev->SetLight (index, pLight);
	}
}

#ifdef DIRECTX9
void CStateManager::GetLight (DWORD index, D3DLIGHT9* pLight)
#endif
{
	assert (index < 8);
	*pLight = m_kLightData.m_akD3DLight[index];
}

bool CStateManager::BeginScene()
{
    m_bScene = true;

	D3DXMATRIX m4Proj;
	D3DXMATRIX m4View;
	D3DXMATRIX m4World;
	GetTransform (D3DTS_WORLD, &m4World);
	GetTransform (D3DTS_PROJECTION, &m4Proj);
	GetTransform (D3DTS_VIEW, &m4View);
	SetTransform (D3DTS_WORLD, &m4World);
	SetTransform (D3DTS_PROJECTION, &m4Proj);
	SetTransform (D3DTS_VIEW, &m4View);

	if (!m_lpD3DDev)
	{
		return false;
	}

	if (FAILED (m_lpD3DDev->BeginScene()))
	{
		return false;
	}

	return true;
}

void CStateManager::EndScene()
{
    if (m_lpD3DDev)
	{
		m_lpD3DDev->EndScene();
	}
	m_bScene = false;
}

#ifdef DIRECTX9
CStateManager::CStateManager (LPDIRECT3DDEVICE9EX lpDevice): m_lpD3DDev (NULL)
#endif
{
	m_bScene = false;
	m_dwBestMinFilter = D3DTEXF_LINEAR;
	m_dwBestMagFilter = D3DTEXF_LINEAR;
	SetDevice (lpDevice);
}

CStateManager::~CStateManager()
{
	if (m_lpD3DDev)
	{
		m_lpD3DDev->Release();
		m_lpD3DDev = NULL;
	}
}

#ifdef DIRECTX9
void CStateManager::SetDevice (LPDIRECT3DDEVICE9EX lpDevice)
#endif
{
    // Log device change
	{
		char buf[256];
		sprintf_s(buf, "CStateManager::SetDevice called. newDevice=%p oldDevice=%p", lpDevice, m_lpD3DDev);
		WriteSystemLog(buf);
	}

	if (lpDevice)
	{
		lpDevice->AddRef();
	}

	if (m_lpD3DDev)
	{
		m_lpD3DDev->Release();
		m_lpD3DDev = NULL;
	}

	m_lpD3DDev = lpDevice;

	// Capture stack backtrace to help identify who called SetDevice
	{
		const int MAX_FRAMES = 62;
		void* stack[MAX_FRAMES];
		USHORT frames = CaptureStackBackTrace(0, MAX_FRAMES, stack, NULL);

		std::ostringstream ss;
		ss << "CStateManager::SetDevice stacktrace frames=" << frames << " newDevice=" << lpDevice << " oldDevice=" << m_lpD3DDev << "\n";
		for (USHORT i = 0; i < frames; ++i)
		{
			ss << "  [" << i << "] " << stack[i] << "\n";
		}
		std::string s = ss.str();
		WriteSystemLog(s.c_str());
	}

#ifdef DIRECTX9
	D3DCAPS9 d3dCaps;
#endif

    if (m_lpD3DDev)
	{
		m_lpD3DDev->GetDeviceCaps (&d3dCaps);
	}

	if (d3dCaps.TextureFilterCaps & D3DPTFILTERCAPS_MAGFANISOTROPIC)
	{
		m_dwBestMagFilter = D3DTEXF_ANISOTROPIC;
	}
	else
	{
		m_dwBestMagFilter = D3DTEXF_LINEAR;
	}

	if (d3dCaps.TextureFilterCaps & D3DPTFILTERCAPS_MINFANISOTROPIC)
	{
		m_dwBestMinFilter = D3DTEXF_ANISOTROPIC;
	}
	else
	{
		m_dwBestMinFilter = D3DTEXF_LINEAR;
	}

	DWORD dwMax = d3dCaps.MaxAnisotropy;
	dwMax = dwMax < 4 ? dwMax : 4;

	for (int i = 0; i < 8; ++i)
	{
		#ifdef DIRECTX9
        if (m_lpD3DDev)
		{
			m_lpD3DDev->SetSamplerState (i, D3DSAMP_MAXANISOTROPY, dwMax);
		}
		#endif
	}

	SetDefaultState();
}

void CStateManager::SetBestFiltering (DWORD dwStage)
{
	#ifdef DIRECTX9
	SetSamplerState (dwStage, D3DSAMP_MINFILTER, m_dwBestMinFilter);
	SetSamplerState (dwStage, D3DSAMP_MAGFILTER, m_dwBestMagFilter);
	SetSamplerState (dwStage, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	#endif
}

void CStateManager::SetDefaultState()
{
	m_CurrentState.ResetState();
	m_CopyState.ResetState();
	m_ChipState.ResetState();

	m_bScene = false;
	m_bForce = true;

	D3DXMATRIX Identity;
	D3DXMatrixIdentity (&Identity);

	SetTransform (D3DTS_WORLD, &Identity);
	SetTransform (D3DTS_VIEW, &Identity);
	SetTransform (D3DTS_PROJECTION, &Identity);

#ifdef DIRECTX9
	D3DMATERIAL9 DefaultMat;
	ZeroMemory (&DefaultMat, sizeof (D3DMATERIAL9));
#endif

	DefaultMat.Diffuse.r = 1.0f;
	DefaultMat.Diffuse.g = 1.0f;
	DefaultMat.Diffuse.b = 1.0f;
	DefaultMat.Diffuse.a = 1.0f;
	DefaultMat.Ambient.r = 1.0f;
	DefaultMat.Ambient.g = 1.0f;
	DefaultMat.Ambient.b = 1.0f;
	DefaultMat.Ambient.a = 1.0f;
	DefaultMat.Emissive.r = 0.0f;
	DefaultMat.Emissive.g = 0.0f;
	DefaultMat.Emissive.b = 0.0f;
	DefaultMat.Emissive.a = 0.0f;
	DefaultMat.Specular.r = 0.0f;
	DefaultMat.Specular.g = 0.0f;
	DefaultMat.Specular.b = 0.0f;
	DefaultMat.Specular.a = 0.0f;
	DefaultMat.Power = 0.0f;

	SetMaterial (&DefaultMat);

	SetRenderState (D3DRS_DIFFUSEMATERIALSOURCE, D3DMCS_MATERIAL);
	SetRenderState (D3DRS_SPECULARMATERIALSOURCE, D3DMCS_MATERIAL);
	SetRenderState (D3DRS_AMBIENTMATERIALSOURCE, D3DMCS_MATERIAL);
	SetRenderState (D3DRS_EMISSIVEMATERIALSOURCE, D3DMCS_MATERIAL);

	#ifndef DIRECTX9
	SetRenderState (D3DRS_LINEPATTERN, 0xFFFFFFFF);
	SetRenderState (D3DRS_ZVISIBLE, FALSE);
	SetRenderState (D3DRS_EDGEANTIALIAS, FALSE);
	SetRenderState (D3DRS_ZBIAS, 0);
	SetRenderState (D3DRS_SOFTWAREVERTEXPROCESSING, FALSE);
	#endif

	SetRenderState (D3DRS_LASTPIXEL, FALSE);
	SetRenderState (D3DRS_ALPHAREF, 1);
	SetRenderState (D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
	SetRenderState (D3DRS_FOGSTART, 0);
	SetRenderState (D3DRS_FOGEND, 0);
	SetRenderState (D3DRS_FOGDENSITY, 0);
	SetRenderState (D3DRS_STENCILWRITEMASK, 0xFFFFFFFF);
	SetRenderState (D3DRS_AMBIENT, 0x00000000);
	SetRenderState (D3DRS_LOCALVIEWER, FALSE);
	SetRenderState (D3DRS_NORMALIZENORMALS, FALSE);
	SetRenderState (D3DRS_VERTEXBLEND, D3DVBF_DISABLE);
	SetRenderState (D3DRS_CLIPPLANEENABLE, 0);
	SetRenderState (D3DRS_MULTISAMPLEANTIALIAS, FALSE);
	SetRenderState (D3DRS_MULTISAMPLEMASK, 0xFFFFFFFF);
	SetRenderState (D3DRS_INDEXEDVERTEXBLENDENABLE, FALSE);
	SetRenderState (D3DRS_COLORWRITEENABLE, 0xFFFFFFFF);
	SetRenderState (D3DRS_FILLMODE, D3DFILL_SOLID);
	SetRenderState (D3DRS_SHADEMODE, D3DSHADE_GOURAUD);
	SetRenderState (D3DRS_CULLMODE, D3DCULL_CW);
	SetRenderState (D3DRS_ALPHABLENDENABLE, FALSE);
	SetRenderState (D3DRS_BLENDOP, D3DBLENDOP_ADD);
	SetRenderState (D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	SetRenderState (D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	SetRenderState (D3DRS_FOGENABLE, FALSE);
	SetRenderState (D3DRS_FOGCOLOR, 0xFF000000);
	SetRenderState (D3DRS_FOGTABLEMODE, D3DFOG_NONE);
	SetRenderState (D3DRS_FOGVERTEXMODE, D3DFOG_LINEAR);
	SetRenderState (D3DRS_RANGEFOGENABLE, FALSE);
	SetRenderState (D3DRS_ZENABLE, TRUE);
	SetRenderState (D3DRS_ZFUNC, D3DCMP_LESSEQUAL);
	SetRenderState (D3DRS_ZWRITEENABLE, TRUE);
	SetRenderState (D3DRS_DITHERENABLE, TRUE);
	SetRenderState (D3DRS_STENCILENABLE, FALSE);
	SetRenderState (D3DRS_ALPHATESTENABLE, FALSE);
	SetRenderState (D3DRS_CLIPPING, TRUE);
	SetRenderState (D3DRS_LIGHTING, FALSE);
	SetRenderState (D3DRS_SPECULARENABLE, FALSE);
	SetRenderState (D3DRS_COLORVERTEX, FALSE);
	SetRenderState (D3DRS_WRAP0, 0);
	SetRenderState (D3DRS_WRAP1, 0);
	SetRenderState (D3DRS_WRAP2, 0);
	SetRenderState (D3DRS_WRAP3, 0);
	SetRenderState (D3DRS_WRAP4, 0);
	SetRenderState (D3DRS_WRAP5, 0);
	SetRenderState (D3DRS_WRAP6, 0);
	SetRenderState (D3DRS_WRAP7, 0);

	SetTextureStageState (0, D3DTSS_COLOROP, D3DTOP_MODULATE);
	SetTextureStageState (0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	SetTextureStageState (0, D3DTSS_COLORARG2, D3DTA_CURRENT);
	SetTextureStageState (0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	SetTextureStageState (0, D3DTSS_ALPHAARG2, D3DTA_CURRENT);
	SetTextureStageState (0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);

	SetTextureStageState (1, D3DTSS_COLOROP, D3DTOP_DISABLE);
	SetTextureStageState (1, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	SetTextureStageState (1, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	SetTextureStageState (1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	SetTextureStageState (1, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	SetTextureStageState (1, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	SetTextureStageState (2, D3DTSS_COLOROP, D3DTOP_DISABLE);
	SetTextureStageState (2, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	SetTextureStageState (2, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	SetTextureStageState (2, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	SetTextureStageState (2, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	SetTextureStageState (2, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	SetTextureStageState (3, D3DTSS_COLOROP, D3DTOP_DISABLE);
	SetTextureStageState (3, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	SetTextureStageState (3, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	SetTextureStageState (3, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	SetTextureStageState (3, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	SetTextureStageState (3, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	SetTextureStageState (4, D3DTSS_COLOROP, D3DTOP_DISABLE);
	SetTextureStageState (4, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	SetTextureStageState (4, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	SetTextureStageState (4, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	SetTextureStageState (4, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	SetTextureStageState (4, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	SetTextureStageState (5, D3DTSS_COLOROP, D3DTOP_DISABLE);
	SetTextureStageState (5, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	SetTextureStageState (5, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	SetTextureStageState (5, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	SetTextureStageState (5, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	SetTextureStageState (5, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	SetTextureStageState (6, D3DTSS_COLOROP, D3DTOP_DISABLE);
	SetTextureStageState (6, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	SetTextureStageState (6, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	SetTextureStageState (6, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	SetTextureStageState (6, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	SetTextureStageState (6, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	SetTextureStageState (7, D3DTSS_COLOROP, D3DTOP_DISABLE);
	SetTextureStageState (7, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	SetTextureStageState (7, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	SetTextureStageState (7, D3DTSS_ALPHAOP, D3DTOP_DISABLE);
	SetTextureStageState (7, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	SetTextureStageState (7, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);

	SetTextureStageState (0, D3DTSS_TEXCOORDINDEX, 0);
	SetTextureStageState (1, D3DTSS_TEXCOORDINDEX, 1);
	SetTextureStageState (2, D3DTSS_TEXCOORDINDEX, 2);
	SetTextureStageState (3, D3DTSS_TEXCOORDINDEX, 3);
	SetTextureStageState (4, D3DTSS_TEXCOORDINDEX, 4);
	SetTextureStageState (5, D3DTSS_TEXCOORDINDEX, 5);
	SetTextureStageState (6, D3DTSS_TEXCOORDINDEX, 6);
	SetTextureStageState (7, D3DTSS_TEXCOORDINDEX, 7);

	#ifdef DIRECTX9
	SetSamplerState (0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	SetSamplerState (0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	SetSamplerState (0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	SetSamplerState (1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	SetSamplerState (1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	SetSamplerState (1, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	SetSamplerState (2, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	SetSamplerState (2, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	SetSamplerState (2, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	SetSamplerState (3, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	SetSamplerState (3, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	SetSamplerState (3, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	SetSamplerState (4, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	SetSamplerState (4, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	SetSamplerState (4, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	SetSamplerState (5, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	SetSamplerState (5, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	SetSamplerState (5, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	SetSamplerState (6, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	SetSamplerState (6, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	SetSamplerState (6, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	SetSamplerState (7, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	SetSamplerState (7, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	SetSamplerState (7, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	SetSamplerState (0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	SetSamplerState (0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	SetSamplerState (1, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	SetSamplerState (1, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	SetSamplerState (2, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	SetSamplerState (2, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	SetSamplerState (3, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	SetSamplerState (3, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	SetSamplerState (4, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	SetSamplerState (4, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	SetSamplerState (5, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	SetSamplerState (5, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	SetSamplerState (6, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	SetSamplerState (6, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	SetSamplerState (7, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	SetSamplerState (7, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	#endif

	SetTextureStageState (0, D3DTSS_TEXTURETRANSFORMFLAGS, 0);
	SetTextureStageState (1, D3DTSS_TEXTURETRANSFORMFLAGS, 0);
	SetTextureStageState (2, D3DTSS_TEXTURETRANSFORMFLAGS, 0);
	SetTextureStageState (3, D3DTSS_TEXTURETRANSFORMFLAGS, 0);
	SetTextureStageState (4, D3DTSS_TEXTURETRANSFORMFLAGS, 0);
	SetTextureStageState (5, D3DTSS_TEXTURETRANSFORMFLAGS, 0);
	SetTextureStageState (6, D3DTSS_TEXTURETRANSFORMFLAGS, 0);
	SetTextureStageState (7, D3DTSS_TEXTURETRANSFORMFLAGS, 0);

	SetTexture (0, NULL);
	SetTexture (1, NULL);
	SetTexture (2, NULL);
	SetTexture (3, NULL);
	SetTexture (4, NULL);
	SetTexture (5, NULL);
	SetTexture (6, NULL);
	SetTexture (7, NULL);

	SetVertexShader(D3DFVF_XYZ);

	m_bForce = false;
}

void CStateManager::SaveMaterial()
{
	m_CopyState.m_D3DMaterial = m_CurrentState.m_D3DMaterial;
}

#ifdef DIRECTX9
void CStateManager::SaveMaterial (const D3DMATERIAL9* pMaterial)
#endif
{
	m_CopyState.m_D3DMaterial = m_CurrentState.m_D3DMaterial;
	SetMaterial (pMaterial);
}

#ifdef DIRECTX9
void CStateManager::SetMaterial (const D3DMATERIAL9* pMaterial)
#endif
{
    if (m_lpD3DDev)
	{
		HRESULT hr = m_lpD3DDev->SetMaterial (pMaterial);
		if (FAILED(hr))
		{
			char buf[256];
			sprintf_s(buf, "CStateManager::SetMaterial failed hr=0x%08x", (unsigned)hr);
			WriteSystemLog(buf);
		}
	}
	m_CurrentState.m_D3DMaterial = *pMaterial;
}

#ifdef DIRECTX9
void CStateManager::GetMaterial (D3DMATERIAL9* pMaterial)
#endif
{
	*pMaterial = m_CurrentState.m_D3DMaterial;
}

DWORD CStateManager::GetRenderState (D3DRENDERSTATETYPE Type)
{
	return m_CurrentState.m_RenderStates[Type];
}

void CStateManager::SaveRenderState (D3DRENDERSTATETYPE Type, DWORD dwValue)
{
	m_CopyState.m_RenderStates[Type] = m_CurrentState.m_RenderStates[Type];
	SetRenderState (Type, dwValue);
}

void CStateManager::RestoreRenderState (D3DRENDERSTATETYPE Type)
{
	SetRenderState (Type, m_CopyState.m_RenderStates[Type]);
}

void CStateManager::SetRenderState (D3DRENDERSTATETYPE Type, DWORD Value)
{
	if (m_CurrentState.m_RenderStates[Type] == Value)
	{
		return;
	}
	if (m_lpD3DDev)
	{
		m_lpD3DDev->SetRenderState (Type, Value);
	}
	m_CurrentState.m_RenderStates[Type] = Value;
}

void CStateManager::GetRenderState (D3DRENDERSTATETYPE Type, DWORD* pdwValue)
{
	*pdwValue = m_CurrentState.m_RenderStates[Type];
}

#ifdef DIRECTX9
void CStateManager::SetTexture (DWORD dwStage, LPDIRECT3DBASETEXTURE9 pTexture)
#endif
{
	if (pTexture == m_CurrentState.m_Textures[dwStage])
	{
		return;
	}

	m_lpD3DDev->SetTexture (dwStage, pTexture);
	m_CurrentState.m_Textures[dwStage] = pTexture;
}

#ifdef DIRECTX9
void CStateManager::GetTexture (DWORD dwStage, LPDIRECT3DBASETEXTURE9* ppTexture)
#endif
{
	*ppTexture = m_CurrentState.m_Textures[dwStage];
}

void CStateManager::SaveTextureStageState (DWORD dwStage, D3DTEXTURESTAGESTATETYPE Type, DWORD dwValue)
{
	m_CopyState.m_TextureStates[dwStage][Type] = m_CurrentState.m_TextureStates[dwStage][Type];
	SetTextureStageState (dwStage, Type, dwValue);
}

void CStateManager::RestoreTextureStageState (DWORD dwStage, D3DTEXTURESTAGESTATETYPE Type)
{
	SetTextureStageState (dwStage, Type, m_CopyState.m_TextureStates[dwStage][Type]);
}

void CStateManager::SetTextureStageState (DWORD dwStage, D3DTEXTURESTAGESTATETYPE Type, DWORD dwValue)
{
	if (m_CurrentState.m_TextureStates[dwStage][Type] == dwValue)
	{
		return;
	}
	if (m_lpD3DDev)
	{
		m_lpD3DDev->SetTextureStageState (dwStage, Type, dwValue);
	}
	m_CurrentState.m_TextureStates[dwStage][Type] = dwValue;
}

void CStateManager::GetTextureStageState (DWORD dwStage, D3DTEXTURESTAGESTATETYPE Type, DWORD* pdwValue)
{
	*pdwValue = m_CurrentState.m_TextureStates[dwStage][Type];
}

#ifdef DIRECTX9
void CStateManager::SaveSamplerState (DWORD dwStage, D3DSAMPLERSTATETYPE Type, DWORD dwValue)
{
	m_CopyState.m_SamplerStates[dwStage][Type] = m_CurrentState.m_SamplerStates[dwStage][Type];
	SetSamplerState (dwStage, Type, dwValue);
}

void CStateManager::RestoreSamplerState (DWORD dwStage, D3DSAMPLERSTATETYPE Type)
{
	SetSamplerState (dwStage, Type, m_CopyState.m_SamplerStates[dwStage][Type]);
}

void CStateManager::SetSamplerState (DWORD dwStage, D3DSAMPLERSTATETYPE Type, DWORD dwValue)
{
	if (m_CurrentState.m_SamplerStates[dwStage][Type] == dwValue)
	{
		return;
	}
	if (m_lpD3DDev)
	{
		m_lpD3DDev->SetSamplerState (dwStage, Type, dwValue);
	}
	m_CurrentState.m_SamplerStates[dwStage][Type] = dwValue;
}
#endif

void CStateManager::SaveVertexShader (DWORD dwShader)
{
	m_CopyState.m_dwVertexShader = m_CurrentState.m_dwVertexShader;
	SetVertexShader (dwShader);
}

void CStateManager::RestoreVertexShader()
{
	SetVertexShader (m_CopyState.m_dwVertexShader);
}

void CStateManager::SetVertexShader (DWORD dwShader)
{
	if (m_CurrentState.m_dwVertexShader == dwShader)
	{
		return;
	}

	#ifdef DIRECTX9
	m_lpD3DDev->SetFVF (dwShader);
	#endif

	m_CurrentState.m_dwVertexShader = dwShader;
}

void CStateManager::GetVertexShader (DWORD* pdwShader)
{
	*pdwShader = m_CurrentState.m_dwVertexShader;
}

void CStateManager::SaveTransform (D3DTRANSFORMSTATETYPE Type, const D3DMATRIX* pMatrix)
{
	m_CopyState.m_Matrices[Type] = m_CurrentState.m_Matrices[Type];
	SetTransform (Type, (D3DXMATRIX*)pMatrix);
}

void CStateManager::RestoreTransform (D3DTRANSFORMSTATETYPE Type)
{
	SetTransform (Type, &m_CopyState.m_Matrices[Type]);
}

void CStateManager::SetTransform (D3DTRANSFORMSTATETYPE Type, const D3DMATRIX* pMatrix)
{
	if (m_bScene)
	{
		m_lpD3DDev->SetTransform (Type, pMatrix);
	}
	else
	{
		assert (D3DTS_VIEW == Type || D3DTS_PROJECTION == Type || D3DTS_WORLD == Type);
	}

	m_CurrentState.m_Matrices[Type] = *pMatrix;
}

void CStateManager::GetTransform (D3DTRANSFORMSTATETYPE Type, D3DMATRIX* pMatrix)
{
	*pMatrix = m_CurrentState.m_Matrices[Type];
}

void CStateManager::SetVertexShaderConstant(DWORD dwRegister,CONST void* pConstantData,DWORD dwConstantCount)
{
	#ifdef DIRECTX9
	m_lpD3DDev->SetVertexShaderConstantF (dwRegister, (const float*)pConstantData, dwConstantCount);
	#endif

	for (DWORD i = 0; i < dwConstantCount; i++)
	{
		StateManager_Assert ((dwRegister + i) < STATEMANAGER_MAX_VCONSTANTS);
		m_CurrentState.m_VertexShaderConstants[dwRegister + i] = * (((D3DXVECTOR4*)pConstantData) + i);
	}
}

#ifdef DIRECTX9
void CStateManager::SetStreamSource (unsigned int StreamNumber, LPDIRECT3DVERTEXBUFFER9 pStreamData, unsigned int Stride)
#endif
{
	CStreamData kStreamData (pStreamData, Stride);
	if (m_CurrentState.m_StreamData[StreamNumber] == kStreamData)
	{
		return;
	}

	#ifdef DIRECTX9
	m_lpD3DDev->SetStreamSource (StreamNumber, pStreamData, 0, Stride);
	#endif
	m_CurrentState.m_StreamData[StreamNumber] = kStreamData;
}

#ifdef DIRECTX9
void CStateManager::SetIndices (LPDIRECT3DINDEXBUFFER9 pIndexData, unsigned int BaseVertexIndex)
#endif
{
	CIndexData kIndexData (pIndexData, BaseVertexIndex);

	if (m_CurrentState.m_IndexData == kIndexData)
	{
		return;
	}

	#ifdef DIRECTX9
	m_lpD3DDev->SetIndices (pIndexData);
	#endif
	m_CurrentState.m_IndexData = kIndexData;
}

HRESULT CStateManager::DrawPrimitive (D3DPRIMITIVETYPE PrimitiveType, unsigned int StartVertex, unsigned int PrimitiveCount)
{
    if (!m_lpD3DDev)
		return E_FAIL;

	return (m_lpD3DDev->DrawPrimitive (PrimitiveType, StartVertex, PrimitiveCount));
}

HRESULT CStateManager::DrawPrimitiveUP (D3DPRIMITIVETYPE PrimitiveType, unsigned int PrimitiveCount, const void* pVertexStreamZeroData, unsigned int VertexStreamZeroStride)
{
	m_CurrentState.m_StreamData[0] = NULL;
    if (!m_lpD3DDev)
		return E_FAIL;

	return (m_lpD3DDev->DrawPrimitiveUP (PrimitiveType, PrimitiveCount, pVertexStreamZeroData, VertexStreamZeroStride));
}

#ifdef DIRECTX9
HRESULT CStateManager::DrawIndexedPrimitive (D3DPRIMITIVETYPE PrimitiveType, int BaseVertexIndex, unsigned int minIndex, unsigned int NumVertices, unsigned int startIndex, unsigned int primCount)
{
    if (!m_lpD3DDev)
		return E_FAIL;

	return (m_lpD3DDev->DrawIndexedPrimitive (PrimitiveType, BaseVertexIndex, minIndex, NumVertices, startIndex, primCount));
}
#endif

#ifdef DIRECTX_ON
HRESULT CStateManager::DrawIndexedPrimitiveUP (D3DPRIMITIVETYPE PrimitiveType, unsigned int MinVertexIndex, unsigned int NumVertexIndices, unsigned int PrimitiveCount, CONST void* pIndexData, D3DFORMAT IndexDataFormat, CONST void* pVertexStreamZeroData, unsigned int VertexStreamZeroStride)
#else
HRESULT CStateManager::DrawIndexedPrimitiveUP (D3DPRIMITIVETYPE PrimitiveType, unsigned int MinVertexIndex, unsigned int NumVertexIndices, unsigned int PrimitiveCount, const void* pIndexData, D3DFORMAT IndexDataFormat, const void* pVertexStreamZeroData, unsigned int VertexStreamZeroStride)
#endif
{
	m_CurrentState.m_IndexData = NULL;
	m_CurrentState.m_StreamData[0] = NULL;
	return (m_lpD3DDev->DrawIndexedPrimitiveUP (PrimitiveType, MinVertexIndex, NumVertexIndices, PrimitiveCount, pIndexData, IndexDataFormat, pVertexStreamZeroData, VertexStreamZeroStride));
}

