#pragma once
#include "StdAfx.h"
#include <map>

class CNetworkPacketHeaderMap
{
	public:
		typedef struct SPacketType
		{
			SPacketType (int iSize = 0, bool bFlag = false)
			{
				iPacketSize = iSize;
				isDynamicSizePacket = bFlag;
			}

			int iPacketSize;
			bool isDynamicSizePacket;
		} TPacketType;
	public:
		CNetworkPacketHeaderMap();
		virtual ~CNetworkPacketHeaderMap();

#ifdef ENABLE_FIX_GAME_CORE_BUG_NEW_SIX
		void Set (int header, TPacketType& rPacketType);
#else
		void Set(int header, const TPacketType & rPacketType);
#endif
		bool Get (int header, TPacketType* pPacketType);

	protected:
		std::map<int, TPacketType> m_headerMap;
};


