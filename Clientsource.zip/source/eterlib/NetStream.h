#pragma once
#include <memory>
#include "../eterbase/tea.h"
#include "NetAddress.h"
#include <AttackDefines.h> // __FIX_BUFFER_CLIENT__
#include "../eterbase/stl.h" //__FIX_BUFFER_CLIENT__

class CNetworkStream
{
public:
	CNetworkStream();
	virtual ~CNetworkStream();

	void SetRecvBufferSize(int recvBufSize);
	void SetSendBufferSize(int sendBufSize);

	int GetRecvBufferSize();

	void Clear();
	void ClearRecvBuffer();

	void Process();

	bool Connect(const CNetworkAddress& c_rkNetAddr, int limitSec = 3);
	bool Connect(const char* c_szAddr, int port, int limitSec = 3);
	bool Connect(DWORD dwAddr, int port, int limitSec = 3);
	void Disconnect();

#ifdef __FIX_BUFFER_CLIENT__
	bool PeekNoFetch(int len);
	bool Peek(int len, char* pDestBuf);
	bool RecvNoFetch(int len);
#else
	bool Peek(int len);
	bool Peek(int len, char* pDestBuf);
	bool Recv(int len);
#endif
	bool Recv(int len, char* pDestBuf);
	bool Send(int len, const char* pSrcBuf);

	bool Peek(int len, void* pDestBuf);
	bool Recv(int len, void* pDestBuf);

	bool Send(int len, const void* pSrcBuf);
	bool SendFlush(int len, const void* pSrcBuf);

#ifdef __FIX_BUFFER_CLIENT__
	template<typename T, std::enable_if_t<utils::IsRawV<T>>* = nullptr>
	bool AutoPeek(T& c_pvData) {
		return Peek(sizeof(T), &c_pvData);
	}
	template<typename C, std::enable_if_t<utils::IsContiguousV<C>>* = nullptr>
	bool AutoPeek(C& v) {
		return Peek(v.size() * sizeof(typename C::value_type), v.data());
	}

	template<typename T, std::enable_if_t<utils::IsRawV<T>>* = nullptr>
	bool AutoRecv(T& c_pvData) {
		return Recv(sizeof(T), &c_pvData);
	}
	template<typename C, std::enable_if_t<utils::IsContiguousV<C>>* = nullptr>
	bool AutoRecv(C& v) {
		return Recv(v.size() * sizeof(typename C::value_type), v.data());
	}

	template<typename T, std::enable_if_t<utils::IsRawV<T>>* = nullptr>
	bool SendFlush(const T& c_pvData) {
		return SendFlush(sizeof(T), &c_pvData);
	}
	template<typename C, std::enable_if_t<utils::IsContiguousV<C>>* = nullptr>
	bool SendFlush(const C& v) {
		return SendFlush(v.size() * sizeof(typename C::value_type), v.data());
	}

	template<typename T, std::enable_if_t<utils::IsRawV<T>>* = nullptr>
	bool Send(const T& c_pvData) {
		return Send(sizeof(T), &c_pvData);
	}
	template<typename C, std::enable_if_t<utils::IsContiguousV<C>>* = nullptr>
	bool Send(const C& v) {
		return Send(v.size() * sizeof(typename C::value_type), v.data());
	}
#endif

	bool IsOnline();

protected:
	virtual void OnConnectSuccess();
	virtual void OnConnectFailure();
	virtual void OnRemoteDisconnect();
	virtual void OnDisconnect();
	virtual bool OnProcess();

	bool __SendInternalBuffer();
	bool __RecvInternalBuffer();

	void __PopSendBuffer();
	int __GetSendBufferSize();


private:
	time_t m_connectLimitTime;

	std::unique_ptr<char[]>	m_recvBuf;
	int m_recvBufSize;
	int m_recvBufInputPos;
	int m_recvBufOutputPos;

	std::unique_ptr<char[]>	m_sendBuf;
	int m_sendBufSize;
	int m_sendBufInputPos;
	int m_sendBufOutputPos;

	bool m_isOnline;

	SOCKET m_sock;
	CNetworkAddress m_addr;
};

