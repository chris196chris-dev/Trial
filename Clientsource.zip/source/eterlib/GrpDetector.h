#pragma once
#include "../DirectUpgrade.h"
#ifdef DIRECTX9
#include <directx/d3d9/d3d9.h>
#endif
#include <string>

#ifdef DIRECTX9
		typedef BOOL (*PFNCONFIRMDEVICE) (D3DCAPS9& rkD3DCaps, unsigned int uBehavior, D3DFORMAT eD3DFmt);
#endif

enum ED3dDeviceType
{
	D3DDEVICETYPE_HAL,
	D3DDEVICETYPE_REF,
	D3DDEVICETYPE_NUM,
};

struct D3D_SModeInfo
{
	unsigned int m_uScrWidth;
	unsigned int m_uScrHeight;
	unsigned int m_uScrDepthBit;
	unsigned int m_dwD3DBehavior;
	D3DFORMAT m_eD3DFmtPixel;
	D3DFORMAT m_eD3DFmtDepthStencil;

	VOID GetString (std::string* pstEnumList);
};

class D3D_CAdapterDisplayModeList
{
	public:
		D3D_CAdapterDisplayModeList() = default;
		~D3D_CAdapterDisplayModeList() = default;

#ifdef DIRECTX9
		VOID Build (IDirect3D9Ex& rkD3D, D3DFORMAT eD3DFmtDefault, unsigned int iAdapter);
#endif

		unsigned int GetDisplayModeNum();
		unsigned int GetPixelFormatNum();

		const D3DDISPLAYMODEEX& GetDisplayModer (unsigned int iD3DDM);
		const D3DFORMAT& GetPixelFormatr (unsigned int iD3DFmt);

	protected:
		enum ED3DDisplayMode
		{
			D3DDISPLAYMODE_MAX = 100,
			D3DFORMAT_MAX = 20,

			FILTEROUT_LOWRESOLUTION_WIDTH = 640,
			FILTEROUT_LOWRESOLUTION_HEIGHT = 480,
		};

	protected:
		D3DDISPLAYMODEEX m_akD3DDM[D3DDISPLAYMODE_MAX];
		D3DFORMAT m_aeD3DFmt[D3DFORMAT_MAX];

		unsigned int m_uD3DDMNum;
		unsigned int m_uD3DFmtNum;

};

class D3D_CDeviceInfo
{
	public:
		D3D_CDeviceInfo() = default;
		~D3D_CDeviceInfo() = default;

#ifdef DIRECTX9
		BOOL Build (IDirect3D9Ex& rkD3D, unsigned int iD3DAdapterInfo, unsigned int iDevType, D3D_CAdapterDisplayModeList& rkD3DADMList, PFNCONFIRMDEVICE pfnConfirmDevice);
#endif

		BOOL Find (unsigned int uScrWidth, unsigned int uScrHeight, unsigned int uScrDepthBits, BOOL isWindowed, unsigned int* piD3DModeInfo);

		unsigned int GetD3DModeInfoNum();

		VOID GetString (std::string* pstEnumList);

#ifdef DIRECTX9
		BOOL FindDepthStencilFormat (IDirect3D9Ex& rkD3D, unsigned int iAdapter, D3DDEVTYPE DeviceType, D3DFORMAT TargetFormat, D3DFORMAT* pDepthStencilFormat);
#endif

		D3D_SModeInfo* GetD3DModeInfop (unsigned int iD3DModeInfo);

	protected:
		enum ED3DModelInfoNum
		{
			D3DMODEINFO_NUM = 150,
		};


	protected:
		const TCHAR* m_szDevDesc;

		D3DDEVTYPE	m_eD3DDevType;
#ifdef DIRECTX9
		D3DCAPS9		m_kD3DCaps;
#endif
		BOOL		m_canDoWindowed;

		unsigned int		m_iCurD3DModeInfo;
		unsigned int		m_uD3DModeInfoNum;
		D3D_SModeInfo	m_akD3DModeInfo[D3DMODEINFO_NUM];


		BOOL		m_isWindowed;

		D3DMULTISAMPLE_TYPE m_eD3DMSTWindowed;
		D3DMULTISAMPLE_TYPE m_eD3DMSTFullscreen;


	protected:
		static const CHAR* msc_aszD3DDevDesc[D3DDEVICETYPE_NUM];
		static const D3DDEVTYPE msc_aeD3DDevType[D3DDEVICETYPE_NUM];
};

class D3D_CAdapterInfo
{
	public:
		D3D_CAdapterInfo() = default;
		~D3D_CAdapterInfo() = default;
		BOOL Find (unsigned int uScrWidth, unsigned int uScrHeight, unsigned int uScrDepthBits, BOOL isWindowed, unsigned int* piD3DModeInfo, unsigned int* piD3DDevInfo);

#ifdef DIRECTX9
		BOOL Build (IDirect3D9Ex& rkD3D, unsigned int iAdapter, PFNCONFIRMDEVICE pfnConfirmDevice);
#endif

		VOID GetString (std::string* pstEnumList);

#ifdef DIRECTX9
		D3DADAPTER_IDENTIFIER9& GetIdentifier()
#endif
		{
			return m_kD3DAdapterIdentifier;
		}

		D3DDISPLAYMODEEX& GetDesktopD3DDisplayModer();
		D3DDISPLAYMODEEX* GetDesktopD3DDisplayModep();

		D3D_CDeviceInfo* GetD3DDeviceInfop (unsigned int iD3DDevInfo);
		D3D_SModeInfo* GetD3DModeInfop (unsigned int iD3DDevInfo, unsigned int iD3DModeInfo);

	protected:
		enum ED3DDeviceInfoNum
		{
			D3DDEVICEINFO_NUM = 5,
		};


	protected:
#ifdef DIRECTX9
		D3DADAPTER_IDENTIFIER9 m_kD3DAdapterIdentifier;
#endif

		D3DDISPLAYMODEEX m_kD3DDMDesktop;

		unsigned int			m_iCurD3DDevInfo;
		unsigned int			m_uD3DDevInfoNum;
		D3D_CDeviceInfo	m_akD3DDevInfo[D3DDEVICEINFO_NUM];

};

class D3D_CDisplayModeAutoDetector
{
	public:
		D3D_CDisplayModeAutoDetector();
		~D3D_CDisplayModeAutoDetector() = default;

		BOOL Find (unsigned int uScrWidth, unsigned int uScrHeight, unsigned int uScrDepthBits, BOOL isWindowed, unsigned int* piD3DModeInfo, unsigned int* piD3DDevInfo, unsigned int* piD3DAdapterInfo);

#ifdef DIRECTX9
		BOOL Build (IDirect3D9Ex& rkD3D, PFNCONFIRMDEVICE pfnConfirmDevice);
#endif

		D3D_CAdapterInfo* GetD3DAdapterInfop (unsigned int iD3DAdapterInfo);
		D3D_SModeInfo* GetD3DModeInfop (unsigned int iD3DAdapterInfo, unsigned int iD3DDevInfo, unsigned int iD3DModeInfo);

		VOID GetString (std::string* pstEnumList);

	protected:
		enum ED3DAdapterInfoNum
		{
			D3DADAPTERINFO_NUM = 10,
		};

	protected:
		D3D_CAdapterInfo	m_akD3DAdapterInfo[D3DADAPTERINFO_NUM];
		unsigned int				m_uD3DAdapterInfoCount;
};

