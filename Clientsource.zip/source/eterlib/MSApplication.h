#pragma once

#include "MSWindow.h"

class CMSApplication : public CMSWindow
{
	public:
		CMSApplication() = default;
		virtual~CMSApplication() = default;

		void Initialize (HINSTANCE hInstance);

		void MessageLoop();

		bool IsMessage();
		bool MessageProcess();

	protected:
		LRESULT WindowProcedure (HWND hWnd, unsigned int uiMsg, WPARAM wParam, LPARAM lParam);
};

