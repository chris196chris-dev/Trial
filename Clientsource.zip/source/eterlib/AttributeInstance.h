#pragma once

#include <vector>
#include "AttributeData.h"
#include "Pool.h"

class CAttributeInstance
{
	public:
		CAttributeInstance() = default;
		virtual~CAttributeInstance() = default;
		void Clear();
		BOOL IsEmpty() const;
		const char* GetDataFileName() const;
		void SetObjectPointer (CAttributeData* pAttributeData);
		void RefreshObject (const D3DXMATRIX& c_rmatGlobal);
		CAttributeData* GetObjectPointer() const;
		bool Picking (const D3DXVECTOR3& v, const D3DXVECTOR3& dir, float& out_x, float& out_y);
		BOOL IsInHeight (float fx, float fy);
		BOOL GetHeight (float fx, float fy, float* pfHeight);

	protected:
		float m_fCollisionRadius;
		float m_fHeightRadius;

		D3DXMATRIX m_matGlobal;

		std::vector< std::vector<D3DXVECTOR3>> m_v3HeightDataVector;

		CAttributeData::TRef					m_roAttributeData;

	public:
		static void CreateSystem (unsigned int uCapacity);
		static void DestroySystem();

		static CAttributeInstance* New();
		static void Delete (CAttributeInstance* pkInst);

		static CDynamicPool<CAttributeInstance> ms_kPool;
};

