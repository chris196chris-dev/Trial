#include "StdAfx.h"
#include "NetStream.h"

void CNetworkStream::SetRecvBufferSize (int recvBufSize)
{
	if (m_recvBuf)
	{
		if (m_recvBufSize > recvBufSize)
		{
			return;
		}

		m_recvBuf.reset();
	}
	m_recvBufSize = recvBufSize;
	m_recvBuf.reset (new char[m_recvBufSize]);
}

void CNetworkStream::SetSendBufferSize (int sendBufSize)
{
	if (m_sendBuf)
	{
		if (m_sendBufSize > sendBufSize)
		{
			return;
		}

		m_sendBuf.reset();
	}

	m_sendBufSize = sendBufSize;
	m_sendBuf.reset (new char[m_sendBufSize]);
}

bool CNetworkStream::__RecvInternalBuffer()
{
	if (m_recvBufOutputPos > 0)
	{
		int recvBufDataSize = m_recvBufInputPos - m_recvBufOutputPos;
		if (recvBufDataSize > 0)
		{
			memmove (m_recvBuf.get(), m_recvBuf.get() + m_recvBufOutputPos, recvBufDataSize);
		}

		m_recvBufInputPos -= m_recvBufOutputPos;
		m_recvBufOutputPos = 0;
	}

	int restSize = m_recvBufSize - m_recvBufInputPos;
	if (restSize > 0)
	{
		int recvSize = recv (m_sock, m_recvBuf.get() + m_recvBufInputPos, m_recvBufSize - m_recvBufInputPos, 0);
		if (recvSize < 0)
		{
			int error = WSAGetLastError();

			if (error == WSAEWOULDBLOCK)
			{
				recvSize = 0;
			}
			else
			{
				return false;
			}
		}
		else if (recvSize == 0)
		{
			return false;
		}
		m_recvBufInputPos += recvSize;
	}
	return true;
}


bool CNetworkStream::__SendInternalBuffer()
{
	{
		int dataSize = __GetSendBufferSize();
		if (dataSize <= 0)
		{
			return true;
		}

		int sendSize = send (m_sock, m_sendBuf.get() + m_sendBufOutputPos, dataSize, 0);
		if (sendSize < 0)
		{
			int error = WSAGetLastError();
			if (error == WSAEWOULDBLOCK)
			{
				return true;
			}
			return false;
		}

		m_sendBufOutputPos += sendSize;

		__PopSendBuffer();
	}
	return true;
}

void CNetworkStream::__PopSendBuffer()
{
	if (m_sendBufOutputPos <= 0)
	{
		return;
	}

	int sendBufDataSize = m_sendBufInputPos - m_sendBufOutputPos;

	if (sendBufDataSize > 0)
	{
		memmove (m_sendBuf.get(), m_sendBuf.get() + m_sendBufOutputPos, sendBufDataSize);
	}

	m_sendBufInputPos = sendBufDataSize;
	m_sendBufOutputPos = 0;
}

#pragma warning(push)
#pragma warning(disable:4127)
void CNetworkStream::Process()
{
	if (m_sock == INVALID_SOCKET)
	{
		return;
	}

	fd_set fdsRecv;
	fd_set fdsSend;

	FD_ZERO(&fdsRecv);
	FD_ZERO(&fdsSend);

	FD_SET(m_sock, &fdsRecv);
	FD_SET(m_sock, &fdsSend);

	TIMEVAL delay;

	delay.tv_sec = 0;
	delay.tv_usec = 0;

	if (select(0, &fdsRecv, &fdsSend, NULL, &delay) == SOCKET_ERROR)
	{
		return;
	}

	if (!m_isOnline)
	{
		if (FD_ISSET(m_sock, &fdsSend))
		{
			int error = 0;
			int len = sizeof(error);
			if (getsockopt(m_sock, SOL_SOCKET, SO_ERROR, reinterpret_cast<char*>(&error), &len) == SOCKET_ERROR || error != 0)
			{
				Clear();
				OnConnectFailure();
				return;
			}

			m_isOnline = true;
			OnConnectSuccess();
		}
		else if (time(NULL) > m_connectLimitTime)
		{
			Clear();
			OnConnectFailure();
		}

		return;
	}

	if (FD_ISSET(m_sock, &fdsSend) && (m_sendBufInputPos > m_sendBufOutputPos))
	{
		if (!__SendInternalBuffer())
		{
			int error = WSAGetLastError();

			if (error != WSAEWOULDBLOCK)
			{
				OnRemoteDisconnect();
				Clear();
				return;
			}
		}
	}

	if (FD_ISSET(m_sock, &fdsRecv))
	{
		if (!__RecvInternalBuffer())
		{
			OnRemoteDisconnect();
			Clear();
			return;
		}
	}

	if (!OnProcess())
	{
		OnRemoteDisconnect();
		Clear();
	}
}
#pragma warning(pop)

void CNetworkStream::Disconnect()
{
	if (m_sock == INVALID_SOCKET)
	{
		return;
	}

	Clear();
}

void CNetworkStream::Clear()
{
	if (m_sock == INVALID_SOCKET)
	{
		return;
	}

	closesocket(m_sock);
	m_sock = INVALID_SOCKET;

	m_isOnline = false;
	m_connectLimitTime = 0;

	m_recvBufInputPos = 0;
	m_recvBufOutputPos = 0;

	m_sendBufInputPos = 0;
	m_sendBufOutputPos = 0;
}

bool CNetworkStream::Connect(const CNetworkAddress& c_rkNetAddr, int limitSec)
{
	Clear();

	m_addr = c_rkNetAddr;

	m_sock = socket(AF_INET, SOCK_STREAM, 0);

	if (m_sock == INVALID_SOCKET)
	{
		Clear();
		OnConnectFailure();
		return false;
	}

	DWORD arg = 1;
	ioctlsocket(m_sock, FIONBIO, &arg);

	if (connect(m_sock, (PSOCKADDR)&m_addr, m_addr.GetSize()) == SOCKET_ERROR)
	{
		int error = WSAGetLastError();
		if (error != WSAEWOULDBLOCK)
		{
			Tracen("error != WSAEWOULDBLOCK");
			Clear();
			OnConnectFailure();
			return false;
		}
	}

	m_connectLimitTime = time(NULL) + limitSec;
	return true;
}

bool CNetworkStream::Connect(DWORD dwAddr, int port, int limitSec)
{
	char szAddr[256];
	{
		BYTE ip[4];
		ip[0] = dwAddr & 0xff;
		dwAddr >>= 8;
		ip[1] = dwAddr & 0xff;
		dwAddr >>= 8;
		ip[2] = dwAddr & 0xff;
		dwAddr >>= 8;
		ip[3] = dwAddr & 0xff;
		dwAddr >>= 8;

		sprintf(szAddr, "%d.%d.%d.%d", ip[0], ip[1], ip[2], ip[3]);
	}

	return Connect(szAddr, port, limitSec);
}

bool CNetworkStream::Connect(const char* c_szAddr, int port, int limitSec)
{
	CNetworkAddress kNetAddr;
	if (!kNetAddr.Set(c_szAddr, port))
	{
		OnConnectFailure();
		return false;
	}

	return Connect(kNetAddr, limitSec);
}

void CNetworkStream::ClearRecvBuffer()
{
	m_recvBufOutputPos = m_recvBufInputPos = 0;
}

int CNetworkStream::GetRecvBufferSize()
{
	return m_recvBufInputPos - m_recvBufOutputPos;
}

#ifdef __FIX_BUFFER_CLIENT__
bool CNetworkStream::PeekNoFetch(int size)
#else
bool CNetworkStream::Peek(int size)
#endif
{
	if (GetRecvBufferSize() < size)
	{
		return false;
	}

	return true;
}

bool CNetworkStream::Peek(int size, char* pDestBuf)
{
	if (GetRecvBufferSize() < size)
	{
		return false;
	}

	if (pDestBuf)
	{
		memcpy (pDestBuf, m_recvBuf.get() + m_recvBufOutputPos, size);
	}
	return true;
}

#ifdef __FIX_BUFFER_CLIENT__
bool CNetworkStream::RecvNoFetch(int size)
{
	if (!PeekNoFetch(size))
#else
bool CNetworkStream::Recv(int size)
{
	if (!Peek(size))
#endif
	{
		return false;
	}

	m_recvBufOutputPos += size;
	return true;
}

bool CNetworkStream::Recv(int size, char* pDestBuf)
{
	if (!Peek(size, pDestBuf))
	{
		return false;
	}

	m_recvBufOutputPos += size;
	return true;
}

int CNetworkStream::__GetSendBufferSize()
{
	return m_sendBufInputPos - m_sendBufOutputPos;
}

bool CNetworkStream::Send(int size, const char* pSrcBuf)
{
	int sendBufRestSize = m_sendBufSize - m_sendBufInputPos;
	if ((size + 1) > sendBufRestSize)
	{
		return false;
	}

	memcpy (m_sendBuf.get() + m_sendBufInputPos, pSrcBuf, size);
	m_sendBufInputPos += size;

	return true;
}

bool CNetworkStream::Peek(int len, void* pDestBuf)
{
	return Peek (len, static_cast<char*> (pDestBuf));
}

bool CNetworkStream::Recv(int len, void* pDestBuf)
{
	return Recv (len, static_cast<char*> (pDestBuf));
}

bool CNetworkStream::SendFlush(int len, const void* pSrcBuf)
{
	if (!Send(len, pSrcBuf))
	{
		return false;
	}

	return __SendInternalBuffer();
}

bool CNetworkStream::Send(int len, const void* pSrcBuf)
{
	return Send (len, static_cast<const char*> (pSrcBuf));
}

bool CNetworkStream::IsOnline()
{
	return m_isOnline;
}

bool CNetworkStream::OnProcess()
{
	return true;
}

void CNetworkStream::OnRemoteDisconnect()
{

}

void CNetworkStream::OnDisconnect()
{

}

void CNetworkStream::OnConnectSuccess()
{
	Tracen("Succeed connecting.");
}

void CNetworkStream::OnConnectFailure()
{
	Tracen("Failed to connect.");
}

CNetworkStream::CNetworkStream()
{
	m_sock = INVALID_SOCKET;
	m_isOnline = false;
	m_connectLimitTime = 0;

	m_recvBuf = nullptr;
	m_recvBufSize = 0;
	m_recvBufOutputPos = 0;
	m_recvBufInputPos = 0;

	m_sendBuf = nullptr;
	m_sendBufSize = 0;
	m_sendBufOutputPos = 0;
	m_sendBufInputPos = 0;
}

CNetworkStream::~CNetworkStream()
{
	Clear();

	if (m_recvBuf)
	{
		m_recvBuf.reset();
	}

	if (m_sendBuf)
	{
		m_sendBuf.reset();
	}
}











