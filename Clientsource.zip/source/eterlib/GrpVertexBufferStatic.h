#pragma once

#include "GrpVertexBuffer.h"

class CStaticVertexBuffer : public CGraphicVertexBuffer
{
	public:
		CStaticVertexBuffer() = default;
		virtual~CStaticVertexBuffer() = default;

		bool Create (int vtxCount, DWORD fvf, bool isManaged = true);
};

