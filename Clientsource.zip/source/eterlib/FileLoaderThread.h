#pragma once

#include <deque>
#include "Thread.h"
#include "Mutex.h"
#include "../eterbase/MappedFile.h"

class CFileLoaderThread
{
	public:
		typedef struct SData
		{
			std::string stFileName;

			CMappedFile File;
			LPVOID pvBuf;
			DWORD dwSize;
		} TData;

	public:
		CFileLoaderThread() : m_bShutdowned (false), m_pArg (NULL), m_hThread (NULL), m_uThreadID (0) {};
		~CFileLoaderThread();

		int Create (void* arg);

	public:
		void Request (std::string& c_rstFileName);
		bool Fetch (TData** ppData);

	protected:
		static unsigned int CALLBACK EntryPoint (void* pThis);
		unsigned int Run (void* arg);

		void* Arg()const
		{
			return m_pArg;
		}

		void Arg (void* arg)
		{
			m_pArg = arg;
		}

		HANDLE m_hThread;

	private:
		void* m_pArg;
		unsigned m_uThreadID;

	protected:
		unsigned int Setup();
		unsigned int Execute (void* pvArg);
		void Destroy();
		void Process();

	private:
		std::deque<TData*> m_pRequestDeque;
		Mutex m_RequestMutex;

		std::deque<TData*> m_pCompleteDeque;
		Mutex m_CompleteMutex;

		HANDLE m_hSemaphore;
		int m_iRestSemCount;
		bool m_bShutdowned;
};

