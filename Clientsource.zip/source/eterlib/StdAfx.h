#pragma once
#define WIN32_LEAN_AND_MEAN
#ifndef _CRT_SECURE_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS
#endif
#include <AttackDefines.h>

#define _WIN32_DCOM
#pragma warning(disable:4710)
#pragma warning(disable:4786)
#pragma warning(disable:4244)
#pragma warning(disable:4018)
#pragma warning(disable:4245)
#pragma warning(disable:4512)
#pragma warning(disable:4201)

#pragma warning(disable:4201 4512 4238 4239)
#ifdef DIRECTX9
#include <directx/d3d9/d3d9.h>
#include <directx/d3d9/d3dx9.h>
#endif

#define DIRECTINPUT_VERSION 0x0800

#include <dinput.h>

#pragma warning ( disable : 4201 )
#include <mmsystem.h>
#pragma warning ( default : 4201 )
#include <process.h>
#include <stdio.h>
#include <math.h>
#include <time.h>
#include <direct.h>
#include <malloc.h>

#pragma comment(lib, "winmm.lib")
#include "../eterbase/StdAfx.h"
#include "../eterbase/Debug.h"
#include "../eterlocale/CodePageId.h"

#include <winsock.h>

