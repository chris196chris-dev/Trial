#pragma once

PyMODINIT_FUNC PyInit_pack(void);
PyMODINIT_FUNC PyInit_dbg(void);
PyMODINIT_FUNC PyInit_ime(void);
PyMODINIT_FUNC PyInit_grp(void);
PyMODINIT_FUNC PyInit_grpImage(void);
PyMODINIT_FUNC PyInit_grpText(void);
PyMODINIT_FUNC PyInit_grpThing(void);
PyMODINIT_FUNC PyInit_wndMgr(void);
PyMODINIT_FUNC PyInit_app(void);
PyMODINIT_FUNC PyInit_systemSetting(void);
PyMODINIT_FUNC PyInit_chr(void);
PyMODINIT_FUNC PyInit_chrmgr(void);
PyMODINIT_FUNC PyInit_player(void);
PyMODINIT_FUNC PyInit_item(void);
PyMODINIT_FUNC PyInit_nonplayer(void);
PyMODINIT_FUNC PyInit_exchange(void);
PyMODINIT_FUNC PyInit_chat(void);
PyMODINIT_FUNC PyInit_textTail(void);
PyMODINIT_FUNC PyInit_net(void);
PyMODINIT_FUNC PyInit_miniMap(void);
PyMODINIT_FUNC PyInit_event(void);
PyMODINIT_FUNC PyInit_effect(void);
PyMODINIT_FUNC PyInit_fly(void);
PyMODINIT_FUNC PyInit_snd(void);
PyMODINIT_FUNC PyInit_shop(void);
PyMODINIT_FUNC PyInit_skill(void);
PyMODINIT_FUNC PyInit_quest(void);
PyMODINIT_FUNC PyInit_background(void);
PyMODINIT_FUNC PyInit_messenger(void);
PyMODINIT_FUNC PyInit_safebox(void);
PyMODINIT_FUNC PyInit_guild(void);
PyMODINIT_FUNC PyInit_acce(void);
PyMODINIT_FUNC PyInit_switchbot(void);

struct BuiltinModuleEntry
{
    const char* name;
    PyObject* (*initfunc)(void);
};

static const BuiltinModuleEntry kBuiltinModules[] =
{
    { "pack", PyInit_pack },
    { "dbg", PyInit_dbg },
    { "ime", PyInit_ime },
    { "grp", PyInit_grp },
    { "grpImage", PyInit_grpImage },
    { "grpText", PyInit_grpText },
    { "grpThing", PyInit_grpThing },
    { "wndMgr", PyInit_wndMgr },
    { "app", PyInit_app },
    { "systemSetting", PyInit_systemSetting },
    { "chr", PyInit_chr },
    { "chrmgr", PyInit_chrmgr },
    { "player", PyInit_player },
    { "item", PyInit_item },
    { "nonplayer", PyInit_nonplayer },
    { "exchange", PyInit_exchange },
    { "chat", PyInit_chat },
    { "textTail", PyInit_textTail },
    { "net", PyInit_net },
    { "miniMap", PyInit_miniMap },
    { "event", PyInit_event },
    { "effect", PyInit_effect },
    { "fly", PyInit_fly },
    { "snd", PyInit_snd },
    { "shop", PyInit_shop },
    { "skill", PyInit_skill },
    { "quest", PyInit_quest },
    { "background", PyInit_background },
    { "messenger", PyInit_messenger },
    { "safebox", PyInit_safebox },
    { "guild", PyInit_guild },
    { "acce", PyInit_acce },
    { "switchbot", PyInit_switchbot },
    { nullptr, nullptr }
};
