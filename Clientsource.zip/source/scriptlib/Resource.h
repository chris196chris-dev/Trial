#pragma once

#include "../effectlib/StdAfx.h"
#include "../eterlib/Resource.h"
#include "../eterlib/ResourceManager.h"

class CPythonResource : public CSingleton<CPythonResource>
{
	public:
		CPythonResource();
		virtual~CPythonResource() = default;

		void Destroy();

	protected:
		CResourceManager m_resManager;
};

