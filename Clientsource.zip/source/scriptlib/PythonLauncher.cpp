#include "StdAfx.h"
#include "PythonLauncher.h"
#include "PythonBuiltinModules.h"
#include "../eterbase/CrashHandler.h"

#include "../eterpack/EterPackManager.h"

#include <vector>
#include <string>
#include <windows.h>

namespace
{
	bool g_pythonInitialized = false;

	std::wstring GetExePathW()
	{
		wchar_t buffer[MAX_PATH] = { 0 };
		GetModuleFileNameW(nullptr, buffer, MAX_PATH);
		return buffer;
	}

	std::wstring GetDirectoryNameW(const std::wstring& path)
	{
		const std::wstring::size_type pos = path.find_last_of(L"\\/");
		if (pos == std::wstring::npos)
			return L".";
		return path.substr(0, pos);
	}

	std::wstring JoinPathW(const std::wstring& a, const std::wstring& b)
	{
		if (a.empty())
			return b;
		if (a.back() == L'\\' || a.back() == L'/')
			return a + b;
		return a + L"\\" + b;
	}

	bool FileExistsW(const std::wstring& path)
	{
		const DWORD attr = GetFileAttributesW(path.c_str());
		return attr != INVALID_FILE_ATTRIBUTES && !(attr & FILE_ATTRIBUTE_DIRECTORY);
	}

	PyObject* CreateModuleStub(const char* name)
	{
		static PyModuleDef moduleDef =
		{
			PyModuleDef_HEAD_INIT,
			nullptr,
			"stub module injected by launcher",
			-1,
			nullptr,
			nullptr,
			nullptr,
			nullptr,
			nullptr,
		};

		moduleDef.m_name = name;
		return PyModule_Create(&moduleDef);
	}

	PyMODINIT_FUNC PyInit__ctypes(void)
	{
		return CreateModuleStub("_ctypes");
	}

	PyMODINIT_FUNC PyInit_ctypes(void)
	{
		PyObject* module = CreateModuleStub("ctypes");
		if (!module)
			return nullptr;

		PyObject* errorType = PyErr_NewException("ctypes.error", nullptr, nullptr);
		if (errorType)
		{
			PyModule_AddObjectRef(module, "error", errorType);
			Py_DECREF(errorType);
		}

		PyModule_AddStringConstant(module, "__doc__", "launcher stub for ctypes");
		return module;
	}

	bool AppendModuleSearchPath(PyConfig& config, const std::wstring& path)
	{
		PyStatus status = PyWideStringList_Append(&config.module_search_paths, path.c_str());
		return !PyStatus_Exception(status);
	}

	bool SetProgramName(PyConfig& config, const std::wstring& exePath)
	{
		PyStatus status = PyConfig_SetString(&config, &config.program_name, exePath.c_str());
		return !PyStatus_Exception(status);
	}

	bool RegisterBuiltinModule(const char* name, PyObject* (*initfunc)(void))
	{
		if (PyImport_AppendInittab(name, initfunc) == -1)
		{
			LogBoxf("Failed to register builtin module: %s", name);
			return false;
		}
		return true;
	}

	bool RegisterBuiltinModules()
	{
		if (!RegisterBuiltinModule("_ctypes", &PyInit__ctypes))
			return false;

		if (!RegisterBuiltinModule("ctypes", &PyInit_ctypes))
			return false;

		for (const BuiltinModuleEntry* mod = kBuiltinModules; mod->name; ++mod)
		{
			if (!RegisterBuiltinModule(mod->name, mod->initfunc))
				return false;
		}

		return true;
	}
}

CPythonLauncher::CPythonLauncher()
	: m_poModule(nullptr)
	, m_poDic(nullptr)
{
}

CPythonLauncher::~CPythonLauncher()
{
	Clear();
}

void CPythonLauncher::Clear()
{
	m_poModule = nullptr;
	m_poDic = nullptr;

	if (g_pythonInitialized)
	{
		Py_FinalizeEx();
		g_pythonInitialized = false;
	}
}

void Traceback()
{
	if (!PyErr_Occurred())
		return;
	PyObject *ptype = NULL, *pvalue = NULL, *ptraceback = NULL;
	PyErr_Fetch(&ptype, &pvalue, &ptraceback);
	PyErr_NormalizeException(&ptype, &pvalue, &ptraceback);

	// Try to stringify the exception value
	if (pvalue)
	{
		PyObject* pStr = PyObject_Str(pvalue);
		if (pStr)
		{
			const char* sz = PyUnicode_AsUTF8(pStr);
			if (sz)
			{
				WritePythonErrorLog(sz);
			}
			Py_DECREF(pStr);
		}
	}

	// fallback to printing to stderr and clearing
	PyErr_Print();
	PyErr_Clear();

	LogBox("Python exception occurred. Check logs/pythonerror.log and logs/sysser.log for details.");

	if (ptype) Py_XDECREF(ptype);
	if (pvalue) Py_XDECREF(pvalue);
	if (ptraceback) Py_XDECREF(ptraceback);
}

int TraceFunc(PyObject*, PyFrameObject*, int, PyObject*)
{
	return 0;
}

bool CPythonLauncher::Create(const char* c_szProgramName)
{
	if (g_pythonInitialized)
		return true;

	if (!RegisterBuiltinModules())
		return false;

	const std::wstring exePath = GetExePathW();
	const std::wstring exeDir = GetDirectoryNameW(exePath);

	// v20 rollback/stable mode:
	// Python 3.14 is embedded/static in the exe, but the stdlib is loaded from the
	// runtime lib/ folder that already worked before v18. python314.zip is optional.
	// Do not require python314.zip here: a bad zip was the cause of the encodings crash.
	const std::wstring lowerLibPath = JoinPathW(exeDir, L"lib");
	const std::wstring upperLibPath = JoinPathW(exeDir, L"Lib");
	const std::wstring zipPath = JoinPathW(exeDir, L"python314.zip");
	const std::wstring dllsPath = JoinPathW(exeDir, L"DLLs");

	const bool hasLowerLib = (GetFileAttributesW(lowerLibPath.c_str()) != INVALID_FILE_ATTRIBUTES);
	const bool hasUpperLib = (GetFileAttributesW(upperLibPath.c_str()) != INVALID_FILE_ATTRIBUTES);
	const bool hasZip = FileExistsW(zipPath);

	if (!hasLowerLib && !hasUpperLib && !hasZip)
	{
		LogBox("Failed to initialize Python runtime: missing lib/ folder. Restore ClientRuntime\\lib beside the client exe.");
		return false;
	}

	PyConfig config;
	PyConfig_InitPythonConfig(&config);

	// Keep this close to the previously working setup. We disable environment/registry
	// pollution, but we do not force isolated zip-only startup.
	config.isolated = 0;
	config.site_import = 0;
	config.use_environment = 0;
	config.parse_argv = 0;
	config.install_signal_handlers = 0;
	config.write_bytecode = 0;
	config.module_search_paths_set = 1;

	if (!SetProgramName(config, exePath))
	{
		PyConfig_Clear(&config);
		return false;
	}

	// Main game/runtime folder first.
	if (!AppendModuleSearchPath(config, exeDir))
	{
		PyConfig_Clear(&config);
		return false;
	}

	// IMPORTANT: lib/ goes before python314.zip, so even if an old/bad zip is present,
	// encodings and importlib are loaded from the known-working loose runtime.
	if (hasLowerLib)
	{
		if (!AppendModuleSearchPath(config, lowerLibPath))
		{
			PyConfig_Clear(&config);
			return false;
		}
	}
	else if (hasUpperLib)
	{
		if (!AppendModuleSearchPath(config, upperLibPath))
		{
			PyConfig_Clear(&config);
			return false;
		}
	}

	// Optional only. Do not depend on this until the Python build is truly frozen/static.
	if (hasZip)
	{
		if (!AppendModuleSearchPath(config, zipPath))
		{
			PyConfig_Clear(&config);
			return false;
		}
	}

	if (GetFileAttributesW(dllsPath.c_str()) != INVALID_FILE_ATTRIBUTES)
	{
		if (!AppendModuleSearchPath(config, dllsPath))
		{
			PyConfig_Clear(&config);
			return false;
		}
	}

	PyStatus status = Py_InitializeFromConfig(&config);
	PyConfig_Clear(&config);

	if (PyStatus_Exception(status))
	{
		LogBoxf("Failed to initialize Python runtime: %s\n\nUse v20 rollback runtime: keep ClientRuntime\\lib beside the client exe. Do not delete lib/ yet.", status.err_msg ? status.err_msg : "unknown error");
		return false;
	}

	g_pythonInitialized = true;

#ifdef _DEBUG
	PyEval_SetTrace(TraceFunc, nullptr);
#endif

	m_poModule = PyImport_AddModule("__main__");
	if (!m_poModule)
		return false;

	m_poDic = PyModule_GetDict(m_poModule);
	if (!m_poDic)
		return false;

	PyObject* builtins = PyImport_ImportModule("builtins");
	if (!builtins)
		return false;

	PyModule_AddIntConstant(builtins, "TRUE", 1);
	PyModule_AddIntConstant(builtins, "FALSE", 0);
	PyDict_SetItemString(m_poDic, "__builtins__", builtins);
	Py_DECREF(builtins);

	if (!RunLine("import __main__"))
		return false;
	if (!RunLine("import sys"))
		return false;

	RunLine("sys.dont_write_bytecode = True");
	RunLine("sys.executable = sys.executable or 'Metin2.exe'");
	RunLine("import builtins; builtins.TRUE = 1; builtins.FALSE = 0");
	RunLine("import types, sys; sys.modules.setdefault('_ctypes', types.ModuleType('_ctypes')); sys.modules.setdefault('ctypes', types.ModuleType('ctypes'))");

	if (c_szProgramName && *c_szProgramName)
		Tracef("Python runtime ready v20 lib fallback: %s\n", c_szProgramName);

	return true;
}

bool CPythonLauncher::RunMemoryTextFile(const char* c_szFileName, size_t uFileSize, const void* c_pvFileData)
{
	if (!m_poDic || !c_pvFileData || uFileSize == 0)
		return false;

	const char* source = reinterpret_cast<const char*>(c_pvFileData);

	PyObject* code = Py_CompileString(source, c_szFileName, Py_file_input);
	if (!code)
	{
		Traceback();
		return false;
	}

	PyObject* result = PyEval_EvalCode(code, m_poDic, m_poDic);
	Py_DECREF(code);

	if (!result)
	{
		Traceback();
		return false;
	}

	Py_DECREF(result);
	return true;
}

bool CPythonLauncher::RunFile(const char* c_szFileName)
{
	char* acBufData = nullptr;
	DWORD dwBufSize = 0;

	{
		CMappedFile file;
		const void* pvData = nullptr;

		if (!CEterPackManager::Instance().Get(file, c_szFileName, &pvData))
			return false;

		dwBufSize = file.Size();
		if (dwBufSize == 0)
			return false;

		acBufData = new char[dwBufSize + 1];
		memcpy(acBufData, pvData, dwBufSize);
		acBufData[dwBufSize] = '\0';
	}

	const bool ret = RunMemoryTextFile(c_szFileName, static_cast<size_t>(dwBufSize), acBufData);
	delete[] acBufData;
	return ret;
}

bool CPythonLauncher::RunLine(const char* c_szSrc)
{
	if (!m_poDic)
		return false;

	PyObject* v = PyRun_String(c_szSrc, Py_file_input, m_poDic, m_poDic);
	if (!v)
	{
		Traceback();
		return false;
	}

	Py_DECREF(v);
	return true;
}