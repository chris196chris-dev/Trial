#pragma once

PyMODINIT_FUNC PyInit_dbg(void);

