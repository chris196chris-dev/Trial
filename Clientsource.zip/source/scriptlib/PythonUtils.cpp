﻿#include "StdAfx.h"
#include "PythonUtils.h"
#ifdef _WIN32
#include <windows.h>
#endif

bool __PyCallClassMemberFunc_ByCString (PyObject* poClass, const char* c_szFunc, PyObject* poArgs, PyObject** poRet);
bool __PyCallClassMemberFunc_ByPyString (PyObject* poClass, PyObject* poFuncName, PyObject* poArgs, PyObject** poRet);
bool __PyCallClassMemberFunc (PyObject* poClass, PyObject* poFunc, PyObject* poArgs, PyObject** poRet);


// Python 3.x / x64 compatibility: accept Python long/float values and cast like the old Python 2 client did.
// This prevents overflows on values such as 0xff000000 and legacy float results from Python 3 division.
static bool M2PyObject_ToSigned64(PyObject* obj, long long* out)
{
	if (!obj || !out)
		return false;
	PyErr_Clear();
	if (PyLong_Check(obj))
	{
		long long v = PyLong_AsLongLong(obj);
		if (PyErr_Occurred())
		{
			PyErr_Clear();
			unsigned long long uv = PyLong_AsUnsignedLongLong(obj);
			if (PyErr_Occurred())
			{
				PyErr_Clear();
				return false;
			}
			v = static_cast<long long>(uv);
		}
		*out = v;
		return true;
	}
	if (PyFloat_Check(obj))
	{
		*out = static_cast<long long>(PyFloat_AsDouble(obj));
		if (PyErr_Occurred())
		{
			PyErr_Clear();
			return false;
		}
		return true;
	}
	PyObject* num = PyNumber_Long(obj);
	if (!num)
	{
		PyErr_Clear();
		return false;
	}
	long long v = PyLong_AsLongLong(num);
	if (PyErr_Occurred())
	{
		PyErr_Clear();
		unsigned long long uv = PyLong_AsUnsignedLongLong(num);
		Py_DECREF(num);
		if (PyErr_Occurred())
		{
			PyErr_Clear();
			return false;
		}
		*out = static_cast<long long>(uv);
		return true;
	}
	Py_DECREF(num);
	*out = v;
	return true;
}

static bool M2PyObject_ToUnsigned64(PyObject* obj, unsigned long long* out)
{
	if (!obj || !out)
		return false;
	PyErr_Clear();
	if (PyLong_Check(obj))
	{
		unsigned long long v = PyLong_AsUnsignedLongLong(obj);
		if (PyErr_Occurred())
		{
			PyErr_Clear();
			long long sv = PyLong_AsLongLong(obj);
			if (PyErr_Occurred())
			{
				PyErr_Clear();
				return false;
			}
			v = static_cast<unsigned long long>(sv);
		}
		*out = v;
		return true;
	}
	if (PyFloat_Check(obj))
	{
		*out = static_cast<unsigned long long>(PyFloat_AsDouble(obj));
		if (PyErr_Occurred())
		{
			PyErr_Clear();
			return false;
		}
		return true;
	}
	PyObject* num = PyNumber_Long(obj);
	if (!num)
	{
		PyErr_Clear();
		return false;
	}
	unsigned long long v = PyLong_AsUnsignedLongLong(num);
	if (PyErr_Occurred())
	{
		PyErr_Clear();
		long long sv = PyLong_AsLongLong(num);
		Py_DECREF(num);
		if (PyErr_Occurred())
		{
			PyErr_Clear();
			return false;
		}
		*out = static_cast<unsigned long long>(sv);
		return true;
	}
	Py_DECREF(num);
	*out = v;
	return true;
}

PyObject* Py_BadArgument()
{
	PyErr_BadArgument();
	return NULL;
}

PyObject* Py_BuildException (const char* c_pszErr, ...)
{
	if (!c_pszErr)
	{
		PyErr_Clear();
	}
	else
	{
		char szErrBuf[512 + 1];
		va_list args;
		va_start (args, c_pszErr);
		vsnprintf (szErrBuf, sizeof (szErrBuf), c_pszErr, args);
		va_end (args);

		PyErr_SetString (PyExc_RuntimeError, szErrBuf);
	}

	return Py_BuildNone();
}


// FINALFORM_V6: build a Python unicode string from UTF-8 or legacy Metin2 ANSI bytes.
// Python 3's Py_BuildValue("s") assumes UTF-8 and raises UnicodeDecodeError on
// CP1253/CP949 item names. This helper never leaves a UnicodeDecodeError pending.
PyObject* Py_BuildM2String(const char* c_szText)
{
    if (!c_szText)
        return PyUnicode_FromString("");

    const Py_ssize_t len = (Py_ssize_t)strlen(c_szText);
    PyObject* obj = PyUnicode_DecodeUTF8(c_szText, len, "strict");
    if (obj)
        return obj;
    PyErr_Clear();

#ifdef _WIN32
    // Prefer Greek first because this project uses locale/gr and the failing bytes
    // in the logs are CP1253 item names. Then try the common legacy pages.
    const UINT codepages[] = { 1253, CP_ACP, 1252, 1250, 1251, 1254, 949 };
    for (UINT cp : codepages)
    {
        int wlen = MultiByteToWideChar(cp, MB_ERR_INVALID_CHARS, c_szText, (int)len, NULL, 0);
        if (wlen <= 0)
        {
            // Some Windows single-byte pages do not like MB_ERR_INVALID_CHARS.
            wlen = MultiByteToWideChar(cp, 0, c_szText, (int)len, NULL, 0);
        }
        if (wlen > 0)
        {
            std::wstring wide;
            wide.resize(wlen);
            int out = MultiByteToWideChar(cp, 0, c_szText, (int)len, &wide[0], wlen);
            if (out > 0)
                return PyUnicode_FromWideChar(wide.c_str(), out);
        }
    }
#endif

    obj = PyUnicode_DecodeLatin1(c_szText, len, "replace");
    if (obj)
        return obj;
    PyErr_Clear();
    return PyUnicode_FromString("");
}


// FINALFORM_V8_GODMOVE: build Python tuples containing legacy Metin2 text safely.
static PyObject* M2TupleNewChecked(Py_ssize_t n)
{
    return PyTuple_New(n);
}

PyObject* Py_BuildM2Tuple_s(const char* s)
{
    PyObject* tuple = M2TupleNewChecked(1);
    if (!tuple)
        return NULL;
    PyObject* o0 = Py_BuildM2String(s);
    if (!o0)
    {
        Py_DECREF(tuple);
        return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    return tuple;
}

PyObject* Py_BuildM2Tuple_is(int i, const char* s)
{
    PyObject* tuple = M2TupleNewChecked(2);
    if (!tuple)
        return NULL;
    PyObject* o0 = PyLong_FromLong(i);
    PyObject* o1 = Py_BuildM2String(s);
    if (!o0 || !o1)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    return tuple;
}

PyObject* Py_BuildM2Tuple_iis(int i1v, int i2v, const char* s)
{
    PyObject* tuple = M2TupleNewChecked(3);
    if (!tuple)
        return NULL;
    PyObject* o0 = PyLong_FromLong(i1v);
    PyObject* o1 = PyLong_FromLong(i2v);
    PyObject* o2 = Py_BuildM2String(s);
    if (!o0 || !o1 || !o2)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_XDECREF(o2); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    PyTuple_SET_ITEM(tuple, 2, o2);
    return tuple;
}

PyObject* Py_BuildM2Tuple_si(const char* s, int i)
{
    PyObject* tuple = M2TupleNewChecked(2);
    if (!tuple)
        return NULL;
    PyObject* s0 = Py_BuildM2String(s);
    PyObject* i1 = PyLong_FromLong(i);
    if (!s0 || !i1)
    {
        Py_XDECREF(s0); Py_XDECREF(i1); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, s0);
    PyTuple_SET_ITEM(tuple, 1, i1);
    return tuple;
}

PyObject* Py_BuildM2Tuple_sii(const char* s, int i1v, int i2v)
{
    PyObject* tuple = M2TupleNewChecked(3);
    if (!tuple)
        return NULL;
    PyObject* s0 = Py_BuildM2String(s);
    PyObject* i1 = PyLong_FromLong(i1v);
    PyObject* i2 = PyLong_FromLong(i2v);
    if (!s0 || !i1 || !i2)
    {
        Py_XDECREF(s0); Py_XDECREF(i1); Py_XDECREF(i2); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, s0);
    PyTuple_SET_ITEM(tuple, 1, i1);
    PyTuple_SET_ITEM(tuple, 2, i2);
    return tuple;
}

PyObject* Py_BuildM2Tuple_sisi(const char* s1, int i1v, const char* s2, int i2v)
{
    PyObject* tuple = M2TupleNewChecked(4);
    if (!tuple)
        return NULL;
    PyObject* o0 = Py_BuildM2String(s1);
    PyObject* o1 = PyLong_FromLong(i1v);
    PyObject* o2 = Py_BuildM2String(s2);
    PyObject* o3 = PyLong_FromLong(i2v);
    if (!o0 || !o1 || !o2 || !o3)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_XDECREF(o2); Py_XDECREF(o3); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    PyTuple_SET_ITEM(tuple, 2, o2);
    PyTuple_SET_ITEM(tuple, 3, o3);
    return tuple;
}


PyObject* Py_BuildM2Tuple_iss(int i, const char* s1, const char* s2)
{
    PyObject* tuple = M2TupleNewChecked(3);
    if (!tuple)
        return NULL;
    PyObject* o0 = PyLong_FromLong(i);
    PyObject* o1 = Py_BuildM2String(s1);
    PyObject* o2 = Py_BuildM2String(s2);
    if (!o0 || !o1 || !o2)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_XDECREF(o2); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    PyTuple_SET_ITEM(tuple, 2, o2);
    return tuple;
}

PyObject* Py_BuildM2Tuple_isss(int i, const char* s1, const char* s2, const char* s3)
{
    PyObject* tuple = M2TupleNewChecked(4);
    if (!tuple)
        return NULL;
    PyObject* o0 = PyLong_FromLong(i);
    PyObject* o1 = Py_BuildM2String(s1);
    PyObject* o2 = Py_BuildM2String(s2);
    PyObject* o3 = Py_BuildM2String(s3);
    if (!o0 || !o1 || !o2 || !o3)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_XDECREF(o2); Py_XDECREF(o3); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    PyTuple_SET_ITEM(tuple, 2, o2);
    PyTuple_SET_ITEM(tuple, 3, o3);
    return tuple;
}

PyObject* Py_BuildM2Tuple_sissii(const char* s1, int i1, const char* s2, const char* s3, int i2, int i3)
{
    PyObject* tuple = M2TupleNewChecked(6);
    if (!tuple)
        return NULL;
    PyObject* o0 = Py_BuildM2String(s1);
    PyObject* o1 = PyLong_FromLong(i1);
    PyObject* o2 = Py_BuildM2String(s2);
    PyObject* o3 = Py_BuildM2String(s3);
    PyObject* o4 = PyLong_FromLong(i2);
    PyObject* o5 = PyLong_FromLong(i3);
    if (!o0 || !o1 || !o2 || !o3 || !o4 || !o5)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_XDECREF(o2); Py_XDECREF(o3); Py_XDECREF(o4); Py_XDECREF(o5); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    PyTuple_SET_ITEM(tuple, 2, o2);
    PyTuple_SET_ITEM(tuple, 3, o3);
    PyTuple_SET_ITEM(tuple, 4, o4);
    PyTuple_SET_ITEM(tuple, 5, o5);
    return tuple;
}

PyObject* Py_BuildM2Tuple_ssssii(const char* s1, const char* s2, const char* s3, const char* s4, int i1, int i2)
{
    PyObject* tuple = M2TupleNewChecked(6);
    if (!tuple)
        return NULL;
    PyObject* o0 = Py_BuildM2String(s1);
    PyObject* o1 = Py_BuildM2String(s2);
    PyObject* o2 = Py_BuildM2String(s3);
    PyObject* o3 = Py_BuildM2String(s4);
    PyObject* o4 = PyLong_FromLong(i1);
    PyObject* o5 = PyLong_FromLong(i2);
    if (!o0 || !o1 || !o2 || !o3 || !o4 || !o5)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_XDECREF(o2); Py_XDECREF(o3); Py_XDECREF(o4); Py_XDECREF(o5); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    PyTuple_SET_ITEM(tuple, 2, o2);
    PyTuple_SET_ITEM(tuple, 3, o3);
    PyTuple_SET_ITEM(tuple, 4, o4);
    PyTuple_SET_ITEM(tuple, 5, o5);
    return tuple;
}

PyObject* Py_BuildM2Tuple_sPsi(const char* s1, const void* p1, const char* s2, int i2v)
{
    PyObject* tuple = M2TupleNewChecked(4);
    if (!tuple)
        return NULL;
    PyObject* o0 = Py_BuildM2String(s1);
    PyObject* o1 = PyLong_FromUnsignedLongLong((unsigned long long)(uintptr_t)p1);
    PyObject* o2 = Py_BuildM2String(s2);
    PyObject* o3 = PyLong_FromLong(i2v);
    if (!o0 || !o1 || !o2 || !o3)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_XDECREF(o2); Py_XDECREF(o3); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    PyTuple_SET_ITEM(tuple, 2, o2);
    PyTuple_SET_ITEM(tuple, 3, o3);
    return tuple;
}

PyObject* Py_BuildM2Tuple_sff(const char* s, float f1v, float f2v)
{
    PyObject* tuple = M2TupleNewChecked(3);
    if (!tuple)
        return NULL;
    PyObject* o0 = Py_BuildM2String(s);
    PyObject* o1 = PyFloat_FromDouble((double)f1v);
    PyObject* o2 = PyFloat_FromDouble((double)f2v);
    if (!o0 || !o1 || !o2)
    {
        Py_XDECREF(o0); Py_XDECREF(o1); Py_XDECREF(o2); Py_DECREF(tuple); return NULL;
    }
    PyTuple_SET_ITEM(tuple, 0, o0);
    PyTuple_SET_ITEM(tuple, 1, o1);
    PyTuple_SET_ITEM(tuple, 2, o2);
    return tuple;
}

PyObject* Py_BuildNone()
{
	Py_INCREF (Py_None);
	return Py_None;
}

void Py_ReleaseNone()
{
	Py_DECREF (Py_None);
}

bool PyTuple_GetObject (PyObject* poArgs, int pos, PyObject** ret)
{
	if (pos >= PyTuple_Size (poArgs))
	{
		return false;
	}

	PyObject* poItem = PyTuple_GetItem (poArgs, pos);

	if (!poItem)
	{
		return false;
	}

	*ret = poItem;
	return true;
}

bool PyTuple_GetLong (PyObject* poArgs, int pos, long* ret)
{
	if (pos >= PyTuple_Size (poArgs))
		return false;
	PyObject* poItem = PyTuple_GetItem (poArgs, pos);
	long long v = 0;
	if (!M2PyObject_ToSigned64(poItem, &v))
		return false;
	*ret = static_cast<long>(v);
	return true;
}

bool PyTuple_GetDouble (PyObject* poArgs, int pos, double* ret)
{
	if (pos >= PyTuple_Size (poArgs))
	{
		return false;
	}

	PyObject* poItem = PyTuple_GetItem (poArgs, pos);

	if (!poItem)
	{
		return false;
	}

	*ret = PyFloat_AsDouble (poItem);
	return true;
}

bool PyTuple_GetFloat (PyObject* poArgs, int pos, float* ret)
{
	if (pos >= PyTuple_Size (poArgs))
	{
		return false;
	}

	PyObject* poItem = PyTuple_GetItem (poArgs, pos);

	if (!poItem)
	{
		return false;
	}

	*ret = float (PyFloat_AsDouble (poItem));
	return true;
}

bool PyTuple_GetByte (PyObject* poArgs, int pos, unsigned char* ret)
{
	int val;
	bool result = PyTuple_GetInteger (poArgs, pos, &val);
	*ret = unsigned char (val);
	return result;
}

bool PyTuple_GetInteger (PyObject* poArgs, int pos, unsigned char* ret)
{
	int val;
	bool result = PyTuple_GetInteger (poArgs, pos, &val);
	*ret = unsigned char (val);
	return result;
}

bool PyTuple_GetInteger (PyObject* poArgs, int pos, WORD* ret)
{
	int val;
	bool result = PyTuple_GetInteger (poArgs, pos, &val);
	*ret = WORD (val);
	return result;
}

bool PyTuple_GetInteger (PyObject* poArgs, int pos, int* ret)
{
	if (pos >= PyTuple_Size (poArgs))
		return false;
	PyObject* poItem = PyTuple_GetItem (poArgs, pos);
	long long v = 0;
	if (!M2PyObject_ToSigned64(poItem, &v))
		return false;
	*ret = static_cast<int>(v);
	return true;
}

bool PyTuple_GetLongLong (PyObject* poArgs, int pos, long long* ret)
{
	if (pos >= PyTuple_Size (poArgs))
		return false;
	PyObject* poItem = PyTuple_GetItem (poArgs, pos);
	return M2PyObject_ToSigned64(poItem, ret);
}

bool PyTuple_GetUnsignedLong (PyObject* poArgs, int pos, unsigned long* ret)
{
	if (pos >= PyTuple_Size (poArgs))
		return false;
	PyObject* poItem = PyTuple_GetItem (poArgs, pos);
	unsigned long long v = 0;
	if (!M2PyObject_ToUnsigned64(poItem, &v))
		return false;
	*ret = static_cast<unsigned long>(v);
	return true;
}

bool PyTuple_GetUnsignedInteger (PyObject* poArgs, int pos, unsigned int* ret)
{
	if (pos >= PyTuple_Size (poArgs))
		return false;
	PyObject* poItem = PyTuple_GetItem (poArgs, pos);
	unsigned long long v = 0;
	if (!M2PyObject_ToUnsigned64(poItem, &v))
		return false;
	*ret = static_cast<unsigned int>(v);
	return true;
}

bool PyTuple_GetUnsignedLongLong (PyObject* poArgs, int pos, unsigned long long* ret)
{
	if (pos >= PyTuple_Size (poArgs))
		return false;
	PyObject* poItem = PyTuple_GetItem (poArgs, pos);
	return M2PyObject_ToUnsigned64(poItem, ret);
}


bool PyTuple_GetString (PyObject* poArgs, int pos, char** ret)
{
	if (pos >= PyTuple_Size (poArgs))
	{
		return false;
	}

	PyObject* poItem = PyTuple_GetItem (poArgs, pos);

	if (!poItem)
	{
		return false;
	}

	if (!PyUnicode_Check (poItem))
	{
		return false;
	}

	const char* utf8 = PyUnicode_AsUTF8 (poItem);
	if (!utf8)
	{
		return false;
	}

	*ret = const_cast<char*> (utf8);
	return true;
}

bool PyTuple_GetBoolean (PyObject* poArgs, int pos, bool* ret)
{
	if (pos >= PyTuple_Size (poArgs))
		return false;
	PyObject* poItem = PyTuple_GetItem (poArgs, pos);
	long long v = 0;
	if (!M2PyObject_ToSigned64(poItem, &v))
		return false;
	*ret = (v != 0);
	return true;
}

bool PyCallClassMemberFunc (PyObject* poClass, PyObject* poFunc, PyObject* poArgs)
{
	PyObject* poRet;

	if (!poClass)
	{
		Py_XDECREF (poArgs);
		return false;
	}

	if (!__PyCallClassMemberFunc (poClass, poFunc, poArgs, &poRet))
	{
		return false;
	}

	Py_DECREF (poRet);
	return true;
}

bool PyCallClassMemberFunc (PyObject* poClass, const char* c_szFunc, PyObject* poArgs)
{
	PyObject* poRet;

	if (!poClass)
	{
		Py_XDECREF (poArgs);
		return false;
	}

	if (!__PyCallClassMemberFunc_ByCString (poClass, c_szFunc, poArgs, &poRet))
	{
		return false;
	}

	Py_DECREF (poRet);
	return true;
}

bool PyCallClassMemberFunc_ByPyString (PyObject* poClass, PyObject* poFuncName, PyObject* poArgs)
{
	PyObject* poRet;

	if (!poClass)
	{
		Py_XDECREF (poArgs);
		return false;
	}

	if (!__PyCallClassMemberFunc_ByPyString (poClass, poFuncName, poArgs, &poRet))
	{
		return false;
	}

	Py_DECREF (poRet);
	return true;
}

bool PyCallClassMemberFunc (PyObject* poClass, const char* c_szFunc, PyObject* poArgs, bool* pisRet)
{
	PyObject* poRet;

	if (!__PyCallClassMemberFunc_ByCString (poClass, c_szFunc, poArgs, &poRet))
	{
		return false;
	}

	if (PyNumber_Check (poRet))
	{
		long long retValue = 0;
		*pisRet = M2PyObject_ToSigned64(poRet, &retValue) ? (retValue != 0) : true;
	}
	else
	{
		*pisRet = true;
	}

	Py_DECREF (poRet);
	return true;
}

bool PyCallClassMemberFunc (PyObject* poClass, const char* c_szFunc, PyObject* poArgs, long* plRetValue)
{
	PyObject* poRet;

	if (!__PyCallClassMemberFunc_ByCString (poClass, c_szFunc, poArgs, &poRet))
	{
		return false;
	}

	if (PyNumber_Check (poRet))
	{
		long long retValue = 0;
		if (!M2PyObject_ToSigned64(poRet, &retValue))
			return false;
		*plRetValue = static_cast<long>(retValue);
		Py_DECREF (poRet);
		return true;
	}

	Py_DECREF (poRet);
	return false;
}

bool __PyCallClassMemberFunc_ByCString (PyObject* poClass, const char* c_szFunc, PyObject* poArgs, PyObject** ppoRet)
{
	if (!poClass)
	{
		Py_XDECREF (poArgs);
		return false;
	}

	PyObject* poFunc = PyObject_GetAttrString (poClass, (char*)c_szFunc);

	if (!poFunc)
	{
		PyErr_Clear();
		Py_XDECREF (poArgs);
		return false;
	}

	if (!PyCallable_Check (poFunc))
	{
		Py_DECREF (poFunc);
		Py_XDECREF (poArgs);
		return false;
	}

	if (!poArgs)
	{
		if (PyErr_Occurred())
			PyErr_Print();
		Py_DECREF (poFunc);
		return false;
	}

	PyObject* poRet = PyObject_CallObject (poFunc, poArgs);

	if (!poRet)
	{
		PyErr_Print();
		Py_DECREF (poFunc);
		Py_XDECREF (poArgs);
		return false;
	}

	*ppoRet = poRet;

	Py_DECREF (poFunc);
	Py_XDECREF (poArgs);
	return true;
}

bool __PyCallClassMemberFunc_ByPyString (PyObject* poClass, PyObject* poFuncName, PyObject* poArgs, PyObject** ppoRet)
{
	if (!poClass)
	{
		Py_XDECREF (poArgs);
		return false;
	}

	PyObject* poFunc = PyObject_GetAttr (poClass, poFuncName);

	if (!poFunc)
	{
		PyErr_Clear();
		Py_XDECREF (poArgs);
		return false;
	}

	if (!PyCallable_Check (poFunc))
	{
		Py_DECREF (poFunc);
		Py_XDECREF (poArgs);
		return false;
	}

	if (!poArgs)
	{
		if (PyErr_Occurred())
			PyErr_Print();
		Py_DECREF (poFunc);
		return false;
	}

	PyObject* poRet = PyObject_CallObject (poFunc, poArgs);

	if (!poRet)
	{
		PyErr_Print();
		Py_DECREF (poFunc);
		Py_XDECREF (poArgs);
		return false;
	}

	*ppoRet = poRet;

	Py_DECREF (poFunc);
	Py_XDECREF (poArgs);
	return true;
}

bool __PyCallClassMemberFunc (PyObject* poClass, PyObject* poFunc, PyObject* poArgs, PyObject** ppoRet)
{
	if (!poClass)
	{
		Py_XDECREF (poArgs);
		return false;
	}

	if (!poFunc)
	{
		PyErr_Clear();
		Py_XDECREF (poArgs);
		return false;
	}

	if (!PyCallable_Check (poFunc))
	{
		Py_DECREF (poFunc);
		Py_XDECREF (poArgs);
		return false;
	}

	if (!poArgs)
	{
		if (PyErr_Occurred())
			PyErr_Print();
		Py_DECREF (poFunc);
		return false;
	}

	PyObject* poRet = PyObject_CallObject (poFunc, poArgs);

	if (!poRet)
	{
		PyErr_Print();
		Py_DECREF (poFunc);
		Py_XDECREF (poArgs);
		return false;
	}

	*ppoRet = poRet;

	Py_DECREF (poFunc);
	Py_XDECREF (poArgs);
	return true;
}

