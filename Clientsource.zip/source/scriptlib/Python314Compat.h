#pragma once
#ifndef M2_CLIENT_PYTHON314_COMPAT_H
#define M2_CLIENT_PYTHON314_COMPAT_H

/*
    Python 3.x compatibility include for the client scriptlib.
    This header intentionally DOES NOT define PyString/Py_InitModule bodies itself.
    The single implementation lives in PythonUtils.h, protected by
    M2_PYTHON3_LEGACY_COMPAT_API_DEFINED, so including Python314Compat.h and
    PythonUtils.h together cannot create duplicate function bodies.
*/

#ifndef PY_SSIZE_T_CLEAN
#define PY_SSIZE_T_CLEAN
#endif

#ifndef Py_NO_ENABLE_SHARED
#define Py_NO_ENABLE_SHARED 1
#endif

#include <new>
#include <cstddef>
#include <stdint.h>

#ifdef _DEBUG
#   undef _DEBUG
#   include "../../../Extern/client/include/python/Python.h"
#   define _DEBUG
#else
#   include "../../../Extern/client/include/python/Python.h"
#endif

#include "../../../Extern/client/include/python/frameobject.h"
#include "../../../Extern/client/include/python/marshal.h"
#include "../../../Extern/client/include/python/compile.h"
#include "../../../Extern/client/include/python/errcode.h"

#include "PythonUtils.h"

#endif /* M2_CLIENT_PYTHON314_COMPAT_H */
