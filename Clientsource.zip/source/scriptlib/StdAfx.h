#pragma once

#include "../eterlib/StdAfx.h"
#include "../etergrnlib/StdAfx.h"

#include <AttackDefines.h>
#ifdef AT
#undef AT
#endif

#include "Python314Compat.h"

#ifdef BYTE
#undef BYTE
#endif
#ifdef AT
#undef AT
#endif

#include "PythonUtils.h"
#include "PythonLauncher.h"
#include "PythonMarshal.h"
#include "Resource.h"

void initdbg();
