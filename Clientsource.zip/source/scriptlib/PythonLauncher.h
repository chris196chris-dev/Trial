﻿#pragma once
#include "../../../Extern/client/include/python/frameobject.h"

#include "../eterbase/Singleton.h"
#include <cstdio>

void Traceback();
int TraceFunc(PyObject* obj, PyFrameObject* f, int what, PyObject* arg);

class CPythonLauncher : public CSingleton<CPythonLauncher>
{
	public:
		CPythonLauncher();
		virtual ~CPythonLauncher();

		void Clear();

		bool Create (const char* c_szProgramName = "eter.python");
		bool RunLine (const char* c_szLine);
        bool RunFile (const char* c_szFileName);
		bool RunMemoryTextFile (const char* c_szFileName, size_t uFileSize, const void* c_pvFileData);

	protected:
		PyObject* m_poModule;
		PyObject* m_poDic;
};

