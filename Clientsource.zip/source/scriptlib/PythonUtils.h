﻿#pragma once
#ifndef M2_CLIENT_PYTHONUTILS_H
#define M2_CLIENT_PYTHONUTILS_H

#include <new>
#include <cstddef>
#include <stdint.h>

#define SET_EXCEPTION(x) PyErr_SetString(PyExc_RuntimeError, #x)

bool PyTuple_GetString(PyObject* poArgs, int pos, char** ret);
bool PyTuple_GetInteger(PyObject* poArgs, int pos, unsigned char* ret);
bool PyTuple_GetInteger(PyObject* poArgs, int pos, int* ret);
bool PyTuple_GetInteger(PyObject* poArgs, int pos, WORD* ret);
bool PyTuple_GetByte(PyObject* poArgs, int pos, unsigned char* ret);
bool PyTuple_GetUnsignedInteger(PyObject* poArgs, int pos, unsigned int* ret);
bool PyTuple_GetLong(PyObject* poArgs, int pos, long* ret);
bool PyTuple_GetLongLong(PyObject* poArgs, int pos, long long* ret);
bool PyTuple_GetUnsignedLong(PyObject* poArgs, int pos, unsigned long* ret);
bool PyTuple_GetUnsignedLongLong(PyObject* poArgs, int pos, unsigned long long* ret);
bool PyTuple_GetFloat(PyObject* poArgs, int pos, float* ret);
bool PyTuple_GetDouble(PyObject* poArgs, int pos, double* ret);
bool PyTuple_GetObject(PyObject* poArgs, int pos, PyObject** ret);
bool PyTuple_GetBoolean(PyObject* poArgs, int pos, bool* ret);

template <typename T>
bool PyTuple_GetPointer(PyObject* poArgs, int pos, T** ret) {
    unsigned long long tmp = 0;
    if (!PyTuple_GetUnsignedLongLong(poArgs, pos, &tmp))
        return false;
    *ret = reinterpret_cast<T*>(static_cast<uintptr_t>(tmp));
    return true;
}

bool PyCallClassMemberFunc(PyObject* poClass, const char* c_szFunc, PyObject* poArgs);
bool PyCallClassMemberFunc(PyObject* poClass, const char* c_szFunc, PyObject* poArgs, bool* pisRet);
bool PyCallClassMemberFunc(PyObject* poClass, const char* c_szFunc, PyObject* poArgs, long* plRetValue);

bool PyCallClassMemberFunc_ByPyString(PyObject* poClass, PyObject* poFuncName, PyObject* poArgs);
bool PyCallClassMemberFunc(PyObject* poClass, PyObject* poFunc, PyObject* poArgs);

PyObject* Py_BuildException(const char* c_pszErr = NULL, ...);
PyObject* Py_BadArgument();
PyObject* Py_BuildNone();
PyObject* Py_BuildEmptyTuple();
// FINALFORM_V6: build a Python unicode string from client text without crashing on legacy ANSI bytes.
PyObject* Py_BuildM2String(const char* c_szText);

// FINALFORM_V8_GODMOVE: tuple builders that decode legacy Metin2 strings safely.
PyObject* Py_BuildM2Tuple_s(const char* s);
PyObject* Py_BuildM2Tuple_is(int i, const char* s);
PyObject* Py_BuildM2Tuple_iis(int i1, int i2, const char* s);
PyObject* Py_BuildM2Tuple_si(const char* s, int i);
PyObject* Py_BuildM2Tuple_sii(const char* s, int i1, int i2);
PyObject* Py_BuildM2Tuple_sisi(const char* s1, int i1, const char* s2, int i2);
PyObject* Py_BuildM2Tuple_iss(int i, const char* s1, const char* s2);
PyObject* Py_BuildM2Tuple_isss(int i, const char* s1, const char* s2, const char* s3);
PyObject* Py_BuildM2Tuple_sissii(const char* s1, int i1, const char* s2, const char* s3, int i2, int i3);
PyObject* Py_BuildM2Tuple_ssssii(const char* s1, const char* s2, const char* s3, const char* s4, int i1, int i2);
PyObject* Py_BuildM2Tuple_sPsi(const char* s1, const void* p1, const char* s2, int i2);
PyObject* Py_BuildM2Tuple_sff(const char* s, float f1, float f2);

#if PY_MAJOR_VERSION >= 3

#ifndef PyInt_Check
#   define PyInt_Check PyLong_Check
#endif
#ifndef PyInt_AsLong
#   define PyInt_AsLong PyLong_AsLong
#endif
#ifndef PyInt_FromLong
#   define PyInt_FromLong PyLong_FromLong
#endif
#ifndef PyString_InternFromString
#   define PyString_InternFromString PyUnicode_InternFromString
#endif
#ifndef PyString_FromString
#   define PyString_FromString PyUnicode_FromString
#endif

#ifndef M2_PYTHON3_LEGACY_COMPAT_API_DEFINED
#define M2_PYTHON3_LEGACY_COMPAT_API_DEFINED

#ifdef PyString_Check
#   undef PyString_Check
#endif
#ifdef PyString_AsString
#   undef PyString_AsString
#endif
#ifdef PyString_AS_STRING
#   undef PyString_AS_STRING
#endif
#ifdef PyString_FromStringAndSize
#   undef PyString_FromStringAndSize
#endif
#ifdef PyObject_AsCharBuffer
#   undef PyObject_AsCharBuffer
#endif
#ifdef Py_InitModule
#   undef Py_InitModule
#endif

inline int PyString_Check(PyObject* obj)
{
    return obj && (PyUnicode_Check(obj) || PyBytes_Check(obj));
}

inline char* PyString_AsString(PyObject* obj)
{
    if (!obj)
    {
        PyErr_SetString(PyExc_TypeError, "NULL Python object");
        return NULL;
    }

    if (PyUnicode_Check(obj))
        return const_cast<char*>(PyUnicode_AsUTF8(obj));

    if (PyBytes_Check(obj))
        return PyBytes_AsString(obj);

    PyErr_SetString(PyExc_TypeError, "expected str or bytes object");
    return NULL;
}

inline char* PyString_AS_STRING(PyObject* obj)
{
    return PyString_AsString(obj);
}

inline PyObject* PyString_FromStringAndSize(const char* str, Py_ssize_t size)
{
    return PyBytes_FromStringAndSize(str, size);
}

inline int PyObject_AsCharBuffer(PyObject* obj, const char** buffer, Py_ssize_t* len)
{
    if (!obj || !buffer || !len)
    {
        PyErr_SetString(PyExc_TypeError, "invalid buffer request");
        return -1;
    }

    if (PyUnicode_Check(obj))
    {
        *buffer = PyUnicode_AsUTF8AndSize(obj, len);
        return *buffer ? 0 : -1;
    }

    if (PyBytes_Check(obj))
        return PyBytes_AsStringAndSize(obj, const_cast<char**>(buffer), len);

    PyErr_SetString(PyExc_TypeError, "expected str or bytes");
    return -1;
}

inline PyObject* Py_InitModule(const char* name, PyMethodDef* methods)
{
    PyModuleDef* moduleDef = new (std::nothrow) PyModuleDef{
        PyModuleDef_HEAD_INIT,
        name,
        NULL,
        -1,
        methods,
        NULL,
        NULL,
        NULL,
        NULL
    };

    if (!moduleDef)
        return PyErr_NoMemory();

    PyObject* module = PyModule_Create(moduleDef);
    if (!module)
    {
        delete moduleDef;
        return NULL;
    }

    PyObject* modules = PyImport_GetModuleDict();
    if (PyDict_SetItemString(modules, name, module) < 0)
    {
        Py_DECREF(module);
        delete moduleDef;
        return NULL;
    }

    Py_DECREF(module);
    return PyDict_GetItemString(modules, name);
}

#endif /* M2_PYTHON3_LEGACY_COMPAT_API_DEFINED */
#endif /* PY_MAJOR_VERSION >= 3 */

#endif /* M2_CLIENT_PYTHONUTILS_H */
