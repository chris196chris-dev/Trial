#include "StdAfx.h"
#include "Locale.h"
#include "PythonApplication.h"
#include "resource.h"
#include "../eterbase/CRC32.h"
#include "../eterpack/EterPackManager.h"
#include <windowsx.h>

char MULTI_LOCALE_PATH[256] = LOCALE_COUNTRY;
char MULTI_LOCALE_NAME[256] = LOCALE_COUNTRY_ENTER;
int LOCALE_CODEPAGE = LOCALE_PASSES;

void LoadConfig()
{
	LOCALE_CODEPAGE = LOCALE_PASSES;
	strcpy (MULTI_LOCALE_NAME, LOCALE_COUNTRY_ENTER);
	sprintf (MULTI_LOCALE_PATH, "locale/%s", MULTI_LOCALE_NAME);
}

unsigned GetGuildLastExp (int level)
{
	static const int GUILD_LEVEL_MAX = 20;
	static DWORD GUILD_EXP_LIST[GUILD_LEVEL_MAX + 1] =
	{
		0,
		15000UL,
		45000UL,
		90000UL,
		160000UL,
		235000UL,
		325000UL,
		430000UL,
		550000UL,
		685000UL,
		835000UL,
		1000000UL,
		1500000UL,
		2100000UL,
		2800000UL,
		3600000UL,
		4500000UL,
		6500000UL,
		8000000UL,
		10000000UL,
		42000000UL
	};

	if (level < 0 && level >= GUILD_LEVEL_MAX)
	{
		return 0;
	}

	return GUILD_EXP_LIST[level];
}

int GetSkillPower (unsigned level)
{
	static const unsigned SKILL_POWER_NUM = 50;
	if (level >= SKILL_POWER_NUM)
	{
		return 0;
	}

	static unsigned SKILL_POWERS[SKILL_POWER_NUM] =
	{
		0,
		5,  6,  8, 10, 12,
		14, 16, 18, 20, 22,
		24, 26, 28, 30, 32,
		34, 36, 38, 40, 50,
		52, 54, 56, 58, 60,
		63, 66, 69, 72, 82,
		85, 88, 91, 94, 98,
		102, 106, 110, 115, 125,
		125,
	};
	return SKILL_POWERS[level];
}

unsigned int GetCodePage()
{
	return LOCALE_CODEPAGE;
}

const char* GetLocalePath()
{
	return MULTI_LOCALE_PATH;
}

int StringCompareCI (LPCSTR szStringLeft, LPCSTR szStringRight, size_t sizeLength)
{
	return _strnicmp (szStringLeft, szStringRight, sizeLength);
}

