#include "stdafx.h"
#include "pythoncharactermanager.h"
#include "PythonBackground.h"
#include "PythonNonPlayer.h"
//MULTI_LANGUAGE
#include "PythonTextTail.h"
//MULTI_LANGUAGE
#include "AbstractPlayer.h"
#include "packet.h"

#include "../eterlib/Camera.h"

int CHAR_STAGE_VIEW_BOUND = 200 * 100;

struct FCharacterManagerCharacterInstanceUpdate
{
	inline void operator() (const std::pair<DWORD, CInstanceBase*>& cr_Pair)
	{
		cr_Pair.second->Update();
	}
};

void CPythonCharacterManager::AdjustCollisionWithOtherObjects (CActorInstance* pInst)
{
	if (!pInst->IsPC())
	{
		return;
	}

	CPythonCharacterManager& rkChrMgr = CPythonCharacterManager::Instance();
	for (auto i = rkChrMgr.CharacterInstanceBegin(); i != rkChrMgr.CharacterInstanceEnd(); ++i)
	{
		CInstanceBase* pkInstEach = *i;
		CActorInstance* rkActorEach = pkInstEach->GetGraphicThingInstancePtr();

		if (rkActorEach == pInst)
		{
			continue;
		}

		if (rkActorEach->IsPC() || rkActorEach->IsNPC() || rkActorEach->IsEnemy())
		{
			continue;
		}

		if (pInst->TestPhysicsBlendingCollision (*rkActorEach))
		{
			TPixelPosition curPos;
			pInst->GetPixelPosition (&curPos);
			pInst->SetBlendingPosition (curPos);
			break;
		}
	}
}


void CPythonCharacterManager::EnableSortRendering (bool isEnable)
{
}

void CPythonCharacterManager::InsertPVPKey (DWORD dwVIDSrc, DWORD dwVIDDst)
{
	CInstanceBase::InsertPVPKey (dwVIDSrc, dwVIDDst);

	CInstanceBase* pkInstSrc = GetInstancePtr (dwVIDSrc);
	if (pkInstSrc)
	{
		pkInstSrc->RefreshTextTail();
	}

	CInstanceBase* pkInstDst = GetInstancePtr (dwVIDDst);
	if (pkInstDst)
	{
		pkInstDst->RefreshTextTail();
	}
}

void CPythonCharacterManager::RemovePVPKey (DWORD dwVIDSrc, DWORD dwVIDDst)
{
	CInstanceBase::RemovePVPKey (dwVIDSrc, dwVIDDst);

	CInstanceBase* pkInstSrc = GetInstancePtr (dwVIDSrc);
	if (pkInstSrc)
	{
		pkInstSrc->RefreshTextTail();
	}

	CInstanceBase* pkInstDst = GetInstancePtr (dwVIDDst);
	if (pkInstDst)
	{
		pkInstDst->RefreshTextTail();
	}
}

void CPythonCharacterManager::ChangeGVG (DWORD dwSrcGuildID, DWORD dwDstGuildID)
{
	for (auto itor = m_kAliveInstMap.begin(); itor != m_kAliveInstMap.end(); itor++)
	{
		CInstanceBase* pInstance = itor->second;

		DWORD dwInstanceGuildID = pInstance->GetGuildID();
		if (dwSrcGuildID == dwInstanceGuildID || dwDstGuildID == dwInstanceGuildID)
		{
			pInstance->RefreshTextTail();
		}
	}
}

void CPythonCharacterManager::ClearMainInstance()
{
	m_pkInstMain = NULL;
}

bool CPythonCharacterManager::SetMainInstance (DWORD dwVID)
{
	m_pkInstMain = GetInstancePtr (dwVID);

	if (!m_pkInstMain)
	{
		return false;
	}

	return true;
}

CInstanceBase* CPythonCharacterManager::GetMainInstancePtr()
{
	return m_pkInstMain;
}

void CPythonCharacterManager::GetInfo (std::string* pstInfo)
{
	pstInfo->append ("Actor: ");

	CInstanceBase::GetInfo (pstInfo);

	char szInfo[256];
	sprintf (szInfo, "Container - Live %d, Dead %d", m_kAliveInstMap.size(), m_kDeadInstList.size());
	pstInfo->append (szInfo);
}


bool CPythonCharacterManager::IsCacheMode()
{
	static bool s_isOldCacheMode = false;

	bool isCacheMode = s_isOldCacheMode;
	if (s_isOldCacheMode)
	{
		if (m_kAliveInstMap.size() < 30)
		{
			isCacheMode = false;
		}
	}
	else
	{
		if (m_kAliveInstMap.size() > 40)
		{
			isCacheMode = true;
		}
	}
	s_isOldCacheMode = isCacheMode;

	return isCacheMode;
}

void CPythonCharacterManager::Update()
{
	CInstanceBase::ResetPerformanceCounter();
	CInstanceBase* pkInstMain = GetMainInstancePtr();
	DWORD dwDeadInstCount = 0;
	DWORD dwForceVisibleInstCount = 0;

	auto i = m_kAliveInstMap.begin();
	while (m_kAliveInstMap.end() != i)
	{
		auto c = i++;

		CInstanceBase* pkInstEach = c->second;
		pkInstEach->Update();

		if (pkInstMain)
		{

			if (pkInstEach->IsForceVisible())
			{
				dwForceVisibleInstCount++;
				#ifndef MEMORY_LEAK_FIX
				continue;
				#endif
			}

			int nDistance = int (pkInstEach->NEW_GetDistanceFromDestInstance (*pkInstMain));
			if (nDistance > CHAR_STAGE_VIEW_BOUND + 10)
			{
				__DeleteBlendOutInstance (pkInstEach);
				m_kAliveInstMap.erase (c);
				dwDeadInstCount++;
			}
		}
	}

	UpdateTransform();
	UpdateDeleting();
	__NEW_Pick();


}

void CPythonCharacterManager::ShowPointEffect (DWORD ePoint, DWORD dwVID)
{
	CInstanceBase* pkInstSel = (dwVID == 0xffffffff) ? GetMainInstancePtr() : GetInstancePtr (dwVID);

	if (!pkInstSel)
	{
		return;
	}

	switch (ePoint)
	{
		case POINT_LEVEL:
			pkInstSel->LevelUp();
			break;
		case POINT_LEVEL_STEP:
			pkInstSel->SkillUp();
			break;
	}
}

bool CPythonCharacterManager::RegisterPointEffect (DWORD ePoint, const char* c_szFileName)
{
	if (ePoint >= POINT_MAX_NUM)
	{
		return false;
	}

	CEffectManager& rkEftMgr = CEffectManager::Instance();
	rkEftMgr.RegisterEffect2 (c_szFileName, &m_adwPointEffect[ePoint]);

	return true;
}

void CPythonCharacterManager::UpdateTransform()
{
	CInstanceBase* pMainInstance = GetMainInstancePtr();
	if (pMainInstance)
	{
		CPythonBackground& rkBG = CPythonBackground::Instance();
		for (auto i = m_kAliveInstMap.begin(); i != m_kAliveInstMap.end(); ++i)
		{
			CInstanceBase* pSrcInstance = i->second;

			pSrcInstance->CheckAdvancing();
			if (pSrcInstance->IsPushing())
			{
				rkBG.CheckAdvancing (pSrcInstance);
			}
		}
		rkBG.CheckAdvancing (m_pkInstMain);
	}

	{
		for (auto itor = m_kAliveInstMap.begin(); itor != m_kAliveInstMap.end(); ++itor)
		{
			CInstanceBase* pInstance = itor->second;
			pInstance->Transform();
		}
	}
}
void CPythonCharacterManager::UpdateDeleting()
{
	auto itor = m_kDeadInstList.begin();
	for (; itor != m_kDeadInstList.end();)
	{
		CInstanceBase* pInstance = *itor;

		if (pInstance->UpdateDeleting())
		{
			++itor;
		}
		else
		{
			CInstanceBase::Delete (pInstance);
			itor = m_kDeadInstList.erase (itor);
		}
	}
}

struct FCharacterManagerCharacterInstanceDeform
{
	inline void operator() (const std::pair<DWORD, CInstanceBase*>& cr_Pair)
	{
		cr_Pair.second->Deform();
	}
};
struct FCharacterManagerCharacterInstanceListDeform
{
	inline void operator() (CInstanceBase* pInstance)
	{
		pInstance->Deform();
	}
};

void CPythonCharacterManager::Deform()
{
	std::for_each (m_kAliveInstMap.begin(), m_kAliveInstMap.end(), FCharacterManagerCharacterInstanceDeform());
	std::for_each (m_kDeadInstList.begin(), m_kDeadInstList.end(), FCharacterManagerCharacterInstanceListDeform());
}




bool CPythonCharacterManager::OLD_GetPickedInstanceVID (DWORD* pdwPickedActorID)
{
	if (!m_pkInstPick)
	{
		return false;
	}

	*pdwPickedActorID = m_pkInstPick->GetVirtualID();
	return true;
}

CInstanceBase* CPythonCharacterManager::OLD_GetPickedInstancePtr()
{
	return m_pkInstPick;
}

D3DXVECTOR2& CPythonCharacterManager::OLD_GetPickedInstPosReference()
{
	return m_v2PickedInstProjPos;
}

bool CPythonCharacterManager::IsRegisteredVID (DWORD dwVID)
{
	if (m_kAliveInstMap.end() == m_kAliveInstMap.find (dwVID))
	{
		return false;
	}

	return true;
}

bool CPythonCharacterManager::IsAliveVID (DWORD dwVID)
{
	return m_kAliveInstMap.find (dwVID) != m_kAliveInstMap.end();
}

bool CPythonCharacterManager::IsDeadVID (DWORD dwVID)
{
	for (auto f = m_kDeadInstList.begin(); f != m_kDeadInstList.end(); ++f)
	{
		if ((*f)->GetVirtualID() == dwVID)
		{
			return true;
		}
	}

	return false;
}

struct LessCharacterInstancePtrRenderOrder
{
	bool operator() (CInstanceBase* pkLeft, CInstanceBase* pkRight)
	{
		return pkLeft->LessRenderOrder (pkRight);
	}
};

struct FCharacterManagerCharacterInstanceRender
{
	inline void operator() (const std::pair<DWORD, CInstanceBase*>& cr_Pair)
	{
		cr_Pair.second->Render();
		cr_Pair.second->RenderTrace();
	}
};
struct FCharacterInstanceRender
{
	inline void operator() (CInstanceBase* pInstance)
	{
		pInstance->Render();
	}
};
struct FCharacterInstanceRenderTrace
{
	inline void operator() (CInstanceBase* pInstance)
	{
		pInstance->RenderTrace();
	}
};


void CPythonCharacterManager::__RenderSortedAliveActorList()
{
	static std::vector<CInstanceBase*> s_kVct_pkInstAliveSort;
	s_kVct_pkInstAliveSort.clear();

	TCharacterInstanceMap& rkMap_pkInstAlive = m_kAliveInstMap;

	for (auto i = rkMap_pkInstAlive.begin(); i != rkMap_pkInstAlive.end(); ++i)
	{
		s_kVct_pkInstAliveSort.push_back (i->second);
	}

	std::sort (s_kVct_pkInstAliveSort.begin(), s_kVct_pkInstAliveSort.end(), LessCharacterInstancePtrRenderOrder());
	std::for_each (s_kVct_pkInstAliveSort.begin(), s_kVct_pkInstAliveSort.end(), FCharacterInstanceRender());
	std::for_each (s_kVct_pkInstAliveSort.begin(), s_kVct_pkInstAliveSort.end(), FCharacterInstanceRenderTrace());
}

void CPythonCharacterManager::__RenderSortedDeadActorList()
{
	static std::vector<CInstanceBase*> s_kVct_pkInstDeadSort;
	s_kVct_pkInstDeadSort.clear();

	TCharacterInstanceList& rkLst_pkInstDead = m_kDeadInstList;

	for (auto i = rkLst_pkInstDead.begin(); i != rkLst_pkInstDead.end(); ++i)
	{
		s_kVct_pkInstDeadSort.push_back (*i);
	}

	std::sort (s_kVct_pkInstDeadSort.begin(), s_kVct_pkInstDeadSort.end(), LessCharacterInstancePtrRenderOrder());
	std::for_each (s_kVct_pkInstDeadSort.begin(), s_kVct_pkInstDeadSort.end(), FCharacterInstanceRender());

}

void CPythonCharacterManager::Render()
{
	STATEMANAGER.SetTexture (0, NULL);
	STATEMANAGER.SetTextureStageState (0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	STATEMANAGER.SetTextureStageState (0, D3DTSS_COLORARG2, D3DTA_CURRENT);
	STATEMANAGER.SetTextureStageState (0, D3DTSS_COLOROP, D3DTOP_MODULATE);
	STATEMANAGER.SetTextureStageState (0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	STATEMANAGER.SetTextureStageState (0, D3DTSS_ALPHAOP, D3DTOP_SELECTARG1);

	STATEMANAGER.SetTexture (1, NULL);
	STATEMANAGER.SetTextureStageState (1, D3DTSS_COLOROP, D3DTOP_DISABLE);
	STATEMANAGER.SetTextureStageState (1, D3DTSS_ALPHAOP, D3DTOP_DISABLE);


	__RenderSortedAliveActorList();
	__RenderSortedDeadActorList();

	CInstanceBase* pkPickedInst = OLD_GetPickedInstancePtr();
	if (pkPickedInst)
	{
		const D3DXVECTOR3& c_rv3Position = pkPickedInst->GetGraphicThingInstanceRef().GetPosition();
		CPythonGraphic::Instance().ProjectPosition (c_rv3Position.x, c_rv3Position.y, c_rv3Position.z, &m_v2PickedInstProjPos.x, &m_v2PickedInstProjPos.y);
	}
}

void CPythonCharacterManager::RenderShadowMainInstance()
{
	CInstanceBase* pkInstMain = GetMainInstancePtr();
	if (pkInstMain)
	{
		pkInstMain->RenderToShadowMap();
	}
}

struct FCharacterManagerCharacterInstanceRenderToShadowMap
{
	inline void operator() (const std::pair<DWORD, CInstanceBase*>& cr_Pair)
	{
		cr_Pair.second->RenderToShadowMap();
	}
};

void CPythonCharacterManager::RenderShadowAllInstances()
{
	std::for_each (m_kAliveInstMap.begin(), m_kAliveInstMap.end(), FCharacterManagerCharacterInstanceRenderToShadowMap());
}

struct FCharacterManagerCharacterInstanceRenderCollision
{
	inline void operator() (const std::pair<DWORD, CInstanceBase*>& cr_Pair)
	{
		cr_Pair.second->RenderCollision();
	}
};

void CPythonCharacterManager::RenderCollision()
{
	std::for_each (m_kAliveInstMap.begin(), m_kAliveInstMap.end(), FCharacterManagerCharacterInstanceRenderCollision());
}

CInstanceBase* CPythonCharacterManager::CreateInstance (const CInstanceBase::SCreateData& c_rkCreateData)
{
	CInstanceBase* pCharacterInstance = RegisterInstance (c_rkCreateData.m_dwVID);
	if (!pCharacterInstance)
	{
		TraceError ("CPythonCharacterManager::CreateInstance: VID[%d] - ALREADY EXIST\n", c_rkCreateData.m_dwVID);
		return NULL;
	}

	if (!pCharacterInstance->Create (c_rkCreateData))
	{
		TraceError ("CPythonCharacterManager::CreateInstance VID[%d] Race[%d]", c_rkCreateData.m_dwVID, c_rkCreateData.m_dwRace);
		DeleteInstance (c_rkCreateData.m_dwVID);
		return NULL;
	}

	if (c_rkCreateData.m_isMain)
	{
		SelectInstance (c_rkCreateData.m_dwVID);
	}

	return (pCharacterInstance);
}

CInstanceBase* CPythonCharacterManager::RegisterInstance (DWORD VirtualID)
{
	auto itor = m_kAliveInstMap.find (VirtualID);

	if (m_kAliveInstMap.end() != itor)
	{
		return NULL;
	}

	CInstanceBase* pCharacterInstance = CInstanceBase::New();
	m_kAliveInstMap.insert (TCharacterInstanceMap::value_type (VirtualID, pCharacterInstance));

	return (pCharacterInstance);
}

void CPythonCharacterManager::DeleteInstance (DWORD dwDelVID)
{
	auto itor = m_kAliveInstMap.find (dwDelVID);

	if (m_kAliveInstMap.end() == itor)
	{
		Tracef ("DeleteCharacterInstance: no vid by %d\n", dwDelVID);
		return;
	}

	CInstanceBase* pkInstDel = itor->second;

	if (pkInstDel == m_pkInstBind)
	{
		m_pkInstBind = NULL;
	}

	if (pkInstDel == m_pkInstMain)
	{
		m_pkInstMain = NULL;
	}

	if (pkInstDel == m_pkInstPick)
	{
		m_pkInstPick = NULL;
	}

	CInstanceBase::Delete (pkInstDel);

	m_kAliveInstMap.erase (itor);
}

void CPythonCharacterManager::__DeleteBlendOutInstance (CInstanceBase* pkInstDel)
{
	pkInstDel->DeleteBlendOut();
	m_kDeadInstList.push_back (pkInstDel);

	IAbstractPlayer& rkPlayer = IAbstractPlayer::GetSingleton();
	rkPlayer.NotifyCharacterDead (pkInstDel->GetVirtualID());
}

void CPythonCharacterManager::DeleteInstanceByFade (DWORD dwVID)
{
	auto f = m_kAliveInstMap.find (dwVID);
	if (m_kAliveInstMap.end() == f)
	{
		return;
	}
	__DeleteBlendOutInstance (f->second);
	m_kAliveInstMap.erase (f);
}

void CPythonCharacterManager::SelectInstance (DWORD VirtualID)
{
	auto itor = m_kAliveInstMap.find (VirtualID);

	if (m_kAliveInstMap.end() == itor)
	{
		Tracef ("SelectCharacterInstance: no vid by %d\n", VirtualID);
		return;
	}

	m_pkInstBind = itor->second;
}

CInstanceBase* CPythonCharacterManager::GetInstancePtr (DWORD VirtualID)
{
	auto itor = m_kAliveInstMap.find (VirtualID);

	if (m_kAliveInstMap.end() == itor)
	{
		return NULL;
	}

	return itor->second;
}

CInstanceBase* CPythonCharacterManager::GetInstancePtrByName (const char* name)
{
	for (auto itor = m_kAliveInstMap.begin(); itor != m_kAliveInstMap.end(); itor++)
	{
		CInstanceBase* pInstance = itor->second;

		if (!strcmp (pInstance->GetNameString(), name))
		{
			return pInstance;
		}
	}

	return NULL;
}

CInstanceBase* CPythonCharacterManager::GetSelectedInstancePtr()
{
	return m_pkInstBind;
}

CInstanceBase* CPythonCharacterManager::FindClickableInstancePtr()
{
	return NULL;
}

void CPythonCharacterManager::__UpdateSortPickedActorList()
{
	__UpdatePickedActorList();
	__SortPickedActorList();
}

void CPythonCharacterManager::__UpdatePickedActorList()
{
	m_kVct_pkInstPicked.clear();

	for (auto i = m_kAliveInstMap.begin(); i != m_kAliveInstMap.end(); ++i)
	{
		CInstanceBase* pkInstEach = i->second;
		if (pkInstEach->CanPickInstance())
		{
			if (pkInstEach->IsDead())
			{
				if (pkInstEach->IntersectBoundingBox())
				{
					m_kVct_pkInstPicked.push_back (pkInstEach);
				}
			}
			else
			{
				if (pkInstEach->IntersectDefendingSphere())
				{
					m_kVct_pkInstPicked.push_back (pkInstEach);
				}
			}
		}
	}
}

struct CInstanceBase_SLessCameraDistance
{
	TPixelPosition m_kPPosEye;

	bool operator() (CInstanceBase* pkInstLeft, CInstanceBase* pkInstRight)
	{
		int nLeftDeadPoint = pkInstLeft->IsDead();
		int nRightDeadPoint = pkInstRight->IsDead();

		if (nLeftDeadPoint < nRightDeadPoint)
		{
			return true;
		}

		if (pkInstLeft->CalculateDistanceSq3d (m_kPPosEye) < pkInstRight->CalculateDistanceSq3d (m_kPPosEye))
		{
			return true;
		}

		return false;
	}
};

void CPythonCharacterManager::__SortPickedActorList()
{
	CCamera* pCamera = CCameraManager::Instance().GetCurrentCamera();
	const D3DXVECTOR3& c_rv3EyePos = pCamera->GetEye();

	CInstanceBase_SLessCameraDistance kLess;
	kLess.m_kPPosEye = TPixelPosition (+c_rv3EyePos.x, -c_rv3EyePos.y, +c_rv3EyePos.z);

	std::sort (m_kVct_pkInstPicked.begin(), m_kVct_pkInstPicked.end(), kLess);
}

void CPythonCharacterManager::__NEW_Pick()
{
	__UpdateSortPickedActorList();

	CInstanceBase* pkInstMain = GetMainInstancePtr();

	{
		for (auto f = m_kVct_pkInstPicked.begin(); f != m_kVct_pkInstPicked.end(); ++f)
		{
			CInstanceBase* pkInstEach = *f;
			if (pkInstEach != pkInstMain && pkInstEach->IntersectBoundingBox())
			{
				if (m_pkInstPick)
					if (m_pkInstPick != pkInstEach)
					{
						m_pkInstPick->OnUnselected();
					}

				if (pkInstEach->CanPickInstance())
				{
					m_pkInstPick = pkInstEach;
					m_pkInstPick->OnSelected();
					return;
				}
			}
		}
	}

	{
		for (auto f = m_kVct_pkInstPicked.begin(); f != m_kVct_pkInstPicked.end(); ++f)
		{
			CInstanceBase* pkInstEach = *f;
			if (pkInstEach != pkInstMain)
			{
				if (m_pkInstPick)
					if (m_pkInstPick != pkInstEach)
					{
						m_pkInstPick->OnUnselected();
					}

				if (pkInstEach->CanPickInstance())
				{
					m_pkInstPick = pkInstEach;
					m_pkInstPick->OnSelected();
					return;
				}
			}
		}
	}

	if (pkInstMain)
	{
		if (pkInstMain->CanPickInstance())
		{
			if (m_kVct_pkInstPicked.end() != std::find (m_kVct_pkInstPicked.begin(), m_kVct_pkInstPicked.end(), pkInstMain))
			{
				if (m_pkInstPick)
				{
					if (m_pkInstPick != pkInstMain)
					{
						m_pkInstPick->OnUnselected();
					}
				}
				m_pkInstPick = pkInstMain;
				m_pkInstPick->OnSelected();
				return;
			}
		}
	}

	if (m_pkInstPick)
	{
		m_pkInstPick->OnUnselected();
		m_pkInstPick = NULL;
	}
}

void CPythonCharacterManager::__OLD_Pick()
{
	for (auto itor = m_kAliveInstMap.begin(); itor != m_kAliveInstMap.end(); ++itor)
	{
		CInstanceBase* pkInstEach = itor->second;

		if (pkInstEach == m_pkInstMain)
		{
			continue;
		}

		if (pkInstEach->IntersectDefendingSphere())
		{
			if (m_pkInstPick)
			{
				if (m_pkInstPick != pkInstEach)
				{
					m_pkInstPick->OnUnselected();
				}
			}
			m_pkInstPick = pkInstEach;
			m_pkInstPick->OnSelected();
			return;
		}
	}

	if (m_pkInstPick)
	{
		m_pkInstPick->OnUnselected();
		m_pkInstPick = NULL;
	}
}

int CPythonCharacterManager::PickAll()
{
	for (auto itor = m_kAliveInstMap.begin(); itor != m_kAliveInstMap.end(); ++itor)
	{
		CInstanceBase* pInstance = itor->second;

		if (pInstance->IntersectDefendingSphere())
		{
			return pInstance->GetVirtualID();
		}
	}

	return -1;
}

CInstanceBase* CPythonCharacterManager::GetCloseInstance (CInstanceBase* pInstance)
{
	float fMinDistance = 10000.0f;
	CInstanceBase* pCloseInstance = NULL;

	auto itor = m_kAliveInstMap.begin();
	for (; itor != m_kAliveInstMap.end(); ++itor)
	{
		CInstanceBase* pTargetInstance = itor->second;

		if (pTargetInstance == pInstance)
		{
			continue;
		}

		DWORD dwVirtualNumber = pTargetInstance->GetVirtualNumber();
		if (CPythonNonPlayer::ON_CLICK_EVENT_BATTLE != CPythonNonPlayer::Instance().GetEventType (dwVirtualNumber))
		{
			continue;
		}

		float fDistance = pInstance->GetDistance (pTargetInstance);
		if (fDistance < fMinDistance)
		{
			fMinDistance = fDistance;
			pCloseInstance = pTargetInstance;
		}
	}

	return pCloseInstance;
}

void CPythonCharacterManager::RefreshAllPCTextTail()
{
	auto itor = CharacterInstanceBegin();
	auto itorEnd = CharacterInstanceEnd();
	for (; itor != itorEnd; ++itor)
	{
		CInstanceBase* pInstance = *itor;
		if (!pInstance->IsPC())
		{
			continue;
		}

		pInstance->RefreshTextTail();
	}
}

void CPythonCharacterManager::RefreshAllGuildMark()
{
	auto itor = CharacterInstanceBegin();
	auto itorEnd = CharacterInstanceEnd();
	for (; itor != itorEnd; ++itor)
	{
		CInstanceBase* pInstance = *itor;
		if (!pInstance->IsPC())
		{
			continue;
		}


		pInstance->ChangeGuild (pInstance->GetGuildID());
		pInstance->RefreshTextTail();
	}
}

//MULTI_LANGUAGE
void CPythonCharacterManager::RefreshAllNPCNames()
{
	auto itor = CharacterInstanceBegin();
	auto itorEnd = CharacterInstanceEnd();
	for (; itor != itorEnd; ++itor)
	{
		CInstanceBase* pInstance = *itor;

		if (pInstance->IsPC())
			continue;

		DWORD dwVnum = pInstance->GetVirtualNumber();
		if (dwVnum == 0)
			continue;

		const char* c_szNewName = CPythonNonPlayer::Instance().GetMonsterName(dwVnum);
		if (c_szNewName && c_szNewName[0])
		{
			pInstance->SetNameString(c_szNewName, strlen(c_szNewName));
			CPythonTextTail::Instance().SetCharacterTextTailName(pInstance->GetVirtualID(), c_szNewName);
			pInstance->RefreshTextTail();
		}
	}
}
//MULTI_LANGUAGE

void CPythonCharacterManager::DeleteAllInstances()
{
	DestroyAliveInstanceMap();
	DestroyDeadInstanceList();
}


void CPythonCharacterManager::DestroyAliveInstanceMap()
{
	for (auto i = m_kAliveInstMap.begin(); i != m_kAliveInstMap.end(); ++i)
	{
		CInstanceBase::Delete (i->second);
	}

	m_kAliveInstMap.clear();
}

void CPythonCharacterManager::DestroyDeadInstanceList()
{
	std::for_each (m_kDeadInstList.begin(), m_kDeadInstList.end(), CInstanceBase::Delete);
	m_kDeadInstList.clear();
}

void CPythonCharacterManager::Destroy()
{
	DeleteAllInstances();

	CInstanceBase::DestroySystem();

	__Initialize();
}

void CPythonCharacterManager::__Initialize()
{
	memset (m_adwPointEffect, 0, sizeof (m_adwPointEffect));
	m_pkInstMain = NULL;
	m_pkInstBind = NULL;
	m_pkInstPick = NULL;
	m_v2PickedInstProjPos = D3DXVECTOR2 (0.0f, 0.0f);
}


CPythonCharacterManager::CPythonCharacterManager()
{
	__Initialize();
}

CPythonCharacterManager::~CPythonCharacterManager()
{
	Destroy();
}

