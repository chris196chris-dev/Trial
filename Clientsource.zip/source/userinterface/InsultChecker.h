#pragma once

class CInsultChecker
{
	public:
		CInsultChecker& GetSingleton();

	public:
		CInsultChecker();
		virtual ~CInsultChecker();

		void Clear();

		void AppendInsult (const std::string& c_rstInsult);
		bool IsInsultIn (const char* c_szLine, unsigned int uLineLen);
		void FilterInsult (char* szLine, unsigned int uLineLen);

	private:
		bool __GetInsultLength (const char* c_szWord, unsigned int* puInsultLen);
		bool __IsInsult (const char* c_szWord);

	private:
		std::list<std::string> m_kList_stInsult;
};

