#pragma once
#include "../eterlib/NetStream.h"
#include "../eterlib/FuncObject.h"

class CAccountConnector : public CNetworkStream, public CSingleton<CAccountConnector>
{
	public:
		enum EAccountConnectorState
		{
			STATE_OFFLINE,
			STATE_HANDSHAKE,
			STATE_AUTH,
		};

	public:
		CAccountConnector();
		virtual ~CAccountConnector();

		void SetHandler (PyObject* poHandler);

#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
		void SetLoginInfo (const char* c_szName, const char* c_szPwd, const char* c_szPin);
#else
		void SetLoginInfo (const char* c_szName, const char* c_szPwd);
#endif

		void ClearLoginInfo( void );

		bool Connect (const char* c_szAddr, int iPort, const char* c_szAccountAddr, int iAccountPort);
		void Disconnect();
		void Process();

	protected:
		void OnConnectFailure();
		void OnConnectSuccess();
		void OnRemoteDisconnect();
		void OnDisconnect();

	protected:
		void __Inialize();
		bool __StateProcess();

		void __OfflineState_Set();
		void __HandshakeState_Set();
		void __AuthState_Set();

		bool __HandshakeState_Process();
		bool __AuthState_Process();

		bool __AuthState_RecvEmpty();
		bool __AuthState_RecvPhase();
		bool __AuthState_RecvHandshake();
		bool __AuthState_RecvPing();
		bool __AuthState_SendPong();
		bool __AuthState_RecvAuthSuccess();
		bool __AuthState_RecvAuthFailure();

		bool __AnalyzePacket (unsigned int uHeader, unsigned int uPacketSize, bool (CAccountConnector::* pfnDispatchPacket)());
		bool __AnalyzeVarSizePacket (unsigned int uHeader, bool (CAccountConnector::* pfnDispatchPacket) (int));

	protected:
		unsigned int m_eState;
		std::string m_strID;
		std::string m_strPassword;
#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
		std::string m_strPin;
#endif

		std::string m_strAddr;
		int m_iPort;

		PyObject* m_poHandler;
};

