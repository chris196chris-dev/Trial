#pragma once
#include <AttackDefines.h>
#include "../DirectUpgrade.h"

unsigned GetCodePage();
const char* GetLocalePath();
void LoadConfig();
unsigned GetGuildLastExp (int level);
int GetSkillPower (unsigned level);
int StringCompareCI (LPCSTR szStringLeft, LPCSTR szStringRight, size_t sizeLength);

