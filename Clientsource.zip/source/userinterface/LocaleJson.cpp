//MULTI_LANGUAGE
#include "stdafx.h"
#include "LocaleJson.h"
#include "PythonSkill.h"
#include "../eterpack/EterPackManager.h"
#include "../eterlocale/CodePageId.h"

#include "json_parser.hpp"
#include <unordered_map>
#include <string>
#include <utility>

// MULTI_LANGUAGE - External function to update default codepage for text rendering
extern bool SetDefaultCodePage(DWORD codePage);

using json = nlohmann::json;

static std::unordered_map<DWORD, std::string> g_ItemNames;
static std::unordered_map<DWORD, std::string> g_MobNames;
static std::string g_strLanguage = DEFAULT_LANGUAGE;

//MULTI_LANGUAGE - UI Strings
struct SLocaleString
{
	std::string text;
	bool isFormat;  // true = SA (string argument), false = SNA/plain
};
static std::unordered_map<std::string, SLocaleString> g_LocaleStrings;
static std::unordered_map<int, std::string> g_QuestStrings;

//MULTI_LANGUAGE - Item Descriptions
struct SItemDesc
{
	std::string desc;
	std::string summary;
};
static std::unordered_map<DWORD, SItemDesc> g_ItemDescs;

//MULTI_LANGUAGE - Skill Descriptions
struct SSkillDesc
{
	std::vector<std::string> names;         // 3 grade names
	std::string description;
	std::vector<std::string> conditions;
	std::vector<std::string> affectDescs;
};
static std::unordered_map<DWORD, SSkillDesc> g_SkillDescs;
//MULTI_LANGUAGE

static int GetCodePageForLanguage(const std::string& lang)
{
	// FINALFORM_V6: Python 3 strings must stay valid UTF-8.
	// The old V4/V5 conversion turned JSON text into CP1253/1252 bytes and then
	// returned them through Py_BuildValue("s"), which Python 3 decodes as UTF-8.
	// That is exactly the UnicodeDecodeError in uiToolTip.py when Greek is active.
	// GrpTextInstance already supports CP_UTF8/65001, so keep all multi-language
	// JSON data as UTF-8 and render it as UTF-8.
	return CP_UTF8;
}

static std::string StripBOM(const std::string& str)
{
	if (str.size() >= 3 &&
		(unsigned char)str[0] == 0xEF &&
		(unsigned char)str[1] == 0xBB &&
		(unsigned char)str[2] == 0xBF)
	{
		return str.substr(3);
	}
	return str;
}

static std::string ConvertFromUTF8(const std::string& utf8, int codepage)
{
	// FINALFORM_V6: no ANSI/CP conversion. Keep JSON text as UTF-8.
	(void)codepage;
	return utf8;
}

static bool LoadNamesFromJSON(
	const char* filename,
	const char* rootKey,
	std::unordered_map<DWORD, std::string>& outMap)
{
	CMappedFile file;
	const void* pvData;

	if (!CEterPackManager::Instance().Get(file, filename, &pvData))
	{
		TraceError("LocaleJson: Cannot open %s", filename);
		return false;
	}

	std::string jsonStr = StripBOM(std::string((const char*)pvData, file.Size()));

	try
	{
		json data = json::parse(jsonStr);

		if (!data.contains(rootKey) || !data[rootKey].is_object())
		{
			TraceError("LocaleJson: Invalid format - missing '%s' in %s", rootKey, filename);
			return false;
		}

		int codepage = GetCodePageForLanguage(g_strLanguage);
		size_t count = 0;

		for (auto& [vnumStr, translations] : data[rootKey].items())
		{
			if (!translations.is_object())
				continue;

			DWORD dwVnum;
			try
			{
				dwVnum = (DWORD)std::stoul(vnumStr);
			}
			catch (...)
			{
				TraceError("LocaleJson: Invalid vnum '%s' in %s", vnumStr.c_str(), filename);
				continue;
			}

			std::string name;
			if (translations.contains(g_strLanguage) && translations[g_strLanguage].is_string())
			{
				name = translations[g_strLanguage].get<std::string>();
			}
			else if (translations.contains(DEFAULT_LANGUAGE) && translations[DEFAULT_LANGUAGE].is_string())
			{
				name = translations[DEFAULT_LANGUAGE].get<std::string>();
			}
			else
			{
				continue;
			}

			outMap[dwVnum] = ConvertFromUTF8(name, codepage);
			count++;
		}

		Tracef("LocaleJson: Loaded %zu %s for language '%s'\n", count, rootKey, g_strLanguage.c_str());
		return true;
	}
	catch (const json::parse_error& e)
	{
		TraceError("LocaleJson: JSON parse error in %s: %s", filename, e.what());
		return false;
	}
}

void LocaleJson_SetLanguage(const char* lang)
{
	if (lang && lang[0])
	{
		g_strLanguage = lang;

		// MULTI_LANGUAGE - Update default codepage for text rendering
		// This ensures fonts and text rendering use the correct codepage for the selected language
		int newCodePage = GetCodePageForLanguage(g_strLanguage);
		if (SetDefaultCodePage(newCodePage))
		{
			Tracef("LocaleJson: Language set to '%s' (codepage: %d)\n", lang, newCodePage);
		}
		else
		{
			TraceError("LocaleJson: Failed to set codepage %d for language '%s'\n", newCodePage, lang);
		}
	}
}

bool LocaleJson_LoadItemNames(const char* filename)
{
	return LoadNamesFromJSON(filename, "items", g_ItemNames);
}

bool LocaleJson_LoadMobNames(const char* filename)
{
	return LoadNamesFromJSON(filename, "mobs", g_MobNames);
}

const char* LocaleJson_GetItemName(DWORD dwVnum)
{
	auto it = g_ItemNames.find(dwVnum);
	if (it != g_ItemNames.end())
		return it->second.c_str();
	return nullptr;
}

const char* LocaleJson_GetMobName(DWORD dwVnum)
{
	auto it = g_MobNames.find(dwVnum);
	if (it != g_MobNames.end())
		return it->second.c_str();
	return nullptr;
}

void LocaleJson_ClearItemNames()
{
	g_ItemNames.clear();
}

void LocaleJson_ClearMobNames()
{
	g_MobNames.clear();
}

//MULTI_LANGUAGE - UI Strings Implementation
bool LocaleJson_LoadStrings(const char* filename)
{
	CMappedFile file;
	const void* pvData;

	if (!CEterPackManager::Instance().Get(file, filename, &pvData))
	{
		TraceError("LocaleJson: Cannot open strings file %s", filename);
		return false;
	}

	std::string jsonStr = StripBOM(std::string((const char*)pvData, file.Size()));

	try
	{
		json data = json::parse(jsonStr);

		if (!data.contains("strings") || !data["strings"].is_object())
		{
			TraceError("LocaleJson: Invalid format - missing 'strings' in %s", filename);
			return false;
		}

		int codepage = GetCodePageForLanguage(g_strLanguage);
		size_t count = 0;

		for (auto& [key, translations] : data["strings"].items())
		{
			if (!translations.is_object())
				continue;

			std::string text;
			if (translations.contains(g_strLanguage) && translations[g_strLanguage].is_string())
			{
				text = translations[g_strLanguage].get<std::string>();
			}
			else if (translations.contains(DEFAULT_LANGUAGE) && translations[DEFAULT_LANGUAGE].is_string())
			{
				text = translations[DEFAULT_LANGUAGE].get<std::string>();
			}
			else
			{
				continue;
			}

			SLocaleString locStr;
			locStr.text = ConvertFromUTF8(text, codepage);
			locStr.isFormat = false;

			// Check for format flag (SA = string argument)
			if (translations.contains("format") && translations["format"].is_string())
			{
				std::string fmt = translations["format"].get<std::string>();
				locStr.isFormat = (fmt == "SA");
			}

			g_LocaleStrings[key] = locStr;
			count++;
		}

		Tracef("LocaleJson: Loaded %zu strings for language '%s'\n", count, g_strLanguage.c_str());
		return true;
	}
	catch (const json::parse_error& e)
	{
		TraceError("LocaleJson: JSON parse error in %s: %s", filename, e.what());
		return false;
	}
}

const char* LocaleJson_GetString(const char* key)
{
	auto it = g_LocaleStrings.find(key);
	if (it != g_LocaleStrings.end())
		return it->second.text.c_str();
	return nullptr;
}

bool LocaleJson_IsFormatString(const char* key)
{
	auto it = g_LocaleStrings.find(key);
	if (it != g_LocaleStrings.end())
		return it->second.isFormat;
	return false;
}

void LocaleJson_ClearStrings()
{
	g_LocaleStrings.clear();
}


//MULTI_LANGUAGE - Quest Strings Implementation
bool LocaleJson_LoadQuestStrings(const char* filename)
{
	CMappedFile file;
	const void* pvData;

	if (!CEterPackManager::Instance().Get(file, filename, &pvData))
	{
		TraceError("LocaleJson: Cannot open quest strings file %s", filename);
		return false;
	}

	std::string jsonStr = StripBOM(std::string((const char*)pvData, file.Size()));

	try
	{
		json data = json::parse(jsonStr);

		if (!data.contains("strings") || !data["strings"].is_object())
		{
			TraceError("LocaleJson: Invalid format - missing 'strings' in %s", filename);
			return false;
		}

		int codepage = GetCodePageForLanguage(g_strLanguage);
		size_t count = 0;

		for (auto& [keyStr, translations] : data["strings"].items())
		{
			if (!translations.is_object())
				continue;

			int key = 0;
			try
			{
				key = std::stoi(keyStr);
			}
			catch (...)
			{
				// Client-side quest markers are numeric only. String-key quests are
				// resolved server-side through translations_quest.json.
				continue;
			}

			std::string text;
			if (translations.contains(g_strLanguage) && translations[g_strLanguage].is_string())
			{
				text = translations[g_strLanguage].get<std::string>();
			}
			else if (translations.contains(DEFAULT_LANGUAGE) && translations[DEFAULT_LANGUAGE].is_string())
			{
				text = translations[DEFAULT_LANGUAGE].get<std::string>();
			}
			else
			{
				continue;
			}

			g_QuestStrings[key] = ConvertFromUTF8(text, codepage);
			count++;
		}

		Tracef("LocaleJson: Loaded %zu quest strings for language '%s'\n", count, g_strLanguage.c_str());
		return true;
	}
	catch (const json::parse_error& e)
	{
		TraceError("LocaleJson: JSON parse error in %s: %s", filename, e.what());
		return false;
	}
}

const char* LocaleJson_GetQuestString(int id)
{
	auto it = g_QuestStrings.find(id);
	if (it != g_QuestStrings.end())
		return it->second.c_str();
	return nullptr;
}

void LocaleJson_ClearQuestStrings()
{
	g_QuestStrings.clear();
}

//MULTI_LANGUAGE - Item Descriptions Implementation
bool LocaleJson_LoadItemDesc(const char* filename)
{
	CMappedFile file;
	const void* pvData;

	if (!CEterPackManager::Instance().Get(file, filename, &pvData))
	{
		TraceError("LocaleJson: Cannot open item desc file %s", filename);
		return false;
	}

	std::string jsonStr = StripBOM(std::string((const char*)pvData, file.Size()));

	try
	{
		json data = json::parse(jsonStr);

		if (!data.contains("items") || !data["items"].is_object())
		{
			TraceError("LocaleJson: Invalid format - missing 'items' in %s", filename);
			return false;
		}

		int codepage = GetCodePageForLanguage(g_strLanguage);
		size_t count = 0;

		for (auto& [vnumStr, translations] : data["items"].items())
		{
			if (!translations.is_object())
				continue;

			DWORD dwVnum;
			try
			{
				dwVnum = (DWORD)std::stoul(vnumStr);
			}
			catch (...)
			{
				TraceError("LocaleJson: Invalid vnum '%s' in %s", vnumStr.c_str(), filename);
				continue;
			}

			// Find the language-specific or default translation
			json* langData = nullptr;
			if (translations.contains(g_strLanguage) && translations[g_strLanguage].is_object())
			{
				langData = &translations[g_strLanguage];
			}
			else if (translations.contains(DEFAULT_LANGUAGE) && translations[DEFAULT_LANGUAGE].is_object())
			{
				langData = &translations[DEFAULT_LANGUAGE];
			}
			else
			{
				continue;
			}

			SItemDesc itemDesc;

			if (langData->contains("desc") && (*langData)["desc"].is_string())
			{
				itemDesc.desc = ConvertFromUTF8((*langData)["desc"].get<std::string>(), codepage);
			}

			if (langData->contains("summary") && (*langData)["summary"].is_string())
			{
				itemDesc.summary = ConvertFromUTF8((*langData)["summary"].get<std::string>(), codepage);
			}

			g_ItemDescs[dwVnum] = itemDesc;
			count++;
		}

		Tracef("LocaleJson: Loaded %zu item descriptions for language '%s'\n", count, g_strLanguage.c_str());
		return true;
	}
	catch (const json::parse_error& e)
	{
		TraceError("LocaleJson: JSON parse error in %s: %s", filename, e.what());
		return false;
	}
}

const char* LocaleJson_GetItemDesc(DWORD dwVnum)
{
	auto it = g_ItemDescs.find(dwVnum);
	if (it != g_ItemDescs.end() && !it->second.desc.empty())
		return it->second.desc.c_str();
	return nullptr;
}

const char* LocaleJson_GetItemSummary(DWORD dwVnum)
{
	auto it = g_ItemDescs.find(dwVnum);
	if (it != g_ItemDescs.end() && !it->second.summary.empty())
		return it->second.summary.c_str();
	return nullptr;
}

void LocaleJson_ClearItemDesc()
{
	g_ItemDescs.clear();
}

//MULTI_LANGUAGE - Skill Descriptions Implementation
bool LocaleJson_LoadSkillDesc(const char* filename)
{
	CMappedFile file;
	const void* pvData;

	if (!CEterPackManager::Instance().Get(file, filename, &pvData))
	{
		TraceError("LocaleJson: Cannot open skill desc file %s", filename);
		return false;
	}

	std::string jsonStr = StripBOM(std::string((const char*)pvData, file.Size()));

	try
	{
		json data = json::parse(jsonStr);

		if (!data.contains("skills") || !data["skills"].is_object())
		{
			TraceError("LocaleJson: Invalid format - missing 'skills' in %s", filename);
			return false;
		}

		int codepage = GetCodePageForLanguage(g_strLanguage);
		size_t count = 0;

		CPythonSkill& rkSkillMgr = CPythonSkill::Instance();

		for (auto& [vnumStr, skillData] : data["skills"].items())
		{
			if (!skillData.is_object())
				continue;

			DWORD dwVnum;
			try
			{
				dwVnum = (DWORD)std::stoul(vnumStr);
			}
			catch (...)
			{
				TraceError("LocaleJson: Invalid vnum '%s' in %s", vnumStr.c_str(), filename);
				continue;
			}

			// Find locale data
			if (!skillData.contains("locale") || !skillData["locale"].is_object())
				continue;

			json& localeData = skillData["locale"];
			json* langData = nullptr;

			if (localeData.contains(g_strLanguage) && localeData[g_strLanguage].is_object())
			{
				langData = &localeData[g_strLanguage];
			}
			else if (localeData.contains(DEFAULT_LANGUAGE) && localeData[DEFAULT_LANGUAGE].is_object())
			{
				langData = &localeData[DEFAULT_LANGUAGE];
			}
			else
			{
				continue;
			}

			SSkillDesc skillDesc;

			// Load names (array of 3)
			if (langData->contains("names") && (*langData)["names"].is_array())
			{
				for (const auto& name : (*langData)["names"])
				{
					if (name.is_string())
					{
						skillDesc.names.push_back(ConvertFromUTF8(name.get<std::string>(), codepage));
					}
				}
			}

			// Ensure we have 3 names (pad with first if needed)
			while (skillDesc.names.size() < 3)
			{
				if (!skillDesc.names.empty())
					skillDesc.names.push_back(skillDesc.names[0]);
				else
					skillDesc.names.push_back("");
			}

			// Load description
			if (langData->contains("description") && (*langData)["description"].is_string())
			{
				skillDesc.description = ConvertFromUTF8((*langData)["description"].get<std::string>(), codepage);
			}

			// Load conditions
			if (langData->contains("conditions") && (*langData)["conditions"].is_array())
			{
				for (const auto& cond : (*langData)["conditions"])
				{
					if (cond.is_string())
					{
						skillDesc.conditions.push_back(ConvertFromUTF8(cond.get<std::string>(), codepage));
					}
				}
			}

			// Load affect descriptions
			if (langData->contains("affect_descs") && (*langData)["affect_descs"].is_array())
			{
				for (const auto& affect : (*langData)["affect_descs"])
				{
					if (affect.is_string())
					{
						skillDesc.affectDescs.push_back(ConvertFromUTF8(affect.get<std::string>(), codepage));
					}
				}
			}

			g_SkillDescs[dwVnum] = skillDesc;

			// MULTI_LANGUAGE: Register skill in CPythonSkill (replaces SkillDesc.txt)
			std::string strJob = skillData.value("job", "");
			std::string strAttribute = skillData.value("attribute", "");
			std::string strWeapon = skillData.value("weapon", "");
			std::string strIcon = skillData.value("icon", "");
			int motionIndex = 0;
			if (skillData.contains("motion_index"))
			{
				if (skillData["motion_index"].is_number())
					motionIndex = skillData["motion_index"].get<int>();
				else if (skillData["motion_index"].is_string())
					motionIndex = atoi(skillData["motion_index"].get<std::string>().c_str());
			}

			// MULTI_LANGUAGE: Parse motion_grade for skill grade animations
			int motionGrade = 0;
			if (skillData.contains("motion_grade"))
			{
				if (skillData["motion_grade"].is_number())
					motionGrade = skillData["motion_grade"].get<int>();
				else if (skillData["motion_grade"].is_string())
					motionGrade = atoi(skillData["motion_grade"].get<std::string>().c_str());
			}

			// MULTI_LANGUAGE: Parse affect formulas for dynamic skill tooltip values
			std::vector<std::pair<std::string, std::string>> affectFormulas;
			if (skillData.contains("affects") && skillData["affects"].is_array())
			{
				for (const auto& affect : skillData["affects"])
				{
					if (!affect.is_object())
						continue;

					std::string minFormula;
					std::string maxFormula;
					if (affect.contains("min") && affect["min"].is_string())
						minFormula = affect["min"].get<std::string>();
					if (affect.contains("max") && affect["max"].is_string())
						maxFormula = affect["max"].get<std::string>();

					if (!minFormula.empty() || !maxFormula.empty())
						affectFormulas.push_back(std::make_pair(minFormula, maxFormula));
				}
			}

			// Register in CPythonSkill
			rkSkillMgr.RegisterSkillDescFromJSON(
				dwVnum,
				strJob,
				strAttribute,
				strWeapon,
				strIcon,
				motionIndex,
				motionGrade,
				skillDesc.names,
				skillDesc.description,
				skillDesc.conditions,
				affectFormulas
			);

			count++;
		}

		Tracef("LocaleJson: Loaded and registered %zu skills for language '%s'\n", count, g_strLanguage.c_str());
		return true;
	}
	catch (const json::parse_error& e)
	{
		TraceError("LocaleJson: JSON parse error in %s: %s", filename, e.what());
		return false;
	}
}

const char* LocaleJson_GetSkillName(DWORD dwVnum, int grade)
{
	auto it = g_SkillDescs.find(dwVnum);
	if (it != g_SkillDescs.end())
	{
		if (grade >= 0 && grade < (int)it->second.names.size())
			return it->second.names[grade].c_str();
		else if (!it->second.names.empty())
			return it->second.names[0].c_str();
	}
	return nullptr;
}

const char* LocaleJson_GetSkillDescription(DWORD dwVnum)
{
	auto it = g_SkillDescs.find(dwVnum);
	if (it != g_SkillDescs.end() && !it->second.description.empty())
		return it->second.description.c_str();
	return nullptr;
}

int LocaleJson_GetSkillConditionCount(DWORD dwVnum)
{
	auto it = g_SkillDescs.find(dwVnum);
	if (it != g_SkillDescs.end())
		return (int)it->second.conditions.size();
	return 0;
}

const char* LocaleJson_GetSkillCondition(DWORD dwVnum, int index)
{
	auto it = g_SkillDescs.find(dwVnum);
	if (it != g_SkillDescs.end())
	{
		if (index >= 0 && index < (int)it->second.conditions.size())
			return it->second.conditions[index].c_str();
	}
	return nullptr;
}

int LocaleJson_GetSkillAffectDescCount(DWORD dwVnum)
{
	auto it = g_SkillDescs.find(dwVnum);
	if (it != g_SkillDescs.end())
		return (int)it->second.affectDescs.size();
	return 0;
}

const char* LocaleJson_GetSkillAffectDesc(DWORD dwVnum, int index)
{
	auto it = g_SkillDescs.find(dwVnum);
	if (it != g_SkillDescs.end())
	{
		if (index >= 0 && index < (int)it->second.affectDescs.size())
			return it->second.affectDescs[index].c_str();
	}
	return nullptr;
}

void LocaleJson_ClearSkillDesc()
{
	g_SkillDescs.clear();
}
//MULTI_LANGUAGE
