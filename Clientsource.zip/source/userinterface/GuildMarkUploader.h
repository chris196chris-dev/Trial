#pragma once

#include "../eterlib/NetStream.h"
#include "MarkImage.h"

class CGuildMarkUploader : public CNetworkStream, public CSingleton<CGuildMarkUploader>
{
	public:
		enum
		{
			ERROR_NONE,
			ERROR_CONNECT,
			ERROR_LOAD,
			ERROR_WIDTH,
			ERROR_HEIGHT,
		};

		enum
		{
			SEND_TYPE_MARK,
			SEND_TYPE_SYMBOL,
		};

	public:
		CGuildMarkUploader();
		virtual ~CGuildMarkUploader();

		void Disconnect();
		bool Connect(const CNetworkAddress& c_rkNetAddr, DWORD dwHandle, DWORD dwRandomKey, DWORD dwGuildID, const char* c_szFileName, unsigned int* peError
#ifdef ENABLE_GUILD_TOKEN_AUTH
			, uint64_t dwGuildToken
#endif
		);
		bool ConnectToSendSymbol(const CNetworkAddress& c_rkNetAddr, DWORD dwHandle, DWORD dwRandomKey, DWORD dwGuildID, const char* c_szFileName, unsigned int* peError
#ifdef ENABLE_GUILD_TOKEN_AUTH
			, uint64_t dwGuildToken
#endif
		);
		bool IsCompleteUploading();

		void Process();

	private:
		enum
		{
			STATE_OFFLINE,
			STATE_LOGIN,
			STATE_COMPLETE,
		};

	private:
		void OnConnectFailure();
		void OnConnectSuccess();
		void OnRemoteDisconnect();
		void OnDisconnect();

		bool __Load (const char* c_szFileName, unsigned int* peError);
		bool __LoadSymbol (const char* c_szFileName, unsigned int* peError);

		void __Initialize(); //fix099918
		bool __StateProcess();

		void __OfflineState_Set();
		void __CompleteState_Set();

		void __LoginState_Set();
		bool __LoginState_Process();
		bool __LoginState_RecvPhase();
		bool __LoginState_RecvHandshake();
		bool __LoginState_RecvPing();

		bool __AnalyzePacket (unsigned int uHeader, unsigned int uPacketSize, bool (CGuildMarkUploader::* pfnDispatchPacket)());

		bool __SendMarkPacket();
		bool __SendSymbolPacket();

	private:
		unsigned int m_eState;

		DWORD m_dwSendType;
		DWORD m_dwHandle;
		DWORD m_dwRandomKey;
		DWORD m_dwGuildID;
#ifdef ENABLE_GUILD_TOKEN_AUTH
		uint64_t m_dwGuildToken{};
#endif

		SGuildMark m_kMark;

		DWORD m_dwSymbolBufSize;
		DWORD m_dwSymbolCRC32;
		BYTE* m_pbySymbolBuf;
};

