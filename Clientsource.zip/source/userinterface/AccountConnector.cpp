#include "StdAfx.h"
#include "AccountConnector.h"
#include "Packet.h"
#include "PythonNetworkStream.h"

void CAccountConnector::SetHandler (PyObject* poHandler)
{
	m_poHandler = poHandler;
}

#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
void CAccountConnector::SetLoginInfo (const char* c_szName, const char* c_szPwd, const char* c_szPin)
#else
void CAccountConnector::SetLoginInfo (const char* c_szName, const char* c_szPwd)
#endif
{
	m_strID = c_szName;
	m_strPassword = c_szPwd;
#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
	m_strPin = c_szPin;
#endif
}

void CAccountConnector::ClearLoginInfo( void )
{
	m_strPassword = "";
#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
	m_strPin = "";
#endif
}

bool CAccountConnector::Connect (const char* c_szAddr, int iPort, const char* c_szAccountAddr, int iAccountPort)
{
	m_strAddr = c_szAddr;
	m_iPort = iPort;
	__OfflineState_Set();

	return CNetworkStream::Connect (c_szAccountAddr, iAccountPort);
}

void CAccountConnector::Disconnect()
{
	CNetworkStream::Disconnect();
	__OfflineState_Set();
}

void CAccountConnector::Process()
{
	CNetworkStream::Process();

	if (!__StateProcess())
	{
		__OfflineState_Set();
		Disconnect();
	}
}

bool CAccountConnector::__StateProcess()
{
	switch (m_eState)
	{
		case STATE_HANDSHAKE:
			return __HandshakeState_Process();
			break;
		case STATE_AUTH:
			return __AuthState_Process();
			break;
	}

	return true;
}

bool CAccountConnector::__HandshakeState_Process()
{
	if (!__AnalyzePacket (HEADER_GC_PHASE, sizeof (TPacketGCPhaseCSCheckDraveniu), &CAccountConnector::__AuthState_RecvPhase))
	{
		return false;
	}

	if (!__AnalyzePacket (HEADER_GC_HANDSHAKE, sizeof (TPacketGCHandshakeCSCheckDraveniu), &CAccountConnector::__AuthState_RecvHandshake))
	{
		return false;
	}

	if (!__AnalyzePacket (HEADER_GC_PING, sizeof (TPacketGCPing), &CAccountConnector::__AuthState_RecvPing))
	{
		return false;
	}

	return true;
}

bool CAccountConnector::__AuthState_Process()
{
	if (!__AnalyzePacket (0, sizeof (BYTE), &CAccountConnector::__AuthState_RecvEmpty))
	{
		return true;
	}

	if (!__AnalyzePacket (HEADER_GC_PHASE, sizeof (TPacketGCPhaseCSCheckDraveniu), &CAccountConnector::__AuthState_RecvPhase))
	{
		return false;
	}

	if (!__AnalyzePacket (HEADER_GC_PING, sizeof (TPacketGCPing), &CAccountConnector::__AuthState_RecvPing))
	{
		return false;
	}

	if (!__AnalyzePacket (HEADER_GC_AUTH_SUCCESS, sizeof (TPacketGCAuthSuccess), &CAccountConnector::__AuthState_RecvAuthSuccess))
	{
		return true;
	}

	if (!__AnalyzePacket (HEADER_GC_LOGIN_FAILURE, sizeof (TPacketGCAuthSuccess), &CAccountConnector::__AuthState_RecvAuthFailure))
	{
		return true;
	}

	if (!__AnalyzePacket (HEADER_GC_HANDSHAKE, sizeof (TPacketGCHandshakeCSCheckDraveniu), &CAccountConnector::__AuthState_RecvHandshake))
	{
		return false;
	}

	return true;
}

bool CAccountConnector::__AuthState_RecvEmpty()
{
	BYTE byEmpty;
	Recv (sizeof (BYTE), &byEmpty);
	return true;
}

bool CAccountConnector::__AuthState_RecvPhase()
{
	TPacketGCPhaseCSCheckDraveniu kPacketPhase;
	if (!Recv (sizeof (kPacketPhase), &kPacketPhase))
	{
		return false;
	}

	if (kPacketPhase.phase == PHASE_HANDSHAKE)
	{
		__HandshakeState_Set();
	}
	else if (kPacketPhase.phase == PHASE_AUTH)
	{
		TPacketCGLoginBCheckDraveniu LoginPacket;
		LoginPacket.header = HEADER_CG_LOGIN3;

		strncpy (LoginPacket.name, m_strID.c_str(), ID_MAX_NUM);
		strncpy (LoginPacket.pwd, m_strPassword.c_str(), PASS_MAX_NUM);
#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
		strncpy(LoginPacket.pin, m_strPin.c_str(), PASS_MAX_NUM);
#endif
		LoginPacket.name[ID_MAX_NUM] = '\0';
		LoginPacket.pwd[PASS_MAX_NUM] = '\0';
#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
		LoginPacket.pin[PASS_MAX_NUM] = '\0';
#endif

		ClearLoginInfo();
		CPythonNetworkStream& rkNetStream = CPythonNetworkStream::Instance();
		rkNetStream.ClearLoginInfo();

		m_strPassword = "";
#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
		m_strPin = "";
#endif

		if (!Send (sizeof (LoginPacket), &LoginPacket))
		{
			Tracen (" CAccountConnector::__AuthState_RecvPhase - SendLogin3 Error");
			return false;
		}
		__AuthState_Set();
	}

	return true;
}

bool CAccountConnector::__AuthState_RecvHandshake()
{
	TPacketGCHandshakeCSCheckDraveniu kPacketHandshake;
	if (!Recv (sizeof (kPacketHandshake), &kPacketHandshake))
	{
		return false;
	}

	Tracenf ("HANDSHAKE RECV %u %d", kPacketHandshake.dwTime, kPacketHandshake.lDelta);
	ELTimer_SetServerMSec (kPacketHandshake.dwTime + kPacketHandshake.lDelta);

	kPacketHandshake.dwTime = kPacketHandshake.dwTime + kPacketHandshake.lDelta + kPacketHandshake.lDelta;
	kPacketHandshake.lDelta = 0;

	Tracenf ("HANDSHAKE SEND %u", kPacketHandshake.dwTime);

	if (!Send (sizeof (kPacketHandshake), &kPacketHandshake))
	{
		Tracen (" CAccountConnector::__AuthState_RecvHandshake - SendHandshake Error");
		return false;
	}

	return true;
}

bool CAccountConnector::__AuthState_RecvPing()
{
	TPacketGCPing kPacketPing;
	if (!Recv (sizeof (kPacketPing), &kPacketPing))
	{
		return false;
	}

	__AuthState_SendPong();

	return true;
}

bool CAccountConnector::__AuthState_SendPong()
{
	TPacketCGPong kPacketPong;
	kPacketPong.bHeader = HEADER_CG_PONG;
	if (!Send (sizeof (kPacketPong), &kPacketPong))
	{
		return false;
	}

	return true;
}

bool CAccountConnector::__AuthState_RecvAuthSuccess()
{
	TPacketGCAuthSuccess kAuthSuccessPacket;
	if (!Recv (sizeof (kAuthSuccessPacket), &kAuthSuccessPacket))
	{
		return false;
	}

	if (!kAuthSuccessPacket.bResult)
	{
		if (m_poHandler)
		{
			PyCallClassMemberFunc (m_poHandler, "OnLoginFailure", Py_BuildValue ("(s)", "BESAMEKEY"));
		}
	}
	else
	{
		CPythonNetworkStream& rkNet = CPythonNetworkStream::Instance();
		rkNet.SetLoginKey (kAuthSuccessPacket.dwLoginKey);
		rkNet.Connect (m_strAddr.c_str(), m_iPort);
	}

	Disconnect();
	__OfflineState_Set();

	return true;
}

bool CAccountConnector::__AuthState_RecvAuthFailure()
{
	TPacketGCLoginFailureCSCheckDraveniu packet_failure;
	if (!Recv (sizeof (TPacketGCLoginFailureCSCheckDraveniu), &packet_failure))
	{
		return false;
	}

	if (m_poHandler)
	{
		PyCallClassMemberFunc (m_poHandler, "OnLoginFailure", Py_BuildValue ("(s)", packet_failure.szStatus));
	}

	return true;
}

bool CAccountConnector::__AnalyzePacket (unsigned int uHeader, unsigned int uPacketSize, bool (CAccountConnector::* pfnDispatchPacket)())
{
	BYTE bHeader;
	if (!Peek (sizeof (bHeader), &bHeader))
	{
		return true;
	}

	if (bHeader != uHeader)
	{
		return true;
	}

#ifdef __FIX_BUFFER_CLIENT__
	if (!PeekNoFetch (uPacketSize))
#else
	if (!Peek (uPacketSize))
#endif
	{
		return true;
	}

	return (this->*pfnDispatchPacket)();
}

bool CAccountConnector::__AnalyzeVarSizePacket (unsigned int uHeader, bool (CAccountConnector::* pfnDispatchPacket) (int))
{
	BYTE bHeader;
	if (!Peek (sizeof (bHeader), &bHeader))
	{
		return true;
	}

	if (bHeader != uHeader)
	{
		return true;
	}

	TDynamicSizePacketHeader dynamicHeader;
	if (!Peek (sizeof (dynamicHeader), &dynamicHeader))
	{
		return true;
	}

#ifdef __FIX_BUFFER_CLIENT__
	if (!PeekNoFetch (dynamicHeader.size))
#else
	if (!Peek (dynamicHeader.size))
#endif
	{
		return true;
	}

	return (this->*pfnDispatchPacket) (dynamicHeader.size);
}


void CAccountConnector::__OfflineState_Set()
{
	__Inialize();
}

void CAccountConnector::__HandshakeState_Set()
{
	m_eState = STATE_HANDSHAKE;
}

void CAccountConnector::__AuthState_Set()
{
	m_eState = STATE_AUTH;
}

void CAccountConnector::OnConnectFailure()
{
	if (m_poHandler)
	{
		PyCallClassMemberFunc (m_poHandler, "OnConnectFailure", Py_BuildValue ("()"));
	}

	__OfflineState_Set();
}

void CAccountConnector::OnConnectSuccess()
{
	m_eState = STATE_HANDSHAKE;
}

void CAccountConnector::OnRemoteDisconnect()
{
	__OfflineState_Set();
}

void CAccountConnector::OnDisconnect()
{
	__OfflineState_Set();
}

void CAccountConnector::__Inialize()
{
	m_eState = STATE_OFFLINE;
}

CAccountConnector::CAccountConnector()
{
	m_poHandler = NULL;
	m_strAddr = "";
	m_iPort = 0;


#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
	SetLoginInfo("", "", "");
#else
	SetLoginInfo ("", "");
#endif
	SetRecvBufferSize (1024 * 128);
	SetSendBufferSize (2048);
	__Inialize();
}

CAccountConnector::~CAccountConnector()
{
	__OfflineState_Set();
}

