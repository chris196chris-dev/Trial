#include "stdafx.h"
#include "MarkManager.h"
#include <iterator>

CGuildMarkImage* CGuildMarkManager::__NewImage()
{
	return new CGuildMarkImage;
}

void CGuildMarkManager::__DeleteImage (CGuildMarkImage* pkImgDel)
{
	delete pkImgDel;
	#ifdef FIX_BLACK_SCREEN
	pkImgDel = nullptr;
	#endif
}

CGuildMarkManager::CGuildMarkManager()
{
	mkdir ("upload/mark");

	for (DWORD i = 0; i < MAX_IMAGE_COUNT * CGuildMarkImage::MARK_TOTAL_COUNT; ++i)
	{
		m_setFreeMarkID.insert (i);
	}
}

CGuildMarkManager::~CGuildMarkManager()
{
	for (auto it = m_mapIdx_Image.begin(); it != m_mapIdx_Image.end(); ++it)
	{
		__DeleteImage (it->second);
	}

	m_mapIdx_Image.clear();
}

bool CGuildMarkManager::GetMarkImageFilename (DWORD imgIdx, std::string& path) const
{
	if (imgIdx >= MAX_IMAGE_COUNT)
	{
		return false;
	}

	char buf[64];
	snprintf (buf, sizeof (buf), "upload/mark/%s_%lu.tga", m_pathPrefix.c_str(), imgIdx);
	path = buf;
	return true;
}

void CGuildMarkManager::SetMarkPathPrefix (const char* prefix)
{
	m_pathPrefix = prefix;
}

bool CGuildMarkManager::LoadMarkIndex()
{
	char buf[64];
	snprintf (buf, sizeof (buf), "upload/mark/%s_index", m_pathPrefix.c_str());
	FILE* fp = fopen (buf, "r");

	if (!fp)
	{
		return false;
	}

	DWORD guildID;
	DWORD markID;

	char line[256];

	while (fgets (line, sizeof (line) - 1, fp))
	{
		sscanf (line, "%lu %lu", &guildID, &markID);
		line[0] = '\0';
		AddMarkIDByGuildID (guildID, markID);
	}

	LoadMarkImages();

	fclose (fp);
	return true;
}

bool CGuildMarkManager::SaveMarkIndex()
{
	char buf[64];
	snprintf (buf, sizeof (buf), "upload/mark/%s_index", m_pathPrefix.c_str());
	FILE* fp = fopen (buf, "w");

	if (!fp)
	{
		TraceError ("MarkManager::SaveMarkData: cannot open index file.");
		return false;
	}

	for (auto it = m_mapGID_MarkID.begin(); it != m_mapGID_MarkID.end(); ++it)
	{
		fprintf (fp, "%d %d\n", it->first, it->second);
	}

	fclose (fp);
	return true;
}

void CGuildMarkManager::LoadMarkImages()
{
	bool isMarkExists[MAX_IMAGE_COUNT];
	memset (isMarkExists, 0, sizeof (isMarkExists));

	for (auto it = m_mapGID_MarkID.begin(); it != m_mapGID_MarkID.end(); ++it)
	{
		DWORD markID = it->second;

		if (markID < MAX_IMAGE_COUNT * CGuildMarkImage::MARK_TOTAL_COUNT)
		{
			isMarkExists[markID / CGuildMarkImage::MARK_TOTAL_COUNT] = true;
		}
	}

	for (DWORD i = 0; i < MAX_IMAGE_COUNT; ++i)
	{
		if (isMarkExists[i])
		{
			__GetImage (i);
		}
	}
}


void CGuildMarkManager::SaveMarkImage (DWORD imgIdx)
{
	std::string path;
	auto fix8123 = std::string(path); //fix8123

	if (GetMarkImageFilename (imgIdx, fix8123))
	{
		if (!__GetImage (imgIdx)->Save (fix8123.c_str()))
		{
			TraceError ("%s Save failed\n", fix8123.c_str());
		}
	}
}


CGuildMarkImage* CGuildMarkManager::__GetImage (DWORD imgIdx)
{
	auto it = m_mapIdx_Image.find (imgIdx);

	if (it == m_mapIdx_Image.end())
	{
		std::string imagePath;
		auto fix8124 = std::string(imagePath); //fix8124

		if (GetMarkImageFilename (imgIdx, fix8124))
		{
			CGuildMarkImage* pkImage = __NewImage();
			m_mapIdx_Image.insert (std::map<DWORD, CGuildMarkImage*>::value_type (imgIdx, pkImage));
			pkImage->Load (fix8124.c_str());
			return pkImage;
		}
		else
		{
			return NULL;
		}
	}
	else
	{
		return it->second;
	}
}

bool CGuildMarkManager::AddMarkIDByGuildID (DWORD guildID, DWORD markID)
{
	if (markID >= MAX_IMAGE_COUNT * CGuildMarkImage::MARK_TOTAL_COUNT)
	{
		return false;
	}

	m_mapGID_MarkID.insert (std::map<DWORD, DWORD>::value_type (guildID, markID));
	m_setFreeMarkID.erase (markID);
	return true;
}

DWORD CGuildMarkManager::GetMarkID (DWORD guildID)
{
	auto it = m_mapGID_MarkID.find (guildID);

	if (it == m_mapGID_MarkID.end())
	{
		return INVALID_MARK_ID;
	}

	return it->second;
}

DWORD CGuildMarkManager::__AllocMarkID (DWORD guildID)
{
	const auto it = m_setFreeMarkID.lower_bound (0);

	if (it == m_setFreeMarkID.end())
	{
		return INVALID_MARK_ID;
	}

	DWORD markID = *it;

	DWORD imgIdx = markID / CGuildMarkImage::MARK_TOTAL_COUNT;
	CGuildMarkImage* pkImage = __GetImage (imgIdx);

	if (pkImage && AddMarkIDByGuildID (guildID, markID))
	{
		return markID;
	}

	return INVALID_MARK_ID;
}

DWORD CGuildMarkManager::GetMarkImageCount() const
{
	return m_mapIdx_Image.size();
}

DWORD CGuildMarkManager::GetMarkCount() const
{
	return m_mapGID_MarkID.size();
}

void CGuildMarkManager::CopyMarkIdx (char* pcBuf) const
{
	WORD* pwBuf = (WORD*)pcBuf;

	for (auto it = m_mapGID_MarkID.begin(); it != m_mapGID_MarkID.end(); ++it)
	{
		* (pwBuf++) = it->first;
		* (pwBuf++) = it->second;
	}
}

DWORD CGuildMarkManager::SaveMark (DWORD guildID, BYTE* pbMarkImage)
{
	DWORD idMark;

	if ((idMark = GetMarkID (guildID)) == INVALID_MARK_ID)
	{
		if ((idMark = __AllocMarkID (guildID)) == INVALID_MARK_ID)
		{
			TraceError ("CGuildMarkManager: cannot alloc mark id %u", guildID);
			return false;
		}
	}

	DWORD imgIdx = (idMark / CGuildMarkImage::MARK_TOTAL_COUNT);
	CGuildMarkImage* pkImage = __GetImage (imgIdx);

	if (pkImage)
	{
		printf ("imgidx %u ", imgIdx);

		std::string pathImage;
		auto fix8128 = std::string(pathImage); //fix8128
		GetMarkImageFilename (imgIdx, fix8128);
		pkImage->Save (fix8128.c_str());

		SaveMarkIndex();
	}

	return idMark;
}

void CGuildMarkManager::DeleteMark (DWORD guildID)
{
	auto it = m_mapGID_MarkID.find (guildID);

	if (it == m_mapGID_MarkID.end())
	{
		return;
	}

	CGuildMarkImage* pkImage;

	if ((pkImage = __GetImage (it->second / CGuildMarkImage::MARK_TOTAL_COUNT)) != NULL)
	{
		pkImage->DeleteMark (it->second % CGuildMarkImage::MARK_TOTAL_COUNT);
	}

	m_mapGID_MarkID.erase (it);
	m_setFreeMarkID.insert (it->second);

	SaveMarkIndex();
}

void CGuildMarkManager::GetDiffBlocks (DWORD imgIdx, const DWORD* crcList, std::map<BYTE, const SGuildMarkBlock*>& mapDiffBlocks)
{
	mapDiffBlocks.clear();

	if (m_mapIdx_Image.end() == m_mapIdx_Image.find (imgIdx))
	{
		TraceError ("invalid idx %u", imgIdx);
		return;
	}

	CGuildMarkImage* p = __GetImage (imgIdx);

	if (p)
	{
		p->GetDiffBlocks (crcList, mapDiffBlocks);
	}
}

bool CGuildMarkManager::SaveBlockFromCompressedData (DWORD imgIdx, DWORD posBlock, const BYTE* pbBlock, DWORD dwSize)
{
	CGuildMarkImage* pkImage = __GetImage (imgIdx);

	if (pkImage)
	{
		pkImage->SaveBlockFromCompressedData (posBlock, pbBlock, dwSize);
	}

	return false;
}

bool CGuildMarkManager::GetBlockCRCList (DWORD imgIdx, DWORD* crcList)
{
	if (m_mapIdx_Image.end() == m_mapIdx_Image.find (imgIdx))
	{
		TraceError ("invalid idx %u", imgIdx);
		return false;
	}

	CGuildMarkImage* p = __GetImage (imgIdx);

	if (p)
	{
		p->GetBlockCRCList (crcList);
	}

	return true;
}

const CGuildMarkManager::TGuildSymbol* CGuildMarkManager::GetGuildSymbol (DWORD guildID)
{
	auto it = m_mapSymbol.find (guildID);

	if (it == m_mapSymbol.end())
	{
		return NULL;
	}

	return &it->second;
}

bool CGuildMarkManager::LoadSymbol (const char* filename)
{
	FILE* fp = fopen (filename, "rb");

	if (!fp)
	{
		return true;
	}
	else
	{
		DWORD symbolCount;
		fread (&symbolCount, 4, 1, fp);

		for (DWORD i = 0; i < symbolCount; i++)
		{
			DWORD guildID;
			DWORD dwSize;
			fread (&guildID, 4, 1, fp);
			fread (&dwSize, 4, 1, fp);

			TGuildSymbol gs;
			gs.raw.resize (dwSize);
			fread (&gs.raw[0], 1, dwSize, fp);
			gs.crc = GetCRC32 (reinterpret_cast<const char*> (&gs.raw[0]), dwSize);
			m_mapSymbol.insert (std::make_pair (guildID, gs));
		}
	}

	fclose (fp);
	return true;
}

void CGuildMarkManager::SaveSymbol (const char* filename)
{
	FILE* fp = fopen (filename, "wb");
	if (!fp)
	{
		TraceError ("Cannot open Symbol file (name: %s)", filename);
		return;
	}

	DWORD symbolCount = m_mapSymbol.size();
	fwrite (&symbolCount, 4, 1, fp);

	for (auto it = m_mapSymbol.begin(); it != m_mapSymbol.end(); ++it)
	{
		DWORD guildID = it->first;
		DWORD dwSize = it->second.raw.size();
		fwrite (&guildID, 4, 1, fp);
		fwrite (&dwSize, 4, 1, fp);
		fwrite (&it->second.raw[0], 1, dwSize, fp);
	}

	fclose (fp);
}

void CGuildMarkManager::UploadSymbol (DWORD guildID, int iSize, const BYTE* pbyData)
{
	if (m_mapSymbol.find (guildID) == m_mapSymbol.end())
	{
		m_mapSymbol.insert (std::make_pair (guildID, TGuildSymbol()));
	}

	TGuildSymbol& rSymbol = m_mapSymbol[guildID];
	rSymbol.raw.clear();

	if (iSize > 0)
	{
		rSymbol.raw.reserve (iSize);
		std::copy (pbyData, (pbyData + iSize), std::back_inserter (rSymbol.raw));
		rSymbol.crc = GetCRC32 (reinterpret_cast<const char*> (pbyData), iSize);
	}
}


