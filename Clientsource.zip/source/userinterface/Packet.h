#include <cstdint>
#pragma once

#include "Locale.h"
#include "../gamelib/RaceData.h"
#include "../gamelib/ItemData.h"

enum EPacketClientGameHeaders
{
	HEADER_CG_ATTACK = 1,
	HEADER_CG_CHAT = 2,
	HEADER_CG_CHARACTER_CREATE = 3,
	HEADER_CG_CHARACTER_DELETE = 4,
	HEADER_CG_CHARACTER_SELECT = 5,
	HEADER_CG_CHARACTER_MOVE = 6,
	HEADER_CG_SYNC_POSITION = 7,
	HEADER_CG_ENTERGAME = 8,
	HEADER_CG_ITEM_USE = 9,
	HEADER_CG_ITEM_DROP = 10,
	HEADER_CG_ITEM_MOVE = 11,
	HEADER_CG_ITEM_PICKUP = 12,
	HEADER_CG_QUICKSLOT_ADD = 13,
	HEADER_CG_QUICKSLOT_DEL = 14,
	HEADER_CG_QUICKSLOT_SWAP = 15,
	HEADER_CG_WHISPER = 16,
	HEADER_CG_ON_CLICK = 17,
	HEADER_CG_EXCHANGE = 18,
	HEADER_CG_CHARACTER_POSITION = 19,
	HEADER_CG_SCRIPT_ANSWER = 20,
	HEADER_CG_QUEST_INPUT_STRING = 21,
	HEADER_CG_QUEST_CONFIRM = 22,
	HEADER_CG_SHOP = 23,
	HEADER_CG_FLY_TARGETING = 24,
	HEADER_CG_USE_SKILL = 25,
	HEADER_CG_ADD_FLY_TARGETING = 26,
	HEADER_CG_SHOOT = 27,
	HEADER_CG_MYSHOP = 28,
	HEADER_CG_ITEM_USE_TO_ITEM = 29,
	HEADER_CG_TARGET = 30,
	HEADER_CG_WARP = 31,
	HEADER_CG_SCRIPT_BUTTON = 32,
	HEADER_CG_MESSENGER = 33,
	HEADER_CG_MALL_CHECKOUT = 34,
	HEADER_CG_SAFEBOX_CHECKIN = 35,
	HEADER_CG_SAFEBOX_CHECKOUT = 36,
	HEADER_CG_PARTY_INVITE = 37,
	HEADER_CG_PARTY_INVITE_ANSWER = 38,
	HEADER_CG_PARTY_REMOVE = 39,
	HEADER_CG_PARTY_SET_STATE = 40,
	HEADER_CG_PARTY_USE_SKILL = 41,
	HEADER_CG_SAFEBOX_ITEM_MOVE = 42,
	HEADER_CG_PARTY_PARAMETER = 43,
	HEADER_CG_GUILD = 44,
	HEADER_CG_ANSWER_MAKE_GUILD = 45,
	HEADER_CG_FISHING = 46,
	HEADER_CG_ITEM_GIVE = 47,
	HEADER_CG_EMPIRE = 48,
	HEADER_CG_REFINE = 49,
	HEADER_CG_MARK_LOGIN = 50,
	HEADER_CG_MARK_CRCLIST = 51,
	HEADER_CG_MARK_UPLOAD = 52,
	HEADER_CG_MARK_IDXLIST = 53,
	HEADER_CG_CHANGE_NAME = 54,
	HEADER_CG_LOGIN2 = 55,
	HEADER_CG_LOGIN3 = 56,
	HEADER_CG_GUILD_SYMBOL_UPLOAD = 57,
	HEADER_CG_GUILD_SYMBOL_CRC = 58,
	HEADER_CG_SCRIPT_SELECT_ITEM = 59,
	HEADER_CG_DRAGON_SOUL_REFINE = 60,
#ifdef ENABLE_ACCE_SYSTEM
	HEADER_CG_ACCE = 61,
#endif
#ifdef ENABLE_SWITCHBOT
	HEADER_CG_SWITCHBOT = 62,
#endif
	//MULTI_LANGUAGE
	HEADER_CG_SET_LANGUAGE = 63,
	//MULTI_LANGUAGE

	HEADER_CG_HANDSHAKE = 150,
	HEADER_CG_PONG = 151,
	HEADER_CG_TIME_SYNC = 152,
};

enum EPacketGameClientHeaders
{
	HEADER_GC_CHARACTER_ADD = 1,
	HEADER_GC_CHARACTER_DEL = 2,
	HEADER_GC_CHARACTER_MOVE = 3,
	HEADER_GC_CHAT = 4,
	HEADER_GC_SYNC_POSITION = 5,
	HEADER_GC_LOGIN_SUCCESS = 6,
	HEADER_GC_LOGIN_FAILURE = 7,
	HEADER_GC_CHARACTER_CREATE_SUCCESS = 8,
	HEADER_GC_CHARACTER_CREATE_FAILURE = 9,
	HEADER_GC_CHARACTER_DELETE_SUCCESS = 10,
	HEADER_GC_CHARACTER_DELETE_FAILURE = 11,
	HEADER_GC_STUN = 12,
	HEADER_GC_DEAD = 13,
	HEADER_GC_CHARACTER_POINTS = 14,
	HEADER_GC_CHARACTER_POINT_CHANGE = 15,
	HEADER_GC_CHARACTER_UPDATE = 16,
	HEADER_GC_ITEM_DEL = 17,
	HEADER_GC_ITEM_SET = 18,
	HEADER_GC_ITEM_USE = 19,
	HEADER_GC_ITEM_UPDATE = 20,
	HEADER_GC_ITEM_GROUND_ADD = 21,
	HEADER_GC_ITEM_GROUND_DEL = 22,
	HEADER_GC_QUICKSLOT_ADD = 23,
	HEADER_GC_QUICKSLOT_DEL = 24,
	HEADER_GC_QUICKSLOT_SWAP = 25,
	HEADER_GC_ITEM_OWNERSHIP = 26,
	HEADER_GC_WHISPER = 27,
	HEADER_GC_MOTION = 28,
	HEADER_GC_SHOP = 29,
	HEADER_GC_SHOP_SIGN = 30,
	HEADER_GC_DUEL_START = 31,
	HEADER_GC_PVP = 32,
	HEADER_GC_EXCHANGE = 33,
	HEADER_GC_CHARACTER_POSITION = 34,
	HEADER_GC_PING = 35,
	HEADER_GC_SCRIPT = 36,
	HEADER_GC_QUEST_CONFIRM = 37,
	HEADER_GC_OWNERSHIP = 38,
	HEADER_GC_TARGET = 39,
	HEADER_GC_WARP = 40,
	HEADER_GC_ADD_FLY_TARGETING = 41,
	HEADER_GC_CREATE_FLY = 42,
	HEADER_GC_FLY_TARGETING = 43,
	HEADER_GC_SKILL_LEVEL = 44,
	HEADER_GC_MESSENGER = 45,
	HEADER_GC_GUILD = 46,
	HEADER_GC_PARTY_INVITE = 47,
	HEADER_GC_PARTY_ADD = 48,
	HEADER_GC_PARTY_UPDATE = 49,
	HEADER_GC_PARTY_REMOVE = 50,
	HEADER_GC_QUEST_INFO = 51,
	HEADER_GC_REQUEST_MAKE_GUILD = 52,
	HEADER_GC_PARTY_PARAMETER = 53,
	HEADER_GC_SAFEBOX_SET = 54,
	HEADER_GC_SAFEBOX_DEL = 55,
	HEADER_GC_SAFEBOX_WRONG_PASSWORD = 56,
	HEADER_GC_SAFEBOX_SIZE = 57,
	HEADER_GC_FISHING = 58,
	HEADER_GC_EMPIRE = 59,
	HEADER_GC_PARTY_LINK = 60,
	HEADER_GC_PARTY_UNLINK = 61,
	HEADER_GC_VIEW_EQUIP = 62,
	HEADER_GC_MARK_BLOCK = 63,
	HEADER_GC_MARK_IDXLIST = 64,
	HEADER_GC_TIME = 65,
	HEADER_GC_CHANGE_NAME = 66,
	HEADER_GC_DUNGEON = 67,
	HEADER_GC_WALK_MODE = 68,
	HEADER_GC_SKILL_GROUP = 69,
	HEADER_GC_MAIN_CHARACTER = 70,
	HEADER_GC_SEPCIAL_EFFECT = 71,
	HEADER_GC_REFINE_INFORMATION = 72,
	HEADER_GC_CHANNEL = 73,
	HEADER_GC_TARGET_UPDATE = 74,
	HEADER_GC_TARGET_DELETE = 75,
	HEADER_GC_TARGET_CREATE = 76,
	HEADER_GC_AFFECT_ADD = 77,
	HEADER_GC_AFFECT_REMOVE = 78,
	HEADER_GC_MALL_OPEN = 79,
	HEADER_GC_MALL_SET = 80,
	HEADER_GC_MALL_DEL = 81,
	HEADER_GC_LAND_LIST = 82,
	HEADER_GC_LOVER_INFO = 83,
	HEADER_GC_LOVE_POINT_UPDATE = 84,
	HEADER_GC_GUILD_SYMBOL_DATA = 85,
	HEADER_GC_DIG_MOTION = 86,
	HEADER_GC_DAMAGE_INFO = 87,
	HEADER_GC_CHAR_ADDITIONAL_INFO = 88,
	HEADER_GC_MAIN_CHARACTER3_BGM = 89,
	HEADER_GC_MAIN_CHARACTER4_BGM_VOL = 90,
	HEADER_GC_AUTH_SUCCESS = 91,
	HEADER_GC_SPECIFIC_EFFECT = 92,
	HEADER_GC_DRAGON_SOUL_REFINE = 93,
#ifdef ENABLE_PLAYER_BLOCK_SYSTEM
	HEADER_GC_PLAYER_BLOCK = 94,
#endif
#ifdef ENABLE_ACCE_SYSTEM
	HEADER_GC_ACCE = 95,
#endif
#ifdef ENABLE_SWITCHBOT
	HEADER_GC_SWITCHBOT = 96,
#endif
#ifdef ENABLE_GUILD_TOKEN_AUTH
	HEADER_GC_GUILD_TOKEN = 97,
#endif
	HEADER_GC_LOCALE_MSG = 98,
	HEADER_GC_HANDSHAKE = 150,
	HEADER_GC_HANDSHAKE_OK = 152,
	HEADER_GC_PHASE = 153,
};

enum
{
	ID_MAX_NUM = 30,
	PASS_MAX_NUM = 16,
	CHAT_MAX_NUM = 128,
	PATH_NODE_MAX_NUM = 64,
	SHOP_SIGN_MAX_LEN = 32,

	PLAYER_PER_ACCOUNT = 4,

	PLAYER_ITEM_SLOT_MAX_NUM = 20,

	QUICKSLOT_MAX_LINE = 4,
	QUICKSLOT_MAX_COUNT_PER_LINE = 8,
	QUICKSLOT_MAX_COUNT = QUICKSLOT_MAX_LINE * QUICKSLOT_MAX_COUNT_PER_LINE,

	QUICKSLOT_MAX_NUM = 36,

	SHOP_HOST_ITEM_MAX_NUM = 40,

	METIN_SOCKET_COUNT = 6,

	PARTY_AFFECT_SLOT_MAX_NUM = 7,

	GUILD_GRADE_NAME_MAX_LEN = 8,
	GUILD_NAME_MAX_LEN = 12,
	GUILD_GRADE_COUNT = 15,
	GULID_COMMENT_MAX_LEN = 50,

	MARK_CRC_NUM = 8 * 8,
	MARK_DATA_SIZE = 16 * 12,
	SYMBOL_DATA_SIZE = 128 * 256,
	QUEST_INPUT_STRING_MAX_NUM = 64,

	PRIVATE_CODE_LENGTH = 8,

	REFINE_MATERIAL_MAX_NUM = 5,

	WEAR_MAX_NUM = CItemData::WEAR_MAX_NUM,

	SHOP_TAB_NAME_MAX = 32,
	SHOP_TAB_COUNT_MAX = 3,
};

#pragma pack(push)
#pragma pack(1)

typedef struct command_mark_login_check_draveniu
{
	BYTE    header;
	DWORD   handle;
	DWORD   random_key;
} TPacketCGMarkLoginCheckDraveniu;

typedef struct command_mark_upload_check_draveniu
{
	BYTE    header;
	DWORD   gid;
	BYTE    image[16 * 12 * 4];
#ifdef ENABLE_GUILD_TOKEN_AUTH
	uint64_t   token;
#endif
} TPacketCGMarkUploadCheckDraveniu;

typedef struct command_mark_idxlist_check_draveniu
{
	BYTE    header;
} TPacketCGMarkIDXListCheckDraveniu;

typedef struct command_mark_crclist_check_draveniu
{
	BYTE    header;
	BYTE    imgIdx;
	DWORD   crclist[80];
} TPacketCGMarkCRCListCheckDraveniu;

typedef struct packet_mark_idxlist_check_draveniu
{
	BYTE    header;
	DWORD	bufSize;
	WORD    count;
} TPacketGCMarkIDXListCheckDraveniu;

typedef struct packet_mark_block_check_draveniu
{
	BYTE    header;
	DWORD   bufSize;
	BYTE	imgIdx;
	DWORD   count;
} TPacketGCMarkBlockCheckDraveniu;

typedef struct command_symbol_upload_check_draveniu
{
	BYTE	header;
	WORD	size;
	DWORD	handle;
#ifdef ENABLE_GUILD_TOKEN_AUTH
	uint64_t	token;
#endif
} TPacketCGSymbolUploadCheckDraveniu;

typedef struct command_symbol_crc_check_draveniu
{
	BYTE	header;
	DWORD	dwGuildID;
	DWORD	dwCRC;
	DWORD	dwSize;
} TPacketCGSymbolCRCCheckDraveniu;

typedef struct packet_symbol_data_check_draveniu
{
	BYTE header;
	WORD size;
	DWORD guild_id;
} TPacketGCGuildSymbolDataCheckDraveniu;

typedef struct command_login_acheck_draveniu
{
	BYTE	header;
	char	name[ID_MAX_NUM + 1];
	DWORD	login_key;
} TPacketCGLoginACheckDraveniu;

typedef struct command_login_bcheck_draveniu
{
	BYTE	header;
	char	name[ID_MAX_NUM + 1];
	char	pwd[PASS_MAX_NUM + 1];
#ifdef ENABLE_CHECK_CLIENT_VERSION_SERVER_AND_PIN
	char	pin[PASS_MAX_NUM + 1];
#endif
} TPacketCGLoginBCheckDraveniu;

typedef struct command_player_select_check_draveniu
{
	BYTE	header;
	BYTE	player_index;
} TPacketCGSelectCharacterCheckDraveniu;

typedef struct command_attack_check_draveniu
{
	BYTE	header;
	BYTE	bType;
	DWORD	dwVictimVID;
} TPacketCGAttackDirectEnterCheckDraveniu;

typedef struct command_chat_check_draveniu
{
	BYTE	header;
	WORD	length;
	BYTE	type;
} TPacketCGChatCheckDraveniu;

typedef struct command_whisper_check_draveniu
{
	BYTE        bHeader;
	WORD        wSize;
	char        szNameTo[CHARACTER_NAME_MAX_LEN + 1];
} TPacketCGWhisperCheckDraveniu;

typedef struct command_enter_check_draveniu
{
	BYTE header;
} TPacketCGEnterGameCheckDraveniu;

typedef struct command_item_use_check_draveniu
{
	BYTE header;
	TItemPos pos;
} TPacketCGItemUseCheckDraveniu;

typedef struct command_item_use_to_item_check_draveniu
{
	BYTE header;
	TItemPos source_pos;
	TItemPos target_pos;
} TPacketCGItemUseBCheckDraveniu;


typedef struct command_item_drop_check_draveniu
{
	BYTE		header;
	TItemPos pos;
	WORD	count;
} TPacketCGItemDropCheckDraveniu;

typedef struct command_item_move_check_draveniu
{
	BYTE header;
	TItemPos pos;
	TItemPos change_pos;
	WORD num;
} TPacketCGItemMoveCheckDraveniu;

typedef struct command_item_pickup_check_draveniu
{
	BYTE header;
	DWORD vid;
} TPacketCGItemPickUpCheckDraveniu;

typedef struct command_quickslot_add_check_draveniu
{
	BYTE        header;
	BYTE        pos;
	TQuickSlot	slot;
} TPacketCGQuickSlotAddCheckDraveniu;

typedef struct command_quickslot_del_check_draveniu
{
	BYTE        header;
	BYTE        pos;
} TPacketCGQuickSlotDelCheckDraveniu;

typedef struct command_quickslot_swap_check_draveniu
{
	BYTE        header;
	BYTE        pos;
	BYTE        change_pos;
} TPacketCGQuickSlotSwapCheckDraveniu;

typedef struct command_on_click_check_draveniu
{
	BYTE		header;
	DWORD		vid;
} TPacketCGOnClickCheckDraveniu;


enum
{
	SHOP_SUBHEADER_CG_END,
	SHOP_SUBHEADER_CG_BUY,
	SHOP_SUBHEADER_CG_SELL,
	SHOP_SUBHEADER_CG_SELL2,
};

typedef struct command_shop_check_draveniu
{
	BYTE        header;
	BYTE		subheader;
} TPacketCGShopCheckDraveniu;

enum
{
	EXCHANGE_SUBHEADER_CG_START,
	EXCHANGE_SUBHEADER_CG_ITEM_ADD,
	EXCHANGE_SUBHEADER_CG_ITEM_DEL,
	EXCHANGE_SUBHEADER_CG_ELK_ADD,
	EXCHANGE_SUBHEADER_CG_ACCEPT,
	EXCHANGE_SUBHEADER_CG_CANCEL,
};

typedef struct command_exchange_check_draveniu
{
	BYTE		header;
	BYTE		subheader;
	long long	arg1;
	BYTE		arg2;
	TItemPos	Pos;
} TPacketCGExchangeCheckDraveniu;

typedef struct command_position_check_draveniu
{
	BYTE        header;
	BYTE        position;
} TPacketCGPositionCheckDraveniu;

typedef struct command_script_answer_check_draveniu
{
	BYTE        header;
	BYTE		answer;
} TPacketCGScriptAnswerCheckDraveniu;

typedef struct command_script_button_check_draveniu
{
	BYTE        header;
	unsigned int			idx;
} TPacketCGScriptButtonCheckDraveniu;

typedef struct command_target_check_draveniu
{
	BYTE        header;
	DWORD       dwVID;
} TPacketCGTargetCheckDraveniu;

typedef struct command_move_check_draveniu
{
	BYTE		bHeader;
	BYTE		bFunc;
	BYTE		bArg;
	BYTE		bRot;
	LONG		lX;
	LONG		lY;
	DWORD		dwTime;
} TPacketCGMoveCheckDraveniu;

typedef struct command_sync_position_element_check_draveniu
{
	DWORD       dwVID;
	long        lX;
	long        lY;
} TPacketCGSyncPositionElementCheckDraveniu;

typedef struct command_sync_position_bcheck_draveniu
{
	BYTE        bHeader;
	WORD		wSize;
} TPacketCGSyncPositionBCheckDraveniu;

typedef struct command_fly_targeting_acheck_draveniu
{
	BYTE		bHeader;
	DWORD		dwTargetVID;
	long		lX;
	long		lY;
} TPacketCGFlyTargetingACheckDraveniu;

typedef struct packet_fly_targeting_bcheck_draveniu
{
	BYTE        bHeader;
	DWORD		dwShooterVID;
	DWORD		dwTargetVID;
	long		lX;
	long		lY;
} TPacketGCFlyTargetingBCheckDraveniu;

typedef struct packet_shoot_sccheck_draveniu
{
	BYTE		bHeader;
	BYTE		bType;
} TPacketCGShootscCheckDraveniu;

enum
{
	MESSENGER_SUBHEADER_GC_LIST,
	MESSENGER_SUBHEADER_GC_LOGIN,
	MESSENGER_SUBHEADER_GC_LOGOUT,
	MESSENGER_SUBHEADER_GC_INVITE,
};

typedef struct packet_messenger_abcheck_draveniu
{
	BYTE header;
	WORD size;
	BYTE subheader;
} TPacketGCMessengerabCheckDraveniu;

typedef struct packet_messenger_list_offline_accheck_draveniu
{
	BYTE connected;
	BYTE length;
} TPacketGCMessengerListOfflineacbCheckDraveniu;

enum
{
	MESSENGER_CONNECTED_STATE_OFFLINE,
	MESSENGER_CONNECTED_STATE_ONLINE,
};

typedef struct packet_messenger_list_online_ackkheck_draveniu
{
	BYTE connected;
	BYTE length;
} TPacketGCMessengerListOnlineackkCheckDraveniu;

typedef struct packet_messenger_login_checklog_draveniu
{
	BYTE length;
} TPacketGCMessengerLoginUnSignedCheckDraveniu;

typedef struct packet_messenger_logout_checklogut_draveniu
{
	BYTE length;
} TPacketGCMessengerLogoutUnSignedCheckDraveniu;

enum
{
	MESSENGER_SUBHEADER_CG_ADD_BY_VID,
	MESSENGER_SUBHEADER_CG_ADD_BY_NAME,
	MESSENGER_SUBHEADER_CG_REMOVE,
};

typedef struct command_messenger_acheck_draveniu
{
	BYTE header;
	BYTE subheader;
} TPacketCGMessengerAcheckDraveniu;

enum
{
	SAFEBOX_MONEY_STATE_SAVE,
	SAFEBOX_MONEY_STATE_WITHDRAW,
};

typedef struct command_safebox_checkout_acheck_draveniu
{
	BYTE        bHeader;
	BYTE        bSafePos;
	TItemPos	ItemPos;
} TPacketCGSafeboxCheckoutAcheckDraveniu;

typedef struct command_safebox_checkin_acheck_draveniu
{
	BYTE        bHeader;
	BYTE        bSafePos;
	TItemPos	ItemPos;
} TPacketCGSafeboxCheckinAcheckDraveniu;

typedef struct command_mall_checkout_acvheck_draveniu
{
	BYTE        bHeader;
	BYTE        bMallPos;
	TItemPos	ItemPos;
} TPacketCGMallCheckoutAchecvkDraveniu;

typedef struct command_use_skill_acvheck_draveniu
{
	BYTE                bHeader;
	DWORD               dwVnum;
	DWORD				dwTargetVID;
} TPacketCGUseSkillAbchecvkDraveniu;

typedef struct command_party_invite_acheck_draveniu
{
	BYTE header;
	DWORD vid;
} TPacketCGPartyInviteACheckDraveniu;

typedef struct command_party_invite_answer_bcheck_draveniu
{
	BYTE header;
	DWORD leader_pid;
	BYTE accept;
} TPacketCGPartyInviteAnswerBCheckDraveniu;

typedef struct command_party_remove_bcheck_draveniu
{
	BYTE header;
	DWORD pid;
} TPacketCGPartyRemoveBCheckDraveniu;

typedef struct command_party_set_state_bcheck_draveniu
{
	BYTE byHeader;
	DWORD dwVID;
	BYTE byState;
	BYTE byFlag;
} TPacketCGPartySetStateBCheckDraveniu;

typedef struct packet_party_link_bcheck_draveniu
{
	BYTE header;
	DWORD pid;
	DWORD vid;
} TPacketGCPartyLinkBCheckDraveniu;

typedef struct command_party_use_skill_bcheck_draveniu
{
	BYTE byHeader;
	BYTE bySkillIndex;
	DWORD dwTargetVID;
} TPacketCGPartyUseSkillBCheckDraveniu;

enum
{
	GUILD_SUBHEADER_CG_ADD_MEMBER,
	GUILD_SUBHEADER_CG_REMOVE_MEMBER,
	GUILD_SUBHEADER_CG_CHANGE_GRADE_NAME,
	GUILD_SUBHEADER_CG_CHANGE_GRADE_AUTHORITY,
	GUILD_SUBHEADER_CG_OFFER,
	GUILD_SUBHEADER_CG_POST_COMMENT,
	GUILD_SUBHEADER_CG_DELETE_COMMENT,
	GUILD_SUBHEADER_CG_REFRESH_COMMENT,
	GUILD_SUBHEADER_CG_CHANGE_MEMBER_GRADE,
	GUILD_SUBHEADER_CG_USE_SKILL,
	GUILD_SUBHEADER_CG_CHANGE_MEMBER_GENERAL,
	GUILD_SUBHEADER_CG_GUILD_INVITE_ANSWER,
	GUILD_SUBHEADER_CG_CHARGE_GSP,
	GUILD_SUBHEADER_CG_DEPOSIT_MONEY,
	GUILD_SUBHEADER_CG_WITHDRAW_MONEY,
};

typedef struct command_guild_acheck_draveniu
{
	BYTE byHeader;
	BYTE bySubHeader;
} TPacketCGGuildACheckDraveniu;

typedef struct command_guild_answer_make_guild_acheck_draveniu
{
	BYTE header;
	char guild_name[GUILD_NAME_MAX_LEN + 1];
} TPacketCGAnswerMakeGuildBCheckDraveniu;

typedef struct command_give_item_scheck_draveniu
{
	BYTE byHeader;
	DWORD dwTargetVID;
	TItemPos ItemPos;
	BYTE byItemCount;
} TPacketCGGiveItemSCheckDraveniu;

typedef struct SShopItemTableSCheckDraveniu
{
	DWORD		vnum;
	WORD		count;

	TItemPos	pos;
	long long		price;
	BYTE		display_pos;
} TShopItemTableCSCheckDraveniu;

typedef struct SPacketCGMyShopSCheckDraveniu
{
	BYTE        bHeader;
	char        szSign[SHOP_SIGN_MAX_LEN + 1];
	BYTE        bCount;
} TPacketCGMyShopCSCheckDraveniu;

typedef struct SPacketCGRefineSCheckDraveniu
{
	BYTE		header;
	BYTE		pos;
	BYTE		type;
} TPacketCGRefineCSCheckDraveniu;

typedef struct SPacketCGChangeNameCheckDraveniu
{
	BYTE header;
	BYTE index;
	char name[CHARACTER_NAME_MAX_LEN + 1];
} TPacketCGChangeNameCSCheckDraveniu;

enum EPartyExpDistributionType
{
	PARTY_EXP_DISTRIBUTION_NON_PARITY,
	PARTY_EXP_DISTRIBUTION_PARITY,
};

typedef struct command_party_parameter_cvheckk_draveniu
{
	BYTE        bHeader;
	BYTE        bDistributeMode;
} TPacketCGPartyParameterCSCheckDraveniu;

typedef struct command_quest_input_string_wheckk_draveniu
{
	BYTE        bHeader;
	char		szString[QUEST_INPUT_STRING_MAX_NUM + 1];
} TPacketCGQuestInputStringCSCheckDraveniu;

typedef struct command_quest_confirm_wheckk_draveniu
{
	BYTE header;
	BYTE answer;
	DWORD requestPID;
} TPacketCGQuestConfirmCSCheckDraveniu;

typedef struct command_script_select_item_selckk_draveniu
{
	BYTE header;
	DWORD selection;
} TPacketCGScriptSelectItemCSCheckDraveniu;

enum EPhase
{
	PHASE_CLOSE,
	PHASE_HANDSHAKE,
	PHASE_LOGIN,
	PHASE_SELECT,
	PHASE_LOADING,
	PHASE_GAME,
	PHASE_DEAD,
	PHASE_DBCLIENT_CONNECTING,
	PHASE_DBCLIENT,
	PHASE_P2P,
	PHASE_AUTH,
};

typedef struct packet_phase_cheek_draveniu
{
	BYTE        header;
	BYTE        phase;
} TPacketGCPhaseCSCheckDraveniu;

typedef struct packet_blank
{
	BYTE		header;
} TPacketGCBlank;

typedef struct packet_blank_dynamic
{
	BYTE		header;
	WORD		size;
} TPacketGCBlankDynamic;

typedef struct packet_header_handshake_cheek_draveniu
{
	BYTE		header;
	DWORD		dwHandshake;
	DWORD		dwTime;
	LONG		lDelta;
} TPacketGCHandshakeCSCheckDraveniu;

typedef struct packet_header_dynamic_size
{
	BYTE		header;
	WORD		size;
} TDynamicSizePacketHeader;

// Server-side localized chat/notice packet.
// The current Python pack may not consume it yet, but the client must
// recognize and drain it so later packets stay aligned.
typedef struct packet_locale_msg
{
	BYTE	header;
	WORD	wSize;
	WORD	wKey;
	BYTE	bChatType;
	BYTE	bParamCount;
} TPacketGCLocaleMsg;

typedef struct SSimplePlayerInformation
{
	DWORD               dwID;
	char                szName[CHARACTER_NAME_MAX_LEN + 1];
	BYTE                byJob;
	BYTE                byLevel;
	DWORD               dwPlayMinutes;
	BYTE                byST, byHT, byDX, byIQ;
	DWORD               wMainPart;
	BYTE                bChangeName;
	DWORD				wHairPart;
#ifdef ENABLE_ACCE_SYSTEM
	DWORD				wAccePart;
#endif
	BYTE				bDummy[4];
	long				x, y;
	LONG				lAddr;
	WORD				wPort;
	BYTE				bySkillGroup;
} TSimplePlayerInformation;

typedef struct packet_login_success
{
	BYTE header;
	TSimplePlayerInformation akSimplePlayerInformation[PLAYER_PER_ACCOUNT];
	DWORD guild_id[PLAYER_PER_ACCOUNT];
	char guild_name[PLAYER_PER_ACCOUNT][GUILD_NAME_MAX_LEN + 1];
	DWORD handle;
	DWORD random_key;
} TPacketGCLoginSuccess;

enum
{
LOGIN_STATUS_MAX_LEN = 8
};

typedef struct packet_login_failure_cheek_draveniu
{
	BYTE	header;
	char	szStatus[LOGIN_STATUS_MAX_LEN + 1];
} TPacketGCLoginFailureCSCheckDraveniu;

typedef struct command_player_create_cheek_draveniu
{
	BYTE        header;
	BYTE        index;
	char        name[CHARACTER_NAME_MAX_LEN + 1];
	WORD        job;
	BYTE		shape;
	BYTE		CON;
	BYTE		INT;
	BYTE		STR;
	BYTE		DEX;
} TPacketCGCreateCharacterCSCheckDraveniu;

typedef struct command_player_create_success_cheek_draveniu
{
	BYTE						header;
	BYTE						bAccountCharacterSlot;
	TSimplePlayerInformation	kSimplePlayerInfomation;
} TPacketGCPlayerCreateSuccessACSCheckDraveniu;

typedef struct command_create_failure_cheek_draveniu
{
	BYTE	header;
	BYTE	bType;
} TPacketGCCreateFailureBCSCheckDraveniu;

typedef struct command_player_delete_cheek_draveniu
{
	BYTE        header;
	BYTE        index;
	char		szPrivateCode[PRIVATE_CODE_LENGTH];
} TPacketCGDestroyCharacterVCheckDraveniu;

typedef struct packet_player_delete_success
{
	BYTE        header;
	BYTE        account_index;
} TPacketGCDestroyCharacterSuccess;

enum
{
	ADD_CHARACTER_STATE_DEAD = (1 << 0),
	ADD_CHARACTER_STATE_SPAWN = (1 << 1),
	ADD_CHARACTER_STATE_GUNGON = (1 << 2),
	ADD_CHARACTER_STATE_KILLER = (1 << 3),
	ADD_CHARACTER_STATE_PARTY = (1 << 4),
};

enum EPKModes
{
	PK_MODE_PEACE,
	PK_MODE_REVENGE,
	PK_MODE_FREE,
	PK_MODE_PROTECT,
	PK_MODE_GUILD,
#ifdef ENABLE_LEAGUEOFLEGENDS_BONUS
	PK_MODE_DUNGEON,
#endif
	PK_MODE_MAX_NUM,
};

enum ECharacterEquipmentPart
{
	CHR_EQUIPPART_ARMOR,
	CHR_EQUIPPART_WEAPON,
	CHR_EQUIPPART_HEAD,
	CHR_EQUIPPART_HAIR,
#ifdef ENABLE_ACCE_SYSTEM
	CHR_EQUIPPART_ACCE,
#endif
	CHR_EQUIPPART_NUM,
};

typedef struct packet_char_additional_info
{
	BYTE    header;
	DWORD   dwVID;
	char    name[CHARACTER_NAME_MAX_LEN + 1];
	DWORD   awPart[CHR_EQUIPPART_NUM];
	BYTE	bEmpire;
	DWORD   dwGuildID;
	DWORD   dwLevel;
	short   sAlignment;
	BYTE    bPKMode;
	DWORD   dwMountVnum;
} TPacketGCCharacterAdditionalInfo;

typedef struct packet_add_char
{
	BYTE        header;

	DWORD       dwVID;

	float       angle;
	long        x;
	long        y;
	long        z;

	BYTE		bType;
	DWORD        wRaceNum;
	DWORD		bMovingSpeed;
	DWORD		bAttackSpeed;

	BYTE        bStateFlag;
	DWORD       dwAffectFlag[2];
} TPacketGCCharacterAdd;

typedef struct packet_update_char
{
	BYTE        header;
	DWORD       dwVID;

	DWORD       awPart[CHR_EQUIPPART_NUM];
	DWORD		bMovingSpeed;
	DWORD		bAttackSpeed;

	BYTE        bStateFlag;
	DWORD       dwAffectFlag[2];

	DWORD		dwGuildID;
	short       sAlignment;
	BYTE		bPKMode;
	DWORD		dwMountVnum;
} TPacketGCCharacterUpdate;

typedef struct packet_del_char
{
	BYTE	header;
	DWORD	dwVID;
} TPacketGCCharacterDelete;

enum EChatType
{
	CHAT_TYPE_TALKING,
	CHAT_TYPE_INFO,
	CHAT_TYPE_NOTICE,
	CHAT_TYPE_PARTY,
	CHAT_TYPE_GUILD,
	CHAT_TYPE_COMMAND,
	CHAT_TYPE_SHOUT,
	CHAT_TYPE_WHISPER,
	CHAT_TYPE_BIG_NOTICE,
	CHAT_TYPE_MONARCH_NOTICE,
	CHAT_TYPE_MAX_NUM
};

typedef struct packet_chat
{
	BYTE	header;
	WORD	size;
	BYTE	type;
	DWORD	dwVID;
	BYTE	bEmpire;
} TPacketGCChat;

typedef struct packet_whisper
{
	BYTE        bHeader;
	WORD        wSize;
	BYTE        bType;
	char        szNameFrom[CHARACTER_NAME_MAX_LEN + 1];
} TPacketGCWhisper;

typedef struct packet_stun
{
	BYTE		header;
	DWORD		vid;
} TPacketGCStun;

typedef struct packet_dead
{
	BYTE	header;
	DWORD	vid;
} TPacketGCDead;

typedef struct packet_main_character
{
	BYTE header;
	DWORD dwVID;
	DWORD wRaceNum;
	char szName[CHARACTER_NAME_MAX_LEN + 1];
	long lX, lY, lZ;
	BYTE byEmpire;
	BYTE bySkillGroup;
} TPacketGCMainCharacter;

typedef struct packet_main_character3_bgm
{
	BYTE header;
	DWORD dwVID;
	DWORD wRaceNum;
	char szUserName[CHARACTER_NAME_MAX_LEN + 1];
	char szBGMName[24 + 1];
	long lX, lY, lZ;
	BYTE byEmpire;
	BYTE bySkillGroup;
} TPacketGCMainCharacter3_BGM;

typedef struct packet_main_character4_bgm_vol
{
	BYTE header;
	DWORD dwVID;
	DWORD wRaceNum;
	char szUserName[CHARACTER_NAME_MAX_LEN + 1];
	char szBGMName[24 + 1];
	float fBGMVol;
	long lX, lY, lZ;
	BYTE byEmpire;
	BYTE bySkillGroup;
} TPacketGCMainCharacter4_BGM_VOL;

enum eFlyTypes
{
	FLY_NONE,
	FLY_EXP,
	FLY_HP_MEDIUM,
	FLY_HP_BIG,
	FLY_SP_SMALL,
	FLY_SP_MEDIUM,
	FLY_SP_BIG,
	FLY_FIREWORK1,
	FLY_FIREWORK2,
	FLY_FIREWORK3,
	FLY_FIREWORK4,
	FLY_FIREWORK5,
	FLY_FIREWORK6,
	FLY_FIREWORK_XMAS,
	FLY_CHAIN_LIGHTNING,
	FLY_HP_SMALL,
	FLY_SKILL_MUYEONG,
};

enum EPointTypes
{
	POINT_NONE,
	POINT_LEVEL,
	POINT_VOICE,
	POINT_EXP,
	POINT_NEXT_EXP,
	POINT_HP,
	POINT_MAX_HP,
	POINT_SP,
	POINT_MAX_SP,
	POINT_STAMINA,
	POINT_MAX_STAMINA,
	POINT_GOLD,
	POINT_ST,
	POINT_HT,
	POINT_DX,
	POINT_IQ,
	POINT_ATT_POWER,
	POINT_ATT_SPEED,
	POINT_EVADE_RATE,
	POINT_MOV_SPEED,
	POINT_DEF_GRADE,
	POINT_CASTING_SPEED,
	POINT_MAGIC_ATT_GRADE,
	POINT_MAGIC_DEF_GRADE,
	POINT_EMPIRE_POINT,
	POINT_LEVEL_STEP,
	POINT_STAT,
	POINT_SUB_SKILL,
	POINT_SKILL,
	POINT_MIN_ATK,
	POINT_MAX_ATK,
	POINT_PLAYTIME,
	POINT_HP_REGEN,
	POINT_SP_REGEN,
	POINT_BOW_DISTANCE,
	POINT_HP_RECOVERY,
	POINT_SP_RECOVERY,
	POINT_POISON_PCT,
	POINT_STUN_PCT,
	POINT_SLOW_PCT,
	POINT_CRITICAL_PCT,
	POINT_PENETRATE_PCT,
	POINT_CURSE_PCT,
	POINT_ATTBONUS_HUMAN,
	POINT_ATTBONUS_ANIMAL,
	POINT_ATTBONUS_ORC,
	POINT_ATTBONUS_MILGYO,
	POINT_ATTBONUS_UNDEAD,
	POINT_ATTBONUS_DEVIL,
	POINT_ATTBONUS_INSECT,
	POINT_ATTBONUS_FIRE,
	POINT_ATTBONUS_ICE,
	POINT_ATTBONUS_DESERT,
	POINT_ATTBONUS_MONSTER,
	POINT_ATTBONUS_WARRIOR,
	POINT_ATTBONUS_ASSASSIN,
	POINT_ATTBONUS_SURA,
	POINT_ATTBONUS_SHAMAN,
	POINT_ATTBONUS_TREE,
	POINT_RESIST_WARRIOR,
	POINT_RESIST_ASSASSIN,
	POINT_RESIST_SURA,
	POINT_RESIST_SHAMAN,
	POINT_STEAL_HP,
	POINT_STEAL_SP,
	POINT_MANA_BURN_PCT,
	POINT_DAMAGE_SP_RECOVER,
	POINT_BLOCK,
	POINT_DODGE,
	POINT_RESIST_SWORD,
	POINT_RESIST_TWOHAND,
	POINT_RESIST_DAGGER,
	POINT_RESIST_BELL,
	POINT_RESIST_FAN,
	POINT_RESIST_BOW,
	POINT_RESIST_FIRE,
	POINT_RESIST_ELEC,
	POINT_RESIST_MAGIC,
	POINT_RESIST_WIND,
	POINT_REFLECT_MELEE,
	POINT_REFLECT_CURSE,
	POINT_POISON_REDUCE,
	POINT_KILL_SP_RECOVER,
	POINT_EXP_DOUBLE_BONUS,
	POINT_GOLD_DOUBLE_BONUS,
	POINT_ITEM_DROP_BONUS,
	POINT_POTION_BONUS,
	POINT_KILL_HP_RECOVER,
	POINT_IMMUNE_STUN,
	POINT_IMMUNE_SLOW,
	POINT_IMMUNE_FALL,
	POINT_PARTY_ATT_GRADE,
	POINT_PARTY_DEF_GRADE,
	POINT_ATT_BONUS,
	POINT_DEF_BONUS,
	POINT_ATT_GRADE_BONUS,
	POINT_DEF_GRADE_BONUS,
	POINT_MAGIC_ATT_GRADE_BONUS,
	POINT_MAGIC_DEF_GRADE_BONUS,
	POINT_RESIST_NORMAL_DAMAGE,
	POINT_STAT_RESET_COUNT = 112,
	POINT_HORSE_SKILL = 113,
	POINT_MALL_ATTBONUS,
	POINT_MALL_DEFBONUS,
	POINT_MALL_EXPBONUS,
	POINT_MALL_ITEMBONUS,
	POINT_MALL_GOLDBONUS,
	POINT_MAX_HP_PCT,
	POINT_MAX_SP_PCT,
	POINT_SKILL_DAMAGE_BONUS,
	POINT_NORMAL_HIT_DAMAGE_BONUS,
	POINT_SKILL_DEFEND_BONUS,
	POINT_NORMAL_HIT_DEFEND_BONUS,
	POINT_ENERGY = 128,
	POINT_ENERGY_END_TIME = 129,
	POINT_COSTUME_ATTR_BONUS = 130,
	POINT_MAGIC_ATT_BONUS_PER = 131,
	POINT_MELEE_MAGIC_ATT_BONUS_PER = 132,
	POINT_RESIST_ICE = 133,
	POINT_RESIST_EARTH = 134,
	POINT_RESIST_DARK = 135,
	POINT_RESIST_CRITICAL = 136,
	POINT_RESIST_PENETRATE = 137,
#ifdef ENABLE_ACCE_SYSTEM
	POINT_ACCEDRAIN_RATE = 138,
#endif
	POINT_MIN_WEP = 200,
	POINT_MAX_WEP,
	POINT_MIN_MAGIC_WEP,
	POINT_MAX_MAGIC_WEP,
	POINT_HIT_RATE,
};

typedef struct packet_points
{
	BYTE        header;
	long long        points[POINT_MAX_NUM];
} TPacketGCPoints;

typedef struct packet_point_change
{
	BYTE         header;
	DWORD		dwVID;
	BYTE		Type;
	long long	amount;
	long long	value;
} TPacketGCPointChange;

typedef struct packet_motion
{
	BYTE		header;
	DWORD		vid;
	DWORD		victim_vid;
	WORD		motion;
} TPacketGCMotion;

typedef struct packet_del_deprecated
{
	BYTE header;
	TItemPos Cell;
} TPacketGCItemDelDeprecated;

typedef struct packet_item_set
{
	BYTE header;
	TItemPos Cell;
	DWORD vnum;
	WORD count;
	DWORD flags;
	DWORD anti_flags;
	bool highlight;
	long alSockets[ITEM_SOCKET_SLOT_MAX_NUM];
	TPlayerItemAttribute aAttr[ITEM_ATTRIBUTE_SLOT_MAX_NUM];
} TPacketGCItemSet;

typedef struct packet_item_del
{
	BYTE        header;
	BYTE        pos;
} TPacketGCItemDel;

typedef struct packet_use_item
{
	BYTE		header;
	TItemPos	Cell;
	DWORD		ch_vid;
	DWORD		victim_vid;

	DWORD		vnum;
} TPacketGCItemUse;

typedef struct packet_item_update
{
	BYTE		header;
	TItemPos	Cell;
	WORD		count;
	long		alSockets[ITEM_SOCKET_SLOT_MAX_NUM];
	TPlayerItemAttribute aAttr[ITEM_ATTRIBUTE_SLOT_MAX_NUM];
} TPacketGCItemUpdate;

typedef struct packet_item_ground_add
{
	BYTE        bHeader;
	long        lX;
	long		lY;
	long		lZ;

	DWORD       dwVID;
	DWORD       dwVnum;
} TPacketGCItemGroundAdd;

typedef struct packet_item_ground_del
{
	BYTE		header;
	DWORD		vid;
} TPacketGCItemGroundDel;

typedef struct packet_item_ownership
{
	BYTE        bHeader;
	DWORD       dwVID;
	char        szName[CHARACTER_NAME_MAX_LEN + 1];
} TPacketGCItemOwnership;

typedef struct packet_quickslot_add
{
	BYTE        header;
	BYTE        pos;
	TQuickSlot	slot;
} TPacketGCQuickSlotAdd;

typedef struct packet_quickslot_del
{
	BYTE        header;
	BYTE        pos;
} TPacketGCQuickSlotDel;

typedef struct packet_quickslot_swap
{
	BYTE        header;
	BYTE        pos;
	BYTE        change_pos;
} TPacketGCQuickSlotSwap;

typedef struct packet_shop_start
{
	struct packet_shop_item		items[SHOP_HOST_ITEM_MAX_NUM];
} TPacketGCShopStart;

typedef struct packet_shop_start_ex
{
	typedef struct sub_packet_shop_tab
	{
		char name[SHOP_TAB_NAME_MAX];
		BYTE coin_type;
		packet_shop_item items[SHOP_HOST_ITEM_MAX_NUM];
	} TSubPacketShopTab;
	DWORD owner_vid;
	BYTE shop_tab_count;
} TPacketGCShopStartEx;

typedef struct packet_shop_update_item
{
	BYTE						pos;
	struct packet_shop_item		item;
} TPacketGCShopUpdateItem;

typedef struct packet_shop_update_price
{
	long long iElkAmount;
} TPacketGCShopUpdatePrice;

enum EPacketShopSubHeaders
{
	SHOP_SUBHEADER_GC_START,
	SHOP_SUBHEADER_GC_END,
	SHOP_SUBHEADER_GC_UPDATE_ITEM,
	SHOP_SUBHEADER_GC_UPDATE_PRICE,
	SHOP_SUBHEADER_GC_OK,
	SHOP_SUBHEADER_GC_NOT_ENOUGH_MONEY,
	SHOP_SUBHEADER_GC_SOLDOUT,
	SHOP_SUBHEADER_GC_INVENTORY_FULL,
	SHOP_SUBHEADER_GC_INVALID_POS,
	SHOP_SUBHEADER_GC_SOLD_OUT,
	SHOP_SUBHEADER_GC_START_EX,
	SHOP_SUBHEADER_GC_NOT_ENOUGH_MONEY_EX,
};

typedef struct packet_shop
{
	BYTE        header;
	WORD		size;
	BYTE        subheader;
} TPacketGCShop;

typedef struct packet_exchange
{
	BYTE        header;
	BYTE        subheader;
	BYTE        is_me;
	long long   arg1;
	TItemPos       arg2;
	DWORD       arg3;
	long		alValues[ITEM_SOCKET_SLOT_MAX_NUM];
	TPlayerItemAttribute aAttr[ITEM_ATTRIBUTE_SLOT_MAX_NUM];
} TPacketGCExchange;

enum
{
	EXCHANGE_SUBHEADER_GC_START,
	EXCHANGE_SUBHEADER_GC_ITEM_ADD,
	EXCHANGE_SUBHEADER_GC_ITEM_DEL,
	EXCHANGE_SUBHEADER_GC_ELK_ADD,
	EXCHANGE_SUBHEADER_GC_ACCEPT,
	EXCHANGE_SUBHEADER_GC_END,
	EXCHANGE_SUBHEADER_GC_ALREADY,
	EXCHANGE_SUBHEADER_GC_LESS_ELK,
};

typedef struct packet_position
{
	BYTE        header;
	DWORD		vid;
	BYTE        position;
} TPacketGCPosition;

typedef struct packet_ping
{
	BYTE		header;
} TPacketGCPing;

typedef struct packet_pong
{
	BYTE		bHeader;
} TPacketCGPong;

typedef struct packet_script
{
	BYTE		header;
	WORD        size;
	BYTE		skin;
	WORD        src_size;
} TPacketGCScript;

typedef struct packet_target
{
	BYTE        header;
	DWORD       dwVID;
	BYTE        bHPPercent;
#ifdef ENABLE_VIEW_TARGET_PLAYER_HP
	int iMinHP;
	int iMaxHP;
#endif
} TPacketGCTarget;

typedef struct packet_damage_info
{
	BYTE header;
	DWORD dwVID;
	BYTE flag;
	int  damage;
} TPacketGCDamageInfo;

typedef struct packet_move
{
	BYTE		bHeader;
	BYTE		bFunc;
	BYTE		bArg;
	BYTE		bRot;
	DWORD		dwVID;
	LONG		lX;
	LONG		lY;
	DWORD		dwTime;
	DWORD		dwDuration;
} TPacketGCMove;

enum
{
	QUEST_SEND_IS_BEGIN = 1 << 0,
	QUEST_SEND_TITLE = 1 << 1,
	QUEST_SEND_CLOCK_NAME = 1 << 2,
	QUEST_SEND_CLOCK_VALUE = 1 << 3,
	QUEST_SEND_COUNTER_NAME = 1 << 4,
	QUEST_SEND_COUNTER_VALUE = 1 << 5,
	QUEST_SEND_ICON_FILE = 1 << 6,
};

typedef struct packet_quest_info
{
	BYTE header;
	WORD size;
	WORD index;
	BYTE flag;
} TPacketGCQuestInfo;

typedef struct packet_quest_confirm
{
	BYTE header;
	char msg[64 + 1];
	long timeout;
	DWORD requestPID;
} TPacketGCQuestConfirm;

typedef struct packetd_sync_position_element
{
	DWORD       dwVID;
	long        lX;
	long        lY;
} TPacketGCSyncPositionElement;

typedef struct packetd_sync_position
{
	BYTE        bHeader;
	WORD		wSize;
} TPacketGCSyncPosition;

typedef struct packet_ownership
{
	BYTE                bHeader;
	DWORD               dwOwnerVID;
	DWORD               dwVictimVID;
} TPacketGCOwnership;

#define	SKILL_MAX_NUM 255

typedef struct SPlayerSkill
{
	BYTE bMasterType;
	BYTE bLevel;
	std::int32_t tNextRead;
} TPlayerSkill;

typedef struct packet_skill_level
{
	BYTE		bHeader;
	TPlayerSkill	skills[SKILL_MAX_NUM];
} TPacketGCSkillLevel;

typedef struct packet_fly
{
	BYTE        bHeader;
	BYTE        bType;
	DWORD       dwStartVID;
	DWORD       dwEndVID;
} TPacketGCCreateFly;

enum EPVPModes
{
	PVP_MODE_NONE,
	PVP_MODE_AGREE,
	PVP_MODE_FIGHT,
	PVP_MODE_REVENGE,
};

typedef struct packet_duel_start
{
	BYTE	header;
	WORD	wSize;
} TPacketGCDuelStart;

typedef struct packet_pvp
{
	BYTE		header;
	DWORD		dwVIDSrc;
	DWORD		dwVIDDst;
	BYTE		bMode;
} TPacketGCPVP;

typedef struct packet_warp
{
	BYTE			bHeader;
	LONG			lX;
	LONG			lY;
	LONG			lAddr;
	WORD			wPort;
} TPacketGCWarp;

typedef struct packet_party_invite
{
	BYTE header;
	DWORD leader_pid;
} TPacketGCPartyInvite;

typedef struct packet_party_add
{
	BYTE header;
	DWORD pid;
	char name[CHARACTER_NAME_MAX_LEN + 1];
} TPacketGCPartyAdd;

typedef struct packet_party_update
{
	BYTE header;
	DWORD pid;
	BYTE state;
	BYTE percent_hp;
	short affects[PARTY_AFFECT_SLOT_MAX_NUM];
} TPacketGCPartyUpdate;

typedef struct packet_party_remove
{
	BYTE header;
	DWORD pid;
} TPacketGCPartyRemove;

typedef TPacketCGSafeboxCheckoutAcheckDraveniu TPacketGCSafeboxCheckout;
typedef TPacketCGSafeboxCheckinAcheckDraveniu TPacketGCSafeboxCheckin;

typedef struct packet_safebox_wrong_password
{
	BYTE        bHeader;
} TPacketGCSafeboxWrongPassword;

typedef struct packet_safebox_size
{
	BYTE bHeader;
	BYTE bSize;
} TPacketGCSafeboxSize;

typedef struct command_empire
{
	BYTE        bHeader;
	BYTE        bEmpire;
} TPacketCGEmpire;

typedef struct packet_empire
{
	BYTE        bHeader;
	BYTE        bEmpire;
} TPacketGCEmpire;

enum
{
	FISHING_SUBHEADER_GC_START,
	FISHING_SUBHEADER_GC_STOP,
	FISHING_SUBHEADER_GC_REACT,
	FISHING_SUBHEADER_GC_SUCCESS,
	FISHING_SUBHEADER_GC_FAIL,
	FISHING_SUBHEADER_GC_FISH,
};

typedef struct packet_fishing
{
	BYTE header;
	BYTE subheader;
	DWORD info;
	BYTE dir;
} TPacketGCFishing;

typedef struct paryt_parameter
{
	BYTE        bHeader;
	BYTE        bDistributeMode;
} TPacketGCPartyParameter;

enum
{
	GUILD_SUBHEADER_GC_LOGIN,
	GUILD_SUBHEADER_GC_LOGOUT,
	GUILD_SUBHEADER_GC_LIST,
	GUILD_SUBHEADER_GC_GRADE,
	GUILD_SUBHEADER_GC_ADD,
	GUILD_SUBHEADER_GC_REMOVE,
	GUILD_SUBHEADER_GC_GRADE_NAME,
	GUILD_SUBHEADER_GC_GRADE_AUTH,
	GUILD_SUBHEADER_GC_INFO,
	GUILD_SUBHEADER_GC_COMMENTS,
	GUILD_SUBHEADER_GC_CHANGE_EXP,
	GUILD_SUBHEADER_GC_CHANGE_MEMBER_GRADE,
	GUILD_SUBHEADER_GC_SKILL_INFO,
	GUILD_SUBHEADER_GC_CHANGE_MEMBER_GENERAL,
	GUILD_SUBHEADER_GC_GUILD_INVITE,
	GUILD_SUBHEADER_GC_WAR,
	GUILD_SUBHEADER_GC_GUILD_NAME,
	GUILD_SUBHEADER_GC_GUILD_WAR_LIST,
	GUILD_SUBHEADER_GC_GUILD_WAR_END_LIST,
	GUILD_SUBHEADER_GC_WAR_POINT,
	GUILD_SUBHEADER_GC_MONEY_CHANGE,
};

typedef struct packet_guild
{
	BYTE header;
	WORD size;
	BYTE subheader;
} TPacketGCGuild;

enum
{
	GUILD_AUTH_ADD_MEMBER = (1 << 0),
	GUILD_AUTH_REMOVE_MEMBER = (1 << 1),
	GUILD_AUTH_NOTICE = (1 << 2),
	GUILD_AUTH_SKILL = (1 << 3),
#ifdef ENABLE_WAR_PERMISSION
	GUILD_AUTH_WAR = (1 << 4),
#endif
};

typedef struct packet_guild_sub_grade
{
	char grade_name[GUILD_GRADE_NAME_MAX_LEN + 1];
	BYTE auth_flag;
} TPacketGCGuildSubGrade;

typedef struct packet_guild_sub_member
{
	DWORD pid;
	BYTE byGrade;
	BYTE byIsGeneral;
	BYTE byJob;
	BYTE byLevel;
	DWORD dwOffer;
	BYTE byNameFlag;
} TPacketGCGuildSubMember;

typedef struct packet_guild_sub_info
{
	WORD member_count;
	WORD max_member_count;
	DWORD guild_id;
	DWORD master_pid;
	DWORD exp;
	BYTE level;
	char name[GUILD_NAME_MAX_LEN + 1];
	DWORD gold;
	BYTE hasLand;
} TPacketGCGuildInfo;

enum EGuildWarState
{
	GUILD_WAR_NONE,
	GUILD_WAR_SEND_DECLARE,
	GUILD_WAR_REFUSE,
	GUILD_WAR_RECV_DECLARE,
	GUILD_WAR_WAIT_START,
	GUILD_WAR_CANCEL,
	GUILD_WAR_ON_WAR,
	GUILD_WAR_END,

	GUILD_WAR_DURATION = 2 * 60 * 60,
};

typedef struct packet_guild_war
{
	DWORD	dwGuildSelf;
	DWORD	dwGuildOpp;
	BYTE	bType;
	BYTE	bWarState;
#ifdef ENABLE_IMPROVED_GUILD_WAR_SYSTEM
	int			iMaxPlayer;
	int			iMaxScore;
#endif
} TPacketGCGuildWar;

typedef struct SPacketGuildWarPoint
{
	DWORD dwGainGuildID;
	DWORD dwOpponentGuildID;
	long lPoint;
} TPacketGuildWarPoint;

enum
{
	DUNGEON_SUBHEADER_GC_TIME_ATTACK_START = 0,
	DUNGEON_SUBHEADER_GC_DESTINATION_POSITION = 1,
};

typedef struct packet_dungeon
{
	BYTE		bHeader;
	WORD		size;
	BYTE		subheader;
} TPacketGCDungeon;

typedef struct SPacketGCShopSign
{
	BYTE        bHeader;
	DWORD       dwVID;
	char        szSign[SHOP_SIGN_MAX_LEN + 1];
} TPacketGCShopSign;

typedef struct SPacketGCTime
{
	BYTE        bHeader;
	std::int32_t      time;
} TPacketGCTime;

enum
{
	WALKMODE_RUN,
	WALKMODE_WALK,
};

typedef struct SPacketGCWalkMode
{
	BYTE        header;
	DWORD       vid;
	BYTE        mode;
} TPacketGCWalkMode;

typedef struct SPacketGCChangeSkillGroup
{
	BYTE        header;
	BYTE        skill_group;
} TPacketGCChangeSkillGroup;

struct TMaterial
{
	DWORD vnum;
	DWORD count;
};

typedef struct SRefineTable
{
	DWORD src_vnum;
	DWORD result_vnum;
	BYTE material_count;
	int cost;
	int prob;
	TMaterial materials[REFINE_MATERIAL_MAX_NUM];
} TRefineTable;

typedef struct SPacketGCRefineInformaion
{
	BYTE header;
	BYTE type;
	BYTE pos;
	TRefineTable refine_table;
} TPacketGCRefineInformation;

enum SPECIAL_EFFECT
{
	SE_NONE,
	SE_SPEEDUP_GREEN,
	SE_DXUP_PURPLE,
	SE_CRITICAL,
	SE_PENETRATE,
	SE_BLOCK,
	SE_DODGE,
	SE_CHINA_FIREWORK,
	SE_SPIN_TOP,
	SE_SUCCESS,
	SE_FAIL,
	SE_FR_SUCCESS,
	SE_PERCENT_DAMAGE1,
	SE_PERCENT_DAMAGE2,
	SE_PERCENT_DAMAGE3,
	SE_EQUIP_RAMADAN_RING,
	SE_EQUIP_HALLOWEEN_CANDY,
	SE_EQUIP_HAPPINESS_RING,
	SE_EQUIP_LOVE_PENDANT,
#ifdef ENABLE_ACCE_SYSTEM
	SE_EFFECT_ACCE_SUCESS_ABSORB,
	SE_EFFECT_ACCE_EQUIP,
#endif
};

typedef struct SPacketGCSpecialEffect
{
	BYTE header;
	BYTE type;
	DWORD vid;
} TPacketGCSpecialEffect;

typedef struct SPacketGCChangeName
{
	BYTE header;
	DWORD pid;
	char name[CHARACTER_NAME_MAX_LEN + 1];
} TPacketGCChangeName;

enum EBlockAction
{
	BLOCK_EXCHANGE = (1 << 0),
	BLOCK_PARTY_INVITE = (1 << 1),
	BLOCK_GUILD_INVITE = (1 << 2),
	BLOCK_WHISPER = (1 << 3),
	BLOCK_MESSENGER_INVITE = (1 << 4),
	BLOCK_PARTY_REQUEST = (1 << 5),
};

typedef struct packet_auth_success
{
	BYTE        bHeader;
	DWORD       dwLoginKey;
	BYTE        bResult;
} TPacketGCAuthSuccess;

typedef struct packet_channel
{
	BYTE header;
	BYTE channel;
} TPacketGCChannel;

typedef struct SEquipmentItemSet
{
	DWORD   vnum;
	WORD	count;
	long    alSockets[ITEM_SOCKET_SLOT_MAX_NUM];
	TPlayerItemAttribute aAttr[ITEM_ATTRIBUTE_SLOT_MAX_NUM];
} TEquipmentItemSet;

typedef struct pakcet_view_equip
{
	BYTE header;
	DWORD dwVID;
	TEquipmentItemSet equips[WEAR_MAX_NUM];
} TPacketGCViewEquip;

typedef struct SLandPacketElement
{
	DWORD       dwID;
	long        x, y;
	long        width, height;
	DWORD       dwGuildID;
} TLandPacketElement;

typedef struct packet_land_list
{
	BYTE        header;
	WORD        size;
} TPacketGCLandList;

enum
{
	CREATE_TARGET_TYPE_NONE,
	CREATE_TARGET_TYPE_LOCATION,
	CREATE_TARGET_TYPE_CHARACTER,
};

typedef struct SPacketGCTargetCreate
{
	BYTE		bHeader;
	long		lID;
	char		szTargetName[32 + 1];
	DWORD		dwVID;
	BYTE		byType;
} TPacketGCTargetCreate;

typedef struct SPacketGCTargetUpdate
{
	BYTE        bHeader;
	long        lID;
	long        lX, lY;
} TPacketGCTargetUpdate;

typedef struct SPacketGCTargetDelete
{
	BYTE        bHeader;
	long        lID;
} TPacketGCTargetDelete;

typedef struct TPacketAffectElement
{
	DWORD       dwType;
	BYTE        bPointIdxApplyOn;
	long        lApplyValue;
	DWORD       dwFlag;
	long        lDuration;
	long        lSPCost;
} TPacketAffectElement;

typedef struct SPacketGCAffectAdd
{
	BYTE bHeader;
	TPacketAffectElement elem;
} TPacketGCAffectAdd;

typedef struct SPacketGCAffectRemove
{
	BYTE bHeader;
	DWORD dwType;
	BYTE bApplyOn;
} TPacketGCAffectRemove;

typedef struct packet_mall_open
{
	BYTE bHeader;
	BYTE bSize;
} TPacketGCMallOpen;

typedef struct packet_lover_info
{
	BYTE bHeader;
	char szName[CHARACTER_NAME_MAX_LEN + 1];
	BYTE byLovePoint;
} TPacketGCLoverInfo;

typedef struct packet_love_point_update
{
	BYTE bHeader;
	BYTE byLovePoint;
} TPacketGCLovePointUpdate;

typedef struct packet_dig_motion
{
	BYTE header;
	DWORD vid;
	DWORD target_vid;
	BYTE count;
} TPacketGCDigMotion;

typedef struct SPacketGCSpecificEffect
{
	BYTE header;
	DWORD vid;
	char effect_file[128];
} TPacketGCSpecificEffect;

enum EDragonSoulRefineWindowRefineType
{
	DragonSoulRefineWindow_UPGRADE,
	DragonSoulRefineWindow_IMPROVEMENT,
	DragonSoulRefineWindow_REFINE,
};

enum EPacketCGDragonSoulSubHeaderType
{
	DS_SUB_HEADER_OPEN,
	DS_SUB_HEADER_CLOSE,
	DS_SUB_HEADER_DO_UPGRADE,
	DS_SUB_HEADER_DO_IMPROVEMENT,
	DS_SUB_HEADER_DO_REFINE,
	DS_SUB_HEADER_REFINE_FAIL,
	DS_SUB_HEADER_REFINE_FAIL_MAX_REFINE,
	DS_SUB_HEADER_REFINE_FAIL_INVALID_MATERIAL,
	DS_SUB_HEADER_REFINE_FAIL_NOT_ENOUGH_MONEY,
	DS_SUB_HEADER_REFINE_FAIL_NOT_ENOUGH_MATERIAL,
	DS_SUB_HEADER_REFINE_FAIL_TOO_MUCH_MATERIAL,
	DS_SUB_HEADER_REFINE_SUCCEED,
};

typedef struct SPacketCGDragonSoulRefine
{
	SPacketCGDragonSoulRefine() : header(HEADER_CG_DRAGON_SOUL_REFINE)
	{}
	BYTE header;
	BYTE bSubType;
	TItemPos ItemGrid[DS_REFINE_WINDOW_MAX_NUM];
} TPacketCGDragonSoulRefine;

typedef struct SPacketGCDragonSoulRefine
{
	SPacketGCDragonSoulRefine() : header(HEADER_GC_DRAGON_SOUL_REFINE)
	{}
	BYTE header;
	BYTE bSubType;
	TItemPos Pos;
} TPacketGCDragonSoulRefine;

#ifdef ENABLE_PLAYER_BLOCK_SYSTEM
enum EPlayerBlockType
{
	PLAYER_BLOCK_TYPE_ADD,
	PLAYER_BLOCK_TYPE_REMOVE,
	PLAYER_BLOCK_TYPE_LOAD
};

typedef struct SPacketGCPlayerBlock
{
	BYTE header;
	WORD size;
	BYTE type;
} TPacketGCPlayerBlock;

typedef struct SPacketGCLoadPlayerBlock
{
	char szName[CHARACTER_NAME_MAX_LEN + 1];
} TPacketGCLoadPlayerBlock;
#endif


#ifdef ENABLE_ACCE_SYSTEM
enum EAcceInfo
{
	ACCE_ABSORPTION_SOCKET = 0,
	ACCE_ABSORBED_SOCKET = 1,
	ACCE_CLEAN_ATTR_VALUE0 = 7,
	ACCE_WINDOW_MAX_MATERIALS = 2,
	ACCE_REVERSAL_VNUM_1 = 39046,
	ACCE_REVERSAL_VNUM_2 = 90000,
};

enum ESashPacket
{
	ACCE_SUBHEADER_GC_OPEN = 0,
	ACCE_SUBHEADER_GC_CLOSE,
	ACCE_SUBHEADER_GC_ADDED,
	ACCE_SUBHEADER_GC_REMOVED,
	ACCE_SUBHEADER_CG_REFINED,
	ACCE_SUBHEADER_CG_CLOSE = 0,
	ACCE_SUBHEADER_CG_ADD,
	ACCE_SUBHEADER_CG_REMOVE,
	ACCE_SUBHEADER_CG_REFINE,
};

typedef struct SPacketAcce
{
	BYTE	header;
	BYTE	subheader;
	bool	bWindow;
	DWORD	dwPrice;
	BYTE	bPos;
	TItemPos	tPos;
	DWORD	dwItemVnum;
	DWORD	dwMinAbs;
	DWORD	dwMaxAbs;
} TPacketAcce;

typedef struct SAcceMaterial
{
	BYTE	bHere;
	WORD	wCell;
} TAcceMaterial;

typedef struct SAcceResult
{
	DWORD	dwItemVnum;
	DWORD	dwMinAbs;
	DWORD	dwMaxAbs;
} TAcceResult;
#endif

#ifdef ENABLE_SWITCHBOT
enum ECGSwitchbotSubheader
{
	SUBHEADER_CG_SWITCHBOT_START,
	SUBHEADER_CG_SWITCHBOT_STOP,
};

struct TPacketCGSwitchbot
{
	BYTE header;
	long long size;
	BYTE subheader;
	BYTE slot;
};

enum EGCSwitchbotSubheader
{
	SUBHEADER_GC_SWITCHBOT_UPDATE,
	SUBHEADER_GC_SWITCHBOT_UPDATE_ITEM,
	SUBHEADER_GC_SWITCHBOT_SEND_ATTRIBUTE_INFORMATION,
};

struct TPacketGCSwitchbot
{
	BYTE header;
	long long size;
	BYTE subheader;
	BYTE slot;
};

struct TSwitchbotUpdateItem
{
	BYTE	slot;
	DWORD	vnum;
	DWORD	count;
	long	alSockets[ITEM_SOCKET_SLOT_MAX_NUM];
	TPlayerItemAttribute aAttr[ITEM_ATTRIBUTE_SLOT_MAX_NUM];
};

#endif

#ifdef ENABLE_GUILD_TOKEN_AUTH
struct TPacketGCGuildToken
{
	uint8_t header;
	uint64_t token;
};
#endif

//MULTI_LANGUAGE
typedef struct TPacketCGSetLanguage
{
	BYTE header;
	char szLanguage[3];
};
//MULTI_LANGUAGE

#pragma pack(pop)
