#include "stdafx.h"
#include "MarkImage.h"

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>

#define STB_IMAGE_IMPLEMENTATION
#define STBI_NO_STDIO
#include <stb_image.h>

namespace
{
	bool ReadFileToMemory(const char* fileName, std::vector<unsigned char>& out)
	{
		FILE* fp = fopen(fileName, "rb");
		if (!fp)
			return false;
		fseek(fp, 0, SEEK_END);
		long size = ftell(fp);
		fseek(fp, 0, SEEK_SET);
		if (size <= 0)
		{
			fclose(fp);
			return false;
		}
		out.resize(static_cast<size_t>(size));
		const size_t readSize = fread(out.data(), 1, out.size(), fp);
		fclose(fp);
		return readSize == out.size();
	}

	bool WriteGuildMarkTGA_BGRA(const char* fileName, const Pixel* pixels, int width, int height)
	{
		FILE* fp = fopen(fileName, "wb");
		if (!fp)
			return false;

		unsigned char header[18] = {};
		header[2] = 2; // uncompressed true-color image
		header[12] = static_cast<unsigned char>(width & 0xff);
		header[13] = static_cast<unsigned char>((width >> 8) & 0xff);
		header[14] = static_cast<unsigned char>(height & 0xff);
		header[15] = static_cast<unsigned char>((height >> 8) & 0xff);
		header[16] = 32;
		header[17] = 0x28; // 8 alpha bits + top-left origin
		if (fwrite(header, 1, sizeof(header), fp) != sizeof(header))
		{
			fclose(fp);
			return false;
		}
		const size_t byteCount = static_cast<size_t>(width) * static_cast<size_t>(height) * sizeof(Pixel);
		const bool ok = fwrite(pixels, 1, byteCount, fp) == byteCount;
		fclose(fp);
		return ok;
	}

	bool LoadImageAsBGRA(const char* fileName, Pixel* outPixels, int expectedWidth, int expectedHeight, unsigned int* peError = nullptr)
	{
		std::vector<unsigned char> bytes;
		if (!ReadFileToMemory(fileName, bytes))
		{
			if (peError) *peError = 2; // ERROR_LOAD in CGuildMarkUploader
			return false;
		}

		int width = 0;
		int height = 0;
		int comp = 0;
		unsigned char* rgba = stbi_load_from_memory(bytes.data(), static_cast<int>(bytes.size()), &width, &height, &comp, 4);
		if (!rgba)
		{
			if (peError) *peError = 2;
			return false;
		}

		if (width != expectedWidth)
		{
			stbi_image_free(rgba);
			if (peError) *peError = 3; // ERROR_WIDTH
			return false;
		}
		if (height != expectedHeight)
		{
			stbi_image_free(rgba);
			if (peError) *peError = 4; // ERROR_HEIGHT
			return false;
		}

		const size_t count = static_cast<size_t>(width) * static_cast<size_t>(height);
		for (size_t i = 0; i < count; ++i)
		{
			const unsigned char r = rgba[i * 4 + 0];
			const unsigned char g = rgba[i * 4 + 1];
			const unsigned char b = rgba[i * 4 + 2];
			const unsigned char a = rgba[i * 4 + 3];
			outPixels[i] = (static_cast<Pixel>(a) << 24) |
				(static_cast<Pixel>(r) << 16) |
				(static_cast<Pixel>(g) << 8) |
				(static_cast<Pixel>(b)); // memory order on little-endian: B,G,R,A (BGRA)
		}

		stbi_image_free(rgba);
		return true;
	}
}

bool LoadGuildMarkImageAsBGRA_STB(const char* fileName, Pixel* outPixels, int expectedWidth, int expectedHeight, unsigned int* peError)
{
	return LoadImageAsBGRA(fileName, outPixels, expectedWidth, expectedHeight, peError);
}

CGuildMarkImage* NewMarkImage()
{
	return new CGuildMarkImage;
}

void DeleteMarkImage (CGuildMarkImage* pkImage)
{
	delete pkImage;
}

CGuildMarkImage::CGuildMarkImage()
{
	memset(m_apxImage, 0, sizeof(m_apxImage));
}

CGuildMarkImage::~CGuildMarkImage()
{
	Destroy();
}

void CGuildMarkImage::Destroy()
{
	memset(m_apxImage, 0, sizeof(m_apxImage));
}

void CGuildMarkImage::Create()
{
	memset(m_apxImage, 0, sizeof(m_apxImage));
}

bool CGuildMarkImage::Save (const char* c_szFileName)
{
	return WriteGuildMarkTGA_BGRA(c_szFileName, m_apxImage, WIDTH, HEIGHT);
}

bool CGuildMarkImage::Build (const char* c_szFileName)
{
	Destroy();
	Create();
	memset(m_apxImage, 0, sizeof(m_apxImage));

	if (!Save(c_szFileName))
	{
		TraceError ("CGuildMarkImage: cannot save empty TGA %s", c_szFileName);
		return false;
	}
	return true;
}

bool CGuildMarkImage::Load (const char* c_szFileName)
{
	Destroy();
	Create();

	if (!LoadImageAsBGRA(c_szFileName, m_apxImage, WIDTH, HEIGHT))
	{
		Build (c_szFileName);
		if (!LoadImageAsBGRA(c_szFileName, m_apxImage, WIDTH, HEIGHT))
		{
			TraceError ("CGuildMarkImage: cannot create/load guild mark image %s", c_szFileName);
			return false;
		}
	}

	BuildAllBlocks();
	return true;
}

void CGuildMarkImage::PutData (unsigned int x, unsigned int y, unsigned int width, unsigned int height, void* data)
{
	if (!data || x + width > WIDTH || y + height > HEIGHT)
		return;

	const Pixel* src = static_cast<const Pixel*>(data);
	for (unsigned int row = 0; row < height; ++row)
	{
		memcpy(&m_apxImage[(y + row) * WIDTH + x], &src[row * width], sizeof(Pixel) * width);
	}
}

void CGuildMarkImage::GetData (unsigned int x, unsigned int y, unsigned int width, unsigned int height, void* data)
{
	if (!data || x + width > WIDTH || y + height > HEIGHT)
		return;

	Pixel* dst = static_cast<Pixel*>(data);
	for (unsigned int row = 0; row < height; ++row)
	{
		memcpy(&dst[row * width], &m_apxImage[(y + row) * WIDTH + x], sizeof(Pixel) * width);
	}
}

bool CGuildMarkImage::SaveMark (DWORD posMark, BYTE* pbImage)
{
	if (posMark >= MARK_TOTAL_COUNT)
	{
		TraceError ("CGuildMarkImage::CopyMarkFromData: Invalid mark position %u", posMark);
		return false;
	}

	DWORD colMark = posMark % MARK_COL_COUNT;
	DWORD rowMark = posMark / MARK_COL_COUNT;
	PutData (colMark * SGuildMark::WIDTH, rowMark * SGuildMark::HEIGHT, SGuildMark::WIDTH, SGuildMark::HEIGHT, pbImage);

	DWORD rowBlock = rowMark / SGuildMarkBlock::MARK_PER_BLOCK_HEIGHT;
	DWORD colBlock = colMark / SGuildMarkBlock::MARK_PER_BLOCK_WIDTH;

	Pixel apxBuf[SGuildMarkBlock::SIZE];
	GetData (colBlock * SGuildMarkBlock::WIDTH, rowBlock * SGuildMarkBlock::HEIGHT, SGuildMarkBlock::WIDTH, SGuildMarkBlock::HEIGHT, apxBuf);
	m_aakBlock[rowBlock][colBlock].Compress (apxBuf);
	return true;
}

bool CGuildMarkImage::DeleteMark (DWORD posMark)
{
	Pixel image[SGuildMark::SIZE];
	memset (&image, 0, sizeof (image));
	return SaveMark (posMark, (BYTE*)&image);
}

bool CGuildMarkImage::SaveBlockFromCompressedData (DWORD posBlock, const BYTE* pbComp, DWORD dwCompSize)
{
	if (posBlock >= BLOCK_TOTAL_COUNT)
		return false;

	Pixel apxBuf[SGuildMarkBlock::SIZE];
	lzo_uint sizeBuf = (lzo_uint)sizeof (apxBuf);
	if (LZO_E_OK != lzo1x_decompress_safe (pbComp, (lzo_uint)dwCompSize, (BYTE*)apxBuf, &sizeBuf, NULL))
	{
		TraceError ("CGuildMarkImage::CopyBlockFromCompressedData: cannot decompress, compressed size = %u", dwCompSize);
		return false;
	}

	if (sizeBuf != sizeof (apxBuf))
	{
		TraceError ("CGuildMarkImage::CopyBlockFromCompressedData: image corrupted, decompressed size = %u", (unsigned)sizeBuf);
		return false;
	}

	DWORD rowBlock = posBlock / BLOCK_COL_COUNT;
	DWORD colBlock = posBlock % BLOCK_COL_COUNT;
	PutData (colBlock * SGuildMarkBlock::WIDTH, rowBlock * SGuildMarkBlock::HEIGHT, SGuildMarkBlock::WIDTH, SGuildMarkBlock::HEIGHT, apxBuf);
	m_aakBlock[rowBlock][colBlock].CopyFrom (pbComp, dwCompSize, GetCRC32 ((const char*)apxBuf, sizeof (Pixel) * SGuildMarkBlock::SIZE));
	return true;
}

void CGuildMarkImage::BuildAllBlocks()
{
	Pixel apxBuf[SGuildMarkBlock::SIZE];
	for (unsigned int row = 0; row < BLOCK_ROW_COUNT; ++row)
	{
		for (unsigned int col = 0; col < BLOCK_COL_COUNT; ++col)
		{
			GetData (col * SGuildMarkBlock::WIDTH, row * SGuildMarkBlock::HEIGHT, SGuildMarkBlock::WIDTH, SGuildMarkBlock::HEIGHT, apxBuf);
			m_aakBlock[row][col].Compress (apxBuf);
		}
	}
}

DWORD CGuildMarkImage::GetEmptyPosition()
{
	SGuildMark kMark;
	for (DWORD row = 0; row < MARK_ROW_COUNT; ++row)
	{
		for (DWORD col = 0; col < MARK_COL_COUNT; ++col)
		{
			GetData (col * SGuildMark::WIDTH, row * SGuildMark::HEIGHT, SGuildMark::WIDTH, SGuildMark::HEIGHT, kMark.m_apxBuf);
			if (kMark.IsEmpty())
				return (row * MARK_COL_COUNT + col);
		}
	}
	return INVALID_MARK_POSITION;
}

void CGuildMarkImage::GetDiffBlocks (const DWORD* crcList, std::map<BYTE, const SGuildMarkBlock*>& mapDiffBlocks)
{
	BYTE posBlock = 0;
	for (DWORD row = 0; row < BLOCK_ROW_COUNT; ++row)
	{
		for (DWORD col = 0; col < BLOCK_COL_COUNT; ++col)
		{
			if (m_aakBlock[row][col].m_crc != *crcList)
				mapDiffBlocks.insert (std::map<BYTE, const SGuildMarkBlock*>::value_type (posBlock, &m_aakBlock[row][col]));
			++crcList;
			++posBlock;
		}
	}
}

void CGuildMarkImage::GetBlockCRCList (DWORD* crcList)
{
	for (DWORD row = 0; row < BLOCK_ROW_COUNT; ++row)
	{
		for (DWORD col = 0; col < BLOCK_COL_COUNT; ++col)
			*(crcList++) = m_aakBlock[row][col].GetCRC();
	}
}

void SGuildMark::Clear()
{
	for (DWORD iPixel = 0; iPixel < SIZE; ++iPixel)
		m_apxBuf[iPixel] = 0xff000000;
}

bool SGuildMark::IsEmpty()
{
	for (DWORD iPixel = 0; iPixel < SIZE; ++iPixel)
	{
		if (m_apxBuf[iPixel] != 0x00000000)
			return false;
	}
	return true;
}

DWORD SGuildMarkBlock::GetCRC() const
{
	return m_crc;
}

void SGuildMarkBlock::CopyFrom (const BYTE* pbCompBuf, DWORD dwCompSize, DWORD crc)
{
	if (dwCompSize > MAX_COMP_SIZE)
		return;
	m_sizeCompBuf = dwCompSize;
	std::memcpy (m_abCompBuf, pbCompBuf, dwCompSize);
	m_crc = crc;
}

void SGuildMarkBlock::Compress (const Pixel* pxBuf)
{
	lzo_uint outSize = MAX_COMP_SIZE;
	if (LZO_E_OK != lzo1x_1_compress ((const BYTE*)pxBuf, (lzo_uint)(sizeof (Pixel) * SGuildMarkBlock::SIZE), m_abCompBuf, &outSize, CLZO::Instance().GetWorkMemory()))
	{
		TraceError ("SGuildMarkBlock::Compress failed");
		return;
	}
	m_sizeCompBuf = (size_t)outSize;
	m_crc = GetCRC32 ((const char*)pxBuf, sizeof (Pixel) * SGuildMarkBlock::SIZE);
}
