#include "StdAfx.h"
#include "GuildMarkUploader.h"
#include "Packet.h"

CGuildMarkUploader::CGuildMarkUploader() : m_pbySymbolBuf (NULL)
{
	SetRecvBufferSize (1024);
	SetSendBufferSize (1024);
	__Initialize(); //fix099918
}

CGuildMarkUploader::~CGuildMarkUploader()
{
	__OfflineState_Set();
}

void CGuildMarkUploader::Disconnect()
{
	__OfflineState_Set();
}

bool CGuildMarkUploader::IsCompleteUploading()
{
	return STATE_OFFLINE == m_eState;
}

bool CGuildMarkUploader::__Load (const char* c_szFileName, unsigned int* peError)
{
	if (!LoadGuildMarkImageAsBGRA_STB(c_szFileName, m_kMark.m_apxBuf, SGuildMark::WIDTH, SGuildMark::HEIGHT, peError))
	{
		return false;
	}

	return true;
}

bool CGuildMarkUploader::__LoadSymbol (const char* c_szFileName, unsigned int* peError)
{
	Pixel checkPixels[64 * 128];
	if (!LoadGuildMarkImageAsBGRA_STB(c_szFileName, checkPixels, 64, 128, peError))
	{
		return false;
	}

	FILE* file = fopen (c_szFileName, "rb");
	if (!file)
	{
		*peError = ERROR_LOAD;
		return false;
	}

	fseek (file, 0, SEEK_END);
	m_dwSymbolBufSize = ftell (file);
	fseek (file, 0, SEEK_SET);

	if (m_dwSymbolBufSize == 0)
	{
		fclose(file);
		*peError = ERROR_LOAD;
		return false;
	}

	delete [] m_pbySymbolBuf;
	m_pbySymbolBuf = new BYTE[m_dwSymbolBufSize];
	if (fread (m_pbySymbolBuf, m_dwSymbolBufSize, 1, file) != 1)
	{
		fclose(file);
		delete [] m_pbySymbolBuf;
		m_pbySymbolBuf = NULL;
		m_dwSymbolBufSize = 0;
		*peError = ERROR_LOAD;
		return false;
	}

	fclose (file);

	m_dwSymbolCRC32 = GetFileCRC32 (c_szFileName);
	return true;
}

bool CGuildMarkUploader::Connect(const CNetworkAddress& c_rkNetAddr, DWORD dwHandle, DWORD dwRandomKey, DWORD dwGuildID, const char* c_szFileName, unsigned int* peError
#ifdef ENABLE_GUILD_TOKEN_AUTH
	, uint64_t dwGuildToken
#endif
)
{
	__OfflineState_Set();
	SetRecvBufferSize (1024);
	SetSendBufferSize (1024);

	if (!CNetworkStream::Connect (c_rkNetAddr))
	{
		*peError = ERROR_CONNECT;
		return false;
	}

	m_dwSendType = SEND_TYPE_MARK;
	m_dwHandle = dwHandle;
	m_dwRandomKey = dwRandomKey;
	m_dwGuildID = dwGuildID;
#ifdef ENABLE_GUILD_TOKEN_AUTH
	m_dwGuildToken = dwGuildToken;
#endif

	if (!__Load (c_szFileName, peError))
	{
		return false;
	}

	return true;
}

bool CGuildMarkUploader::ConnectToSendSymbol(const CNetworkAddress& c_rkNetAddr, DWORD dwHandle, DWORD dwRandomKey, DWORD dwGuildID, const char* c_szFileName, unsigned int* peError
#ifdef ENABLE_GUILD_TOKEN_AUTH
	, uint64_t dwGuildToken
#endif
)
{
	__OfflineState_Set();
	SetRecvBufferSize (1024);
	SetSendBufferSize (64 * 1024);

	if (!CNetworkStream::Connect (c_rkNetAddr))
	{
		*peError = ERROR_CONNECT;
		return false;
	}

	m_dwSendType = SEND_TYPE_SYMBOL;
	m_dwHandle = dwHandle;
	m_dwRandomKey = dwRandomKey;
	m_dwGuildID = dwGuildID;
#ifdef ENABLE_GUILD_TOKEN_AUTH
	m_dwGuildToken = dwGuildToken;
#endif

	if (!__LoadSymbol (c_szFileName, peError))
	{
		return false;
	}

	return true;
}

void CGuildMarkUploader::Process()
{
	CNetworkStream::Process();

	if (!__StateProcess())
	{
		__OfflineState_Set();
		Disconnect();
	}
}

void CGuildMarkUploader::OnConnectFailure()
{
	__OfflineState_Set();
}

void CGuildMarkUploader::OnConnectSuccess()
{
	__LoginState_Set();
}

void CGuildMarkUploader::OnRemoteDisconnect()
{
	__OfflineState_Set();
}

void CGuildMarkUploader::OnDisconnect()
{
	__OfflineState_Set();
}

void CGuildMarkUploader::__Initialize()
{
	m_eState = STATE_OFFLINE;

	m_dwGuildID = 0;
	m_dwHandle = 0;
	m_dwRandomKey = 0;
#ifdef ENABLE_GUILD_TOKEN_AUTH
	m_dwGuildToken = 0;
#endif

	if (m_pbySymbolBuf)
	{
		delete m_pbySymbolBuf;
	}

	m_dwSymbolBufSize = 0;
	#ifdef FIX_BLACK_SCREEN
	m_pbySymbolBuf = nullptr;
	#else
	m_pbySymbolBuf = NULL;
	#endif
}

bool CGuildMarkUploader::__StateProcess()
{
	switch (m_eState)
	{
		case STATE_LOGIN:
			return __LoginState_Process();
			break;
	}

	return true;
}

void CGuildMarkUploader::__OfflineState_Set()
{
	__Initialize();
}

void CGuildMarkUploader::__CompleteState_Set()
{
	m_eState = STATE_COMPLETE;

	__OfflineState_Set();
}


void CGuildMarkUploader::__LoginState_Set()
{
	m_eState = STATE_LOGIN;
}

bool CGuildMarkUploader::__LoginState_Process()
{
	if (!__AnalyzePacket (HEADER_GC_PHASE, sizeof (TPacketGCPhaseCSCheckDraveniu), &CGuildMarkUploader::__LoginState_RecvPhase))
	{
		return false;
	}

	if (!__AnalyzePacket (HEADER_GC_HANDSHAKE, sizeof (TPacketGCHandshakeCSCheckDraveniu), &CGuildMarkUploader::__LoginState_RecvHandshake))
	{
		return false;
	}

	if (!__AnalyzePacket (HEADER_GC_PING, sizeof (TPacketGCPing), &CGuildMarkUploader::__LoginState_RecvPing))
	{
		return false;
	}

	return true;
}

bool CGuildMarkUploader::__SendMarkPacket()
{
	TPacketCGMarkUploadCheckDraveniu kPacketMarkUpload;
	kPacketMarkUpload.header = HEADER_CG_MARK_UPLOAD;
	kPacketMarkUpload.gid = m_dwGuildID;

#ifdef ENABLE_GUILD_TOKEN_AUTH
	kPacketMarkUpload.token = m_dwGuildToken;
#endif
	assert (sizeof (kPacketMarkUpload.image) == sizeof (m_kMark.m_apxBuf));
	memcpy (kPacketMarkUpload.image, m_kMark.m_apxBuf, sizeof (kPacketMarkUpload.image));

	if (!Send (sizeof (kPacketMarkUpload), &kPacketMarkUpload))
	{
		return false;
	}

	return true;
}
bool CGuildMarkUploader::__SendSymbolPacket()
{
	if (!m_pbySymbolBuf)
	{
		return false;
	}

	TPacketCGSymbolUploadCheckDraveniu kPacketSymbolUpload;
	kPacketSymbolUpload.header = HEADER_CG_GUILD_SYMBOL_UPLOAD;
	kPacketSymbolUpload.handle = m_dwGuildID;
	kPacketSymbolUpload.size = sizeof (TPacketCGSymbolUploadCheckDraveniu) + m_dwSymbolBufSize;

#ifdef ENABLE_GUILD_TOKEN_AUTH
	kPacketSymbolUpload.token = m_dwGuildToken;
#endif
	if (!Send (sizeof (TPacketCGSymbolUploadCheckDraveniu), &kPacketSymbolUpload))
	{
		return false;
	}
	if (!Send (m_dwSymbolBufSize, m_pbySymbolBuf))
	{
		return false;
	}

	#ifdef _DEBUG
	printf ("__SendSymbolPacket : [GuildID:%d/PacketSize:%d/BufSize:%d/CRC:%d]\n", m_dwGuildID, kPacketSymbolUpload.size, m_dwSymbolBufSize, m_dwSymbolCRC32);
	#endif

	CNetworkStream::__SendInternalBuffer();
	__CompleteState_Set();

	return true;
}

bool CGuildMarkUploader::__LoginState_RecvPhase()
{
	TPacketGCPhaseCSCheckDraveniu kPacketPhase;
	if (!Recv (sizeof (kPacketPhase), &kPacketPhase))
	{
		return false;
	}

	if (kPacketPhase.phase == PHASE_LOGIN)
	{

		if (SEND_TYPE_MARK == m_dwSendType)
		{
			if (!__SendMarkPacket())
			{
				return false;
			}
		}
		else if (SEND_TYPE_SYMBOL == m_dwSendType)
		{
			if (!__SendSymbolPacket())
			{
				return false;
			}
		}
	}

	return true;
}

bool CGuildMarkUploader::__LoginState_RecvHandshake()
{
	TPacketGCHandshakeCSCheckDraveniu kPacketHandshake;
	if (!Recv (sizeof (kPacketHandshake), &kPacketHandshake))
	{
		return false;
	}


	TPacketCGMarkLoginCheckDraveniu kPacketMarkLogin;
	kPacketMarkLogin.header = HEADER_CG_MARK_LOGIN;
	kPacketMarkLogin.handle = m_dwHandle;
	kPacketMarkLogin.random_key = m_dwRandomKey;
	if (!Send (sizeof (kPacketMarkLogin), &kPacketMarkLogin))
	{
		return false;
	}

	return true;
}

bool CGuildMarkUploader::__LoginState_RecvPing()
{
	TPacketGCPing kPacketPing;
	if (!Recv (sizeof (kPacketPing), &kPacketPing))
	{
		return false;
	}

	TPacketCGPong kPacketPong;
	kPacketPong.bHeader = HEADER_CG_PONG;

	if (!Send (sizeof (TPacketCGPong), &kPacketPong))
	{
		return false;
	}

	return true;
}

bool CGuildMarkUploader::__AnalyzePacket (unsigned int uHeader, unsigned int uPacketSize, bool (CGuildMarkUploader::* pfnDispatchPacket)())
{
	BYTE bHeader;
	if (!Peek (sizeof (bHeader), &bHeader))
	{
		return true;
	}

	if (bHeader != uHeader)
	{
		return true;
	}

#ifdef __FIX_BUFFER_CLIENT__
	if (!PeekNoFetch (uPacketSize))
#else
	if (!Peek (uPacketSize))
#endif
	{
		return true;
	}

	return (this->*pfnDispatchPacket)();
}

