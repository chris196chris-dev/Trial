//MULTI_LANGUAGE
#pragma once
#include <windows.h>

#define DEFAULT_LANGUAGE "en"

void LocaleJson_SetLanguage(const char* lang);
bool LocaleJson_LoadItemNames(const char* filename);
bool LocaleJson_LoadMobNames(const char* filename);
const char* LocaleJson_GetItemName(DWORD dwVnum);
const char* LocaleJson_GetMobName(DWORD dwVnum);
void LocaleJson_ClearItemNames();
void LocaleJson_ClearMobNames();

//MULTI_LANGUAGE - UI Strings
bool LocaleJson_LoadStrings(const char* filename);
const char* LocaleJson_GetString(const char* key);
bool LocaleJson_IsFormatString(const char* key);
void LocaleJson_ClearStrings();

//MULTI_LANGUAGE - Quest Strings
bool LocaleJson_LoadQuestStrings(const char* filename);
const char* LocaleJson_GetQuestString(int id);
void LocaleJson_ClearQuestStrings();

//MULTI_LANGUAGE - Item Descriptions
bool LocaleJson_LoadItemDesc(const char* filename);
const char* LocaleJson_GetItemDesc(DWORD dwVnum);
const char* LocaleJson_GetItemSummary(DWORD dwVnum);
void LocaleJson_ClearItemDesc();

//MULTI_LANGUAGE - Skill Descriptions
bool LocaleJson_LoadSkillDesc(const char* filename);
const char* LocaleJson_GetSkillName(DWORD dwVnum, int grade);
const char* LocaleJson_GetSkillDescription(DWORD dwVnum);
int LocaleJson_GetSkillConditionCount(DWORD dwVnum);
const char* LocaleJson_GetSkillCondition(DWORD dwVnum, int index);
int LocaleJson_GetSkillAffectDescCount(DWORD dwVnum);
const char* LocaleJson_GetSkillAffectDesc(DWORD dwVnum, int index);
void LocaleJson_ClearSkillDesc();
//MULTI_LANGUAGE

