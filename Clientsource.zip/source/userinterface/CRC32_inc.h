#pragma once

// FINALFORM_V8_GODMOVE
// Compatibility include for older UserInterface.vcxproj entries. The real
// CRC32 implementation lives in source/eterbase/CRC32.h / CRC32.cpp and is
// linked through EterBase. Do not duplicate the implementation here.
#include "../eterbase/CRC32.h"
