#pragma once
#include "Image.h"

class CTGAImage : public CImage
{
	public:
		CTGAImage();
		CTGAImage (CImage& image);
		virtual~CTGAImage() = default;

		virtual void Create (int width, int height);
		virtual bool LoadFromMemory (int iSize, const BYTE* c_pbMem);

		TGA_HEADER& GetHeader();

	protected:
		TGA_HEADER m_Header;
		DWORD m_dwFlag;
};

