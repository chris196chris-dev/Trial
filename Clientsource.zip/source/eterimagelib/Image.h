#pragma once
#include <windows.h>
#include <string>

#pragma pack(push)
#pragma pack(1)
struct TGA_HEADER
{
	char idLen;
	char palType;
	char imgType;
	WORD colorBegin;
	WORD colorCount;
	char palEntrySize;
	WORD left;
	WORD top;
	WORD width;
	WORD height;
	char colorBits;
	char desc;
};
#pragma pack(pop)

class CImage
{
	public:
		CImage();
		CImage (CImage& image);
		virtual~CImage();

		void Destroy();
		void Create (int width, int height);
		void Clear (DWORD color = 0);

		int GetWidth() const;
		int GetHeight() const;

		DWORD* GetBasePointer();
		DWORD* GetLinePointer (int line);

		void FlipTopToBottom();
		bool IsEmpty() const;

	protected:
		void Initialize();

	protected:
		DWORD* m_pdwColors;
		int m_width;
		int m_height;
};

