#if !defined(AFX_STDAFX_H__BCF68E23_E7D8_4BF3_A905_AFDBEF92B0F6__INCLUDED_)
#define AFX_STDAFX_H__BCF68E23_E7D8_4BF3_A905_AFDBEF92B0F6__INCLUDED_

#pragma once
#pragma warning(disable:4786)

#define WIN32_LEAN_AND_MEAN

#include <AttackDefines.h>
#include <windows.h>
#include <assert.h>
#pragma warning(push, 3)
#include <string>
#include <vector>
#pragma warning(pop)
#pragma warning(default:4018)
#endif

