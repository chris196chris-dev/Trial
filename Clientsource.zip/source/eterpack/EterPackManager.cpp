#include "StdAfx.h"
#include "EterPackManager.h"

#include "../eterbase/Debug.h"
#include "../eterbase/CRC32.h"
#include <vector>
#include <algorithm>

int CEterPackManager::ConvertFileName (const char* c_szFileName, std::string& rstrFileName)
{
	rstrFileName = c_szFileName;
	stl_lowers (rstrFileName);
	int iCount = 0;

	for (DWORD i = 0; i < rstrFileName.length(); ++i)
	{
		if (rstrFileName[i] == '/')
		{
			++iCount;
		}
		else if (rstrFileName[i] == '\\')
		{
			rstrFileName[i] = '/';
			++iCount;
		}
	}

	return iCount;
}


// FINALFORM_V6_ALT_PACK_PATHS: tolerate old x32/client asset path variants.
static void FinalForm_AddAlternativePackNames(const std::string& in, std::vector<std::string>& out)
{
    auto add = [&](std::string v)
    {
        stl_lowers(v);
        for (char& c : v) if (c == '\\') c = '/';
        if (!v.empty() && std::find(out.begin(), out.end(), v) == out.end())
            out.push_back(v);
    };

    add(in);

    std::string s = in;
    stl_lowers(s);
    for (char& c : s) if (c == '\\') c = '/';

    // Some unpacked assets are stored without d:/ while code requests d:/ymir work/.
    const std::string dymir = "d:/ymir work/";
    const std::string ymir = "ymir work/";
    size_t p = s.find(dymir);
    if (p != std::string::npos)
    {
        std::string tail = s.substr(p + dymir.size());

        // x32 packs were often built from folders like "npc/", "monster/",
        // "item/", "effect/", "terrainmaps/" instead of keeping the
        // absolute "d:/ymir work/" prefix.  The x64 client asks for the
        // absolute YMIR path, so first try the clean relative tail.  This is
        // the important fallback for invisible NPC / mobs / mounts / pets and
        // missing item/effect resources.
        add(tail);

        // Also keep the previous compatibility variants for packs that did
        // preserve a partial ymir-work prefix or pack-name prefix.
        add(ymir + tail);
        add("enoria/ymir work/" + tail);
        add("new_pack/ymir work/" + tail);
        add("newpack/ymir work/" + tail);
        add("map/ymir work/" + tail);

        // Some repackers include one extra top folder before the relative
        // asset path.  These are cheap CRC lookups and make the loader much
        // more tolerant without changing pack format.
        add("enoria/" + tail);
        add("new_pack/" + tail);
        add("newpack/" + tail);
        add("map/" + tail);
        add("pc/" + tail);
        add("pc2/" + tail);
    }

    // Season path sometimes exists under map/season* in the x32 pack dump.
    if (s.find("#season") == 0)
        add(s.substr(1));
    if (s.find("season1/") == 0 || s.find("season2/") == 0)
        add("map/" + s);

    // Broken Korean 'common' folder mojibake from old YMIR props. In this asset set
    // these hay objects live in zone/b/obj, not zone/common. Use explicit bytes so
    // Visual Studio source-file encoding cannot change the match string.
    const char mojibakeCommonBytes[] = { 'z','o','n','e','/', char(0xB0), char(0xF8), char(0xBF), char(0xEB), '/', 0 };
    const std::string mojibakeCommon(mojibakeCommonBytes);
    p = s.find(mojibakeCommon);
    if (p != std::string::npos)
    {
        std::string rest = s.substr(p + mojibakeCommon.size());
        add(s.substr(0, p) + "zone/b/obj/" + rest);
        add(s.substr(0, p) + "zone/common/" + rest);
        add("zone/b/obj/" + rest);
        add("zone/common/" + rest);
    }

    // UTF-8 spelling of Korean common folder: zone/공용/
    const char utf8CommonBytes[] = { 'z','o','n','e','/', char(0xEA), char(0xB3), char(0xB5), char(0xEC), char(0x9A), char(0xA9), '/', 0 };
    const std::string utf8Common(utf8CommonBytes);
    p = s.find(utf8Common);
    if (p != std::string::npos)
    {
        std::string rest = s.substr(p + utf8Common.size());
        add(s.substr(0, p) + "zone/b/obj/" + rest);
        add(s.substr(0, p) + "zone/common/" + rest);
        add("zone/b/obj/" + rest);
        add("zone/common/" + rest);
    }

    // Property data sometimes requests .mdatr for objects that only exist as .gr2.
    // Do NOT map .mdatr to .gr2 here; that would feed the wrong resource type.
}

CEterPackManager::SCache* CEterPackManager::FindCache (DWORD dwFileNameHash)
{
	auto it = m_kMap_dwNameKey_kCache.find (dwFileNameHash);
	if (m_kMap_dwNameKey_kCache.end() == it)
	{
		return NULL;
	}

	return &it->second;
}

void CEterPackManager::ClearCacheMap()
{
	for (auto it = m_kMap_dwNameKey_kCache.begin(); it != m_kMap_dwNameKey_kCache.end(); ++it)
	{
		delete [] it->second.m_abBufData;
		#ifdef FIX_BLACK_SCREEN
		it->second.m_abBufData = nullptr;
		#endif
	}

	m_kMap_dwNameKey_kCache.clear();
}

bool CEterPackManager::Get (CMappedFile& rMappedFile, const char* c_szFileName, LPCVOID* pData)
{
	if (GetFromPack (rMappedFile, c_szFileName, pData))
	{
		return true;
	}

	#ifndef FILES_ONLY_FROM_PACK
	if (GetFromFile (rMappedFile, c_szFileName, pData))
	{
		return true;
	}
	#endif

	#ifdef _DEBUG
	TraceError ("CANNOT_FIND_FILE [%s]", c_szFileName);
	#endif

	return false;
}

struct FinderLock
{
	FinderLock (CRITICAL_SECTION& cs) : p_cs (&cs)
	{
		EnterCriticalSection (p_cs);
	}

	~FinderLock()
	{
		LeaveCriticalSection (p_cs);
	}

	CRITICAL_SECTION* p_cs;
};

bool CEterPackManager::GetFromPack (CMappedFile& rMappedFile, const char* c_szFileName, LPCVOID* pData)
{
	FinderLock lock (m_csFinder);
	static std::string strFileName;

	ConvertFileName(c_szFileName, strFileName);
	std::vector<std::string> candidates;
	FinalForm_AddAlternativePackNames(strFileName, candidates);

	for (const std::string& candidate : candidates)
	{
		if (candidate.find('/') == std::string::npos)
		{
			Tracef("GetFromPack: requesting '%s' -> normalized '%s' (root pack try)", c_szFileName, candidate.c_str());
			if (m_RootPack.Get(rMappedFile, candidate.c_str(), pData))
				return true;
			continue;
		}

		DWORD dwFileNameHash = GetCRC32(candidate.c_str(), candidate.length());
		Tracef("GetFromPack: requesting '%s' -> normalized '%s' crc=0x%08X", c_szFileName, candidate.c_str(), dwFileNameHash);

		SCache* pkCache = FindCache(dwFileNameHash);
		if (pkCache)
		{
			Tracef("GetFromPack: cache hit for '%s' crc=0x%08X size=%u", candidate.c_str(), dwFileNameHash, pkCache->m_dwBufSize);
			rMappedFile.Link(pkCache->m_dwBufSize, pkCache->m_abBufData);
			return true;
		}

		CEterFileDict::Item* pkFileItem = m_FileDict.GetItem(dwFileNameHash, candidate.c_str());
		if (pkFileItem && pkFileItem->pkPack)
		{
			Tracef("GetFromPack: found in pack for '%s' crc=0x%08X packIndexId=%d", candidate.c_str(), dwFileNameHash, pkFileItem->pkInfo ? pkFileItem->pkInfo->id : -1);
			return pkFileItem->pkPack->Get2(rMappedFile, candidate.c_str(), pkFileItem->pkInfo, pData);
		}
	}

	Tracef("GetFromPack: not found in file dict for '%s' normalized='%s'", c_szFileName, strFileName.c_str());
	return false;
}

bool CEterPackManager::GetFromFile (CMappedFile& rMappedFile, const char* c_szFileName, LPCVOID* pData)
{
	return rMappedFile.Create (c_szFileName, pData, 0, 0) ? true : false;
}

bool CEterPackManager::isExistInPack (const char* c_szFileName)
{
	FinderLock lock (m_csFinder);

	std::string strFileName;
	ConvertFileName (c_szFileName, strFileName);

	std::vector<std::string> candidates;
	FinalForm_AddAlternativePackNames(strFileName, candidates);

	for (const std::string& candidate : candidates)
	{
		if (candidate.find('/') == std::string::npos)
		{
			if (m_RootPack.IsExist (candidate.c_str()))
				return true;
			continue;
		}

		DWORD dwFileNameHash = GetCRC32 (candidate.c_str(), candidate.length());
		CEterFileDict::Item* pkFileItem = m_FileDict.GetItem (dwFileNameHash, candidate.c_str());
		if (pkFileItem && pkFileItem->pkPack)
		{
			return true;
		}
	}

	return false;
}

bool CEterPackManager::isExist (const char* c_szFileName)
{
	if (isExistInPack (c_szFileName))
	{
		return true;
	}

	return _access (c_szFileName, 0) == 0 ? true : false;
}

void CEterPackManager::RegisterRootPack (const char* c_szName)
{
    // Resolve full path for logging
	char fullPath[MAX_PATH + 1] = {0};
	if (GetFullPathNameA(c_szName, MAX_PATH, fullPath, NULL) == 0)
		strncpy(fullPath, c_szName, MAX_PATH);

	Tracef("RegisterRootPack: attempting to register root pack '%s' (resolved: %s)\n", c_szName, fullPath);

	if (!m_RootPack.Create (m_FileDict, c_szName, ""))
	{
		TraceError ("%s: Pack file does not exist", c_szName);
	}
}

bool CEterPackManager::RegisterPack (const char* c_szName, const char* c_szDirectory)
{
	CEterPack* pEterPack = NULL;
	{
		auto itor = m_PackMap.find (c_szName);

		if (m_PackMap.end() == itor)
		{
            pEterPack = new CEterPack;

			// Log and check existence before attempting create
			char fullPath[MAX_PATH + 1] = {0};
			if (GetFullPathNameA(c_szName, MAX_PATH, fullPath, NULL) == 0)
				strncpy(fullPath, c_szName, MAX_PATH);

			Tracef("RegisterPack: attempting to register pack '%s' (resolved: %s) dir='%s'\n", c_szName, fullPath, c_szDirectory ? c_szDirectory : "");

			if (pEterPack->Create (m_FileDict, c_szName, c_szDirectory, true))
			{
				m_PackMap.insert (TEterPackMap::value_type (c_szName, pEterPack));
			}
			else
			{
				#ifdef _DEBUG
				Tracef ("The eterpack doesn't exist [%s]\n", c_szName);
				#endif
				delete pEterPack;
				#ifdef FIX_BLACK_SCREEN
				pEterPack = nullptr;
				#else
				pEterPack = NULL;
				#endif
				return false;
			}
		}
		else
		{
			pEterPack = itor->second;
		}
	}

	if (c_szDirectory && c_szDirectory[0] != '*')
	{
		auto itor = m_DirPackMap.find (c_szDirectory);
		if (m_DirPackMap.end() == itor)
		{
			m_PackList.push_front (pEterPack);
			m_DirPackMap.insert (TEterPackMap::value_type (c_szDirectory, pEterPack));
		}
	}

	return true;
}

CEterPackManager::CEterPackManager()
{
	InitializeCriticalSection (&m_csFinder);
}

CEterPackManager::~CEterPackManager()
{
	ClearCacheMap();
	auto it = m_PackMap.begin();
	auto et = m_PackMap.end();

	while (it != et)
	{
		delete it->second;
		#ifdef FIX_BLACK_SCREEN
		it->second = nullptr;
		#endif
		it++;
	}

	DeleteCriticalSection (&m_csFinder);
}
