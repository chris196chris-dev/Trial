#include "StdAfx.h"
#include "EterPack.h"
#include "Inline.h"

#include "../eterbase/utils.h"
#include "../eterbase/Debug.h"
#include "../eterbase/CRC32.h"
#include <errno.h>

const TeaKey& s_adwEterPackKey()
{
	static const TeaKey key
	{
		std::array <DWORD, 4> {{
				LZO_PROTECT_KEY_1,
				LZO_PROTECT_KEY_2,
				LZO_PROTECT_KEY_3,
				LZO_PROTECT_KEY_4,
			}
		}
	};
	return key;
}

const TeaKey& s_adwEterPackSecurityKey()
{
	static const TeaKey key
	{
		std::array <DWORD, 4> {{
				LZO_PROTECT_KEY_1,
				LZO_PROTECT_KEY_2,
				LZO_PROTECT_KEY_3,
				LZO_PROTECT_KEY_4,
			}
		}
	};
	return key;
}

CEterPack::CEterPack(): m_indexCount (0), m_FragmentSize (0), m_bEncrypted (false), m_bReadOnly (false)
{
}

CEterPack::~CEterPack()
{
	Destroy();
}

void CEterPack::Destroy()
{
	m_bReadOnly = false;
	m_bEncrypted = false;
	m_indexCount = 0;
	m_DataPositionMap.clear();

	for (int i = 0; i < FREE_INDEX_MAX_SIZE + 1; ++i)
	{
		m_FreeIndexList[i].clear();
	}

	m_indexData.clear();
	m_FragmentSize = 0;

	memset (m_dbName, 0, sizeof (m_dbName));
	memset (m_indexFileName, 0, sizeof (m_indexFileName));
}

bool CEterPack::Create (CEterFileDict& rkFileDict, const char* dbname, const char* pathName, bool bReadOnly)
{
	m_stPathName = pathName;
	strncpy (m_dbName, dbname, DBNAME_MAX_LEN);

	strncpy (m_indexFileName, dbname, MAX_PATH);
	strcat (m_indexFileName, ".eix");

	m_stDataFileName = dbname;
	m_stDataFileName += ".epk";

	m_bReadOnly = bReadOnly;

	if (!CreateIndexFile())
	{
		return false;
	}

	if (!CreateDataFile())
	{
		return false;
	}

	BuildIndex (rkFileDict);
	return true;
}

bool CEterPack::BuildIndex (CEterFileDict& rkFileDict, bool bOverwrite)
{
    Tracef("CEterPack::BuildIndex - index='%s' data='%s'", m_indexFileName, m_stDataFileName.c_str());
	CMappedFile file;
	LPCVOID pvData;
	CLZObject zObj;

	if (!file.Create (m_indexFileName, &pvData, 0, 0))
	{
		TraceError ("Cannot open pack index file! %s", m_dbName);
		return false;
	}

	if (file.Size() < eterpack::c_HeaderSize)
	{
		TraceError ("Pack index file header error! %s (size: %u, required: %u)", m_dbName, file.Size(), eterpack::c_HeaderSize);
		return false;
	}

	DWORD fourcc = * (DWORD*) pvData;
	TraceError ("[DEBUG] Index file %s - FourCC: 0x%08X, Expected MCOZ: 0x%08X or IndexCC: 0x%08X", m_dbName, fourcc, CLZObject::ms_dwFourCC, eterpack::c_IndexCC);

	BYTE* pbData;
	unsigned int uiFileSize;

	if (fourcc == eterpack::c_IndexCC)
	{
		TraceError ("[DEBUG] Index file %s - Using unencrypted format", m_dbName);
		pbData = (BYTE*) pvData;
		uiFileSize = file.Size();
	}
	else if (fourcc == CLZObject::ms_dwFourCC)
	{
		m_bEncrypted = true;
		const DWORD* pKey = s_adwEterPackKey();
		TraceError ("[DEBUG] Index file %s - Using encrypted format, attempting TEA decryption with keys: 0x%08X 0x%08X 0x%08X 0x%08X",
			m_dbName,
			pKey[0],
			pKey[1],
			pKey[2],
			pKey[3]);

		if (!CLZO::Instance().Decompress (zObj, (const BYTE*) pvData, s_adwEterPackKey()))
		{
			TraceError ("[ERROR] Index file %s - TEA decryption failed! Wrong encryption key or corrupted file", m_dbName);
			return false;
		}

		if (zObj.GetSize() < eterpack::c_HeaderSize)
		{
			TraceError ("[ERROR] Index file %s - Decompressed size too small: %u < %u", m_dbName, zObj.GetSize(), eterpack::c_HeaderSize);
			return false;
		}

		TraceError ("[DEBUG] Index file %s - Decryption successful, decompressed size: %u", m_dbName, zObj.GetSize());
		pbData = zObj.GetBuffer();
		uiFileSize = zObj.GetSize();
	}
	else
	{
		TraceError ("Pack index file fourcc error! %s - Got 0x%08X, expected 0x%08X or 0x%08X", m_dbName, fourcc, CLZObject::ms_dwFourCC, eterpack::c_IndexCC);
		return false;
	}

	pbData += sizeof (DWORD);
	DWORD ver = * (DWORD*) pbData;
	pbData += sizeof (DWORD);

	if (ver != eterpack::c_Version)
	{
		TraceError ("[ERROR] Pack index file version error! %s - Got version: %u, Expected: %u", m_dbName, ver, eterpack::c_Version);
		return false;
	}

	TraceError ("[DEBUG] Index file %s - Version check passed: %u", m_dbName, ver);

	m_indexCount = * (long*) pbData;
	pbData += sizeof (long);

	TraceError ("[DEBUG] Index file %s - Index count: %d", m_dbName, m_indexCount);

	if (uiFileSize < eterpack::c_HeaderSize + sizeof (TEterPackIndex) * m_indexCount)
	{
		TraceError ("[ERROR] Pack index file size error! %s - File size: %u, Required: %u (header: %u + %d indices * %u bytes)",
			m_dbName, uiFileSize, eterpack::c_HeaderSize + sizeof (TEterPackIndex) * m_indexCount,
			eterpack::c_HeaderSize, m_indexCount, sizeof (TEterPackIndex));
		return false;
	}

	m_indexData.resize (m_indexCount);
	memcpy (m_indexData.data(), pbData, sizeof (TEterPackIndex) * m_indexCount);

	for (TEterPackIndex& index : m_indexData)
	{
		if (!index.filename_crc)
		{
			PushFreeIndex (&index);
		}
		else
		{
			if (index.real_data_size > index.data_size)
			{
				m_FragmentSize += index.real_data_size - index.data_size;
			}

			m_DataPositionMap.insert (TDataPositionMap::value_type (index.filename_crc, &index));

			if (bOverwrite)
			{
				rkFileDict.UpdateItem (this, &index);
			}
			else
			{
				rkFileDict.InsertItem (this, &index);
			}
		}
	}

	return true;
}

bool CEterPack::Get (CMappedFile& out_file, const char* filename, LPCVOID* data)
{
	TEterPackIndex* index = FindIndex (filename);

	if (!index)
	{
		return false;
	}

	out_file.Create (m_stDataFileName.c_str(), data, index->data_position, index->data_size);

	if (COMPRESSED_TYPE_COMPRESS == index->compressed_type)
	{
		CLZObject* zObj = new CLZObject;

		if (!CLZO::Instance().Decompress (*zObj, static_cast<const BYTE*> (*data)))
		{
			TraceError ("Failed to decompress : %s", filename);
			delete zObj;
			#ifdef FIX_BLACK_SCREEN
			zObj = nullptr;
			#endif
			return false;
		}

		out_file.BindLZObject (zObj);
		*data = zObj->GetBuffer();
	}
	else if (COMPRESSED_TYPE_SECURITY == index->compressed_type)
	{
		CLZObject* zObj = new CLZObject;

		if (!CLZO::Instance().Decompress (*zObj, static_cast<const BYTE*> (*data), s_adwEterPackSecurityKey()))
		{
			TraceError ("Failed to encrypt : %s", filename);
			delete zObj;
			#ifdef FIX_BLACK_SCREEN
			zObj = nullptr;
			#endif
			return false;
		}

		out_file.BindLZObject (zObj);
		*data = zObj->GetBuffer();
	}

	return true;
}

bool CEterPack::Get2 (CMappedFile& out_file, const char* filename, TEterPackIndex* index, LPCVOID* data)
{
	if (!index)
	{
		return false;
	}

	out_file.Create (m_stDataFileName.c_str(), data, index->data_position, index->data_size);

	if (COMPRESSED_TYPE_COMPRESS == index->compressed_type)
	{
		CLZObject* zObj = new CLZObject;

		if (!CLZO::Instance().Decompress (*zObj, static_cast<const BYTE*> (*data)))
		{
			TraceError ("Failed to decompress : %s", filename);
			delete zObj;
			#ifdef FIX_BLACK_SCREEN
			zObj = nullptr;
			#endif
			return false;
		}

		out_file.BindLZObject (zObj);
		*data = zObj->GetBuffer();
	}
	else if (COMPRESSED_TYPE_SECURITY == index->compressed_type)
	{
		CLZObject* zObj = new CLZObject;

		if (!CLZO::Instance().Decompress (*zObj, static_cast<const BYTE*> (*data), s_adwEterPackSecurityKey()))
		{
			TraceError ("Failed to encrypt : %s", filename);
			delete zObj;
			#ifdef FIX_BLACK_SCREEN
			zObj = nullptr;
			#endif
			return false;
		}

		out_file.BindLZObject (zObj);
		*data = zObj->GetBuffer();
	}

	return true;
}

bool CEterPack::CreateIndexFile()
{
	FILE* fp;

	if (NULL != (fp = fopen (m_indexFileName, "rb")))
	{
		fclose (fp);
		return true;
	}
	else if (m_bReadOnly)
	{
		return false;
	}

	fp = fopen (m_indexFileName, "wb");

	if (!fp)
	{
		return false;
	}

	fwrite (&eterpack::c_IndexCC, sizeof (DWORD), 1, fp);
	fwrite (&eterpack::c_Version, sizeof (DWORD), 1, fp);
	fwrite (&m_indexCount, sizeof (long), 1, fp);
	fclose (fp);
	return true;
}

void CEterPack::WriteIndex (CFileBase& file, TEterPackIndex* index)
{
	file.Seek (sizeof (DWORD) + sizeof (DWORD));
	file.Write (&m_indexCount, sizeof (long));
	file.Seek (eterpack::c_HeaderSize + (index->id * sizeof (TEterPackIndex)));

	if (!file.Write (index, sizeof (TEterPackIndex)))
	{
		assert (!"WriteIndex: fwrite failed");
		return;
	}
}

int CEterPack::GetFreeBlockIndex (long size)
{
	return min (FREE_INDEX_MAX_SIZE, size / FREE_INDEX_BLOCK_SIZE);
}

void CEterPack::PushFreeIndex (TEterPackIndex* index)
{
	if (index->filename_crc != 0)
	{
		auto it = m_DataPositionMap.find (index->filename_crc);

		if (it != m_DataPositionMap.end())
		{
			m_DataPositionMap.erase (it);
		}

		index->filename_crc = 0;
		memset (index->filename, 0, sizeof (index->filename));
	}

	int blockidx = GetFreeBlockIndex (index->real_data_size);
	m_FreeIndexList[blockidx].push_back (index);
	m_FragmentSize += index->real_data_size;
}

long CEterPack::GetNewIndexPosition (CFileBase& file)
{
	long pos = (file.Size() - eterpack::c_HeaderSize) / sizeof (TEterPackIndex);
	++m_indexCount;
	return (pos);
}

TEterPackIndex* CEterPack::NewIndex (CFileBase& file, const char* filename, long size)
{
	TEterPackIndex* index = NULL;
	int block_size = size + (DATA_BLOCK_SIZE - (size % DATA_BLOCK_SIZE));
	int blockidx = GetFreeBlockIndex (block_size);

	for (auto it = m_FreeIndexList[blockidx].begin(); it != m_FreeIndexList[blockidx].end(); ++it)
	{
		if ((*it)->real_data_size >= size)
		{
			index = *it;
			m_FreeIndexList[blockidx].erase (it);
			assert (index->filename_crc == 0);
			break;
		}
	}

	if (!index)
	{
		index = new TEterPackIndex;
		index->real_data_size = block_size;
		index->id = GetNewIndexPosition (file);
	}

	strncpy (index->filename, filename, FILENAME_MAX_LEN);
	index->filename[FILENAME_MAX_LEN] = '\0';
	inlineConvertPackFilename (index->filename);

	index->filename_crc = GetCRC32 (index->filename, strlen (index->filename));

	m_DataPositionMap.insert (TDataPositionMap::value_type (index->filename_crc, index));
	return index;
}

TEterPackIndex* CEterPack::FindIndex (const char* filename)
{
	static char tmpFilename[MAX_PATH + 1];
	strncpy (tmpFilename, filename, MAX_PATH);
	inlineConvertPackFilename (tmpFilename);
	DWORD filename_crc = GetCRC32 (tmpFilename, strlen (tmpFilename));
    auto it = m_DataPositionMap.find (filename_crc);

	if (it == m_DataPositionMap.end())
	{
		Tracef("CEterPack::FindIndex - not found '%s' normalized='%s' crc=0x%08X", filename, tmpFilename, filename_crc);
		return NULL;
	}

	Tracef("CEterPack::FindIndex - found '%s' normalized='%s' crc=0x%08X indexId=%d", filename, tmpFilename, filename_crc, it->second ? it->second->id : -1);
	return (it->second);
}

bool CEterPack::IsExist (const char* filename)
{
	return FindIndex (filename) ? true : false;
}

bool CEterPack::CreateDataFile()
{
	FILE* fp;

	if (NULL != (fp = fopen (m_stDataFileName.c_str(), "rb")))
	{
		fclose (fp);
		return true;
	}
	else if (m_bReadOnly)
	{
		return false;
	}

	fp = fopen (m_stDataFileName.c_str(), "wb");

	if (!fp)
	{
		return false;
	}

	fclose (fp);
	return true;
}

long CEterPack::GetNewDataPosition (CFileBase& file)
{
	return file.Size();
}

bool CEterPack::WriteNewData (CFileBase& file, TEterPackIndex* index, LPCVOID data)
{
	file.Seek (index->data_position);

	if (!file.Write (data, index->data_size))
	{
		assert (!"WriteData: fwrite data failed");
		return false;
	}

	int empty_size = index->real_data_size - index->data_size;

	if (empty_size < 0)
	{
		printf ("SYSERR: WriteNewData(): CRITICAL ERROR: empty_size lower than 0!\n");
		exit (1);
	}

	if (empty_size == 0)
	{
		return true;
	}

	char* empty_buf = (char*) calloc (empty_size, sizeof (char));

	if (!file.Write (empty_buf, empty_size))
	{
		assert (!"WriteData: fwrite empty data failed");
		return false;
	}

	free (empty_buf);
	return true;
}

TDataPositionMap& CEterPack::GetIndexMap()
{
	return m_DataPositionMap;
}

void CEterFileDict::InsertItem (CEterPack* pkPack, TEterPackIndex* pkInfo)
{
	Item item;
	item.pkPack = pkPack;
	item.pkInfo = pkInfo;
	m_dict.insert (TDict::value_type (pkInfo->filename_crc, item));
}

void CEterFileDict::UpdateItem (CEterPack* pkPack, TEterPackIndex* pkInfo)
{
	Item item;
	item.pkPack = pkPack;
	item.pkInfo = pkInfo;

	auto it = m_dict.find (pkInfo->filename_crc);
	if (it == m_dict.end())
	{
		m_dict.insert (TDict::value_type (pkInfo->filename_crc, item));
	}
	else
	{
		if (strcmp (it->second.pkInfo->filename, item.pkInfo->filename) == 0)
		{
			it->second = item;
		}
		else
		{
			TraceError ("NAME_COLLISION: OLD: %s NEW: %s", it->second.pkInfo->filename, item.pkInfo->filename);
		}
	}
}

CEterFileDict::Item* CEterFileDict::GetItem (DWORD dwFileNameHash, const char* c_pszFileName)
{
	auto iter_pair = m_dict.equal_range (dwFileNameHash);
	auto iter = iter_pair.first;

	while (iter != iter_pair.second)
	{
		Item& item = iter->second;
		if (0 == strcmp (c_pszFileName, item.pkInfo->filename))
		{
			return &item;
		}
		++iter;
	}

	return NULL;
}
