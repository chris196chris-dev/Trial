#pragma once

char korean_tolower(const char c);

inline void inlineConvertPackFilename(char* name)
{
	if (!name)
		return;

	for (char* p = name; *p; ++p)
	{
		if (*p == '\\')
			*p = '/';
		else
			*p = korean_tolower(*p);
	}
}