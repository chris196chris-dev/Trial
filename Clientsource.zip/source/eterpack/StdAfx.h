#pragma once

#define WIN32_LEAN_AND_MEAN
#include <AttackDefines.h>

#include <windows.h>
#include <assert.h>
#include <io.h>
#include <mmsystem.h>
#include <iostream>
#include <fstream>
#include "../eterbase/StdAfx.h"

