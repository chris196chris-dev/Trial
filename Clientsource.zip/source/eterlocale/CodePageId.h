#pragma once

#define CP_1250				1250
#define CP_EASTEUROPE		CP_1250

#define CP_1251				1251
#define CP_CYRILLIC			CP_1251

#define CP_1252				1252
#define CP_LATIN			CP_1252

#define CP_1253				1253
#define CP_GREEK			CP_1253

#define CP_1254				1254
#define CP_TURKISH			CP_1254

#define CP_1256				1256
#define CP_ARABIC			CP_1256

#define CP_65001			65001

